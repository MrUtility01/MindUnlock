package com.mindunlock.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.mindunlock.app.data.repository.SyncRepository
import com.mindunlock.app.ui.theme.MindUnlockTheme

class MainActivity : ComponentActivity() {
    private lateinit var speech: PersianSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        speech = PersianSpeech(this)
        val app = application as MindUnlockApp
        val preferences = getSharedPreferences("mindunlock_preferences", MODE_PRIVATE)
        setContent {
            var theme by remember { mutableStateOf(preferences.getString("theme", "dark") ?: "dark") }
            var fontScale by remember { mutableStateOf(preferences.getFloat("font_scale", 1f)) }
            val density = LocalDensity.current
            var unlocked by rememberSaveable { mutableStateOf(false) }
            var lockPassword by rememberSaveable { mutableStateOf("") }
            var lockError by rememberSaveable { mutableStateOf("") }
            MindUnlockTheme(theme) {
                CompositionLocalProvider(
                    LocalLayoutDirection provides LayoutDirection.Rtl,
                    LocalDensity provides Density(density.density, density.fontScale * fontScale)
                ) {
                    if (!unlocked) {
                        Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
                            Text("MindUnlock · قفل برنامه", style = MaterialTheme.typography.headlineSmall)
                            Text(if (AppLock.isConfigured(preferences)) "برای ورود رمز برنامه را وارد کن." else "برای محافظت از اطلاعات، رمز اولیه برنامه را تعیین کن (حداقل ۸ نویسه).")
                            OutlinedTextField(lockPassword, { lockPassword = it; lockError = "" }, Modifier.fillMaxWidth(), label = { Text("رمز برنامه") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                            if (lockError.isNotBlank()) Text(lockError, color = MaterialTheme.colorScheme.error)
                            Button(onClick = {
                                try {
                                    if (AppLock.isConfigured(preferences)) {
                                        if (AppLock.verify(preferences, lockPassword.toCharArray())) { unlocked = true; lockPassword = "" }
                                        else lockError = "رمز برنامه صحیح نیست."
                                    } else {
                                        AppLock.setPassword(preferences, lockPassword.toCharArray()); unlocked = true; lockPassword = ""
                                    }
                                } catch (e: Exception) { lockError = e.message ?: "تنظیم رمز ناموفق بود." }
                            }, modifier = Modifier.fillMaxWidth(), enabled = lockPassword.length >= 8) { Text(if (AppLock.isConfigured(preferences)) "ورود به برنامه" else "فعال‌سازی قفل و ورود") }
                        }
                    } else {
                        MindUnlockRoot(
                            repository = app.repository, speech = speech, initialTheme = theme,
                            onThemeChange = { theme = it; preferences.edit().putString("theme", it).apply() },
                            onFontScaleChange = { fontScale = it; preferences.edit().putFloat("font_scale", it).apply() },
                            preferences = preferences, onLockApp = { unlocked = false }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        if (::speech.isInitialized) speech.close()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MindUnlockRoot(
    repository: SyncRepository,
    speech: PersianSpeech,
    initialTheme: String,
    onThemeChange: (String) -> Unit,
    onFontScaleChange: (Float) -> Unit,
    preferences: android.content.SharedPreferences,
    onLockApp: () -> Unit
) {
    var screen by rememberSaveable { mutableStateOf("home") }
    var previousScreen by rememberSaveable { mutableStateOf("home") }
    var selectedChapter by rememberSaveable { mutableStateOf("") }
    var selectedItem by rememberSaveable { mutableStateOf("") }
    val title = when (screen) {
        "chapter" -> "محتوای فصل"
        "reader" -> "مطالعه"
        "courses" -> "دوره‌ها و فصل‌ها"
        "flashcards" -> "فلش‌کارت و مرور فاصله‌دار"
        "notes" -> "دفتر یادداشت"
        "quiz" -> "آزمون و تمرین"
        "labs" -> "آزمایشگاه و پروژه‌ها"
        "planner" -> "برنامه‌ریز و یادآورها"
        "progress" -> "گزارش پیشرفت"
        "bookmarks" -> "نشانک‌ها"
        "settings" -> "تنظیمات"
        "sync" -> "اتصال و دریافت محتوا"
        "more" -> "ابزارهای یادگیری"
        else -> "MindUnlock"
    }
    fun back() {
        screen = when (screen) {
            "reader" -> previousScreen
            "chapter" -> "courses"
            "sync", "settings", "more", "quiz", "labs", "planner", "progress", "bookmarks" -> "home"
            else -> "home"
        }
    }
    BackHandler(enabled = screen != "home" && screen !in listOf("courses", "flashcards", "notes")) { back() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    if (screen !in listOf("home", "courses", "flashcards", "notes")) {
                        IconButton(onClick = { back() }) { Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت") }
                    }
                },
                actions = {
                    IconButton(onClick = { screen = "sync" }) { Icon(Icons.Default.CloudDownload, contentDescription = "دریافت از ویندوز") }
                    IconButton(onClick = onLockApp) { Icon(Icons.Default.Lock, contentDescription = "قفل برنامه") }
                    IconButton(onClick = { screen = "settings" }) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = screen == "home", onClick = { screen = "home" }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("خانه") })
                NavigationBarItem(selected = screen in listOf("courses", "chapter", "reader"), onClick = { screen = "courses" }, icon = { Icon(Icons.Default.Book, null) }, label = { Text("مطالعه") })
                NavigationBarItem(selected = screen == "flashcards", onClick = { screen = "flashcards" }, icon = { Icon(Icons.Default.FlashOn, null) }, label = { Text("مرور") })
                NavigationBarItem(selected = screen == "notes", onClick = { screen = "notes" }, icon = { Icon(Icons.Default.Notes, null) }, label = { Text("یادداشت") })
                NavigationBarItem(selected = screen == "more", onClick = { screen = "more" }, icon = { Icon(Icons.Default.MoreHoriz, null) }, label = { Text("بیشتر") })
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                "home" -> DashboardScreen(repository.database, onNavigate = { screen = it }, onContinue = { id -> selectedChapter = id; screen = "chapter" })
                "courses" -> ChapterListScreen(repository.database, onChapterClick = { id -> selectedChapter = id; screen = "chapter" })
                "chapter" -> ChapterContentScreen(repository.database, selectedChapter, onItemClick = { uid -> selectedItem = uid; previousScreen = "chapter"; screen = "reader" })
                "reader" -> ReaderScreen(repository.database, selectedItem, speech, preferences)
                "flashcards" -> FlashcardsScreen(repository.database, speech, preferences)
                "notes" -> NotesScreen(repository.database)
                "quiz" -> QuizScreen(repository.database)
                "labs" -> LabsScreen(repository.database, onOpenItem = { uid -> selectedItem = uid; previousScreen = "labs"; screen = "reader" })
                "planner" -> PlannerScreen(repository.database)
                "progress" -> ProgressScreen(repository.database)
                "bookmarks" -> BookmarksScreen(repository.database, onOpenItem = { uid -> selectedItem = uid; previousScreen = "bookmarks"; screen = "reader" })
                "settings" -> SettingsScreen(speech, preferences, initialTheme, onThemeChange, onFontScaleChange)
                "sync" -> SyncScreen(repository, onDone = { screen = "courses" })
                else -> MoreScreen(onNavigate = { screen = it })
            }
        }
    }
}

@Composable
private fun MoreScreen(onNavigate: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("ابزارهای آموزشی روی گوشی", style = MaterialTheme.typography.titleLarge)
        Text("همهٔ داده‌های این بخش‌ها روی همین گوشی ذخیره می‌شوند و پس از دانلود فصل‌ها بدون اینترنت در دسترس‌اند.", style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("آزمون و تمرین", "quiz", onNavigate, Modifier.weight(1f))
            ActionTile("آزمایشگاه و پروژه", "labs", onNavigate, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("برنامه‌ریز", "planner", onNavigate, Modifier.weight(1f))
            ActionTile("گزارش پیشرفت", "progress", onNavigate, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("نشانک‌ها", "bookmarks", onNavigate, Modifier.weight(1f))
            ActionTile("تنظیمات", "settings", onNavigate, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("اتصال به ویندوز", "sync", onNavigate, Modifier.weight(1f))
            ActionTile("دوره‌ها", "courses", onNavigate, Modifier.weight(1f))
        }
    }
}
