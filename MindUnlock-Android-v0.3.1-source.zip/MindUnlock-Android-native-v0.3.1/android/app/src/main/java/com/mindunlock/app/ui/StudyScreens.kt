package com.mindunlock.app

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.Html
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import com.google.gson.JsonParser
import com.mindunlock.app.PersianSpeech
import com.mindunlock.app.StudyReminderReceiver
import com.mindunlock.app.data.local.AppDatabase
import com.mindunlock.app.data.local.BookmarkEntity
import com.mindunlock.app.data.local.ContentItemEntity
import com.mindunlock.app.data.local.NoteEntity
import com.mindunlock.app.data.local.ProgressEntity
import com.mindunlock.app.data.local.StudyTaskEntity
import com.mindunlock.app.data.repository.ManifestChapter
import com.mindunlock.app.data.repository.SyncRepository
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ActionTile(label: String, destination: String, onNavigate: (String) -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = { onNavigate(destination) },
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Text("باز کردن", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun DashboardScreen(
    db: AppDatabase,
    onNavigate: (String) -> Unit,
    onContinue: (String) -> Unit
) {
    val chapters by db.chapterDao().observeAll().collectAsState(initial = emptyList())
    val items by db.contentItemDao().observeAll().collectAsState(initial = emptyList())
    val progress by db.progressDao().observeAll().collectAsState(initial = emptyList())
    val notes by db.noteDao().observeAll().collectAsState(initial = emptyList())
    val completed = progress.count { it.completed }
    val dueCards = items.filter { it.type.equals("flashcard", true) }.count { item ->
        val p = progress.firstOrNull { it.itemUid == item.uid }
        p?.dueAt == null || p.dueAt <= System.currentTimeMillis()
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("محیط یادگیری شخصی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("موضوع‌ها و فصل‌ها از نسخهٔ ویندوز دریافت می‌شوند؛ مطالعه و پیگیری یادگیری روی همین گوشی و به‌صورت آفلاین ادامه پیدا می‌کند.")
                Button(onClick = { onNavigate("sync") }) { Icon(Icons.Default.Download, null); Spacer(Modifier.size(6.dp)); Text("اتصال به ویندوز و دریافت فصل‌ها") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("فصل‌های دریافت‌شده", chapters.size.toString(), Modifier.weight(1f))
            MetricCard("مطالب ذخیره‌شده", items.size.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("مطالب تکمیل‌شده", completed.toString(), Modifier.weight(1f))
            MetricCard("فلش‌کارت سررسید", dueCards.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("مطالعهٔ دوره‌ها", "courses", onNavigate, Modifier.weight(1f))
            ActionTile("مرور فلش‌کارت‌ها", "flashcards", onNavigate, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("آزمون و تمرین", "quiz", onNavigate, Modifier.weight(1f))
            ActionTile("آزمایشگاه و پروژه", "labs", onNavigate, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionTile("دفتر یادداشت (${notes.size})", "notes", onNavigate, Modifier.weight(1f))
            ActionTile("برنامه‌ریز", "planner", onNavigate, Modifier.weight(1f))
        }
        Text("ادامهٔ آخرین فصل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        val last = chapters.firstOrNull()
        if (last != null) {
            Card(onClick = { onContinue(last.id) }) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text(last.title, fontWeight = FontWeight.SemiBold)
                    Text(last.groupName ?: "", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            EmptyMessage("هنوز محتوایی روی گوشی دریافت نشده است. از دکمهٔ اتصال به ویندوز استفاده کن.")
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun ChapterListScreen(db: AppDatabase, onChapterClick: (String) -> Unit) {
    val chapters by db.chapterDao().observeAll().collectAsState(initial = emptyList())
    val items by db.contentItemDao().observeAll().collectAsState(initial = emptyList())
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = chapters.filter { query.isBlank() || it.title.contains(query, true) || it.groupName.orEmpty().contains(query, true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("جست‌وجوی دوره یا فصل") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Text("${chapters.size} فصل دریافت‌شده · ${items.size} محتوای آموزشی", style = MaterialTheme.typography.bodySmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
            items(filtered, key = { it.id }) { chapter ->
                Card(onClick = { onChapterClick(chapter.id) }) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(chapter.title, fontWeight = FontWeight.SemiBold)
                        if (!chapter.groupName.isNullOrBlank()) Text(chapter.groupName, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                        if (!chapter.description.isNullOrBlank()) Text(chapter.description, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        Text("${chapter.itemCount} مطلب", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterContentScreen(db: AppDatabase, chapterId: String, onItemClick: (String) -> Unit) {
    val chapter = db.chapterDao().observeAll().collectAsState(initial = emptyList()).value.firstOrNull { it.id == chapterId }
    val items by db.contentItemDao().observeForChapter(chapterId).collectAsState(initial = emptyList())
    var query by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf("همه") }
    val kindOptions = listOf("همه", "درس", "سؤال", "فلش‌کارت", "آزمایشگاه", "دستور", "مثال", "یادداشت")
    val visible = items.filter { item ->
        val kindOk = kind == "همه" || kindLabel(item.type) == kind
        val textOk = query.isBlank() || item.title.orEmpty().contains(query, true) || item.summary.orEmpty().contains(query, true) || item.content.orEmpty().contains(query, true)
        kindOk && textOk
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(chapter?.title ?: "فصل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (!chapter?.description.isNullOrBlank()) Text(chapter?.description.orEmpty(), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("جست‌وجو در مطالب") }, singleLine = true)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            kindOptions.forEach { option -> FilterChip(selected = kind == option, onClick = { kind = option }, label = { Text(option) }) }
        }
        Text("${visible.size} مورد", style = MaterialTheme.typography.labelSmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(visible, key = { it.uid }) { item -> ContentItemCard(item, onClick = { onItemClick(item.uid) }) }
        }
    }
}

@Composable
private fun ContentItemCard(item: ContentItemEntity, onClick: () -> Unit) {
    Card(onClick = onClick) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(kindLabel(item.type), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                if (item.sourceStatus != "verified") Text("غیرقابل مطالعه", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
            }
            Text(item.title ?: "بدون عنوان", fontWeight = FontWeight.SemiBold)
            if (!item.summary.isNullOrBlank()) Text(item.summary, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ReaderScreen(db: AppDatabase, itemUid: String, speech: PersianSpeech, preferences: android.content.SharedPreferences) {
    val item by db.contentItemDao().observe(itemUid).collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val bookmarks by db.bookmarkDao().observeAll().collectAsState(initial = emptyList())
    var selectedOption by remember(itemUid) { mutableIntStateOf(-1) }
    var answerMessage by remember(itemUid) { mutableStateOf("") }
    var answerVisible by remember(itemUid) { mutableStateOf(false) }
    var noteDialog by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    if (item == null) {
        EmptyMessage("این محتوا در حافظهٔ محلی پیدا نشد.")
        return
    }
    val current = item!!
    val metadata = runCatching { JsonParser.parseString(current.metadataJson ?: "{}").asJsonObject }.getOrNull()
    val options = readStringArray(current.optionsJson ?: metadata?.get("options")?.toString())
    val correctIndex = metadata?.get("correct_index")?.let { runCatching { it.asInt }.getOrNull() }
    val marked = bookmarks.any { it.itemUid == current.uid }
    val bodyText = listOfNotNull(current.summary, current.content).filter { it.isNotBlank() }.joinToString("\n\n")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(kindLabel(current.type), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Text(current.title ?: "بدون عنوان", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (!current.summary.isNullOrBlank()) Text(cleanHtml(current.summary), style = MaterialTheme.typography.titleSmall)
        if (!current.content.isNullOrBlank()) Text(cleanHtml(current.content), style = MaterialTheme.typography.bodyLarge)
        when (current.type?.lowercase(Locale.ROOT)) {
            "question" -> {
                if (options.isNotEmpty()) {
                    Text("گزینه‌ها", fontWeight = FontWeight.Bold)
                    options.forEachIndexed { index, option ->
                        Row(Modifier.fillMaxWidth().clickable { selectedOption = index }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedOption == index, onClick = { selectedOption = index })
                            Text(option)
                        }
                    }
                    Button(onClick = {
                        if (selectedOption < 0) answerMessage = "ابتدا یک گزینه را انتخاب کن."
                        else if (correctIndex == null) answerMessage = "کلید پاسخ برای این سؤال در بانک ذخیره نشده است."
                        else {
                            val correct = selectedOption == correctIndex
                            answerMessage = if (correct) "پاسخ درست است." else "پاسخ صحیح: گزینهٔ ${correctIndex + 1}"
                            scope.launch {
                                val old = db.progressDao().get(current.uid) ?: ProgressEntity(current.uid, current.chapterId)
                                db.progressDao().upsert(old.copy(attempts = old.attempts + 1, correct = old.correct + if (correct) 1 else 0, wrong = old.wrong + if (correct) 0 else 1, lastResult = if (correct) "correct" else "wrong", updatedAt = System.currentTimeMillis()))
                            }
                        }
                    }) { Text("بررسی پاسخ") }
                    if (answerMessage.isNotBlank()) Text(answerMessage, color = MaterialTheme.colorScheme.primary)
                    if (answerVisible || answerMessage.isNotBlank()) metadata?.get("explanation")?.let { Text("توضیح: ${it.asString}") }
                } else Text("گزینه‌ای برای این سؤال ثبت نشده است.")
            }
            "flashcard" -> {
                val back = metadata?.get("back")?.let { runCatching { it.asString }.getOrNull() }.orEmpty().ifBlank { current.summary ?: current.content.orEmpty() }
                OutlinedButton(onClick = { answerVisible = !answerVisible }) { Text(if (answerVisible) "پنهان‌کردن پاسخ" else "نمایش پاسخ") }
                if (answerVisible) Text(cleanHtml(back), style = MaterialTheme.typography.bodyLarge)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = {
                val text = "${current.title}. $bodyText"
                speech.speak(cleanHtml(text), preferences.getFloat("speech_rate", 1f), preferences.getString("speech_voice", null))
            }, enabled = speech.ready.value) { Icon(Icons.Default.PlayArrow, null); Text("خواندن فارسی") }
            OutlinedButton(onClick = { speech.stop() }) { Icon(Icons.Default.Stop, null); Text("توقف صدا") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                scope.launch {
                    if (marked) db.bookmarkDao().delete(current.uid)
                    else db.bookmarkDao().upsert(BookmarkEntity(current.uid, current.chapterId))
                }
            }) { Icon(Icons.Default.Bookmark, null); Text(if (marked) "حذف نشانک" else "نشانک") }
            OutlinedButton(onClick = { noteDialog = true }) { Text("یادداشت مرتبط") }
        }
        Button(onClick = {
            scope.launch {
                val old = db.progressDao().get(current.uid) ?: ProgressEntity(current.uid, current.chapterId)
                db.progressDao().upsert(old.copy(completed = true, completedAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
            }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Check, null); Text("خواندم؛ ثبت در پیشرفت") }
        if (current.sourceStatus != "verified") Text("این محتوا تأییدشده نیست و برای مطالعه در اپ اندروید قابل استفاده نیست.", color = MaterialTheme.colorScheme.error)
    }
    if (noteDialog) {
        AlertDialog(onDismissRequest = { noteDialog = false }, title = { Text("یادداشت برای این مطلب") },
            text = { OutlinedTextField(noteText, { noteText = it }, label = { Text("متن یادداشت") }, minLines = 3) },
            confirmButton = { TextButton(onClick = {
                if (noteText.isNotBlank()) scope.launch { db.noteDao().upsert(NoteEntity(itemUid = current.uid, chapterId = current.chapterId, title = current.title ?: "یادداشت", body = noteText.trim())) }
                noteText = ""; noteDialog = false
            }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = { noteDialog = false }) { Text("انصراف") } })
    }
}

@Composable
fun FlashcardsScreen(db: AppDatabase, speech: PersianSpeech, preferences: android.content.SharedPreferences) {
    val all by db.contentItemDao().observeByTypes(listOf("flashcard")).collectAsState(initial = emptyList())
    val progress by db.progressDao().observeAll().collectAsState(initial = emptyList())
    val cards = all.filter { it.sourceStatus == "verified" }
    var index by rememberSaveable { mutableIntStateOf(0) }
    var flipped by rememberSaveable { mutableStateOf(false) }
    val current = cards.getOrNull(index.coerceIn(0, maxOf(0, cards.lastIndex)))
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("کارت‌های تأییدشده: ${cards.size}", style = MaterialTheme.typography.bodySmall)
        if (current == null) EmptyMessage("هنوز فلش‌کارت آفلاین دریافت نشده است.") else {
            Text("کارت ${index + 1} از ${cards.size}", color = MaterialTheme.colorScheme.primary)
            Card(Modifier.fillMaxWidth().clickable { flipped = !flipped }) {
                Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(if (flipped) "پاسخ" else "رو", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    val meta = runCatching { JsonParser.parseString(current.metadataJson ?: "{}").asJsonObject }.getOrNull()
                    val back = meta?.get("back")?.let { runCatching { it.asString }.getOrNull() }.orEmpty().ifBlank { current.summary ?: current.content.orEmpty() }
                    Text(cleanHtml(if (flipped) back else current.title ?: current.summary ?: ""), style = MaterialTheme.typography.titleLarge)
                    Text("برای نمایش ${if (flipped) "روی کارت" else "پاسخ"} لمس کن.", style = MaterialTheme.typography.bodySmall)
                }
            }
            val old = progress.firstOrNull { it.itemUid == current.uid }
            Text("تعداد مرور: ${old?.attempts ?: 0} · پاسخ درست: ${old?.correct ?: 0}", style = MaterialTheme.typography.labelSmall)
            OutlinedButton(onClick = { speech.speak(cleanHtml(current.title.orEmpty() + ". " + current.content.orEmpty()), preferences.getFloat("speech_rate", 1f), preferences.getString("speech_voice", null)) }, enabled = speech.ready.value) { Text("خواندن کارت") }
            if (flipped) {
                Text("کیفیت یادآوری را انتخاب کن تا موعد مرور بعدی تعیین شود.")
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("دوباره" to 0, "سخت" to 3, "خوب" to 4, "آسان" to 5).forEach { (label, quality) ->
                        FilledTonalButton(onClick = {
                            scope.launch {
                                val prev = db.progressDao().get(current.uid) ?: ProgressEntity(current.uid, current.chapterId)
                                val nextInterval = when {
                                    quality < 3 -> 1
                                    prev.intervalDays == 0 -> 1
                                    prev.intervalDays == 1 -> 3
                                    else -> (prev.intervalDays * if (quality == 5) 3.0 else 2.2).roundToInt().coerceAtMost(180)
                                }
                                db.progressDao().upsert(prev.copy(attempts = prev.attempts + 1, quality = quality, intervalDays = nextInterval, dueAt = System.currentTimeMillis() + nextInterval * 86_400_000L, lastResult = "reviewed", updatedAt = System.currentTimeMillis()))
                                index = (index + 1).coerceAtMost(maxOf(0, cards.lastIndex)); flipped = false
                            }
                        }) { Text(label) }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { index = (index - 1).coerceAtLeast(0); flipped = false }, enabled = index > 0) { Text("قبلی") }
                OutlinedButton(onClick = { index = (index + 1).coerceAtMost(cards.lastIndex); flipped = false }, enabled = index < cards.lastIndex) { Text("بعدی") }
            }
            val due = cards.count { card -> progress.firstOrNull { it.itemUid == card.uid }?.dueAt?.let { it <= System.currentTimeMillis() } ?: true }
            Text("سررسید امروز: $due کارت", style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun QuizScreen(db: AppDatabase) {
    val questions by db.contentItemDao().observeByTypes(listOf("question")).collectAsState(initial = emptyList())
    val valid = questions.filter { it.sourceStatus == "verified" }
    val scope = rememberCoroutineScope()
    var index by rememberSaveable { mutableIntStateOf(0) }
    var answer by rememberSaveable { mutableIntStateOf(-1) }
    var checked by rememberSaveable { mutableStateOf(false) }
    val item = valid.getOrNull(index)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("بانک سؤال‌های تأییدشده: ${valid.size}", style = MaterialTheme.typography.bodySmall)
        if (item == null) EmptyMessage("سؤال قابل آزمونی در محتوای دریافت‌شده وجود ندارد.") else {
            Text("سؤال ${index + 1} از ${valid.size}", color = MaterialTheme.colorScheme.primary)
            Text(item.title.orEmpty(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(cleanHtml(item.content.orEmpty()))
            val meta = runCatching { JsonParser.parseString(item.metadataJson ?: "{}").asJsonObject }.getOrNull()
            val options = readStringArray(item.optionsJson ?: meta?.get("options")?.toString())
            options.forEachIndexed { i, option ->
                Row(Modifier.fillMaxWidth().clickable(enabled = !checked) { answer = i }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = answer == i, onClick = { answer = i }, enabled = !checked)
                    Text(option)
                }
            }
            if (checked) {
                val correct = meta?.get("correct_index")?.let { runCatching { it.asInt }.getOrNull() }
                Text(if (correct != null && answer == correct) "درست" else "پاسخ صحیح: ${correct?.plus(1) ?: "ثبت نشده"}", color = MaterialTheme.colorScheme.primary)
                meta?.get("explanation")?.let { Text("توضیح: ${it.asString}") }
            }
            Button(enabled = answer >= 0 && !checked, onClick = {
                val correct = meta?.get("correct_index")?.let { runCatching { it.asInt }.getOrNull() }
                checked = true
                scope.launch {
                    val old = db.progressDao().get(item.uid) ?: ProgressEntity(item.uid, item.chapterId)
                    db.progressDao().upsert(old.copy(attempts = old.attempts + 1, correct = old.correct + if (correct == answer) 1 else 0, wrong = old.wrong + if (correct == answer) 0 else 1, lastResult = if (correct == answer) "correct" else "wrong", updatedAt = System.currentTimeMillis()))
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("ثبت و بررسی پاسخ") }
            OutlinedButton(onClick = { index = (index + 1).coerceAtMost(valid.lastIndex); answer = -1; checked = false }, modifier = Modifier.fillMaxWidth(), enabled = index < valid.lastIndex) { Text("سؤال بعدی") }
            TextButton(onClick = { index = 0; answer = -1; checked = false }) { Text("شروع دوباره") }
        }
    }
}

@Composable
fun NotesScreen(db: AppDatabase) {
    val notes by db.noteDao().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showDialog by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("یادداشت‌های ذخیره‌شده فقط روی گوشی", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { title = ""; body = ""; showDialog = true }) { Icon(Icons.Default.Add, null); Text("یادداشت جدید") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(notes, key = { it.id }) { note ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(note.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { scope.launch { db.noteDao().delete(note.id) } }) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
                        }
                        Text(note.body)
                        if (!note.chapterId.isNullOrBlank()) Text("شناسه فصل: ${note.chapterId}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
    if (showDialog) AlertDialog(onDismissRequest = { showDialog = false }, title = { Text("یادداشت جدید") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("عنوان") }, singleLine = true)
            OutlinedTextField(body, { body = it }, label = { Text("متن") }, minLines = 4)
        } },
        confirmButton = { TextButton(onClick = {
            if (body.isNotBlank()) scope.launch { db.noteDao().upsert(NoteEntity(title = title.ifBlank { "یادداشت" }, body = body.trim())) }
            showDialog = false
        }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = { showDialog = false }) { Text("انصراف") } })
}

@Composable
fun LabsScreen(db: AppDatabase, onOpenItem: (String) -> Unit) {
    val content by db.contentItemDao().observeByTypes(listOf("lab", "command", "example")).collectAsState(initial = emptyList())
    val tasks by db.studyTaskDao().observeAll().collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("تمرین‌های عملی، دستورها و مثال‌های دوره", style = MaterialTheme.typography.bodySmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            if (content.isEmpty() && tasks.none { it.taskType == "project" }) item { EmptyMessage("مورد عملی یا پروژه‌ای در دادهٔ دریافت‌شده وجود ندارد.") }
            items(content.filter { it.sourceStatus == "verified" }, key = { it.uid }) { ContentItemCard(it) { onOpenItem(it.uid) } }
            items(tasks.filter { it.taskType == "project" }, key = { "project-${it.id}" }) { task ->
                Card { Column(Modifier.fillMaxWidth().padding(13.dp)) { Text(task.title, fontWeight = FontWeight.SemiBold); Text(task.details) } }
            }
        }
    }
}

@Composable
fun PlannerScreen(db: AppDatabase) {
    val tasks by db.studyTaskDao().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var title by rememberSaveable { mutableStateOf("") }
    var details by rememberSaveable { mutableStateOf("") }
    var whenText by rememberSaveable { mutableStateOf(LocalDateTime.now().plusHours(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))) }
    var type by rememberSaveable { mutableStateOf("task") }
    var reminder by rememberSaveable { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("برنامهٔ روزانه، تکلیف و پروژهٔ شخصی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("عنوان") }, singleLine = true)
        OutlinedTextField(details, { details = it }, Modifier.fillMaxWidth(), label = { Text("توضیحات") }, minLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = type == "task", onClick = { type = "task" }, label = { Text("کار مطالعاتی") })
            FilterChip(selected = type == "project", onClick = { type = "project" }, label = { Text("پروژه") })
        }
        OutlinedTextField(whenText, { whenText = it }, Modifier.fillMaxWidth(), label = { Text("تاریخ و ساعت: yyyy-MM-dd HH:mm") }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(checked = reminder, onCheckedChange = { reminder = it }); Text("یادآور اعلان‌دار") }
        Button(enabled = title.isNotBlank(), onClick = {
            val date = runCatching { LocalDateTime.parse(whenText, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) }.getOrNull()
            val due = date?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
            scope.launch {
                val id = db.studyTaskDao().upsert(StudyTaskEntity(title = title.trim(), details = details.trim(), taskType = type, dueAt = due, remindAt = if (reminder) due else null))
                if (reminder && due != null) scheduleReminder(context, id, title.trim(), due)
                title = ""; details = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("افزودن به برنامه") }
        HorizontalDivider()
        Text("برنامه‌های ثبت‌شده (${tasks.size})", style = MaterialTheme.typography.titleMedium)
        tasks.forEach { task ->
            Card {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(task.title, fontWeight = FontWeight.SemiBold)
                        Text(if (task.taskType == "project") "پروژه" else "کار مطالعاتی", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                        if (task.dueAt != null) Text(java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(java.util.Date(task.dueAt)), style = MaterialTheme.typography.bodySmall)
                        if (task.details.isNotBlank()) Text(task.details, style = MaterialTheme.typography.bodySmall)
                    }
                    Checkbox(task.completed, onCheckedChange = { checked -> scope.launch { db.studyTaskDao().upsert(task.copy(completed = checked)) } })
                    IconButton(onClick = { scope.launch { db.studyTaskDao().delete(task.id) } }) { Icon(Icons.Default.Delete, null) }
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(db: AppDatabase) {
    val items by db.contentItemDao().observeAll().collectAsState(initial = emptyList())
    val progress by db.progressDao().observeAll().collectAsState(initial = emptyList())
    val tasks by db.studyTaskDao().observeAll().collectAsState(initial = emptyList())
    val completed = progress.count { it.completed }
    val total = items.size
    val ratio = if (total == 0) 0f else completed.toFloat() / total
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("گزارش پیشرفت محلی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("$completed از $total مطلب تکمیل شده")
        LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth())
        MetricCard("تلاش‌های آزمون و تمرین", progress.sumOf { it.attempts }.toString(), Modifier.fillMaxWidth())
        MetricCard("پاسخ‌های درست", progress.sumOf { it.correct }.toString(), Modifier.fillMaxWidth())
        MetricCard("یادداشت‌ها و مرورهای ثبت‌شده", "${progress.count { it.intervalDays > 0 }} مرور زمان‌بندی‌شده", Modifier.fillMaxWidth())
        MetricCard("کارهای باز", tasks.count { !it.completed }.toString(), Modifier.fillMaxWidth())
        Text("این آمار فقط روی همین گوشی ذخیره می‌شود و با ویندوز ادغام نشده است.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun BookmarksScreen(db: AppDatabase, onOpenItem: (String) -> Unit) {
    val bookmarks by db.bookmarkDao().observeAll().collectAsState(initial = emptyList())
    val all by db.contentItemDao().observeAll().collectAsState(initial = emptyList())
    val saved = bookmarks.mapNotNull { mark -> all.firstOrNull { it.uid == mark.itemUid } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (saved.isEmpty()) item { EmptyMessage("هنوز نشانکی ذخیره نشده است.") }
        items(saved, key = { it.uid }) { ContentItemCard(it) { onOpenItem(it.uid) } }
    }
}

@Composable
fun SettingsScreen(
    speech: PersianSpeech,
    preferences: android.content.SharedPreferences,
    theme: String,
    onThemeChange: (String) -> Unit,
    onFontScaleChange: (Float) -> Unit
) {
    var speed by remember { mutableStateOf(preferences.getFloat("speech_rate", 1f)) }
    var voiceName by remember { mutableStateOf(preferences.getString("speech_voice", null)) }
    var fontScale by remember { mutableStateOf(preferences.getFloat("font_scale", 1f)) }
    var expanded by remember { mutableStateOf(false) }
    var newAppPassword by remember { mutableStateOf("") }
    var passwordMessage by remember { mutableStateOf("") }
    val context = LocalContext.current
    val voices = speech.voices.value
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ظاهر برنامه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        listOf("dark" to "تیره", "light" to "روشن", "sepia" to "مطالعهٔ سپیا").forEach { (value, label) ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onThemeChange(value) }) {
                RadioButton(selected = theme == value, onClick = { onThemeChange(value) })
                Text(label)
            }
        }
        Text("اندازهٔ نوشته: ${(fontScale * 100).roundToInt()}٪")
        Slider(value = fontScale, onValueChange = { fontScale = it; onFontScaleChange(it) }, valueRange = 0.85f..1.35f)
        HorizontalDivider()
        Text("خواندن با صدای فارسی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(speech.status.value, style = MaterialTheme.typography.bodySmall)
        speech.error.value?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        Text("سرعت خواندن: ${String.format(Locale.US, "%.2f", speed)}×")
        Slider(value = speed, onValueChange = { speed = it; preferences.edit().putFloat("speech_rate", it).apply() }, valueRange = 0.65f..1.6f)
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(voices.firstOrNull { it.name == voiceName }?.name ?: "انتخاب صدای فارسی") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            voices.forEach { voice -> DropdownMenuItem(text = { Text(voice.name) }, onClick = { voiceName = voice.name; preferences.edit().putString("speech_voice", voice.name).apply(); expanded = false }) }
        }
        if (voices.isEmpty()) Text("اگر صدای فارسی در فهرست نیست، در تنظیمات گوشی به Text-to-speech برو و دادهٔ زبان فارسی را نصب کن. برای کار آفلاین، موتور باید بستهٔ صوتی محلی داشته باشد.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { speech.speak("سلام. این یک آزمایش واقعی خواندن فارسی در برنامه مایندآنلاک است. اگر صدا شنیده نمی‌شود، موتور گفتار و خروجی صدای گوشی را بررسی کن.", speed, voiceName) }, enabled = speech.ready.value) { Text("آزمایش واقعی صدا") }
            OutlinedButton(onClick = { speech.stop() }) { Text("توقف") }
        }
        OutlinedButton(onClick = { runCatching { context.startActivity(Intent("android.speech.tts.engine.INSTALL_TTS_DATA").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, modifier = Modifier.fillMaxWidth()) { Text("مدیریت / نصب داده‌های گفتار گوشی") }
        HorizontalDivider()
        Text("امنیت برنامه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("قفل برنامه با رمز محلی فعال است. رمز به‌صورت هش‌شده ذخیره می‌شود و متن خام آن نگهداری نمی‌شود.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(newAppPassword, { newAppPassword = it; passwordMessage = "" }, Modifier.fillMaxWidth(), label = { Text("رمز جدید برنامه (حداقل ۸ نویسه)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Button(enabled = newAppPassword.length >= 8, onClick = {
            runCatching { com.mindunlock.app.AppLock.setPassword(preferences, newAppPassword.toCharArray()) }
                .onSuccess { newAppPassword = ""; passwordMessage = "رمز برنامه تغییر کرد؛ در ورود بعدی از رمز جدید استفاده کن." }
                .onFailure { passwordMessage = it.message ?: "تغییر رمز ناموفق بود." }
        }) { Text("ذخیره رمز جدید") }
        if (passwordMessage.isNotBlank()) Text(passwordMessage, color = MaterialTheme.colorScheme.primary)
        HorizontalDivider()
        Text("حریم داده و همگام‌سازی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("مطالب، پیشرفت، یادداشت‌ها، نشانک‌ها و برنامه‌ها در پایگاه‌دادهٔ خصوصی همین گوشی ذخیره می‌شوند. این نسخه فقط محتوا را از سرور ویندوز دریافت می‌کند؛ ارسال پیشرفت و یادداشت به ویندوز هنوز در قرارداد همگام‌سازی تعریف نشده است.", style = MaterialTheme.typography.bodySmall)
        Text("اتصال HTTP فقط برای شبکهٔ محلی مورداعتماد است. پورت برنامهٔ ویندوز را به اینترنت عمومی فوروارد نکن.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun SyncScreen(repository: SyncRepository, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var host by remember { mutableStateOf(repository.savedHost()) }
    var port by remember { mutableStateOf(repository.savedPort().toString()) }
    var username by rememberSaveable { mutableStateOf("admin") }
    var password by rememberSaveable { mutableStateOf("") }
    var manifest by remember { mutableStateOf<List<ManifestChapter>>(emptyList()) }
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("آدرس IP رایانه‌ای را وارد کن که برنامهٔ ویندوز روی آن اجراست.") }
    var progress by remember { mutableStateOf(0f) }
    var progressText by remember { mutableStateOf("") }
    var diagnostic by remember { mutableStateOf<com.mindunlock.app.data.repository.ConnectionDiagnostics?>(null) }
    var diagnosticBusy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("اتصال به سرور ویندوز", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(host, { host = it }, Modifier.fillMaxWidth(), label = { Text("IP یا نام میزبان ویندوز") }, singleLine = true, placeholder = { Text("مثلاً 192.168.1.10") })
        OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, Modifier.fillMaxWidth(), label = { Text("پورت") }, singleLine = true)
        OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), label = { Text("نام کاربری ویندوز") }, singleLine = true)
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("رمز برنامهٔ ویندوز") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        Text("گوشی و رایانه باید در یک شبکهٔ محلی باشند. پورت پیش‌فرض ۸۲ است.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(
            enabled = !busy && !diagnosticBusy && host.isNotBlank() && ((port.toIntOrNull() ?: 0) in 1..65535),
            onClick = {
                diagnosticBusy = true; diagnostic = null
                scope.launch {
                    diagnostic = repository.diagnoseConnection(host, port.toIntOrNull() ?: 82, username, password)
                    diagnosticBusy = false
                }
            }, modifier = Modifier.fillMaxWidth()
        ) { if (diagnosticBusy) CircularProgressIndicator(Modifier.size(18.dp)) else Text("عیب‌یابی مرحله‌ای اتصال") }
        diagnostic?.let { d ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("گزارش عیب‌یابی", fontWeight = FontWeight.Bold)
                    Text("۱. دسترسی IP و پورت (TCP): ${if (d.tcpReachable) "موفق" else "ناموفق"}")
                    Text("۲. پاسخ سرویس HTTP: ${if (d.httpReachable) "موفق" else "ناموفق"}")
                    Text("۳. احراز هویت: ${if (d.authenticated) "موفق" else "ناموفق / انجام‌نشده"}")
                    Text("۴. دریافت فهرست محتوا: ${if (d.manifestAvailable) "موفق" else "ناموفق / انجام‌نشده"}")
                    Text(d.message, color = if (d.manifestAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
            }
        }
        Button(enabled = !busy && host.isNotBlank() && ((port.toIntOrNull() ?: 0) in 1..65535), onClick = {
            busy = true; message = "در حال اتصال و دریافت فهرست فصل‌ها…"; manifest = emptyList(); selected.clear()
            scope.launch {
                runCatching { repository.fetchManifest(host, port.toIntOrNull() ?: 82, username, password) }
                    .onSuccess { data -> manifest = data; selected.addAll(data.map { it.id }); message = "${data.size} فصل پیدا شد؛ فصل‌های موردنیاز را تیک بزن و دانلود کن." }
                    .onFailure { message = it.message ?: "اتصال ناموفق بود." }
                busy = false
            }
        }, modifier = Modifier.fillMaxWidth()) { if (busy) CircularProgressIndicator(Modifier.size(18.dp)) else Text("بررسی اتصال و نمایش محتوا") }
        Text(message, style = MaterialTheme.typography.bodyMedium, color = if (message.contains("ناموفق") || message.contains("لازم") || message.contains("رمز")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        if (manifest.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("انتخاب فصل‌ها (${selected.size}/${manifest.size})", fontWeight = FontWeight.Bold)
                TextButton(onClick = { if (selected.size == manifest.size) selected.clear() else { selected.clear(); selected.addAll(manifest.map { it.id }) } }) { Text(if (selected.size == manifest.size) "لغو همه" else "انتخاب همه") }
            }
            manifest.forEach { ch ->
                Card {
                    Row(Modifier.fillMaxWidth().clickable {
                        if (selected.contains(ch.id)) selected.remove(ch.id) else selected.add(ch.id)
                    }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = selected.contains(ch.id), onCheckedChange = { checked -> if (checked) selected.add(ch.id) else selected.remove(ch.id) })
                        Column(Modifier.weight(1f)) {
                            Text(ch.title, fontWeight = FontWeight.SemiBold)
                            Text("${ch.groupName ?: "بدون گروه"} · ${ch.itemCount} مطلب", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Button(enabled = !busy && selected.isNotEmpty(), onClick = {
                busy = true; progress = 0f; progressText = "شروع دانلود…"
                val chosen = manifest.filter { selected.contains(it.id) }
                scope.launch {
                    val result = runCatching {
                        repository.syncSelected(host, port.toIntOrNull() ?: 82, chosen) { current, total, title ->
                            progress = if (total == 0) 1f else current.toFloat() / total
                            progressText = "$current از $total · $title"
                        }
                    }
                    result.onSuccess { r ->
                        message = "دانلود شد: ${r.downloaded} فصل · بدون تغییر: ${r.skipped} فصل · خطا: ${r.failures.size}"
                        if (r.failures.isNotEmpty()) progressText = r.failures.joinToString("\n")
                        password = ""
                    }.onFailure { message = it.message ?: "دانلود ناموفق بود." }
                    busy = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("دانلود فصل‌های انتخاب‌شده") }
            if (busy || progress > 0f) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text(progressText, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("رفتن به کتابخانهٔ آفلاین") }
        }
    }
}

@Composable
private fun EmptyMessage(text: String) {
    Box(Modifier.fillMaxWidth().padding(18.dp), contentAlignment = Alignment.Center) { Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) }
}

private fun kindLabel(kind: String?): String = when (kind?.lowercase(Locale.ROOT)) {
    "lesson" -> "درس"
    "question" -> "سؤال"
    "flashcard" -> "فلش‌کارت"
    "command" -> "دستور"
    "lab" -> "آزمایشگاه"
    "example" -> "مثال"
    "note" -> "یادداشت"
    "asset" -> "رسانه"
    else -> kind ?: "مطلب"
}

private fun cleanHtml(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_COMPACT).toString().trim()

private fun readStringArray(value: String?): List<String> = runCatching {
    val json = JsonParser.parseString(value ?: "[]").asJsonArray
    json.mapNotNull { if (it.isJsonNull) null else runCatching { it.asString }.getOrNull() }
}.getOrDefault(emptyList())

private fun scheduleReminder(context: Context, id: Long, title: String, remindAt: Long) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, StudyReminderReceiver::class.java).putExtra("title", title).putExtra("task_id", id)
    val pending = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, maxOf(remindAt, System.currentTimeMillis() + 5_000L), pending)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
        context is Activity) {
        ActivityCompat.requestPermissions(context, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 902)
    }
}
