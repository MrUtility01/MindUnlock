package com.mindunlock.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.mutableStateOf
import java.util.Locale

class PersianSpeech(context: Context) : TextToSpeech.OnInitListener {
    private val engine = TextToSpeech(context.applicationContext, this)
    val ready = mutableStateOf(false)
    val error = mutableStateOf<String?>(null)
    val status = mutableStateOf("در انتظار راه‌اندازی موتور گفتار…")
    val voices = mutableStateOf<List<Voice>>(emptyList())

    override fun onInit(result: Int) {
        if (result != TextToSpeech.SUCCESS) {
            error.value = "موتور گفتار اندروید راه‌اندازی نشد (کد $result)."
            status.value = error.value!!
            return
        }
        val languageResult = engine.setLanguage(Locale.forLanguageTag("fa-IR"))
        voices.value = engine.voices?.filter { it.locale.language == "fa" }.orEmpty()
        ready.value = true
        error.value = when (languageResult) {
            TextToSpeech.LANG_MISSING_DATA -> "دادهٔ زبان فارسی نصب نیست. از تنظیمات Text-to-speech گوشی بستهٔ فارسی را نصب کن."
            TextToSpeech.LANG_NOT_SUPPORTED -> "موتور فعلی از زبان فارسی پشتیبانی نمی‌کند؛ موتور دیگری انتخاب کن."
            else -> null
        }
        status.value = error.value ?: if (voices.value.isEmpty()) "موتور فعال است، اما صدای فارسی اختصاصی در فهرست نیست." else "موتور آماده است؛ ${voices.value.size} صدای فارسی شناسایی شد."
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { status.value = "خواندن متن شروع شد…" }
            override fun onDone(utteranceId: String?) { status.value = "خواندن آزمایشی با موفقیت تمام شد." }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { error.value = "موتور گفتار هنگام خواندن خطا داد."; status.value = error.value!! }
            override fun onError(utteranceId: String?, errorCode: Int) { error.value = "خطای موتور گفتار (کد $errorCode)."; status.value = error.value!! }
        })
    }

    fun speak(text: String, speed: Float = 1f, voiceName: String? = null) {
        if (!ready.value || text.isBlank()) {
            error.value = "موتور آماده نیست یا متن آزمایش خالی است."
            status.value = error.value!!
            return
        }
        engine.stop()
        engine.setSpeechRate(speed.coerceIn(0.5f, 2f))
        val selected = voices.value.firstOrNull { it.name == voiceName }
        val languageResult = if (selected != null) { engine.voice = selected; TextToSpeech.SUCCESS }
            else engine.setLanguage(Locale.forLanguageTag("fa-IR"))
        if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            error.value = "زبان یا صدای فارسی برای موتور انتخاب‌شده در دسترس نیست."
            status.value = error.value!!
            return
        }
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mindunlock-test-${System.currentTimeMillis()}")
        if (result == TextToSpeech.ERROR) {
            error.value = "موتور نتوانست درخواست خواندن را اجرا کند."
            status.value = error.value!!
        } else {
            error.value = null
            status.value = "درخواست خواندن به موتور ارسال شد؛ منتظر تأیید خروجی هستیم…"
        }
    }

    fun stop() { engine.stop(); status.value = "خواندن متوقف شد." }
    fun close() { engine.stop(); engine.shutdown() }
}
