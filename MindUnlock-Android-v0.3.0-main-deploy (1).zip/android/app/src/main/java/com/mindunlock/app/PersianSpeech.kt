package com.mindunlock.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.compose.runtime.mutableStateOf
import java.util.Locale

class PersianSpeech(context: Context) : TextToSpeech.OnInitListener {
    private val engine = TextToSpeech(context.applicationContext, this)
    val ready = mutableStateOf(false)
    val error = mutableStateOf<String?>(null)
    val voices = mutableStateOf<List<Voice>>(emptyList())

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            error.value = "موتور گفتار اندروید راه‌اندازی نشد."
            return
        }
        val result = engine.setLanguage(Locale.forLanguageTag("fa-IR"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            error.value = "صدای فارسی روی گوشی نصب نیست؛ دادهٔ گفتار فارسی را در تنظیمات Text-to-speech اندروید نصب کن."
        }
        voices.value = engine.voices?.filter { it.locale.language == "fa" }.orEmpty()
        ready.value = true
    }

    fun speak(text: String, speed: Float = 1f, voiceName: String? = null) {
        if (!ready.value || text.isBlank()) return
        engine.stop()
        engine.setSpeechRate(speed.coerceIn(0.65f, 1.6f))
        val selected = voices.value.firstOrNull { it.name == voiceName }
        if (selected != null) engine.voice = selected else engine.language = Locale.forLanguageTag("fa-IR")
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mindunlock-read-${System.currentTimeMillis()}")
    }

    fun stop() { engine.stop() }
    fun close() { engine.stop(); engine.shutdown() }
}
