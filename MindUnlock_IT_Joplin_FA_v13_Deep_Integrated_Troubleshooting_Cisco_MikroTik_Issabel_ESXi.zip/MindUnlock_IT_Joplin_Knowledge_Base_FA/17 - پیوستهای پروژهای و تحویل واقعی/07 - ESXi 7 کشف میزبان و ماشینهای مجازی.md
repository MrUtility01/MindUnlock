# VMware ESXi 7: کشف Host، VM، Port Group و مسیر ذخیره‌سازی

## ثبت از Host Client/vCenter
- Hostname، Management vmkernel، DNS، Gateway، NTP، نسخه Build و License.
- CPU، RAM، NIC، HBA، BIOS، RAID/Controller، سلامت سخت‌افزار.
- vSwitch استاندارد/Distributed، Uplinkها، Port Groupها، VLAN ID، MTU و Security Policy.
- VMها، VMID، Power State، Guest OS، vCPU، RAM، vNIC، MAC، Port Group، Datastore، Snapshot و VMware Tools.
- Datastoreها، ظرفیت آزاد، مسیر LUN/NFS، Multipathing و هشدارها.

## ESXi Shell (فقط خواندنی)
```bash
vmware -vl
esxcli system hostname get
esxcli network ip interface list
esxcli network ip interface ipv4 get
esxcli network ip route ipv4 list
esxcli network nic list
esxcli network vswitch standard list
esxcli network vswitch standard portgroup list
esxcli storage filesystem list
esxcli storage core device list
esxcli vm process list
vim-cmd vmsvc/getallvms
```

## پورت VM
- Port Group، VLAN ID و Uplink teaming را با vNIC هر VM تطبیق بده.
- شماره Port ID نمایش‌داده‌شده در vSphere را با TCP/UDP داخل Guest اشتباه نگیر.
- پورت‌های سرویس داخل Guest را از خود سیستم‌عامل استخراج کن:
Windows:
```powershell
Get-NetTCPConnection -State Listen
Get-NetUDPEndpoint
Get-NetFirewallProfile
```
Linux:
```bash
ss -lntup
ip -br addr
ip route
```
- Port Group فقط اتصال لایه ۲ را فراهم می‌کند؛ فایروال Guest، سرویس و Route هم باید بررسی شوند.

## VMID و اطلاعات VM
```bash
vim-cmd vmsvc/getallvms
vim-cmd vmsvc/power.getstate <VMID>
vim-cmd vmsvc/get.config <VMID>
```
قبل از Snapshot، Consolidation یا تغییر Datastore وضعیت Backup، فضای آزاد و I/O را بررسی کن. Snapshot جایگزین Backup نیست.

## تست ارتباط
از vmkernel مناسب، فقط با مقصد مجاز:
```bash
vmkping <destination>
vmkping -I vmkX <destination>
```
برای MTU بزرگ، اندازه Packet و DF را طبق نسخه ESXi و مسیر شبکه تنظیم کن؛ نتیجه باید با MTU سوئیچ و روتر همخوان باشد.

## احتیاط
ESXi 7 پایان چرخه پشتیبانی/سازگاری وابسته به نسخه و قرارداد است؛ قبل از ارتقا، HCL، نسخه Firmware، Backup و سازگاری VM Hardware را بررسی کن. دسترسی Management را از VLAN کاربران جدا و فقط از Jump Host/VPN مجاز محدود کن.

<!-- joplin-tags: domain/17, type/reference, topic/network-handover, vendor/vmware -->
