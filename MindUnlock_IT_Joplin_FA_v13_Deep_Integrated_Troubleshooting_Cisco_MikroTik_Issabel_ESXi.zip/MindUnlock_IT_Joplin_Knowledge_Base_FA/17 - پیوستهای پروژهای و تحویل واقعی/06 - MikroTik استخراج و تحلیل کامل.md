# MikroTik RouterOS: استخراج و تحلیل کامل

## شناسایی و سلامت
```routeros
/system identity print
/system resource print
/system routerboard print
/system package print
/system clock print
/system ntp client print
/system logging print
/system history print
```

## Backup و Export
```routeros
/export file=before-change
/system backup save name=before-change
```
- Export متنی برای تحلیل و Diff مناسب است؛ Backup باینری برای بازگردانی روی دستگاه/نسخه سازگار مناسب‌تر است.
- فایل Backup باینری را محرمانه و رمزنگاری‌شده نگه دار؛ آن را در ایمیل/چت عمومی ارسال نکن.
- خروجی Export را پیش از اشتراک‌گذاری از Secretها، کلیدهای VPN، رمزها، SNMP community و داده‌های هویتی پاک‌سازی کن.
- گزینه‌های نمایش Secret در نسخه‌ها متفاوت‌اند؛ برای مستندسازی عمومی عمداً از نمایش Secret خودداری کن.

## IP، Route، VLAN و Bridge
```routeros
/ip address print detail
/ip route print detail
/ip arp print detail
/ip neighbor print detail
/interface print detail
/interface ethernet print detail
/interface bridge print detail
/interface bridge port print detail
/interface bridge vlan print detail
/interface bridge host print detail
/interface vlan print detail
```

## DHCP، DNS، NAT و Firewall
```routeros
/ip dhcp-server print detail
/ip dhcp-server network print detail
/ip dhcp-server lease print detail
/ip pool print detail
/ip dns print
/ip firewall nat print detail stats
/ip firewall filter print detail stats
/ip firewall raw print detail stats
/ip firewall mangle print detail stats
/ip firewall address-list print detail
/ip service print
```

## VPN و تونل
```routeros
/interface wireguard print detail
/interface wireguard peers print detail
/interface l2tp-client print detail
/interface l2tp-server server print
/interface pptp-client print detail
/interface sstp-client print detail
/interface ovpn-client print detail
/interface ipip print detail
/interface gre print detail
/interface eoip print detail
/ip ipsec peer print detail
/ip ipsec policy print detail
/ip ipsec installed-sa print detail
```
فقط بخش‌هایی که در نسخه/پکیج نصب‌شده وجود دارند قابل اجرا هستند. وضعیت Peer، Endpoint، Allowed Address، Proposal، Policy، NAT-T، Route و Firewall باید با هم تحلیل شوند؛ صرفاً `running` بودن Interface به معنی عبور ترافیک نیست.

## عیب‌یابی
```routeros
/ping <destination> src-address=<source-ip> count=5
/tool traceroute <destination>
/tool torch interface=<interface>
/interface monitor-traffic <interface>
/log print where topics~"firewall|ipsec|wireguard|route"
/ip route check <destination>
```
Torch و Packet Sniffer ممکن است اطلاعات حساس کاربران را ببینند؛ با مجوز و Capture محدود استفاده کن.

## ترتیب تحلیل Firewall
1. ترتیب Ruleها و Chainها (input/forward/output).
2. Connection State و FastTrack.
3. Interface List و Address List.
4. NAT قبل/بعد از Route و اثر روی تونل.
5. Mangle، Routing Mark و Policy Routing.
6. MTU/MSS، Fragmentation و مسیر برگشت.
7. Counterها و Log محدود برای Rule موردنظر.

## VLAN Filtering
قبل از فعال‌کردن `vlan-filtering=yes`، Bridge VLAN table، PVID، Tagged/Untagged membership، CPU/Bridge port، Management VLAN و مسیر دسترسی را کامل بررسی کن. اشتباه در این بخش می‌تواند دسترسی مدیریتی را قطع کند. ابتدا طرح تغییر و Rollback بنویس و ترجیحاً Safe Mode/دسترسی Out-of-band داشته باش.

<!-- joplin-tags: domain/17, type/reference, topic/network-handover, vendor/mikrotik -->
