# اتوماسیون شبکه و Backup کانفیگ

## معماری پیشنهادی
- مخزن Git خصوصی برای نسخه‌های Sanitized و Diff؛ فایل‌های خام محرمانه در Vault/Backup رمزنگاری‌شده.
- Ansible برای اجرای Read-only و جمع‌آوری Factها؛ Netmiko/Nornir برای تجهیزات CLI؛ API رسمی RouterOS/VMware برای داده ساختاریافته.
- Credential از Vault/Secret Manager؛ نه داخل Script، CSV، Git یا Notebook.
- حساب Automation مجزا، کم‌دسترسی، محدود به Management VLAN و ACL مبدأ.
- زمان‌بندی شبانه/هفتگی با گزارش تغییرات و هشدار Drift.

## گردش کار
1. Inventory از hostname، platform، management address و گروه دسترسی.
2. اتصال با SSH/HTTPS و تأیید Host Key/Certificate.
3. اجرای فرمان‌های Read-only از Allowlist.
4. ذخیره خروجی با timestamp و شناسه تجهیز.
5. محاسبه SHA256 و ثبت نتیجه.
6. Sanitization قبل از Commit.
7. Diff با نسخه قبل؛ تغییرات غیرمنتظره هشدار.
8. آزمون Restore روی Lab یا دستگاه جایگزین؛ Backup بدون تست Restore قابل اتکا نیست.

## نمونه امن Ansible برای جمع‌آوری (قالب)
```yaml
# inventory.ini
[cisco]
sw-core ansible_host=192.0.2.10

[mikrotik]
mt-edge ansible_host=192.0.2.1

# گروه‌ها را فقط با IPهای تأییدشده و دسترسی مجاز پر کن.
```
```yaml
# collect_readonly.yml
- name: Collect read-only network evidence
  hosts: cisco
  gather_facts: false
  tasks:
    - name: Capture version and interfaces
      cisco.ios.ios_command:
        commands:
          - show version
          - show interfaces status
          - show vlan brief
          - show ip interface brief
      register: evidence
    - name: Save evidence
      ansible.builtin.copy:
        content: "{{ evidence.stdout | to_nice_yaml }}"
        dest: "./evidence/{{ inventory_hostname }}_{{ lookup('pipe','date +%Y%m%d_%H%M%S') }}.yml"
      delegate_to: localhost
```
این Playbook نمونه آموزشی است؛ Collection، Python، SSH، مسیر Evidence و مجوزها باید در محیط آزمایشگاهی تست شوند. برای MikroTik از Collection سازگار با RouterOS و نسخه دقیق استفاده کن؛ فرمان‌های Export حساس را خودکار در Git قرار نده.

## کنترل کیفیت
- موفقیت اتصال با موفقیت جمع‌آوری یکی نیست.
- خروجی خالی، Timeout و Permission denied باید Failure واضح باشند.
- تغییرات فقط در Playbook جداگانه، با Review دو نفره، Check Mode در صورت پشتیبانی، Backup و Rollback انجام شود.
- هرگز Playbook عمومی با `save`, `set`, `remove`, `reset`, `reboot` یا `upgrade` را روی همه تجهیزات اجرا نکن.

<!-- joplin-tags: domain/17, type/reference, topic/network-handover, topic/automation -->
