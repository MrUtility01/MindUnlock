# Issabel 4: کشف داخلی‌ها، SIP Trunk، DID و Call Flow

## اول نسخه و سرویس
```bash
cat /etc/issabel-release 2>/dev/null
cat /etc/redhat-release
asterisk -rx "core show version"
asterisk -rx "core show uptime"
systemctl status asterisk
systemctl status httpd
```
در Issabel 4 بسته به نصب، CentOS/RHEL قدیمی و نسخه‌های متفاوت Asterisk ممکن است وجود داشته باشد. قبل از اجرای فرمان تغییردهنده، نسخه را ثبت کن.

## شمارش داخلی‌ها
```bash
asterisk -rx "sip show peers"
asterisk -rx "sip show peer <extension>"
asterisk -rx "pjsip show endpoints"
asterisk -rx "pjsip show contacts"
asterisk -rx "core show channels"
asterisk -rx "core show channels concise"
```
- همه سیستم‌ها SIP Channel Driver یکسان ندارند؛ `chan_sip` و `pjsip` را با هم فرض نکن.
- تعداد داخلی تعریف‌شده را از FreePBX/Issabel GUI و فایل‌های Generated مقایسه کن.
- تعداد Registered با تعداد Configured برابر نیست.
- داخلی‌های Disabled، بلااستفاده، Softphone، تلفن فیزیکی و Trunk endpoint را جدا بشمار.

## Trunk و DID
```bash
asterisk -rx "sip show registry"
asterisk -rx "sip show registry"
asterisk -rx "pjsip show registrations"
asterisk -rx "dialplan show from-trunk"
asterisk -rx "dialplan show from-pstn"
```
نام Contextها به نسخه و تنظیمات وابسته است. از GUI بخش Trunks، Inbound Routes، Outbound Routes و DID Numberها را Export/ثبت کن.
- **تعداد خط مستقیم (DID):** تعداد شماره‌های ورودی یکتا که واقعاً به سازمان تخصیص یافته و Route شده‌اند؛ تعداد Trunkها یا کانال‌های همزمان معادل DID نیست.
- **ظرفیت کانال:** تعداد تماس همزمان مجاز اپراتور/Trunk؛ از قرارداد و تست کنترل‌شده تأیید شود.
- **شماره‌های خروجی Caller ID:** جدا از DID ورودی ثبت شوند.

## IVR، Queue، Ring Group و ضبط
```bash
asterisk -rx "queue show"
asterisk -rx "core show hints"
asterisk -rx "dialplan show"
asterisk -rx "module show"
```
از GUI، IVRها، Queueها، Ring Groupها، Time Condition، Follow Me، Voicemail، Paging، Conference و Recording Policy را مستند کن.

## لاگ و دیباگ کنترل‌شده
```bash
asterisk -rx "core show channels"
asterisk -rx "core show channel <channel-name>"
tail -f /var/log/asterisk/full
```
برای SIP debug یا Packet Capture فقط تماس آزمایشی، بازه کوتاه و مجوز روشن؛ شماره تماس، IP عمومی و محتوای صوتی داده حساس‌اند. پس از تست Debug را خاموش کن.

## Database و حفظ داده
- نوع DB و اتصال را از تنظیمات سرویس و پکیج نصب‌شده شناسایی کن؛ نام دیتابیس را حدس نزن.
- Backup سازگار با نسخه DB بگیر، Restore را در محیط جداگانه آزمایش کن.
- SIP Secret، رمز GUI، رمز DB و فایل‌های TLS را در گزارش متنی چاپ نکن.
- فایل‌های کانفیگ Asterisk/FreePBX را بدون تغییر کپی کن؛ ویرایش مستقیم فایل‌های Generated ممکن است با Apply Config بازنویسی شود.

## خروجی نهایی VoIP
تعداد داخلی تعریف‌شده، فعال، Registered، غیرفعال؛ تعداد Trunk؛ DIDهای ورودی؛ کانال همزمان؛ مسیرهای ورودی/خروجی؛ IVR/Queue/Ring Group؛ ساعات کاری؛ Codec؛ NAT/RTP؛ QoS؛ Backup و مالک هر مورد.

<!-- joplin-tags: domain/17, type/reference, topic/network-handover, vendor/issabel, topic/voip -->
