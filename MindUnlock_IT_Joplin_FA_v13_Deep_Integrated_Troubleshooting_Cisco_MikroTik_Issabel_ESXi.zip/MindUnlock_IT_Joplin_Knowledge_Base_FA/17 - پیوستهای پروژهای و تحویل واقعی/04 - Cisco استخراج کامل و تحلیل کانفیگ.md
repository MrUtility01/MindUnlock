# Cisco: استخراج کامل و تحلیل کانفیگ

## شناسایی اولیه (Read-only)
```text
terminal length 0
show clock
show version
show inventory
show license
show switch
show redundancy
show environment all
show processes cpu sorted
show memory statistics
show interfaces status
show ip interface brief
show vlan brief
show interfaces trunk
show etherchannel summary
show spanning-tree summary
show mac address-table
show cdp neighbors detail
show lldp neighbors detail
show ip route
show ip arp
show access-lists
show ip access-lists
show logging
show users
show line
show running-config
show startup-config
```
فرمان‌ها بر اساس IOS/IOS-XE/NX-OS و مدل فرق دارند؛ `show switch` یا `show environment all` ممکن است روی برخی مدل‌ها وجود نداشته باشد.

## ذخیره خروجی متنی
- از SSH Terminal Logging استفاده کن و کل Session را با تاریخ ثبت کن.
- در صورت پشتیبانی و وجود سرور TFTP/SCP مجاز:
```text
copy running-config scp:
copy startup-config scp:
```
یا:
```text
copy running-config tftp:
copy startup-config tftp:
```
در بعضی نسخه‌ها مقصد/سینتکس با Prompt تعاملی دریافت می‌شود. پیش از انتقال، مسیر، ACL و فضای مقصد را کنترل کن.
- Running و Startup را جدا نگه دار؛ اختلاف آن‌ها مهم است.
- پس از ذخیره:
```bash
sha256sum <filename>
```
یا روی Windows:
```powershell
Get-FileHash .\\filename -Algorithm SHA256
```

## تحلیل کانفیگ به ترتیب
1. `hostname`, نسخه، مدل، stack و لایسنس.
2. Interfaceها: Access/Trunk, speed/duplex, shutdown, description, errors.
3. VLANها: VLAN ID، نام، پورت‌های عضو، Native VLAN.
4. STP: Root Bridge، Root Port، PortFast، BPDU Guard، Loop Guard.
5. EtherChannel: اعضا، LACP/PAgP، mismatch.
6. SVI و IP: آدرس، mask، helper-address، ACL.
7. Routing: default route، static/dynamic، next-hop، route preference.
8. Security: ACL، Port Security، DHCP Snooping، DAI، 802.1X.
9. Voice: Voice VLAN، QoS trust boundary، LLDP-MED/CDP.
10. Management: SSH، AAA، local users، SNMP، NTP، Syslog، VTY ACL.
11. PoE budget و توان مصرفی تلفن‌ها/APها.
12. مقایسه Running با Startup و بررسی تغییرات ثبت‌شده.

## فرمان‌های تکمیلی عیب‌یابی
```text
show interfaces counters errors
show interfaces <interface>
show interfaces <interface> switchport
show spanning-tree interface <interface> detail
show etherchannel <number> detail
show port-security interface <interface>
show power inline
show ip route <destination>
show ip cef <destination>
show logging | include LINK|LINEPROTO|SPANTREE|ERR
ping <destination> source <source-interface>
traceroute <destination>
```
در فرمان‌های فیلترشده، Pipe و کلیدواژه‌ها در IOSهای مختلف ممکن است تفاوت داشته باشند.

## نکته حیاتی
`show running-config` معمولاً Secretهای هش‌شده یا رمزهای قابل نمایش را نشان می‌دهد، نه رمز عبور قابل بازیابی همه کاربران. برای اشتراک، کانفیگ را Sanitise کن. از انتشار `enable secret`, کلیدها، SNMP community و PSK خودداری کن.

<!-- joplin-tags: domain/17, type/reference, topic/network-handover, vendor/cisco -->
