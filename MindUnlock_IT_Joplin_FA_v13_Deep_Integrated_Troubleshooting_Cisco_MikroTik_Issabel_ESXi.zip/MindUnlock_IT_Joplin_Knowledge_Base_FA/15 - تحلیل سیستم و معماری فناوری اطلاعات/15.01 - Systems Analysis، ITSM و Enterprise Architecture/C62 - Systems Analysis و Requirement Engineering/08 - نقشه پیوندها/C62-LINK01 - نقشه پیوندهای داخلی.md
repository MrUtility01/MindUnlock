# C62-LINK01 - نقشه پیوندهای داخلی

- **شناسه ثابت (Stable ID):** `C62-LINK01`
- **نوع صفحه (Page Type):** `link-map`
- **وضعیت (Status):** `Not Started`
- **برچسب‌های پیشنهادی (Suggested Tags):** `type/link-map`، `domain/15`، `status/not-started`

---

## هدف نقشه پیوند (Link Map Purpose)
این صفحه برای ثبت پیوندهای داخلی واقعی Joplin پس از Import است. شناسه ثابت هر یادداشت در Manifest موجود است.

## پیوندهای این فصل (Chapter Links)
| شناسه مقصد | عنوان | پیوند داخلی Joplin |
|---|---|---|
| | | پس از Import با `Tools → Link to note` درج شود |

## ارتباط با فصل‌های دیگر (Cross-Chapter Links)
| شناسه | دلیل ارتباط | پیوند |
|---|---|---|
| | | |

## یادداشت
برای ساخت پیوند واقعی، یادداشت مقصد را در Joplin با `Copy Markdown link` کپی و در جدول بالا قرار بده.
