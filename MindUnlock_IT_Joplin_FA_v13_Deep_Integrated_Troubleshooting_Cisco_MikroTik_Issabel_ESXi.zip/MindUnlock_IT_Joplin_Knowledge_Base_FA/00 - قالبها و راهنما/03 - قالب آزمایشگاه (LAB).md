# قالب آزمایشگاه (LAB)

- **شناسه ثابت (Stable ID):** `DOC-2C0298C3D0`
- **نوع صفحه (Page Type):** `template`
- **وضعیت (Status):** `Not Started`
- **برچسب‌های پیشنهادی (Suggested Tags):** `type/template`، `domain/00`، `status/not-started`

---

## هدف آزمایشگاه (Lab Objectives)
- [ ] 

## پیش‌نیازها (Prerequisites)
- 

## محیط و ابزارها (Environment & Tools)
- نرم‌افزار / نسخه:
- تجهیزات یا VMها:
- منابع موردنیاز:

## توپولوژی و دیاگرام (Topology)
> تصویر یا دیاگرام را اینجا اضافه کن.

```text
# ترسیم متنی توپولوژی در صورت نیاز
```

## آدرس‌دهی و مشخصات (Addressing & Inventory)
| دستگاه | Interface | IP / VLAN | نقش |
|---|---|---|---|
| | | | |

## سناریو و مراحل اجرا (Procedure)
1. 
2. 
3. 

## دستورات و پیکربندی (Commands & Configuration)
```text
# دستورات را اینجا وارد کن
```

## نتیجه مورد انتظار (Expected Results)


## خروجی واقعی و شواهد (Actual Results & Evidence)


## خطای عمدی و تمرین عیب‌یابی (Fault Injection & Troubleshooting)
- خطای ایجادشده:
- نشانه مورد انتظار:
- روش تشخیص:
- روش اصلاح:

## پاک‌سازی و بازگردانی محیط (Cleanup & Rollback)


## چک‌لیست تکمیل آزمایشگاه (Completion Checklist)
- [ ] سناریو اجرا شد.
- [ ] خروجی‌ها ذخیره شدند.
- [ ] عیب‌یابی انجام شد.
- [ ] مستندات تکمیل شد.

## نتیجه‌گیری و مهارت کسب‌شده (Learning Outcome)
