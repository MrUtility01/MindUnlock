# قالب عیب‌یابی (TROUBLESHOOTING)

- **شناسه ثابت (Stable ID):** `DOC-A14534943D`
- **نوع صفحه (Page Type):** `template`
- **وضعیت (Status):** `Not Started`
- **برچسب‌های پیشنهادی (Suggested Tags):** `type/template`، `domain/00`، `status/not-started`

---

## مشخصات مشکل (Issue Profile)
- **پلتفرم / سرویس:** 
- **شدت:** 
- **اثر:** 

## نشانه‌ها (Symptoms)
- 

## اطلاعات جمع‌آوری‌شده (Evidence Collection)
- لاگ:
- وضعیت سرویس:
- شبکه:
- منابع سیستم:

## فرضیه‌های محتمل (Possible Causes)
1. 
2. 
3. 

## روند عیب‌یابی (Troubleshooting Steps)
1. 
2. 
3. 

## دستورات بررسی (Diagnostic Commands)
```text
# دستورات تشخیصی
```

## علت ریشه‌ای (Root Cause)


## راهکار (Resolution)


## اعتبارسنجی نهایی (Verification)
- [ ] سرویس سالم است.
- [ ] لاگ جدید خطای مرتبط ندارد.
- [ ] عملکرد به حالت مورد انتظار برگشته است.

## پیشگیری از تکرار (Prevention)


## ارجاع به سناریو / آزمایشگاه مرتبط
- شناسه‌ها: 
