# قالب مرجع و مستندات (REFERENCE)

- **شناسه ثابت (Stable ID):** `DOC-893624A6EA`
- **نوع صفحه (Page Type):** `template`
- **وضعیت (Status):** `Not Started`
- **برچسب‌های پیشنهادی (Suggested Tags):** `type/template`، `domain/00`، `status/not-started`

---

## مشخصات منبع (Reference Metadata)
- **ناشر / سازنده:** 
- **نوع منبع:** Official Documentation / RFC / Book / Article / Video
- **محصول و نسخه:** 
- **تاریخ بررسی:** 

## پیوند منبع (Source URL)
- 

## بخش‌های مهم (Relevant Sections)
- 

## نکات استخراج‌شده (Key Notes)


## نسخه‌ها و سازگاری (Version Compatibility)


## موضوعات مرتبط (Related Topics)
- شناسه‌ها: 

## یادداشت و ارزیابی اعتبار منبع (Source Review)
