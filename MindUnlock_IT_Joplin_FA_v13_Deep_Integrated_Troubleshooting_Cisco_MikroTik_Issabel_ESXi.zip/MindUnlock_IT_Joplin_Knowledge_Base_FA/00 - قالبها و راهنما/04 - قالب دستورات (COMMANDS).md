# قالب دستورات (COMMANDS)

- **شناسه ثابت (Stable ID):** `DOC-CDA620471D`
- **نوع صفحه (Page Type):** `template`
- **وضعیت (Status):** `Not Started`
- **برچسب‌های پیشنهادی (Suggested Tags):** `type/template`، `domain/00`، `status/not-started`

---

## مشخصات (Command Reference)
- **پلتفرم (Platform):** 
- **نسخه / محیط (Version / Environment):** 
- **هدف (Purpose):** 

## دستور (Command)
```text
# دستور را اینجا وارد کن
```

## ساختار و پارامترها (Syntax & Parameters)
| پارامتر | معنی | مقدار نمونه |
|---|---|---|
| | | |

## مثال اجرا (Usage Example)
```text
# مثال اجرا
```

## خروجی نمونه (Sample Output)
```text
# خروجی واقعی یا نمونه
```

## تفسیر خروجی (Output Interpretation)


## کاربرد عملی (Operational Use Case)


## ملاحظات امنیتی و ریسک تغییر (Security & Change Risk)


## بازگشت از تغییر (Rollback)


## دستورات مرتبط (Related Commands)
- 
