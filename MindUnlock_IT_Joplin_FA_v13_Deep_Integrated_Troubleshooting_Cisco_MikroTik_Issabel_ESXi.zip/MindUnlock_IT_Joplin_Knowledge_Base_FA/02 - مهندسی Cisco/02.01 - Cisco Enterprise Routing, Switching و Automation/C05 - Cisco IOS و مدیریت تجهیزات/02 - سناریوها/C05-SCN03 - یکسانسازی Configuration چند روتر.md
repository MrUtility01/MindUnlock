# C05-SCN03 - یکسان‌سازی Configuration چند روتر

- **شناسه ثابت (Stable ID):** `C05-SCN03`
- **نوع صفحه (Page Type):** `scenario`
- **وضعیت (Status):** `Not Started`
- **برچسب‌های پیشنهادی (Suggested Tags):** `type/scenario`، `domain/02`، `status/not-started`

---

## مشخصات سناریو (Scenario Brief)
- **محیط:** 
- **سطح دشواری:** 
- **محدوده مجاز (Authorized Scope):** فقط محیط متعلق به خود یا دارای مجوز صریح.

## وضعیت اولیه (Initial State)


## مسئله و نشانه‌ها (Problem & Symptoms)
- 

## اثر کسب‌وکاری (Business Impact)


## شواهد و داده‌های اولیه (Evidence)
- لاگ‌ها:
- خروجی دستورات:
- نمودارها / تصاویر:

## فرضیه‌ها (Hypotheses)
1. 
2. 
3. 

## روش بررسی (Investigation Plan)
1. 
2. 
3. 

## دستورات و ابزارها (Commands & Tools)
```text
# دستورات را اینجا ثبت کن
```

## تحلیل علت ریشه‌ای (Root Cause Analysis)


## راهکار اصلاحی (Remediation)


## اعتبارسنجی (Validation)
- [ ] مشکل رفع شده است.
- [ ] اثر جانبی ایجاد نشده است.
- [ ] شواهد پس از اصلاح ثبت شده‌اند.

## پیشگیری و درس‌آموخته‌ها (Prevention & Lessons Learned)


## گزارش نهایی (Final Report)
