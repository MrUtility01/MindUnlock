﻿param(
    [switch]$IncludeUserData
)
$ErrorActionPreference = 'Stop'
$Root = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$Parent = Split-Path -Parent $Root
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$Output = Join-Path $Parent "NetworkLearning_Offline_Portable_$Stamp.zip"
$Ready = Join-Path $Root '.portable-ready.json'
$Python = Join-Path $Root '.portable-python\python.exe'
$Model = Join-Path $Root 'models\mana-persian-piper\fa_IR-mana-medium.onnx'
$ModelConfig = Join-Path $Root 'models\mana-persian-piper\fa_IR-mana-medium.onnx.json'
$ExpectedModelHash = 'e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126'

function Fail([string]$Message) { throw $Message }
function Get-RelativePath([string]$Base, [string]$FullName) {
    return $FullName.Substring($Base.Length).TrimStart('\','/').Replace('\','/')
}

if (!(Test-Path -LiteralPath $Ready -PathType Leaf) -or !(Test-Path -LiteralPath $Python -PathType Leaf)) {
    Fail 'Portable runtime not detected. Run install_portable_windows.bat successfully first.'
}
if (!(Test-Path -LiteralPath (Join-Path $Root 'app.py')) -or !(Test-Path -LiteralPath $Model -PathType Leaf) -or !(Test-Path -LiteralPath $ModelConfig -PathType Leaf)) {
    Fail 'Required application or Persian voice files are missing. Re-run the portable installer.'
}
try {
    $ReadyData = Get-Content -LiteralPath $Ready -Raw -Encoding UTF8 | ConvertFrom-Json
} catch { Fail ('Readiness marker is invalid JSON: ' + $_.Exception.Message) }
if ($ReadyData.release -ne '0.6.0-foundation') { Fail 'Readiness marker release does not match this application.' }
$ActualModelHash = (Get-FileHash -LiteralPath $Model -Algorithm SHA256).Hash.ToLowerInvariant()
if ($ActualModelHash -ne $ExpectedModelHash -or $ReadyData.model_sha256 -ne $ExpectedModelHash) {
    Fail 'Persian voice model integrity check failed. Re-run the portable installer before packaging.'
}
try {
    $null = Get-Content -LiteralPath $ModelConfig -Raw -Encoding UTF8 | ConvertFrom-Json
} catch { Fail ('Persian voice model config is invalid JSON: ' + $_.Exception.Message) }
$oldPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try {
    $runtimeOutput = @(& $Python -c "import sys,fastapi,uvicorn,multipart,docx,pypdf,piper,onnxruntime; assert sys.version_info[:2] == (3,13); assert sys.maxsize > 2**32; print(sys.version)" 2>&1)
    $runtimeExit = $LASTEXITCODE
} finally { $ErrorActionPreference = $oldPreference }
if ($runtimeExit -ne 0) { Fail ('Portable Python/dependency smoke test failed: ' + (($runtimeOutput | ForEach-Object { [string]$_ }) -join ' | ')) }

$DataFiles = @(Get-ChildItem -LiteralPath (Join-Path $Root 'data') -File -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne '.gitkeep' })
if (!$IncludeUserData -and $DataFiles.Count -gt 0) {
    Write-Host ('The data folder contains {0} file(s), which may include accounts, progress, notes and personal content.' -f $DataFiles.Count) -ForegroundColor Yellow
    $answer = Read-Host 'Include this private user data in the portable ZIP? Type YES to include; default is NO'
    if ($answer -ceq 'YES') { $IncludeUserData = $true }
}
if ($IncludeUserData) {
    Write-Host 'Private user data WILL be included in the archive.' -ForegroundColor Yellow
} else {
    Write-Host 'Private data files will be excluded. The target app will create a fresh local database.' -ForegroundColor Cyan
}

$files = @(Get-ChildItem -LiteralPath $Root -File -Recurse -Force | Where-Object {
    $rel = Get-RelativePath $Root $_.FullName
    $parts = $rel -split '[\\/]'
    if ($parts -contains '.venv' -or $parts -contains '.tts-venv' -or $parts -contains '.portable-cache' -or $parts -contains '.portable-python.installing') { return $false }
    if ($parts | Where-Object { $_ -like '.portable-python_backup_*' }) { return $false }
    if ($parts -contains '__pycache__' -or $parts -contains '.pytest_cache') { return $false }
    if (!$IncludeUserData -and $parts[0] -eq 'data') { return $false }
    if ($_.Extension -in @('.pyc','.pyo','.log','.part')) { return $false }
    if ($rel -eq 'OFFLINE_PACKAGE_MANIFEST.json') { return $false }
    return $true
})
if (!$files -or $files.Count -eq 0) { Fail 'No files were found to package.' }

$records = New-Object 'System.Collections.Generic.List[object]'
foreach ($f in $files) {
    $rel = Get-RelativePath $Root $f.FullName
    $records.Add([ordered]@{ path = $rel; size_bytes = [long]$f.Length; sha256 = (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant() })
}
$manifest = [ordered]@{
    format = 'network-learning-offline-portable'
    format_version = 1
    app_release = '0.6.0-foundation'
    created_utc = [DateTime]::UtcNow.ToString('o')
    runtime = 'CPython 3.13 x64 embedded'
    includes_user_data = [bool]$IncludeUserData
    file_count = $records.Count
    files = @($records)
}
$manifestBytes = [Text.Encoding]::UTF8.GetBytes(($manifest | ConvertTo-Json -Depth 8))

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::Open($Output, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($f in $files) {
        $rel = Get-RelativePath $Root $f.FullName
        $entry = $archive.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal)
        $src = [IO.File]::OpenRead($f.FullName)
        try {
            $dest = $entry.Open()
            try { $src.CopyTo($dest) } finally { $dest.Dispose() }
        } finally { $src.Dispose() }
    }
    $manifestEntry = $archive.CreateEntry('OFFLINE_PACKAGE_MANIFEST.json', [IO.Compression.CompressionLevel]::Optimal)
    $manifestStream = $manifestEntry.Open()
    try { $manifestStream.Write($manifestBytes, 0, $manifestBytes.Length) } finally { $manifestStream.Dispose() }
} finally { $archive.Dispose() }

Write-Host ''
Write-Host 'OFFLINE PORTABLE ARCHIVE CREATED' -ForegroundColor Green
Write-Host $Output -ForegroundColor Green
Write-Host (('Files: {0}; ZIP size: {1:N1} MiB' -f ($files.Count + 1), ((Get-Item $Output).Length / 1MB)))
try { & (Join-Path $Root 'verify_offline_portable_package.ps1') -Archive $Output } catch { Remove-Item -LiteralPath $Output -Force -ErrorAction SilentlyContinue; throw }
