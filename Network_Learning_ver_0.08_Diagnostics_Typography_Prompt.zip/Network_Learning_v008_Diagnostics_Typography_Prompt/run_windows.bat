﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "APP_PY="

rem Prefer an existing prepared runtime only if all app dependencies can be imported.
if exist ".portable-python\python.exe" (
  ".portable-python\python.exe" -c "import fastapi,uvicorn,multipart,docx,pypdf" >nul 2>nul
  if not errorlevel 1 set "APP_PY=.portable-python\python.exe"
)
if not defined APP_PY if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import fastapi,uvicorn,multipart,docx,pypdf" >nul 2>nul
  if not errorlevel 1 set "APP_PY=.venv\Scripts\python.exe"
)
if not defined APP_PY (
  echo No ready local Python environment was found. Preparing development dependencies...
  call "%~dp0setup_dev_windows.bat"
  if errorlevel 1 goto setup_failed
  if exist ".venv\Scripts\python.exe" set "APP_PY=.venv\Scripts\python.exe"
)
if not defined APP_PY goto setup_failed

rem Read saved network configuration without overwriting it with defaults.
if not defined NL_PORT for /f "delims=" %%P in ('"%APP_PY%" launch_server.py --print-port') do set "NL_PORT=%%P"
if not defined NL_HOST for /f "delims=" %%H in ('"%APP_PY%" launch_server.py --print-host') do set "NL_HOST=%%H"
if not defined NL_PORT set "NL_PORT=82"
if not defined NL_HOST set "NL_HOST=0.0.0.0"
set "NL_PORT=%NL_PORT%"
set "NL_HOST=%NL_HOST%"

"%APP_PY%" -c "import sys; print('Python runtime:', sys.version.split()[0])"
echo.
echo ============================================================
echo Network Learning - ver 0.08
echo Project folder: %CD%
echo Local URL: http://127.0.0.1:%NL_PORT%/?v=009
echo LAN URLs - open one from another PC on the same private network:
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0show_lan_addresses.ps1" -Port %NL_PORT%
echo.
echo This is the development baseline; final offline packaging is deferred.
echo Do not forward port %NL_PORT% to the public Internet.
echo ============================================================
start "Network Learning ver 0.08" "http://127.0.0.1:%NL_PORT%/?v=009"
"%APP_PY%" launch_server.py
if errorlevel 1 goto server_error
goto end

:setup_failed
echo.
echo ERROR: Development environment could not be prepared.
echo Review the setup error above. Runtime downloads and final offline packaging are not part of this release step.
pause
exit /b 1
:server_error
echo.
echo ERROR: Network Learning stopped. Review the traceback above.
pause
exit /b 1
:end
endlocal
