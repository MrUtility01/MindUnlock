from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parent
DB = ROOT / "data" / "network_learning.db"

print("بازنشانی رمز محلی برنامهٔ دانشنامه جامع یادگیری")
print("ابتدا مطمئن شو سرور برنامه بسته است.")
if not DB.exists():
    print("پایگاه‌داده پیدا نشد؛ برنامه را یک بار اجرا کن و دوباره تلاش کن.")
    raise SystemExit(1)
confirm = input("برای پاک‌کردن فقط تنظیمات ورود و ساخت دوبارهٔ رمز، عبارت RESET را وارد کن: ").strip()
if confirm != "RESET":
    print("لغو شد؛ هیچ تغییری انجام نشد.")
    raise SystemExit(0)
with sqlite3.connect(DB) as conn:
    conn.execute("DELETE FROM settings WHERE key IN ('password_hash','auth_secret','password_length')")
    # Keep secondary accounts/content intact. First setup replaces the primary admin account.
    try:
        primary = conn.execute("SELECT value FROM settings WHERE key='auth_username'").fetchone()
        if primary:
            conn.execute("UPDATE user_accounts SET password_hash='' WHERE username=? COLLATE NOCASE", (primary[0],))
    except sqlite3.OperationalError:
        # Compatibility with databases created before multi-user accounts.
        pass
print("انجام شد. محتوا، فصل‌ها، پیشرفت و تاریخچه حذف نشده‌اند.")
print("برنامه را دوباره اجرا کن و از خود رایانهٔ میزبان یک رمز قوی با حداقل ۱۲ نویسه بساز.")
