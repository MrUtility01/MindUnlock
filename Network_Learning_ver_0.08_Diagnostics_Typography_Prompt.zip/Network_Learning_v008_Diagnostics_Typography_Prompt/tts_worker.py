"""Optional isolated Piper worker for Windows hosts whose main Python is newer than ONNX Runtime supports."""
from __future__ import annotations
import base64
import io
import json
import sys
import wave
from pathlib import Path


def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
        text = str(payload.get("text") or "").strip()
        model = Path(str(payload.get("model") or ""))
        if not text or not model.is_file() or not Path(str(model) + ".json").is_file():
            raise ValueError("متن یا فایل مدل معتبر نیست")
        from piper import PiperVoice
        voice = PiperVoice.load(str(model))
        audio = io.BytesIO()
        with wave.open(audio, "wb") as wav_file:
            voice.synthesize_wav(text, wav_file)
        print(json.dumps({"ok": True, "wav_base64": base64.b64encode(audio.getvalue()).decode("ascii")}, ensure_ascii=False))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:200]}"}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
