﻿param(
    [Parameter(Mandatory=$true)][string]$Archive
)
$ErrorActionPreference = 'Stop'
$Archive = [IO.Path]::GetFullPath($Archive)
if (!(Test-Path -LiteralPath $Archive -PathType Leaf)) { throw ('Archive not found: ' + $Archive) }
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::OpenRead($Archive)
try {
    $manifestEntry = $zip.GetEntry('OFFLINE_PACKAGE_MANIFEST.json')
    if (!$manifestEntry) { throw 'OFFLINE_PACKAGE_MANIFEST.json is missing.' }
    $manifestStream = $manifestEntry.Open()
    $reader = [System.IO.StreamReader]::new($manifestStream, [Text.Encoding]::UTF8)
    try { $manifest = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose(); $manifestStream.Dispose() }
    if ($manifest.format -ne 'network-learning-offline-portable' -or $manifest.format_version -ne 1) { throw 'Unsupported offline package manifest format.' }
    $listed = @{}
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        foreach ($file in $manifest.files) {
            $path = [string]$file.path
            if ([string]::IsNullOrWhiteSpace($path) -or $path.StartsWith('/') -or $path -match '(^|/)\.\.(/|$)') { throw ('Unsafe manifest path: ' + $path) }
            if ($listed.ContainsKey($path)) { throw ('Duplicate manifest path: ' + $path) }
            $listed[$path] = $true
            $entry = $zip.GetEntry($path)
            if (!$entry) { throw ('Archive entry is missing: ' + $path) }
            if ([long]$entry.Length -ne [long]$file.size_bytes) { throw ('Size mismatch: ' + $path) }
            $stream = $entry.Open()
            try { $hash = ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant() } finally { $stream.Dispose() }
            if ($hash -ne ([string]$file.sha256).ToLowerInvariant()) { throw ('SHA-256 mismatch: ' + $path) }
        }
    } finally { $sha.Dispose() }
    $actualEntries = @($zip.Entries | Where-Object { $_.FullName -ne 'OFFLINE_PACKAGE_MANIFEST.json' })
    if ($actualEntries.Count -ne $listed.Count) { throw ('Archive entry count mismatch. Listed {0}; found {1}.' -f $listed.Count, $actualEntries.Count) }
    foreach ($entry in $actualEntries) { if (!$listed.ContainsKey($entry.FullName)) { throw ('Unlisted archive entry: ' + $entry.FullName) } }
    Write-Host ('PASS: Offline package integrity verified ({0} files, release {1}).' -f $listed.Count, $manifest.app_release) -ForegroundColor Green
    if ($manifest.includes_user_data) { Write-Host 'WARNING: This archive includes private user data.' -ForegroundColor Yellow }
    else { Write-Host 'Private user data was excluded.' -ForegroundColor Cyan }
} finally { $zip.Dispose() }
