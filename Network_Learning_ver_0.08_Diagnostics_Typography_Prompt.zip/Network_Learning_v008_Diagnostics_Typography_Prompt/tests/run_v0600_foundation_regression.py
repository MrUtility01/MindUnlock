#!/usr/bin/env python3
"""Regression suite inherited from the 0.6.0 LAN foundation, executed against ver 0.08."""
from __future__ import annotations
import base64, importlib.util, json, shutil, sqlite3, subprocess, sys, tempfile, zipfile
from io import BytesIO
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
TMP = Path(tempfile.mkdtemp(prefix='network-learning-v0600-'))
client = None
checks = []
def check(name, condition, detail=''):
    if not condition:
        raise AssertionError(f'FAIL: {name}: {detail}')
    checks.append(name)

try:
    for name in ('app.py','static','VERSION.txt','tts_worker.py','launch_server.py'):
        src, dst = ROOT/name, TMP/name
        if src.is_dir(): shutil.copytree(src, dst)
        else: shutil.copy2(src, dst)
    (TMP/'data').mkdir(exist_ok=True)
    (TMP/'data'/'media').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v0600_app',TMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    client=TestClient(mod.app,client=('127.0.0.1',16000))
    health=client.get('/api/health')
    check('release version','0.08' == health.json().get('version'),health.text)
    check('unauthenticated data API is gated', client.get('/api/topics').status_code == 401)

    password='FoundationPassword2026!'
    setup=client.post('/api/auth/setup',json={'username':'admin.root','password':password})
    check('strong first-admin setup',setup.status_code==200,setup.text)
    check('current admin session',client.get('/api/auth/status').json().get('role')=='admin')

    topic=client.post('/api/topics',json={'title':'مسیر تخصصی تست نفوذ','description':'مسیر نمونهٔ قابل واردسازی؛ این عنوان فقط در تست ایزوله است.','features':{'lessons':True,'questions':True,'flashcards':True,'commands':True,'labs':True,'images':True,'sources':True}})
    check('create topic',topic.status_code==200,topic.text)
    topic_id=topic.json()['id']

    # ZIP with a single canonical unified content pack and image path; test all paths without user data.
    pack={
      'format':'network-learning-content-pack-v2','version':2,'title':'بستهٔ تست واردسازی','topic':{'title':'مسیر تخصصی تست نفوذ'},
      'chapters':[{'id':'foundation-ch01','title':'مرحلهٔ اول: مبانی و آزمایشگاه مجاز','slug':'stage-01','order_num':1,'description':'فصل آزمایشی'}],
      'items':[
        {'chapter_id':'foundation-ch01','kind':'lesson','title':'محدودهٔ مجاز آزمایش','summary':'درس پایه','content':'## هدف\nمحیط آزمایش باید متعلق به خودت یا دارای مجوز روشن باشد.\n\n![نمودار](assets/stage-01/lab.png)','source_uid':'foundation-lesson-001','source_status':'verified','metadata':{}},
        {'chapter_id':'foundation-ch01','kind':'question','title':'پیش از آزمون چه چیزی لازم است؟','summary':'سؤال تأییدی','content':'','source_uid':'foundation-question-001','source_status':'verified','metadata':{'question':'پیش از آزمون چه چیزی لازم است؟','options':['مجوز روشن','فقط اتصال به شبکه','هیچ چیز','فقط نصب ابزار'],'correct_index':0,'explanation':'محدوده و مجوز باید روشن باشد.'}},
        {'chapter_id':'foundation-ch01','kind':'flashcard','title':'محدودهٔ آزمون','summary':'کارت','content':'مجوز کتبی','source_uid':'foundation-card-001','source_status':'verified','metadata':{'front':'محدودهٔ مجاز چیست؟','back':'سامانه‌ها و روش‌هایی که صریحاً اجازهٔ آزمون دارند.'}},
        {'chapter_id':'foundation-ch01','kind':'asset','title':'lab.png','summary':'تصویر آزمایش','content':'assets/stage-01/lab.png','source_uid':'foundation-asset-001','source_status':'verified','metadata':{'file_name':'assets/stage-01/lab.png','asset_type':'diagram'}},
        {'chapter_id':'foundation-ch01','kind':'asset','title':'درخت تصمیم مفهومی','summary':'این تصویر از روی پرامپت باید ساخته شود.','content':'','source_uid':'foundation-asset-prompt-001','source_status':'review_required','metadata':{'asset_type':'infographic','output_status':'prompt_only_not_generated','prompt_fa':'یک نمودار آموزشی از مفهوم اصلی بساز.','prompt_en':'Create a clear educational diagram.'}}
      ]
    }
    # Known valid 1x1 PNG image bytes.
    png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/pWQAAAAASUVORK5CYII=')
    buffer=BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
      z.writestr('package_manifest.json',json.dumps({'format':'network-learning-course-package-v1','version':1},ensure_ascii=False))
      z.writestr('content_pack.json',json.dumps(pack,ensure_ascii=False))
      z.writestr('assets/stage-01/lab.png',png)
    zip_bytes=buffer.getvalue()
    preview=client.post('/api/import/preview',files=[('files',('course_package.zip',zip_bytes,'application/zip'))],data={'mode':'auto','target_topic_id':topic_id})
    check('unified zip preview endpoint',preview.status_code==200,preview.text)
    preview_json=preview.json()
    check('preview detects new chapter',any(x.get('title')=='مرحلهٔ اول: مبانی و آزمایشگاه مجاز' for x in preview_json['chapters']),json.dumps(preview_json,ensure_ascii=False)[:1200])
    imported=client.post('/api/import',files=[('files',('course_package.zip',zip_bytes,'application/zip'))],data={'mode':'auto','target_topic_id':topic_id})
    check('unified zip imported',imported.status_code==200,imported.text)
    result=imported.json()['summary']
    check('import contains no errors',not result.get('errors'),json.dumps(result,ensure_ascii=False))
    check('imported lesson+question+card+asset+prompt note',sum(int(result.get(k,0) or 0) for k in ('lessons','questions','cards','assets','notes'))>=5,json.dumps(result,ensure_ascii=False))
    with mod.connect() as c:
      ch=c.execute("SELECT ch.id,ch.title,ct.topic_id FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ch.title=?",('مرحلهٔ اول: مبانی و آزمایشگاه مجاز',)).fetchone()
      items=c.execute("SELECT kind,content,source_status,metadata_json FROM items WHERE chapter_id=?",(ch['id'],)).fetchall() if ch else []
    check('chapter assigned to selected topic',bool(ch and ch['topic_id']==topic_id),str(dict(ch) if ch else None))
    check('all imported data needs review',bool(items) and all(r['source_status']=='review_required' for r in items),str([(r['kind'],r['source_status']) for r in items]))
    check('image saved, lesson link rewritten, prompt-only visual retained as note',any(r['kind']=='asset' and r['content'].startswith('/media/') for r in items) and any('/media/' in r['content'] for r in items if r['kind']=='lesson') and any(r['kind']=='note' and json.loads(r['metadata_json']).get('visual_prompt_only') for r in items))

    # Authoring-kit sample content must not be imported.
    sample={**pack,'sample_only':True}
    b=BytesIO()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('content_pack.json',json.dumps(sample,ensure_ascii=False))
    bad=client.post('/api/import',files=[('files',('sample.zip',b.getvalue(),'application/zip'))],data={'mode':'auto','target_topic_id':topic_id})
    check('sample zip rejected without importing',bad.status_code==200 and bool(bad.json().get('summary',{}).get('errors')),bad.text)

    # Account management, learner permission boundary, and session refresh retains identity.
    made=client.post('/api/users',json={'username':'student.one','password':'StudentPassword2026!','role':'learner'})
    check('create learner account',made.status_code==200,made.text)
    learner=TestClient(mod.app,client=('127.0.0.1',16001))
    login=learner.post('/api/auth/login',json={'username':'student.one','password':'StudentPassword2026!'})
    check('learner login',login.status_code==200,login.text)
    activity=learner.post('/api/auth/activity')
    check('session activity refresh',activity.status_code==200,activity.text)
    status=learner.get('/api/auth/status').json()
    check('refresh retains learner identity',status.get('username')=='student.one' and status.get('role')=='learner',json.dumps(status,ensure_ascii=False))
    blocked=learner.post('/api/topics',json={'title':'No permission','description':'','features':{}})
    check('learner cannot create topics',blocked.status_code==403,blocked.text)
    allowed=learner.get('/api/items')
    check('learner can read approved study API',allowed.status_code==200,allowed.text[:300])

    # IP/CIDR ACL enforcement at the server middleware boundary.
    network=client.put('/api/network/config',json={'port':8188,'bind_host':'0.0.0.0','acl_enabled':True,'require_allowlist':True,'allowlist':'192.168.1.0/24','denylist':'192.168.1.99'})
    check('save network port and ACL',network.status_code==200,network.text)
    saved=client.get('/api/network/config').json()['network']
    check('network settings persist',saved['port']==8188 and saved['acl_enabled'] and '192.168.1.0/24' in saved['allowlist'])
    allowed_remote=TestClient(mod.app,client=('192.168.1.23',16002))
    allowed_remote.cookies.update(client.cookies)
    remote_health=allowed_remote.get('/api/health')
    check('IP inside allowlisted CIDR admitted',remote_health.status_code==200,remote_health.text)
    denied_remote=TestClient(mod.app,client=('10.10.10.5',16003))
    denied_remote.cookies.update(client.cookies)
    denied_health=denied_remote.get('/api/health')
    check('IP outside allowlist denied',denied_health.status_code==403,denied_health.text)
    deny_remote=TestClient(mod.app,client=('192.168.1.99',16004))
    deny_remote.cookies.update(client.cookies)
    check('explicit deny beats allow',deny_remote.get('/api/health').status_code==403)

    port=subprocess.run([sys.executable,str(TMP/'launch_server.py'),'--print-port'],capture_output=True,text=True,timeout=10)
    check('launcher reads configured port',port.returncode==0 and port.stdout.strip()=='8188',port.stdout+' '+port.stderr)
    host=subprocess.run([sys.executable,str(TMP/'launch_server.py'),'--print-host'],capture_output=True,text=True,timeout=10)
    check('launcher reads configured bind host',host.returncode==0 and host.stdout.strip()=='0.0.0.0',host.stdout+' '+host.stderr)

    html=(ROOT/'static/index.html').read_text(encoding='utf-8')
    check('frontend sends all authoring count settings',all(x in html[html.index('collectTopicPromptPayload=function'):html.index('collectTopicPromptPayload=function')+500] for x in ('flashcards_per_lesson','notes_per_chapter','commands_per_chapter','labs_per_chapter','images_per_chapter')))
    check('new network and user settings UI',all(x in html for x in ('networkAdminPanel','userAdminPanel','netAllowlist','newUserForm')))
    check('PWA cache bumped','nla-shell-v009' in (ROOT/'static/sw.js').read_text(encoding='utf-8'))
    print('PASS: '+', '.join(checks))
    print(f'RESULT: PASS ({len(checks)} checks)')
finally:
    if client: client.close()
    shutil.rmtree(TMP,ignore_errors=True)
