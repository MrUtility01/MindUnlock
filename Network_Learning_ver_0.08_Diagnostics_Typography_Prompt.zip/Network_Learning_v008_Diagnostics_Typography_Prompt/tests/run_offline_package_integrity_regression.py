"""Static checks for creation and verification of a portable offline archive."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
builder = (ROOT / 'create_offline_portable_zip.ps1').read_text(encoding='utf-8-sig').lower()
verifier = (ROOT / 'verify_offline_portable_package.ps1').read_text(encoding='utf-8-sig').lower()
bat = (ROOT / 'create_offline_portable_zip.bat').read_text(encoding='utf-8-sig').lower()
checks = {
    'builder_requires_readiness_marker_and_embedded_python': '.portable-ready.json' in builder and '.portable-python\\python.exe' in builder,
    'builder_checks_persian_model_hash_and_ready_marker': 'expectedmodelhash' in builder and 'readydata.model_sha256' in builder,
    'builder_checks_config_json': 'convertfrom-json' in builder and 'modelconfig' in builder,
    'builder_runs_dependency_smoke_test': 'import sys,fastapi,uvicorn,multipart,docx,pypdf,piper,onnxruntime' in builder,
    'user_data_is_not_included_without_explicit_yes': "-ceq 'yes'" in builder and 'private user data' in builder,
    'manifest_records_sha256_and_sizes': 'sha256' in builder and 'size_bytes' in builder and 'offline_package_manifest.json' in builder,
    'builder_verifies_archive_after_creation': 'verify_offline_portable_package.ps1' in builder,
    'verifier_checks_every_file_hash': 'computehash($stream)' in verifier and 'sha-256 mismatch' in verifier,
    'verifier_rejects_unsafe_or_duplicate_paths': 'unsafe manifest path' in verifier and 'duplicate manifest path' in verifier,
    'verifier_rejects_unlisted_archive_entries': 'unlisted archive entry' in verifier,
    'bat_invokes_builder': 'create_offline_portable_zip.ps1' in bat,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print('RESULT: PASS')
