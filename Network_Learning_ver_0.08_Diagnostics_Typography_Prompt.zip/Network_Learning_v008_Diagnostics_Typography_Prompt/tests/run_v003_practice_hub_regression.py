from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
html = (root / "static" / "index.html").read_text(encoding="utf-8")
checks = {
    "practice navigation exists": 'data-view="practice"' in html,
    "practice view exists": 'id="view-practice"' in html,
    "lab list uses existing item API": "api('/api/items?kind=lab&limit=100&offset=0&topic_id=')" in html,
    "prompt generator exists": "function generatePracticePrompt()" in html,
    "prompt copy action exists": "function copyPracticePrompt()" in html,
    "prompt TXT export exists": "function downloadPracticePrompt()" in html,
    "skills checklist is persisted locally": "nl_practice_skills_v1" in html,
    "practice view loads on navigation": "if(view==='practice')loadPracticeHub()" in html,
    "prompt includes solution and grading rubric": "راه‌حل تشریحی جداگانه" in html and "rubric امتیازدهی از 100" in html,
    "safety scope included": "هدف واقعی/شخص ثالث" in html,
    "service worker cache bumped": "nla-shell-v009" in (root / "static" / "sw.js").read_text(encoding="utf-8"),
    "persistent practice attempt API": "@app.post('/api/practice/attempts')" in (root / "app.py").read_text(encoding="utf-8"),
    "staged hint and solution API": "@app.get('/api/practice/lab/{item_id}/hint')" in (root / "app.py").read_text(encoding="utf-8") and "@app.get('/api/practice/lab/{item_id}/solution')" in (root / "app.py").read_text(encoding="utf-8"),
    "fresh installs do not seed incomplete starter content": "starter_log_course_v1" not in (root / "app.py").read_text(encoding="utf-8"),
    "backup includes practice attempts": "practice_attempts=[dict(r) for r in c.execute" in (root / "app.py").read_text(encoding="utf-8"),
}
for name, ok in checks.items(): print(("PASS" if ok else "FAIL") + ": " + name)
print(f"RESULT: {'PASS' if all(checks.values()) else 'FAIL'} ({sum(checks.values())}/{len(checks)} checks)")
sys.exit(0 if all(checks.values()) else 1)
