#!/usr/bin/env python3
"""Compatibility entry point for the current ver 0.08 startup tests."""
from pathlib import Path
import runpy
ROOT=Path(__file__).resolve().parents[1]
runpy.run_path(str(ROOT/'tests'/'run_v001_startup_regression.py'),run_name='__main__')
