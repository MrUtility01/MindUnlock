#!/usr/bin/env python3
"""Isolated API regression for user-imported practice content, staged hints and backup round-trip."""
from pathlib import Path
import importlib.util, json, shutil, sys, tempfile
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v003-practice-'))
checks=[]
def check(name, ok, detail=''):
    if not ok: raise AssertionError(f'FAIL: {name}: {detail}')
    checks.append(name)
try:
    for name in ('app.py','static','VERSION.txt','tts_worker.py','launch_server.py'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
    (TMP/'data').mkdir(exist_ok=True); (TMP/'data'/'media').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v003_practice_app',TMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    client=TestClient(mod.app,client=('127.0.0.1',16433))
    check('health version 0.08',client.get('/api/health').json().get('version')=='0.08')
    setup=client.post('/api/auth/setup',json={'username':'practice.admin','password':'PracticeRegressionPassword2026!'})
    check('admin setup',setup.status_code==200,setup.text)
    with mod.connect() as c:
        empty_before=c.execute('SELECT COUNT(*) n FROM chapters').fetchone()['n']
        check('fresh install starts without default chapters',empty_before==0,str(empty_before))
        c.execute("INSERT INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)",('test-topic','تمرین آزمایشی','', '{}',mod.now_iso(),mod.now_iso()))
        c.execute("INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)",('test-chapter','فصل آزمایشی',1,'main','test-fixture','',mod.now_iso()))
        c.execute("INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?)",('test-chapter','test-topic'))
        meta={'hints':['راهنمایی اول','راهنمایی دوم'],'solution':'راه‌حل آزمایشی تشریحی','rubric':[{'criterion':'توضیح درست','points':100}]}
        c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",('test-chapter','lab','تمرین آزمایشی','سناریوی تست','صورت مسئله','verified','test-fixture','test-lab-1',json.dumps(meta,ensure_ascii=False),mod.now_iso()))
        c.commit()
        labs=[dict(r) for r in c.execute("SELECT id,title,metadata_json FROM items WHERE kind='lab' AND source_file='test-fixture' ORDER BY id")]
        starter_chapters=c.execute("SELECT COUNT(*) n FROM chapters WHERE source='starter_log_course_v1'").fetchone()['n']
    check('no bundled starter topic is seeded',client.get('/api/topics').status_code==200 and 'topic_log_threat_hunting' not in [x.get('id') for x in client.get('/api/topics').json().get('topics',[])])
    check('no bundled starter course rows',starter_chapters==0)
    check('test fixture lab created',len(labs)==1,str(len(labs)))
    item_id=labs[0]['id']
    detail=client.get(f'/api/practice/lab/{item_id}')
    check('practice detail omits solution/hints',detail.status_code==200 and 'solution' not in detail.json()['metadata'] and 'hints' not in detail.json()['metadata'],detail.text[:200])
    hint=client.get(f'/api/practice/lab/{item_id}/hint?step=1')
    check('hint endpoint returns one hint',hint.status_code==200 and hint.json().get('step')==1 and hint.json().get('hint'))
    blocked=client.get(f'/api/practice/lab/{item_id}/solution')
    check('solution gated before attempt',blocked.status_code==409,blocked.text[:120])
    saved=client.post('/api/practice/attempts',json={'item_id':item_id,'answer':'severity 2 را اول بررسی می‌کنم و زمینه را هم می‌سنجم.','self_score':80,'hints_used':1,'duration_seconds':72})
    check('attempt saved',saved.status_code==200 and saved.json().get('attempt_count')==1,saved.text[:200])
    summary=client.get('/api/practice/summary').json()
    check('summary records attempt and score',summary.get('total_attempts')==1 and summary['labs'][str(item_id)]['latest_score']==80,json.dumps(summary,ensure_ascii=False)[:300])
    solution=client.get(f'/api/practice/lab/{item_id}/solution')
    check('solution unlocks after attempt',solution.status_code==200 and solution.json().get('solution') and solution.json().get('rubric'))
    export=client.get('/api/export')
    backup=export.json()
    check('export schema 4 includes practice attempt',backup.get('backup_schema_version')==5 and len(backup.get('practice_attempts',[]))==1)
    preview=client.post('/api/restore/preview',files={'file':('network-learning-backup.json',json.dumps(backup,ensure_ascii=False).encode('utf-8'),'application/json')})
    check('restore preview validates practice history',preview.status_code==200 and preview.json().get('ok') and preview.json()['counts'].get('practice_attempts')==1,preview.text[:300])
    restored=client.post('/api/restore',files={'file':('network-learning-backup.json',json.dumps(backup,ensure_ascii=False).encode('utf-8'),'application/json')},data={'mode':'replace'})
    check('actual restore preserves practice attempt',restored.status_code==200 and client.get('/api/practice/summary').json().get('total_attempts')==1,restored.text[:300])
    status=client.get('/api/backup/status').json()
    check('backup status counts practice attempts',status.get('counts',{}).get('practice_attempts')==1)
    mod.init_db()
    with mod.connect() as c:
        chapters_again=c.execute("SELECT COUNT(*) n FROM chapters WHERE source='starter_log_course_v1'").fetchone()['n']
        labs_again=c.execute("SELECT COUNT(*) n FROM items WHERE kind='lab' AND source_file='test-fixture'").fetchone()['n']
        attempts_again=c.execute('SELECT COUNT(*) n FROM practice_attempts').fetchone()['n']
    check('startup does not add defaults and keeps user content/history',chapters_again==0 and labs_again==1 and attempts_again==1,f'chapters={chapters_again}, labs={labs_again}, attempts={attempts_again}')
    print('\n'.join('PASS: '+x for x in checks));print(f'RESULT: PASS ({len(checks)} checks)')
finally:
    shutil.rmtree(TMP,ignore_errors=True)
