from pathlib import Path
import importlib.util, json, shutil, sys, tempfile
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v005-'))
checks=[]
def check(n,ok,detail=''):
    if not ok: raise AssertionError(f'FAIL {n}: {detail}')
    checks.append(n)
try:
    for name in ('app.py','static','config','schemas','VERSION.txt','tts_worker.py','launch_server.py'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
    (TMP/'data').mkdir(exist_ok=True); (TMP/'data'/'media').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v005_test',TMP/'app.py'); mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
    c=TestClient(mod.app,client=('127.0.0.1',16705))
    setup=c.post('/api/auth/setup',json={'username':'admin05','password':'RegressionPass-2026-Strong!'})
    check('first-run admin setup',setup.status_code==200,setup.text[:150])
    check('version 0.08',c.get('/api/health').json().get('version')=='0.08')
    check('fresh DB has no chapters',c.get('/api/state').json().get('totals',{}).get('chapters',0)==0)
    profiles=c.get('/api/course-builder/profiles').json(); check('eight profiles retained',len(profiles['profiles'])>=8)
    check('eight prompt models exposed',len(profiles['prompt_models'])==8)
    empty_backup=c.get('/api/export').json()
    empty_preview=c.post('/api/restore/preview',files={'file':('empty-backup.json',json.dumps(empty_backup,ensure_ascii=False).encode(),'application/json')})
    check('empty workspace backup preview is valid',empty_preview.status_code==200 and empty_preview.json().get('ok'),empty_preview.text[:180])
    empty_restore=c.post('/api/restore',files={'file':('empty-backup.json',json.dumps(empty_backup,ensure_ascii=False).encode(),'application/json')},data={'mode':'replace'})
    check('empty workspace backup restore is valid',empty_restore.status_code==200,empty_restore.text[:180])
    base={'title':'عیب‌یابی شبکه و دامین','domain_profile':'network_it','level':'intermediate','goal':'practice','format':'mixed','chapter_count':10,'weekly_hours':8,'prompt_model':'troubleshooting','depth':'reference','scope':'DNS؛ DHCP؛ Active Directory؛ PowerShell؛ عیب‌یابی و تعمیر','prerequisites':'TCP/IP و Windows Server','platforms':'Windows Server 2022، PowerShell 7','include_troubleshooting':True,'include_commands':True,'include_pitfalls':True,'include_security':True,'include_verification':True,'include_variants':True}
    r=c.post('/api/course-builder/preview',json=base); check('expanded preview returns 200',r.status_code==200,r.text[:250]); d=r.json();
    check('selected prompt model persisted in blueprint',d['blueprint']['prompt_model']=='troubleshooting')
    check('scope included in blueprint',d['blueprint']['scope']==base['scope'])
    check('prompt includes root cause and rollback','علت ریشه‌ای' in d['prompt'] and 'rollback' in d['prompt'].lower())
    check('prompt includes PowerShell and domain troubleshooting','PowerShell' in d['prompt'] and 'Active Directory' in d['prompt'])
    check('prompt warns against fabricated sources','منبع' in d['prompt'] and 'ساختگی' in d['prompt'])
    for model in profiles['prompt_models']:
        req=dict(base,prompt_model=model)
        x=c.post('/api/course-builder/preview',json=req)
        check('prompt model '+model,x.status_code==200 and x.json()['blueprint']['prompt_model']==model,x.text[:100])
    invalid=c.post('/api/course-builder/preview',json=dict(base,prompt_model='not-a-model'))
    check('invalid prompt model rejected',invalid.status_code==400)
    saved=c.post('/api/course-builder/blueprints',json=base); check('expanded blueprint saves',saved.status_code==200,saved.text[:200])
    check('saved blueprint retains selected prompt model',c.get('/api/course-builder/blueprints/'+saved.json()['id']).json()['blueprint']['prompt_model']=='troubleshooting')
    html=(ROOT/'static'/'index.html').read_text(encoding='utf-8')
    check('course title no longer prefilled with sample', 'id="cbTitle" maxlength="240" required value=' not in html)
    check('prompt selector in UI','id="cbPromptModel"' in html)
    check('expanded scope controls in UI','id="cbScope"' in html and 'id="cbPlatforms"' in html)
    print('\n'.join('PASS: '+x for x in checks)); print(f'RESULT: PASS ({len(checks)} checks)')
finally: shutil.rmtree(TMP,ignore_errors=True)
