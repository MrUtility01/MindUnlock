from pathlib import Path
import importlib.util,json,shutil,sys,tempfile
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v004-'))
checks=[]
def check(name,ok,detail=''):
    if not ok: raise AssertionError(f'FAIL {name}: {detail}')
    checks.append(name)
try:
    for name in ('app.py','static','config','schemas','VERSION.txt','tts_worker.py','launch_server.py'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
    (TMP/'data').mkdir(exist_ok=True);(TMP/'data'/'media').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v004_app',TMP/'app.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    client=TestClient(mod.app,client=('127.0.0.1',16434))
    check('health reports v0.08',client.get('/api/health').json().get('version')=='0.08')
    check('admin setup',client.post('/api/auth/setup',json={'username':'admin04','password':'RegressionPass-2026-Strong!'}).status_code==200)
    arch=client.get('/api/learning/architecture').json();check('eight domain profiles available',len(arch.get('profiles',{}))>=8)
    check('shared capabilities listed',len(arch.get('shared_capabilities',[]))>=8)
    req={'title':'دورهٔ امنیت نمونه','domain_profile':'cybersecurity','level':'beginner','goal':'practice','format':'mixed','chapter_count':10,'weekly_hours':6,'environment':'VM ایزوله','include_practice':True,'include_quiz':True,'include_flashcards':True,'include_project':True,'sources_required':True}
    prev=client.post('/api/course-builder/preview',json=req);check('course preview works',prev.status_code==200,prev.text[:200]);bp=prev.json()['blueprint'];check('course blueprint has ten chapters',len(bp['chapters'])==10);check('cyber rubric safety gate',bp['pass_policy']['safety_gate'] is True);check('prompt includes safe lab limits','آزمایشگاه ایزوله' in prev.json()['prompt'])
    saved=client.post('/api/course-builder/blueprints',json=req);check('blueprint persisted',saved.status_code==200,saved.text[:200]);bid=saved.json()['id'];check('blueprint get works',client.get('/api/course-builder/blueprints/'+bid).status_code==200)
    check('blueprint list includes saved',any(x['id']==bid for x in client.get('/api/course-builder/blueprints').json()['blueprints']))
    pack={'format':'network-learning-content-pack-v2','title':'نمونه','chapters':[{'id':'ch01','title':'فصل ۱'}],'items':[{'uid':'l1','chapter_id':'ch01','kind':'lesson','title':'درس','content':'متن'}]}
    val=client.post('/api/course-builder/validate-pack',json={'pack':pack});check('valid pack accepted for review',val.status_code==200 and val.json()['ok'],val.text[:200])
    bad={'format':'wrong','title':'','chapters':[{'id':'x','title':'فصل'},{'id':'x','title':'تکراری'}],'items':[{'chapter_id':'missing','kind':'question','title':'سؤال','metadata':{'options':['الف','ب'],'correct_index':8}}]}
    valbad=client.post('/api/course-builder/validate-pack',json={'pack':bad}).json();check('invalid package reports structural errors',not valbad['ok'] and len(valbad['errors'])>=4)
    check('import validator rejects malformed v2 packs',len(mod.validate_content_pack_v2_data(bad))>=4)
    ev=client.post('/api/learning/competencies/evidence',json={'domain_profile':'cybersecurity','competency_id':'comp-01','competency_title':'ignored title','status':'demonstrated','score':90,'evidence':'تمرین آزمایشگاهی تکمیل شد'})
    check('competency evidence saves',ev.status_code==200,ev.text[:200]);cl=client.get('/api/learning/competencies?domain_profile=cybersecurity').json();check('competency evidence persists',cl['items'][0]['status']=='demonstrated' and cl['items'][0]['score']==90)
    backup=client.get('/api/export').json();check('backup schema v5 contains new records',backup['backup_schema_version']==5 and len(backup['course_blueprints'])==1 and len(backup['competency_evidence'])==1)
    status=client.get('/api/backup/status').json();check('backup status counts new architecture data',status['counts'].get('course_blueprints')==1 and status['counts'].get('competency_evidence')==1)
    prevrestore=client.post('/api/restore/preview',files={'file':('backup.json',json.dumps(backup,ensure_ascii=False).encode(),'application/json')});check('backup preview accepts schema v5',prevrestore.status_code==200 and prevrestore.json()['ok'],prevrestore.text[:200])
    restored=client.post('/api/restore',files={'file':('backup.json',json.dumps(backup,ensure_ascii=False).encode(),'application/json')},data={'mode':'replace'});check('restore preserves blueprint and evidence',restored.status_code==200,restored.text[:200]);check('post-restore records exist',len(client.get('/api/course-builder/blueprints').json()['blueprints'])==1 and client.get('/api/learning/competencies?domain_profile=cybersecurity').json()['items'][0]['status']=='demonstrated')
    learner=client.post('/api/users',json={'username':'learner04','password':'LearnerPass-2026-Strong!','role':'learner'})
    check('admin can create learner for permission test',learner.status_code in (200,201),learner.text[:200])
    login=client.post('/api/auth/login',json={'username':'learner04','password':'LearnerPass-2026-Strong!'})
    check('learner login works',login.status_code==200,login.text[:200])
    ev2=client.post('/api/learning/competencies/evidence',json={'domain_profile':'cybersecurity','competency_id':'comp-02','competency_title':'ignored','status':'practicing','score':50,'evidence':'تمرین اولیه'})
    check('learner can record own competency evidence',ev2.status_code==200,ev2.text[:200])
    print('\n'.join('PASS: '+x for x in checks));print(f'RESULT: PASS ({len(checks)} checks)')
finally: shutil.rmtree(TMP,ignore_errors=True)
