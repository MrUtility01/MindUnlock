#!/usr/bin/env python3
"""Verify that release-manifest file paths and SHA-256 hashes for the current ver 0.08 baseline are consistent."""
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'PACKAGE_FILE_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest.get('version')=='0.08', manifest.get('version')
entries=manifest.get('files')
assert isinstance(entries,list) and manifest.get('file_count')==len(entries)
seen=set()
for row in entries:
    rel=row['path']; p=Path(rel)
    assert rel not in seen, rel
    seen.add(rel)
    assert '..' not in p.parts and not p.is_absolute(), rel
    f=ROOT/rel
    assert f.is_file(), f'missing release file: {rel}'
    data=f.read_bytes()
    assert len(data)==row['size_bytes'], f'size mismatch: {rel}'
    assert hashlib.sha256(data).hexdigest()==row['sha256'], f'hash mismatch: {rel}'
    assert not ({'__pycache__','.pytest_cache','.venv','venv','.tts-venv'} & set(p.parts)), rel
    assert not rel.endswith(('.pyc','.pyo','.db','.db-wal','.db-shm','.log')), rel
assert 'data/.gitkeep' in seen and 'data/media/.gitkeep' in seen
assert 'app.py' in seen and 'launch_server.py' in seen and 'README_FA.md' in seen
assert not any(p.startswith('android/') or p.startswith('data/network_learning.db') for p in seen)
print(f'PASS: {len(entries)} release files match sizes and SHA-256; runtime DB, caches and virtualenvs are excluded.')
