#!/usr/bin/env python3
"""Regression tests for hierarchy-aware ZIP import, authoring prompts, and the tree UI."""
from __future__ import annotations
import importlib.util, json, shutil, sys, tempfile, zipfile, re
from io import BytesIO
from pathlib import Path
from fastapi.testclient import TestClient

ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v10-hierarchy-'))
checks=[]
def check(name, condition, detail=''):
    if not condition: raise AssertionError(f'FAIL: {name}: {detail}')
    checks.append(name)

try:
    for name in ('app.py','static','VERSION.txt','tts_worker.py','launch_server.py'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
    (TMP/'data'/'media').mkdir(parents=True,exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v10_test_app',TMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    # This test targets import hierarchy only; remove the default starter course from
    # its isolated temporary database so its original one-chapter assertion stays focused.
    with mod.connect() as c:
        c.execute("DELETE FROM chapter_topics WHERE topic_id='topic_log_threat_hunting'")
        c.execute("DELETE FROM items WHERE source_file='starter-course:logsec-v1'")
        c.execute("DELETE FROM chapters WHERE source='starter_log_course_v1'")
        c.execute("DELETE FROM topics WHERE id='topic_log_threat_hunting'")
        c.execute("DELETE FROM settings WHERE key='starter_log_course_v1'")
        c.commit()
    client=TestClient(mod.app,client=('127.0.0.1',17020))
    login=client.post('/api/auth/setup',json={'username':'admin.root','password':'HierarchyTestPassword2026!'})
    check('test admin setup',login.status_code==200,login.text)
    topic=client.post('/api/topics',json={'title':'موضوع تست ساختار','description':'برای تست موقت','features':{'lessons':True,'questions':True,'flashcards':True,'commands':True,'labs':True,'images':True,'sources':True}})
    check('test topic created',topic.status_code==200,topic.text)
    tid=topic.json()['id']

    files={
      'chapter-01/manifest.json':{'title':'فصل ۱: مبانی شبکه','slug':'network-basics','type':'chapter'},
      'chapter-01/lessons.json':{'items':[{'uid':'lesson-root-01','title':'مفهوم پایه','content':'محتوای ریشه'}]},
      'chapter-01/addressing/manifest.json':{'title':'آدرس‌دهی IP','slug':'ip-addressing','type':'chapter'},
      'chapter-01/addressing/lessons.json':{'items':[{'uid':'lesson-sub-01','title':'Subnetting','content':'محتوای زیر‌فصل'}]},
    }
    payload=BytesIO()
    with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED) as z:
        for path,obj in files.items(): z.writestr(path,json.dumps(obj,ensure_ascii=False))
    raw=payload.getvalue()
    preview=client.post('/api/import/preview',files=[('files',('one-chapter.zip',raw,'application/zip'))],data={'mode':'auto','target_topic_id':tid})
    check('ZIP preview responds',preview.status_code==200,preview.text)
    pv=preview.json()
    check('nested manifest preview has one chapter',len(pv.get('chapters',[]))==1,json.dumps(pv,ensure_ascii=False)[:1000])
    check('nested manifest preview exposes subsection',len(pv.get('subchapters',[]))==1,json.dumps(pv,ensure_ascii=False)[:1000])
    imported=client.post('/api/import',files=[('files',('one-chapter.zip',raw,'application/zip'))],data={'mode':'auto','target_topic_id':tid})
    check('nested ZIP import accepted',imported.status_code==200,imported.text)
    result=imported.json().get('summary',{})
    check('nested ZIP makes one chapter',result.get('chapters_created')==1,json.dumps(result,ensure_ascii=False))
    with mod.connect() as c:
        chapters=c.execute('SELECT id,title FROM chapters').fetchall()
        subsection_item=c.execute("SELECT metadata_json FROM items WHERE source_uid='lesson-sub-01'").fetchone()
    check('one chapter row exists',len(chapters)==1,str([dict(x) for x in chapters]))
    metadata=json.loads(subsection_item['metadata_json']) if subsection_item else {}
    check('subsection metadata persists to content',metadata.get('source_subchapter_title')=='آدرس‌دهی IP',json.dumps(metadata,ensure_ascii=False))

    prompt=client.post('/api/topics/prompt-preview',json={'topic_id':tid,'chapter_titles':['فصل ۱: مبانی شبکه','آدرس‌دهی IP','VLAN و سوئیچینگ'], 'structure_mode':'single_chapter_subsections','chapter_numbering_mode':'app_order'})
    check('prompt preview responds',prompt.status_code==200,prompt.text[:600])
    spec_data=prompt.json().get('spec',{})
    check('single chapter prompt keeps first title only',spec_data.get('generation',{}).get('chapter_titles')==['فصل ۱: مبانی شبکه'],json.dumps(spec_data.get('generation'),ensure_ascii=False))
    check('prompt stores remaining titles as subsections',spec_data.get('generation',{}).get('subchapter_titles')==['آدرس‌دهی IP','VLAN و سوئیچینگ'],json.dumps(spec_data.get('generation'),ensure_ascii=False))
    check('prompt numbering is app-managed',spec_data.get('chapter_numbering',{}).get('mode')=='app_order' and 'exclusively assigns display sequence' in spec_data.get('chapter_numbering',{}).get('policy',''),json.dumps(spec_data.get('chapter_numbering'),ensure_ascii=False))

    html=(TMP/'static'/'index.html').read_text(encoding='utf-8')
    check('dedicated complete contents menu exists','data-view="catalog"' in html and 'فهرست کامل مطالب' in html)
    check('tree supports subsection metadata','source_subchapter_title' in html and 'tree-subchapter' in html)
    check('UI display number not read from package',"function chapterDisplayNumber(c,index){return index+1}" in html)
    check('study, notes, quiz and review redesign hooks exist',all(x in html for x in ('study-mode-banner','quizHeroState','reviewHeroDue','notesModeBanner')))
    print('PASS: '+', '.join(checks))
    print(f'RESULT: PASS ({len(checks)} checks)')
finally:
    shutil.rmtree(TMP,ignore_errors=True)
