#!/usr/bin/env python3
"""Regression for the v0.08 Piper NameError fix and responsive study/management layout."""
from pathlib import Path
import base64, importlib.util, io, json, shutil, sys, tempfile, wave
from types import SimpleNamespace
from unittest.mock import patch
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v007-layout-tts-'))
checks=[]
def check(name, condition, detail=''):
    if not condition: raise AssertionError(f'FAIL {name}: {detail}')
    checks.append(name)
client=None
try:
    for name in ('app.py','static','VERSION.txt','tts_worker.py'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
    (TMP/'data').mkdir(exist_ok=True); (TMP/'data'/'media').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v007_regression_app',TMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    client=TestClient(mod.app,client=('127.0.0.1',17707))
    check('release health reports 0.08',client.get('/api/health').json().get('version')=='0.08')
    setup=client.post('/api/auth/setup',json={'username':'ttsadmin','password':'StrongTestPassword-2026!'})
    check('isolated setup for TTS route tests',setup.status_code==200,setup.text[:100])
    check('subprocess imported in app runtime','sys, subprocess' in (ROOT/'app.py').read_text(encoding='utf-8'))
    # Simulate a known-good optional worker, so status and actual route exercise subprocess.run.
    candidate=TMP/'.tts-venv'/'Scripts'/'python.exe';candidate.parent.mkdir(parents=True);candidate.write_bytes(b'test-double')
    mod.PIPER_WORKER_CANDIDATES=[candidate]
    mod.PIPER_CONFIGURED_INTERPRETER=TMP/'missing-piper-python-path.txt'
    model=TMP/'models'/'mana-persian-piper'/'fa_IR-mana-medium.onnx'
    model.parent.mkdir(parents=True);model.write_bytes(b'fake-onnx-for-mocked-worker')
    Path(str(model)+'.json').write_text('{}',encoding='utf-8')
    mod.TTS_MODEL=model;mod.TTS_CONFIG=Path(str(model)+'.json')
    probe={'python':'3.14.3','bits':64,'compatible_python':True,'gil_enabled':True,'piper':True,'onnxruntime':True,'error':'','ok':True}
    audio=io.BytesIO()
    with wave.open(audio,'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(22050);w.writeframes(b'\x00\x00'*32)
    wav64=base64.b64encode(audio.getvalue()).decode('ascii')
    calls=[]
    def fake_run(args, **kwargs):
        calls.append(list(map(str,args)))
        if '-c' in args:
            return SimpleNamespace(returncode=0,stdout=json.dumps(probe),stderr='')
        return SimpleNamespace(returncode=0,stdout=json.dumps({'ok':True,'wav_base64':wav64}),stderr='')
    with patch.object(mod.subprocess,'run',side_effect=fake_run):
        status=client.get('/api/tts/status')
        check('TTS status uses the optional worker probe',status.status_code==200,status.text[:100])
        sd=status.json()
        check('worker import makes status ready when model exists',sd.get('piper_available') is True,repr(sd))
        check('worker runtime label identifies .tts-venv',sd.get('worker_runtime')=='.tts-venv',repr(sd.get('worker_runtime')))
        out=client.post('/api/tts/synthesize',json={'text':'سلام، این یک آزمون است.'})
        check('synthesis worker returns HTTP 200',out.status_code==200,out.text[:180])
        check('synthesis response is an actual WAV container',out.headers.get('content-type','').startswith('audio/wav') and out.content[:4]==b'RIFF',repr(out.headers))
    check('subprocess worker path was called for both probing and synthesis',len(calls)>=3,repr(calls))
    html=(ROOT/'static'/'index.html').read_text(encoding='utf-8')
    sw=(ROOT/'static'/'sw.js').read_text(encoding='utf-8')
    css_checks={
        'desktop sidebar is 60 percent at 156px': 'grid-template-columns: minmax(0, 1fr) 156px !important' in html and 'width:156px' in html,
        'quick content create form is three-column on desktop':'grid-template-columns:repeat(3,minmax(0,1fr))' in html and '#view-content #quickCreateForm' in html,
        'management filter grid is four-column':'#view-content .panel:has(#manageTopic)>.controls:first-child' in html and 'grid-template-columns:repeat(4,minmax(0,1fr))' in html,
        'bulk actions use a grid':'#view-content .bulk-toolbar { display:grid' in html,
        'narrow-screen responsive layout exists':'@media (max-width:650px)' in html and '#view-content .bulk-toolbar' in html,
        'navigation labels have native titles and aria labels':'button.setAttribute(\'title\',label)' in html and 'button.setAttribute(\'aria-label\',label)' in html,
        'service worker cache updated':'nla-shell-v009' in sw,
    }
    for name,ok in css_checks.items():check(name,ok)
    print('\n'.join('PASS: '+x for x in checks));print(f'RESULT: PASS ({len(checks)} checks)')
finally:
    if client: client.close()
    shutil.rmtree(TMP,ignore_errors=True)
