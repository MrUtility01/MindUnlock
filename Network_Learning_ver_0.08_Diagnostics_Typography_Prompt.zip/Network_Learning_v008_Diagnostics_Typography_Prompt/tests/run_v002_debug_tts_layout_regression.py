#!/usr/bin/env python3
"""Regression checks for v0.03 diagnostics, TTS environment probing, layout and topic numbering."""
from pathlib import Path
import importlib.util, json, shutil, sys, tempfile, subprocess, zipfile
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
app=(ROOT/'app.py').read_text(encoding='utf-8')
launch=(ROOT/'launch_server.py').read_text(encoding='utf-8')
html=(ROOT/'static/index.html').read_text(encoding='utf-8')
sw=(ROOT/'static/sw.js').read_text(encoding='utf-8')
collector=(ROOT/'collect_debug_logs.py').read_text(encoding='utf-8')
piper_setup=(ROOT/'setup_mana_piper_core.bat').read_text(encoding='utf-8-sig').lower()
piper_wrapper=(ROOT/'setup_mana_piper.bat').read_text(encoding='utf-8-sig').lower()
checks={
 'version_008':(ROOT/'VERSION.txt').read_text().strip()=='0.08',
 'debug_batch_exists':(ROOT/'debug_logs_windows.bat').is_file(),
 'diagnostic_collector_exists':(ROOT/'collect_debug_logs.py').is_file(),
 'collector_excludes_database_and_notes':'No SQLite database' in collector and 'user notes' in collector,
 'collector_collects_tts_api_status':"api/tts/status" in collector,
 'collector_treats_authenticated_http_401_as_reachable':'except urllib.error.HTTPError' in collector and 'authentication required' in collector,
 'collector_port_probe_prefers_runtime_used_by_app':"ROOT/'.portable-python'/'python.exe'" in collector,
 'collector_collects_piper_setup_log':"logdir/'piper_setup.log'" in collector,
 'rotating_server_log_enabled':'RotatingFileHandler' in launch and "'server.log'" in launch,
 'tts_probe_checks_python_compatibility':"(3,11)<=v<=(3,14)" in app,
 'tts_probe_checks_piper_and_onnx':'import piper' in app and 'import onnxruntime' in app and "'gil_enabled'" in app,
 'tts_diagnostics_distinguish_model_and_engine':"'model_present':model_present" in app and "'main_python_import_error':direct_reason" in app and "'main_python_version':sys.version.split()[0]" in app,
 'tts_worker_path_is_discovered':"PIPER_WORKER_CANDIDATES" in app and 'worker_path' in app,
 'configured_system_python_can_be_used':"PIPER_CONFIGURED_INTERPRETER = BASE / 'piper_python_path.txt'" in app and 'nl_tts_python' in piper_setup and 'configured_runtime_ready' in piper_setup and 'piper_python_path.txt' in piper_setup,
 'piper_model_setup_does_not_assume_venv':'set \"model_py=\"' in piper_setup and '.portable-python\\python.exe' in piper_setup and 'the main app may continue to run' in piper_setup,
 'piper_setup_is_logged':'piper_setup.log' in piper_wrapper and 'call "%nl_piper_core%" > "%nl_piper_log%" 2>&1' in piper_wrapper,
 'existing_piper_venv_reused':'reuse a working piper venv' in piper_setup and 'import sys,struct,piper,onnxruntime' in piper_setup,
 'numbering_counters_are_topic_scoped':'topicCounters=new Map()' in html and "c.topic_id||'__unassigned__'" in html,
 'layout_hardening_styles_exist':'ver002-layout-hardening' in html and '@media(max-width:760px)' in html and 'runtimeDetails=d.main_python_version' in html,
 'cache_bumped': 'v=009' in html and 'nla-shell-v009' in sw,
 'api_health_reports_008':"'0.08'" in (ROOT/'tests'/'run_v0600_foundation_regression.py').read_text(encoding='utf-8'),
}
# Exercise API chapter numbering with two separate topics in a temporary isolated database.
tmp=Path(tempfile.mkdtemp(prefix='network-learning-v002-numbering-'))
client=None
try:
 for name in ('app.py','static','VERSION.txt','tts_worker.py'):
  src,dst=ROOT/name,tmp/name
  if src.is_dir(): shutil.copytree(src,dst)
  else: shutil.copy2(src,dst)
 (tmp/'data').mkdir(exist_ok=True)
 spec=importlib.util.spec_from_file_location('network_learning_v002_numbering_app',tmp/'app.py')
 mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
 client=TestClient(mod.app,client=('127.0.0.1',16432))
 setup=client.post('/api/auth/setup',json={'username':'debug.admin','password':'DebugRegressionPassword2026!'})
 checks['isolated_admin_setup_for_numbering_test']=setup.status_code==200
 tts_status=client.get('/api/tts/status')
 tts_json=tts_status.json() if tts_status.status_code==200 else {}
 checks['tts_status_api_reports_engine_separately_from_model']=tts_status.status_code==200 and 'piper_available' in tts_json and 'model_present' in tts_json and 'worker_diagnostics' in tts_json
 (tmp/'piper_python_path.txt').write_text(sys.executable,encoding='utf-8')
 configured_path=mod._piper_worker_candidate_paths()[-1]
 checks['configured_python_path_is_loaded_for_probe']=configured_path==Path(sys.executable)
 ids=[]
 for title in ('موضوع شبکه','موضوع فلسفه'):
  r=client.post('/api/topics',json={'title':title,'description':'','features':{}})
  ids.append(r.json().get('id') if r.status_code==200 else '')
 for topic_id,prefix in zip(ids,('شبکه','فلسفه')):
  for title in (f'{prefix} فصل اول',f'{prefix} فصل دوم'):
   r=client.post('/api/chapter',json={'title':title,'topic_id':topic_id,'group_name':'imported'})
   if r.status_code!=200: raise AssertionError(r.text)
 state=client.get('/api/state').json()['chapters']
 nums={}
 for row in state:
  key=row.get('topic_id') or '__unassigned__';nums.setdefault(key,[]).append(row.get('chapter_number'))
 checks['two_topics_each_start_at_one']=all(nums.get(tid)==[1,2] for tid in ids)
 for tid in ids:
  route=client.get(f'/api/topics/{tid}/chapters').json()['chapters']
  checks['topic_chapters_api_numbered_independently']=checks.get('topic_chapters_api_numbered_independently',True) and [x['chapter_number'] for x in route]==[1,2]
finally:
 if client: client.close()
 shutil.rmtree(tmp,ignore_errors=True)
# Exercise the standard-library diagnostic ZIP against dummy logs and a database sentinel.
dbg=Path(tempfile.mkdtemp(prefix='network-learning-v002-debug-'))
try:
 shutil.copy2(ROOT/'collect_debug_logs.py',dbg/'collect_debug_logs.py')
 shutil.copy2(ROOT/'VERSION.txt',dbg/'VERSION.txt')
 (dbg/'data').mkdir(); (dbg/'data'/'network_learning.db').write_bytes(b'PRIVATE_DB_SENTINEL')
 (dbg/'piper_python_path.txt').write_text(sys.executable,encoding='utf-8')
 (dbg/'logs').mkdir(); (dbg/'logs'/'server.log').write_text('INFO ordinary line\npassword=my-private-test-password\n',encoding='utf-8')
 (dbg/'logs'/'piper_setup.log').write_text('ERROR Piper missing\nAuthorization: Bearer test-secret-token\n',encoding='utf-8')
 run=subprocess.run([sys.executable,str(dbg/'collect_debug_logs.py')],cwd=dbg,capture_output=True,text=True,timeout=20)
 zips=list((dbg/'debug_logs').glob('Network_Learning_debug_*.zip'))
 ok=run.returncode==0 and len(zips)==1
 if ok:
  with zipfile.ZipFile(zips[0]) as z:
   names=z.namelist(); contents='\n'.join(z.read(n).decode('utf-8','replace') for n in names)
   checks['collector_redacts_secrets_and_excludes_private_db']=('redacted_logs/server.log' in names and 'redacted_logs/piper_setup.log' in names and 'PRIVATE_DB_SENTINEL' not in contents and 'my-private-test-password' not in contents and 'test-secret-token' not in contents and '[REDACTED' in contents and not any(n.endswith('.db') for n in names) and 'configured_system_runtime' in contents and str(sys.executable) not in contents)
 else: checks['collector_redacts_secrets_and_excludes_private_db']=False
finally:
 shutil.rmtree(dbg,ignore_errors=True)
# Ensure each inline JS block is syntactically parseable where Node is available.
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit(1)
print(f'RESULT: PASS ({len(checks)} checks)')
