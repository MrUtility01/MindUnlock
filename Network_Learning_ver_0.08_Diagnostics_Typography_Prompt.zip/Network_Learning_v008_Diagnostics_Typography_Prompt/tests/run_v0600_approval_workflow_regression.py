#!/usr/bin/env python3
"""Regression inherited from v0.6.0, run against ver 0.08: approval gating, topic filters, import order, authentication, authoring and offline TTS."""
import importlib.util, json, shutil, sqlite3, sys, tempfile
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TEMP=Path(tempfile.mkdtemp(prefix='network-learning-v0600-approval-'))
client=None
try:
    for name in ('app.py','static','VERSION.txt','tts_worker.py'):
        src,dst=ROOT/name,TEMP/name
        if src.is_dir():shutil.copytree(src,dst)
        else:shutil.copy2(src,dst)
    (TEMP/'data').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v0600_approval_app',TEMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    client=TestClient(mod.app,client=('127.0.0.1',12598))
    assert client.get('/api/health').json()['version']=='0.08'
    r=client.post('/api/auth/setup',json={'username':'test.user','password':'FoundationRegressionPassword2026!'});assert r.status_code==200,r.text
    a=client.get('/api/auth/status').json();assert a['configured'] and a['login_username']=='test.user' and a['authenticated']
    # Persistent title and username settings.
    r=client.put('/api/settings',json={'app_title':'آزمایشگاه محلی','login_username':'test.new','timezone':'Asia/Tehran'});assert r.status_code==200,r.text
    settings=client.get('/api/settings').json();assert settings['preferences']['app_title']=='آزمایشگاه محلی' and settings['login_username']=='test.new'
    # Two topics, then a pack with contradictory external chapter order fields.
    topic_a=client.post('/api/topics',json={'title':'فناوری اطلاعات','description':'شبکه و آزمایشگاه','features':{'lessons':True,'questions':True,'flashcards':True,'commands':True,'labs':True,'images':True,'sources':True}});assert topic_a.status_code==200,topic_a.text
    ta=topic_a.json()['id']
    topic_b=client.post('/api/topics',json={'title':'مبانی','description':'موضوع دوم','features':{'lessons':True,'flashcards':True}});assert topic_b.status_code==200,topic_b.text
    tb=topic_b.json()['id']
    pack={'format':'network-learning-content-pack-v2','version':2,'title':'آزمایش شماره‌گذاری','topic':{'id':ta,'title':'فناوری اطلاعات'},'chapters':[
       {'id':'pack-c1','title':'فصل تازه اول','order_num':900,'description':'اول'},
       {'id':'pack-c2','title':'فصل تازه دوم','order_num':1,'description':'دوم'}],
       'items':[
        {'chapter_id':'pack-c1','kind':'lesson','title':'درس pending اول','summary':'خلاصه','content':'متن pending','source_status':'verified','source_uid':'uid-pending-lesson','metadata':{}},
        {'chapter_id':'pack-c1','kind':'note','title':'نکته تاییدشده','summary':'خلاصه نکته','content':'نکته','source_status':'verified','source_uid':'uid-approved-note','metadata':{}},
        {'chapter_id':'pack-c1','kind':'flashcard','title':'کارت تاییدشده','summary':'پرسش','content':'پاسخ','source_status':'verified','source_uid':'uid-approved-card','metadata':{'front':'سوال','back':'جواب'}},
        {'chapter_id':'pack-c2','kind':'lesson','title':'درس فصل دوم','summary':'خلاصه','content':'متن','source_status':'verified','source_uid':'uid-pending-lesson2','metadata':{}},
       ]}
    files=[('files',('pack.json',json.dumps(pack,ensure_ascii=False).encode(),'application/json'))]
    r=client.post('/api/import',files=files,data={'mode':'auto','target_topic_id':ta});assert r.status_code==200,r.text
    summary=r.json()['summary'];assert not summary.get('errors'),summary
    with mod.connect() as c:
        ch=c.execute("SELECT ch.id,ch.order_num,ct.topic_id FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ch.id IN ('pack-c1','pack-c2') ORDER BY ch.order_num").fetchall()
        assert [x['id'] for x in ch]==['pack-c1','pack-c2'],[(x['id'],x['order_num']) for x in ch]
        assert ch[1]['order_num']==ch[0]['order_num']+1,[(x['id'],x['order_num']) for x in ch]
        c.execute("UPDATE items SET source_status='review_required' WHERE source_uid IN ('uid-pending-lesson','uid-pending-lesson2')")
        c.execute("UPDATE items SET source_status='verified' WHERE source_uid IN ('uid-approved-note','uid-approved-card')")
        pending_id=c.execute("SELECT id FROM items WHERE source_uid='uid-pending-lesson'").fetchone()['id']
        approved_note_id=c.execute("SELECT id FROM items WHERE source_uid='uid-approved-note'").fetchone()['id']
        approved_card_id=c.execute("SELECT id FROM items WHERE source_uid='uid-approved-card'").fetchone()['id']
        c.commit()
    # User routes show only verified content; management sees pending content scoped to its topic.
    learner=client.get('/api/items',params={'topic_id':ta,'limit':100}).json()['items']
    assert all(x['source_status']=='verified' for x in learner)
    assert all(x['source_uid']!='uid-pending-lesson' for x in learner)
    assert any(x['source_uid']=='uid-approved-note' for x in learner)
    assert client.get('/api/items',params={'topic_id':ta,'kind':'note'}).json()['total_count']==1
    mgr=client.get('/api/management/items',params={'topic_id':ta,'status':'pending','limit':100}).json()['items']
    assert any(x['source_uid']=='uid-pending-lesson' for x in mgr)
    assert all(x.get('chapter_id')!='other-topic-chapter' for x in mgr)
    assert client.get('/api/review/due',params={'topic_id':ta,'mode':'all','limit':100}).json()['cards'][0]['id']==approved_card_id
    # Approving changes learner visibility; sync surfaces must not leak pending content.
    with mod.connect() as c: c.execute("UPDATE items SET source_status='verified' WHERE source_uid='uid-approved-card'");c.commit()
    client.put(f'/api/item/{pending_id}',json={'source_status':'verified'})
    learner=client.get('/api/items',params={'topic_id':ta,'limit':100}).json()['items']
    assert any(x['source_uid']=='uid-pending-lesson' for x in learner)
    manifest=client.get('/api/sync/manifest').json()
    assert all('uid-pending-lesson' not in json.dumps(x,ensure_ascii=False) for x in manifest['chapters'])
    sync=client.get('/api/sync/chapter/pack-c1').json();assert all(i['source_status']=='verified' for i in sync['items'])
    # Prompt contract covers all key item types and won't use outdated top-level schema.
    prompt=client.post('/api/topics/prompt-preview',json={'topic_id':ta,'lesson_count':3,'questions_per_lesson':4,'examples_per_lesson':2,'flashcards_per_lesson':5,'notes_per_chapter':3,'commands_per_chapter':6,'labs_per_chapter':2,'images_per_chapter':2,'chapter_titles':['مسیریابی در شبکه‌های IP'],'include_commands':True,'include_labs':True,'include_images':True})
    assert prompt.status_code==200,prompt.text
    pp=prompt.json()['prompt']; spec=prompt.json()['spec']
    for term in ['flashcards_per_lesson','labs_per_chapter','images_per_chapter','metadata.options','metadata.correct_index','prompt_fa','prompt_en','review_required','تنظیمات ساخت','فقط محتوای واقعی','اگر محیط AI به تولید تصویر واقعی دسترسی دارد']:
        assert term in pp,term
    assert spec['output_contract']['required_top_level']==['format','version','title','chapter_id','chapters','items','topic']
    assert spec['features']['commands'] and spec['features']['labs'] and spec['features']['images']
    # Optional TTS status is safe when model is not bundled and no new dependency is installed.
    tts=client.get('/api/tts/status');assert tts.status_code==200,tts.text
    # Front-end / release invariants.
    html=(ROOT/'static/index.html').read_text(encoding='utf-8')
    assert 'id="studyTopic"' in html and 'id="reviewTopic"' in html and 'id="manageTopic"' in html
    assert 'IDLE_LOCK_MS=15*60*1000' in html and "id=\"prefAppTitle\"" in html
    assert 'readItemAloud' in html and 'v=009' in html
    read_fn=html[html.index('window.readItemAloud=async function(itemId){'):html.index('async function checkTtsStatus()',html.index('window.readItemAloud=async function(itemId){'))]
    assert read_fn.index('if(status?.piper_available)') < read_fn.index("if('speechSynthesis'in window)"), 'Piper should be preferred over browser speech'
    assert 'دانلود اسکریپت دریافت مدل Mana' in html
    print('PASS: ver 0.08 version; username/password setup; preference title+username; sequential topic-scoped chapter import independent of pack order; approval gating; note/flashcard topic filters; topic-scoped approval manager; approved-only sync; detailed AI authoring contract; optional offline TTS; lock/title UI markers.')
finally:
    if client: client.close()
    shutil.rmtree(TEMP,ignore_errors=True)
