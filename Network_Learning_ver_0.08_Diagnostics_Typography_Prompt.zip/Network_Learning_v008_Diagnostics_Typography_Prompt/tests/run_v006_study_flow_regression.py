#!/usr/bin/env python3
"""Release regression for v0.06 themes/navigation, book ZIP creation and cited import."""
from pathlib import Path
import importlib.util, io, json, shutil, sys, tempfile, zipfile
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v006-study-flow-'))
checks=[]
def check(name, condition, detail=''):
    if not condition: raise AssertionError(f'FAIL {name}: {detail}')
    checks.append(name)
try:
    for name in ('app.py','static','config','schemas','VERSION.txt','tts_worker.py','launch_server.py','requirements.txt'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
    (TMP/'data').mkdir(exist_ok=True); (TMP/'data'/'media').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v006_study_flow_test',TMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    c=TestClient(mod.app,client=('127.0.0.1',17606))
    check('release version is 0.08',c.get('/api/health').json().get('version')=='0.08')
    setup=c.post('/api/auth/setup',json={'username':'testadmin','password':'StrongPassword-2026!'})
    check('fresh admin setup',setup.status_code==200,setup.text[:120])
    check('fresh install has zero chapters',c.get('/api/state').json().get('totals',{}).get('chapters',0)==0)
    prof=c.get('/api/course-builder/profiles').json()
    check('eight prompt models remain available',len(prof['prompt_models'])==8)
    base={'title':'طرح عیب‌یابی با فصل‌های دلخواه','domain_profile':'network_it','level':'intermediate','goal':'practice','format':'mixed','chapter_count':8,'weekly_hours':6,'prompt_model':'troubleshooting','depth':'reference','scope':'DNS و عیب‌یابی شبکه','outline_titles':'فصل اول — مبانی\nفصل دوم — تشخیص\nفصل سوم — تعمیر','include_project':True}
    preview=c.post('/api/course-builder/preview',json=base)
    check('course builder accepts explicit ordered chapter titles',preview.status_code==200,preview.text[:180])
    bp=preview.json()['blueprint']
    check('only the three supplied chapters are used',[x['title'] for x in bp['chapters']]==['فصل اول — مبانی','فصل دوم — تشخیص','فصل سوم — تعمیر'])
    check('integrative project assigned to last custom chapter','پروژهٔ تلفیقی با روبریک' in bp['chapters'][-1]['activity_types'])
    text='''# فصل اول: مبانی شبکه\nاین فصل مبانی شبکه و روش بررسی اتصال را پوشش می‌دهد. شبکه از دستگاه‌ها و پروتکل‌هایی تشکیل می‌شود که برای ارتباط با هم کار می‌کنند. عیب‌یابی باید با جمع‌آوری شواهد شروع شود.\n\n## فصل دوم: DNS\nDNS نام دامنه را به نشانی IP ترجمه می‌کند. برای بررسی مشکل باید پاسخ resolver و تنظیمات کلاینت بررسی شود. خروجی فرمان و زمان آزمون را ثبت کن.\n\n## فصل سوم: DHCP\nDHCP تنظیمات آدرس‌دهی را به کلاینت می‌دهد. محدودهٔ آدرس، مدت اجاره و لاگ‌ها باید پیش از هر تغییر بررسی شوند.\n'''
    source={'book_title':'کتاب آزمایشی شبکه','author':'نویسندهٔ آزمون','edition':'ویرایش ۱','publication_year':'2025','publisher':'ناشر آزمون','source_url':'https://example.org/book','isbn':'978-0000000000','chapter_count':'3','split_mode':'auto','chapter_titles':''}
    inspect=c.post('/api/course-builder/book/inspect',files={'file':('sample.md',text,'text/markdown')},data=source)
    check('book inspection returns metadata and detected headings',inspect.status_code==200 and len(inspect.json()['source']['detected_headings'])>=3,inspect.text[:180])
    source.update({'topic_title':'دورهٔ کتاب آزمایشی','include_source_text':'true','include_extracts':'true','include_review_questions':'true','include_glossary':'false','include_definition_cards':'false'})
    built=c.post('/api/course-builder/book-to-pack',files={'file':('sample.md',text,'text/markdown')},data=source)
    check('book file creates a validated ZIP',built.status_code==200 and built.headers.get('X-Content-Pack-Validated')=='true',built.text[:180] if built.status_code!=200 else '')
    z=zipfile.ZipFile(io.BytesIO(built.content))
    expected={'content_pack.json','source_manifest.json','outline.json','validation_report.json','README_IMPORT_FA.md'}
    check('book ZIP includes complete manifest/outline/report layout',expected.issubset(set(z.namelist())),str(z.namelist()))
    pack=json.loads(z.read('content_pack.json'))
    check('all generated items need human review',bool(pack['items']) and all(i.get('source_status')=='review_required' for i in pack['items']))
    check('all content records retain book source metadata',all(i.get('metadata',{}).get('source_reference',{}).get('title')=='کتاب آزمایشی شبکه' for i in pack['items']))
    check('original book bytes are not embedded in output ZIP','sample.md' not in z.namelist())
    pre=c.post('/api/import/preview',files=[('files',('book_course.zip',built.content,'application/zip'))])
    check('import preview accepts generated book ZIP',pre.status_code==200 and not pre.json().get('errors'),pre.text[:180])
    imported=c.post('/api/import',files=[('files',('book_course.zip',built.content,'application/zip'))],data={'mode':'auto'})
    check('book ZIP imports without errors',imported.status_code==200 and not imported.json()['summary']['errors'],imported.text[:200])
    sums=imported.json()['summary']
    check('book import automatically creates named topic',sums.get('topics_created')==1,repr(sums))
    check('book import creates all three chapters',sums.get('chapters_created')==3,repr(sums))
    topics=c.get('/api/topics').json()['topics']
    topic=next((x for x in topics if x['title']=='دورهٔ کتاب آزمایشی'),None)
    check('newly imported chapters are assigned to the declared topic',topic is not None and topic['chapter_count']==3,repr(topic))
    chapters=c.get('/api/topics/'+topic['id']+'/chapters').json()['chapters']
    check('each imported item keeps source URL',len(chapters)>=3)
    rows=c.get('/api/management/items',params={'chapter_id':chapters[0]['id'],'status':'all','limit':100,'offset':0}).json().get('items',[])
    check('source-linked records imported',bool(rows),repr(rows[:1]))
    one=c.get('/api/item/'+str(rows[0]['id'])).json()
    md=one.get('metadata') or {}
    check('imported item retains readable source reference',md.get('source_reference',{}).get('url')=='https://example.org/book',repr(md.get('source_reference')))
    bad=c.post('/api/course-builder/book/inspect',files={'file':('invalid.exe',b'not a book','application/octet-stream')},data={})
    check('unsupported book formats fail with clear 415',bad.status_code==415,bad.text[:100])
    html=(ROOT/'static'/'index.html').read_text(encoding='utf-8')
    for name,needle in [
        ('four theme options','option value="sepia"'),('study theme default',"'sepia')"),('keyboard shortcuts','id="shortcutBtn"'),
        ('grouped navigation','id="navStudyGroup"'),('book builder','id="cbBookBuild"'),('book configuration save','id="cbBookConfigDownload"'),
        ('book configuration load','id="cbBookConfigFile"'),('lesson source footer','renderItemSourceFooter(x)'),
        ('authoring specification link','COURSE_PACK_SPECIFICATION_V006_FA.md'),('no dead series import path','/static/offline-packages/series-1.json')]:
        if name=='no dead series import path': check(name,needle not in html)
        else: check(name,needle in html)
    check('service worker cache bumped to v008',"nla-shell-v009" in (ROOT/'static'/'sw.js').read_text(encoding='utf-8'))
    print('\n'.join('PASS: '+n for n in checks));print(f'RESULT: PASS ({len(checks)} checks)')
finally:
    shutil.rmtree(TMP,ignore_errors=True)
