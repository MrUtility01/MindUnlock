#!/usr/bin/env python3
"""Regression checks for v0.08 audio diagnostics, typography, topic workspace and prompt profiles."""
from pathlib import Path
import importlib.util, json, shutil, sys, tempfile, subprocess, re, zipfile, io
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='network-learning-v008-diagnostics-'))
checks=[]
def check(name,condition,detail=''):
    if not condition: raise AssertionError(f'FAIL {name}: {detail}')
    checks.append(name)
client=None
try:
    for name in ('app.py','static','VERSION.txt','tts_worker.py','ai_authoring_kit.py','schemas','config'):
        src,dst=ROOT/name,TMP/name
        if src.is_dir(): shutil.copytree(src,dst)
        elif src.exists(): shutil.copy2(src,dst)
    (TMP/'data').mkdir(exist_ok=True); (TMP/'data'/'media').mkdir(exist_ok=True)
    sys.path.insert(0,str(TMP))
    spec=importlib.util.spec_from_file_location('network_learning_v008_regression_app',TMP/'app.py')
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    client=TestClient(mod.app,client=('127.0.0.1',17808))
    health=client.get('/api/health')
    check('health reports release 0.08',health.status_code==200 and health.json().get('version')=='0.08',health.text[:250])
    unauth=client.get('/api/diagnostics/system')
    check('system diagnostics remain behind authentication',unauth.status_code==401,unauth.text[:200])
    setup=client.post('/api/auth/setup',json={'username':'diag.admin','password':'V008-Diagnostics-Strong-Password!2026'})
    check('isolated admin setup',setup.status_code==200,setup.text[:200])
    diag=client.get('/api/diagnostics/system')
    check('system diagnostics endpoint returns checks',diag.status_code==200,diag.text[:250])
    dj=diag.json()
    check('diagnostics include runtime/database/tts/disk',all(k in dj for k in ('runtime','database','tts','disk','checks')),str(dj.keys()))
    check('SQLite quick integrity check reported',dj.get('database',{}).get('integrity')=='ok',str(dj.get('database')))
    diag_text=json.dumps(dj,ensure_ascii=False)
    check('diagnostic payload avoids absolute Windows paths',not re.search(r'[A-Za-z]:\\\\',diag_text),diag_text[:500])
    check('diagnostic payload includes worker check',any(x.get('name')=='isolated_piper_worker' for x in dj.get('checks',[])),str(dj.get('checks')))
    good_prefs={'app_font_family':'segoe','study_font_family':'vazirmatn','study_font_size':'22','study_line_height':'2.15','study_content_width':'1080','app_density':'spacious'}
    saved=client.put('/api/settings',json=good_prefs)
    check('valid typography preferences save',saved.status_code==200,saved.text[:250])
    prefs=client.get('/api/settings').json()['preferences']
    check('typography preferences persist',all(prefs.get(k)==v for k,v in good_prefs.items()),json.dumps({k:prefs.get(k) for k in good_prefs},ensure_ascii=False))
    bad_font=client.put('/api/settings',json={'study_font_family':'not-a-font'})
    check('unknown font rejected',bad_font.status_code==400,bad_font.text[:180])
    bad_size=client.put('/api/settings',json={'study_font_size':'99'})
    check('out-of-range font size rejected',bad_size.status_code==400,bad_size.text[:180])
    topic=client.post('/api/topics',json={'title':'شبکه و عیب‌یابی','description':'موضوع آزمایشی','features':{'lessons':True,'questions':True,'flashcards':True,'commands':True,'labs':True,'sources':True}})
    check('topic can be created for prompt suite',topic.status_code==200,topic.text[:200])
    tid=topic.json()['id']
    profile_ids=['balanced','deep_textbook','troubleshooting','commands_scripts','security_dual','source_faithful','socratic','reference_manual','reviewer']
    prompt_payload={'topic_id':tid,'chapter_titles':['عیب‌یابی DNS','PowerShell و ثبت رخداد'],'lesson_count':4,'questions_per_lesson':3,'examples_per_lesson':2,'include_commands':True,'include_labs':True,'prompt_profile':'troubleshooting','quality_review':True}
    p=client.post('/api/topics/prompt-preview',json=prompt_payload)
    check('prompt preview accepts specialized profile',p.status_code==200,p.text[:300])
    pj=p.json()
    check('troubleshooting profile is reflected in spec and prompt',pj.get('spec',{}).get('prompt_profile',{}).get('id')=='troubleshooting' and 'تست تفکیک‌کننده' in pj.get('prompt',''),pj.get('prompt','')[-400:])
    check('independent QA request is reflected',pj.get('spec',{}).get('quality_review',{}).get('enabled') is True and 'گزارش QA' in pj.get('prompt',''),pj.get('prompt','')[-400:])
    for profile in profile_ids:
        r=client.post('/api/topics/prompt-preview',json={**prompt_payload,'prompt_profile':profile})
        check(f'prompt profile {profile} works',r.status_code==200 and r.json().get('spec',{}).get('prompt_profile',{}).get('id')==profile,r.text[:180])
    kit=client.post('/api/topics/prompt-kit',json=prompt_payload)
    check('authoring ZIP endpoint works with chosen profile',kit.status_code==200 and kit.headers.get('content-type','').startswith('application/zip'),kit.text[:180])
    z=zipfile.ZipFile(io.BytesIO(kit.content)); kit_names=z.namelist()
    check('authoring ZIP has prompt and schema files',len(kit_names)>=4 and any('prompt' in n.lower() for n in kit_names) and any(n.endswith('.json') for n in kit_names),str(kit_names))
    html=(ROOT/'static'/'index.html').read_text(encoding='utf-8'); sw=(ROOT/'static'/'sw.js').read_text(encoding='utf-8')
    for name,expr in {
      'audio diagnostic panel':'id="diagnosticsPanel"' in html,
      'real Piper test button':'id="testPiperAudio"' in html,
      'browser voice diagnostic':'id="testBrowserVoice"' in html,
      'output tone test':'id="testOutputAudio"' in html,
      'system check action':'id="runFullDiagnostics"' in html,
      'diagnostic report download':'id="downloadDiagnosticsReport"' in html,
      'visible audio player in TTS diagnostic':'id="diagnosticWavPlayer"' in html and 'RIFF/WAVE' in html,
      'multiple font controls':'id="prefAppFont"' in html and 'id="prefStudyFont"' in html and 'id="prefStudyFontSize"' in html,
      'topic filter and sort controls':'id="topicSearchFilter"' in html and 'id="topicFeatureFilter"' in html and 'id="topicSortOrder"' in html,
      'nine prompt profiles available':'value="reviewer"' in html and 'value="troubleshooting"' in html and 'id="promptQualityReview"' in html,
      'service worker cache bumped':'nla-shell-v009' in sw,
      'default course-free UI wording':'هنوز موضوعی ساخته نشده است' in html,
    }.items(): check(name,expr)
    # Parse and syntax-check every classic inline script with Node when available.
    scripts=re.findall(r'<script\b(?![^>]*\bsrc=)[^>]*>(.*?)</script\s*>',html,re.S|re.I)
    node=shutil.which('node')
    if node:
        for i,script in enumerate(scripts):
            tempjs=TMP/f'inline_{i}.js';tempjs.write_text(script,encoding='utf-8')
            result=subprocess.run([node,'--check',str(tempjs)],capture_output=True,text=True)
            check(f'inline JavaScript syntax #{i}',result.returncode==0,(result.stderr or result.stdout)[:400])
    else:
        check('inline JavaScript blocks exist',len(scripts)>=8,str(len(scripts)))
    print('\n'.join('PASS: '+x for x in checks));print(f'RESULT: PASS ({len(checks)} checks)')
finally:
    if client: client.close()
    if str(TMP) in sys.path: sys.path.remove(str(TMP))
    shutil.rmtree(TMP,ignore_errors=True)
