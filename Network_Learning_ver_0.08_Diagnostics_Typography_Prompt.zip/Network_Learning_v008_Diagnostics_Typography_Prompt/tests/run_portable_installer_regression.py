"""Static release checks for the Windows portable/offline installer."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ps = (ROOT / 'install_portable_windows.ps1').read_text(encoding='utf-8').lower()
bat = (ROOT / 'install_portable_windows.bat').read_text(encoding='utf-8').lower()
zipps = (ROOT / 'create_offline_portable_zip.ps1').read_text(encoding='utf-8').lower()
zipbat = (ROOT / 'create_offline_portable_zip.bat').read_text(encoding='utf-8').lower()
ps_raw = (ROOT / 'install_portable_windows.ps1').read_bytes()
shortcut_raw = (ROOT / 'install_windows_shortcut.ps1').read_bytes()
checks = {
    'installer_powershell_utf8_bom_for_windows_powershell_5_1': ps_raw.startswith(b'\xef\xbb\xbf'),
    'shortcut_powershell_utf8_bom_for_windows_powershell_5_1': shortcut_raw.startswith(b'\xef\xbb\xbf'),
    'official_embedded_python_url': 'https://www.python.org/ftp/python/$candidateversion/python-$candidateversion-embed-amd64.zip' in ps,
    'runtime_version_is_explicit': "$runtimeversion = '3.13.17'" in ps and "$runtimeminor = '3.13'" in ps,
    'embedded_python_adds_project_root_to_isolated_search_path': "$lines | where-object { $_.trim() -eq '.' }" in ps and "$lines += '.'" in ps,
    'pip_bootstrap_is_present': 'https://bootstrap.pypa.io/get-pip.py' in ps,
    'pip_bootstrap_uses_long_timeout_and_retries': "'--timeout','90','--retries','8'" in ps and "$env:pip_default_timeout = '90'" in ps,
    'pip_bootstrap_retries_transient_failures': 'for ($pipattempt = 1; $pipattempt -le 3; $pipattempt++)' in ps,
    'pip_bootstrap_script_is_cached_and_validated': '100kb' in ps and "join-path $cache 'get-pip.py'" in ps,
    'native_stderr_is_captured_without_hiding_tracebacks': '2>&1' in ps and 'invoke-nativelogged' in ps and 'portable_setup.log' in ps,
    'full_exception_is_logged': 'full error:' in ps and 'exception.tostring()' in ps,
    'stale_ready_marker_is_removed': 'removing stale readiness marker' in ps,
    'main_dependencies_installed': "-r',(join-path $root 'requirements.txt')" in ps,
    'piper_engine_installed': 'piper-tts==1.8.0' in ps and 'onnxruntime' in ps,
    'persian_voice_model_is_downloaded': 'download_mana_persian_piper_model.py' in ps,
    'voice_model_hash_is_verified': 'e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126' in ps,
    'final_import_check_avoids_nested_quotes_in_native_python_code': 'assert pipervoice is not none; print(1)' in ps and 'print(\"app dependencies: ok\")' not in ps,
    'portable_ready_marker_written': "join-path $root '.portable-ready.json'" in ps and "set-content -literalpath $readyfile" in ps,
    'runtime_not_bound_to_system_venv': "$runtimedir = join-path $root '.portable-python'" in ps and "$python = join-path $runtimedir 'python.exe'" in ps and '.venv\\scripts\\python.exe' not in ps,
    'manual_installer_exists': 'install_portable_windows.ps1' in bat,
    'offline_zip_requires_prepared_runtime': '.portable-ready.json' in zipps,
    'offline_zip_includes_app_folder_contents': 'ziparchive' in zipps and "-recurse -force" in zipps,
    'offline_zip_requires_explicit_confirmation_for_private_data': "-ceq 'yes'" in zipps and 'private user data' in zipps and "$parts[0] -eq 'data'" in zipps,
    'manual_zip_command_exists': 'create_offline_portable_zip.ps1' in zipbat,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print('RESULT: PASS')
