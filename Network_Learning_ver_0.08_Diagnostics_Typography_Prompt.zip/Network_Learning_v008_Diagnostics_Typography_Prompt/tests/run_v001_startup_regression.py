#!/usr/bin/env python3
"""Regression checks for the ver 0.06 development-first launcher."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
run=(ROOT/'run_windows.bat').read_text(encoding='utf-8-sig').lower()
setup=(ROOT/'setup_dev_windows.bat').read_text(encoding='utf-8-sig').lower()
version=(ROOT/'VERSION.txt').read_text(encoding='utf-8').strip()
launch=(ROOT/'launch_server.py').read_text(encoding='utf-8').lower()
html=(ROOT/'static/index.html').read_text(encoding='utf-8').lower()
sw=(ROOT/'static/sw.js').read_text(encoding='utf-8').lower()
checks={
 'version_is_008':version=='0.08',
 'launcher_reuses_prepared_portable_runtime':'.portable-python\\python.exe' in run,
 'launcher_reuses_local_venv':'.venv\\scripts\\python.exe' in run,
 'launcher_does_not_call_portable_installer':'install_portable_windows.ps1' not in run,
 'launcher_uses_development_setup':'setup_dev_windows.bat' in run,
 'launcher_executes_settings_aware_server':'launch_server.py' in run,
 'launcher_uses_saved_port':'--print-port' in run and '--print-host' in run,
 'launcher_prints_version_url':'?v=009' in run,
 'no_public_port_forwarding_warning':'do not forward port %nl_port% to the public internet' in run,
 'dev_setup_uses_ensurepip':'-m ensurepip --upgrade' in setup,
 'dev_setup_has_mirror_fallbacks':'mirrors.tuna.tsinghua.edu.cn' in setup and 'repo.huaweicloud.com' in setup,
 'dev_setup_does_not_download_embedded_python':'python.org/ftp/python' not in setup and 'install_portable_windows.ps1' not in setup,
 'launcher_inserts_project_root_for_isolated_python':'sys.path.insert(0, str(base))' in launch,
 'html_cache_query_bumped':'v=009' in html,
 'pwa_cache_bumped':'nla-shell-v009' in sw,
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()):raise SystemExit(1)
print(f'RESULT: PASS ({len(checks)} checks)')
