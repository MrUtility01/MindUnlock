from __future__ import annotations
import base64, hashlib, hmac, json, mimetypes, os, random, re, secrets, sqlite3, time, zipfile, struct, sys, subprocess
from datetime import datetime, date, timedelta
from io import BytesIO
from pathlib import Path, PurePosixPath
from zoneinfo import ZoneInfo
from typing import Any, Optional

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
try:
    APP_VERSION = (BASE / "VERSION.txt").read_text(encoding="utf-8").strip() or "unknown"
except OSError:
    APP_VERSION = "unknown"
DATA = BASE / "data"
MEDIA = DATA / "media"
DB = DATA / "network_learning.db"
INDEX = BASE / "static" / "index.html"
DATA.mkdir(exist_ok=True); MEDIA.mkdir(exist_ok=True)

app = FastAPI(title="دانشنامه جامع یادگیری", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")


@app.middleware("http")
async def avoid_api_cache_v047(request: Request, call_next):
    """The dashboards must always show committed state, especially after approvals/imports."""
    response = await call_next(request)
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

CHAPTERS = [
 (1,"مبانی شبکه، مدل‌های OSI/TCP-IP و جریان بسته"),
 (2,"لایه فیزیکی، Data Link، Ethernet، ARP و کابل‌کشی"),
 (3,"آدرس‌دهی IPv4، Subnetting، VLSM و IPv6"),
 (4,"لایه انتقال؛ TCP، UDP، QUIC و کنترل ازدحام"),
 (5,"سرویس‌های شبکه؛ DNS، DHCP، NTP، SNMP، Syslog و AAA"),
 (6,"سوئیچینگ سیسکو؛ VLAN، STP، EtherChannel و امنیت لایه ۲"),
 (7,"مسیریابی؛ Static، OSPF، BGP، Route-map و Redistribution"),
 (8,"فناوری‌های پیشرفته؛ MPLS، VRF، EVPN/VXLAN، Multicast و SD-WAN"),
 (9,"مفاهیم عمومی NAT، ACL و Firewall"),
 (10,"FortiGate؛ از مبانی تا پیکربندی و عیب‌یابی پیشرفته"),
 (11,"فایروال‌های دیگر؛ pfSense، OPNsense و Sophos"),
 (12,"VPN سازمانی؛ IPsec، SSL-VPN و WireGuard"),
 (13,"MikroTik؛ Routing، Firewall، QoS، VPN و HA"),
 (14,"وایرلس سازمانی و لینک‌های PtP/PtMP"),
 (15,"Windows Server، Active Directory و سرویس‌های ویندوزی"),
 (16,"لینوکس؛ مدیریت سیستم، شبکه، سرویس‌ها و امنیت"),
 (17,"امنیت Endpoint و Zero Trust"),
 (18,"مجازی‌سازی؛ VMware، Hyper-V، Proxmox، Docker و Kubernetes"),
 (19,"Storage سازمانی، Backup و Disaster Recovery"),
 (20,"معماری دیتاسنتر، HA و Load Balancing"),
 (21,"شبکه و امنیت ابری؛ AWS، Azure و Governance"),
 (22,"مانیتورینگ، SIEM و تحلیل پکت با Wireshark"),
 (23,"امنیت پیشرفته شبکه، SOC، Incident Response و Ethical Hacking دفاعی"),
 (24,"اتوماسیون شبکه؛ Ansible، Nornir، NAPALM، NETCONF و AI در IT"),
 (25,"پایتون، Bash و PowerShell برای شبکه و اسکریپت‌نویسی"),
 (26,"مدیریت و امنیت پایگاه داده"),
 (27,"عملیات IT، NOC، مستندسازی، Runbook و CMDB"),
 (28,"Git و GitHub در محیط سازمانی"),
 (29,"مرجع کامل دستورات؛ Cisco، FortiGate، MikroTik، Linux و Windows"),
 (30,"پایتون و اتوماسیون شبکه؛ طراحی اسکریپت‌های امن و قابل نگهداری"),
 (31,"تست نفوذ شبکه و آزمایشگاه؛ از برنامه‌ریزی مجاز تا گزارش و اصلاح"),
 (32,"مهندسی پرامپت و هوش مصنوعی؛ طراحی، ارزیابی و استفادهٔ مسئولانه"),
]

DEMO_LESSONS = [
 {"title":"مدل OSI و وظیفهٔ لایه‌ها", "summary":"مدل OSI ارتباطات شبکه را به هفت لایه تقسیم می‌کند تا طراحی، استانداردسازی و عیب‌یابی ساده‌تر شود.", "content":"""# مدل OSI و وظیفهٔ لایه‌ها

مدل **OSI (Open Systems Interconnection)** یک مدل مرجع هفت‌لایه برای توضیح وظایف ارتباطات شبکه است. در عیب‌یابی، از نشانه‌های لایهٔ پایین شروع می‌کنیم و به سمت سرویس‌های لایهٔ بالا پیش می‌رویم.

| لایه | نام | نمونه یا وظیفه |
|---:|---|---|
| 7 | Application | HTTP، DNS و سرویس‌های نزدیک به برنامه |
| 6 | Presentation | قالب‌بندی داده، رمزنگاری و فشرده‌سازی در مدل نظری |
| 5 | Session | مدیریت نشست در مدل نظری |
| 4 | Transport | TCP/UDP، پورت‌ها و ارتباط انتها‌به‌انتها |
| 3 | Network | IP و انتخاب مسیر بین شبکه‌ها |
| 2 | Data Link | Ethernet، MAC، VLAN و Frame |
| 1 | Physical | سیگنال، کابل، فیبر، کانکتور و لینک فیزیکی |

**نکته:** در پیاده‌سازی واقعی TCP/IP مرزبندی‌ها دقیقاً یک‌به‌یک با OSI نیستند؛ OSI بیشتر یک مدل مرجع آموزشی و عیب‌یابی است.

## سناریوی عیب‌یابی
اگر Link روی پورت خاموش است، ابتدا کابل/فیبر، Transceiver، برق و وضعیت پورت را بررسی کن؛ هنوز سراغ DNS یا HTTP نرو.

## پرسش برای مرور
چرا در عیب‌یابی معمولاً از لایه‌های پایین شروع می‌کنیم؟ چون شکست در لایهٔ پایین می‌تواند همهٔ سرویس‌های بالاتر را از دسترس خارج کند."""},
 {"title":"مدل TCP/IP و نگاشت به OSI", "summary":"مدل TCP/IP معمولاً چهار لایه دارد: Link، Internet، Transport و Application.", "content":"""# مدل TCP/IP و نگاشت به OSI

| مدل TCP/IP | لایه‌های متناظر در OSI | نمونه |
|---|---|---|
| Application | Application، Presentation، Session | HTTP، DNS، SMTP، SSH |
| Transport | Transport | TCP، UDP، QUIC (روی UDP) |
| Internet | Network | IPv4، IPv6، ICMP |
| Link / Network Access | Data Link و Physical | Ethernet، Wi-Fi |

در عمل، مجموعهٔ پروتکل‌های TCP/IP مبنای ارتباطات اینترنت و بیشتر شبکه‌های سازمانی است. هنگام تحلیل ترافیک باید بین **پروتکل کاربردی**، **پروتکل انتقال** و **آدرس‌دهی لایهٔ شبکه** تفاوت گذاشت."""},
 {"title":"Encapsulation و مسیر حرکت بسته", "summary":"در فرستنده، داده به‌ترتیب سربرگ‌های لایه‌های پایین‌تر را می‌گیرد؛ در گیرنده این سربرگ‌ها بررسی و حذف می‌شوند.", "content":"""# Encapsulation و مسیر حرکت بسته

1. برنامه، دادهٔ کاربردی می‌سازد؛ برای نمونه یک درخواست HTTP.
2. لایهٔ انتقال آن را در TCP Segment یا UDP Datagram قرار می‌دهد.
3. لایهٔ IP یک Packet می‌سازد و آدرس مبدأ/مقصد IP را اضافه می‌کند.
4. لایهٔ پیوند داده، Packet را داخل Ethernet Frame قرار می‌دهد.
5. لایهٔ فیزیکی بیت‌ها را روی رسانه منتقل می‌کند.

| اصطلاح | لایهٔ رایج | نکته |
|---|---|---|
| Data | Application | محتوای برنامه |
| Segment / Datagram | Transport | TCP Segment یا UDP Datagram |
| Packet | Network | بستهٔ IP |
| Frame | Data Link | فریم در یک لینک محلی |
| Bits | Physical | سیگنال قابل انتقال روی رسانه |

**در روتر:** هدر لایهٔ ۲ ورودی معمولاً برداشته می‌شود و برای لینک خروجی هدر لایهٔ ۲ تازه ساخته می‌شود؛ بستهٔ IP برای مسیریابی پردازش می‌شود و TTL/Hop Limit کاهش می‌یابد."""},
]
DEMO_CARDS = [
 ("مدل OSI چند لایه دارد؟","هفت لایه؛ از Physical تا Application."),
 ("وظیفهٔ اصلی لایهٔ Network چیست؟","آدرس‌دهی IP و انتقال بسته بین شبکه‌ها با مسیریابی."),
 ("تفاوت Packet و Frame چیست؟","Packet معمولاً واحد لایهٔ IP است؛ Frame واحد لایهٔ پیوند داده در یک لینک است."),
 ("TCP و UDP در کدام لایه قرار می‌گیرند؟","لایهٔ Transport؛ TCP اتصال‌گراست و UDP دیتاگرام‌محور است."),
 ("DNS معمولاً چه کاری انجام می‌دهد؟","نام دامنه را به رکوردهای موردنیاز مانند آدرس IP نگاشت می‌کند."),
 ("پس از هر Hop روتر چه اتفاقی برای Ethernet Frame می‌افتد؟","فریم ورودی باز می‌شود و برای لینک خروجی فریم جدید ساخته می‌شود."),
]
DEMO_QUESTIONS = [
 {"question":"کدام پروتکل در لایهٔ Internet مدل TCP/IP کار می‌کند؟","options":["IP","TCP","HTTP","Ethernet"],"correct_index":0,"explanation":"IP مسئول آدرس‌دهی و انتقال بسته‌ها بین شبکه‌هاست."},
 {"question":"کدام گزینه واحد رایج لایهٔ Data Link است؟","options":["Frame","Segment","DNS Query","Process"],"correct_index":0,"explanation":"Frame واحد پروتکلی لایهٔ پیوند داده است."},
 {"question":"کدام گزینه دربارهٔ TCP درست است؟","options":["اتصال‌گراست و تحویل مرتب را فراهم می‌کند","پروتکل لایهٔ فیزیکی است","همیشه سریع‌تر از UDP است","جایگزین IP است"],"correct_index":0,"explanation":"TCP قابلیت‌هایی مانند تحویل قابل‌اعتماد و مرتب‌سازی جریان داده را فراهم می‌کند؛ لزوماً از UDP سریع‌تر نیست."},
]

def connect():
    conn = sqlite3.connect(DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    # UDF is registered before the chapter ordering helper is defined; its lambda resolves
    # the helper at query time, after module initialization has finished.
    conn.create_function("chapter_content_seq", 5, lambda kind, uid, title, metadata_json, item_id: _chapter_record_sequence({"kind": kind, "source_uid": uid, "title": title, "metadata_json": metadata_json, "id": item_id}))
    conn.create_collation("NATURAL_NOCASE", lambda left, right: _natural_text_compare(left, right))
    return conn

_TIMEZONE_CACHE: str | None = None

def user_timezone_name() -> str:
    """Configured display/scheduling timezone; cached because imports create thousands of records."""
    global _TIMEZONE_CACHE
    if _TIMEZONE_CACHE:
        return _TIMEZONE_CACHE
    try:
        candidate = str(get_setting('pref_timezone', 'Asia/Tehran') or 'Asia/Tehran') if 'get_setting' in globals() else 'Asia/Tehran'
        ZoneInfo(candidate)
        _TIMEZONE_CACHE = candidate
        return candidate
    except Exception:
        _TIMEZONE_CACHE = 'Asia/Tehran'
        return _TIMEZONE_CACHE


def user_datetime() -> datetime:
    try:
        return datetime.now(ZoneInfo(user_timezone_name())).replace(tzinfo=None)
    except Exception:
        return datetime.now()


def now_iso(): return user_datetime().isoformat(timespec="seconds")


def jalali_to_gregorian(jy: int, jm: int, jd: int) -> date:
    """Convert Jalali calendar date to Gregorian without optional dependencies."""
    if not (1 <= jm <= 12 and 1 <= jd <= (31 if jm <= 6 else 30 if jm <= 11 else 30)):
        raise ValueError('تاریخ شمسی نامعتبر است')
    jy += 1595
    days = -355668 + 365 * jy + (jy // 33) * 8 + ((jy % 33 + 3) // 4) + jd
    days += (jm - 1) * 31 if jm <= 7 else 186 + (jm - 7) * 30
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        gy += 100 * ((days - 1) // 36524)
        days = (days - 1) % 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    month_days = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 1
    while gm <= 12 and gd > month_days[gm - 1]:
        gd -= month_days[gm - 1]
        gm += 1
    return date(gy, gm, gd)


def gregorian_to_jalali(gdate: date) -> str:
    gy, gm, gd = gdate.year, gdate.month, gdate.day
    gdm = [0,31,59,90,120,151,181,212,243,273,304,334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + 365*gy + (gy2+3)//4 - (gy2+99)//100 + (gy2+399)//400 + gd + gdm[gm-1]
    jy = -1595 + 33*(days//12053)
    days %= 12053
    jy += 4*(days//1461)
    days %= 1461
    if days > 365:
        jy += (days-1)//365
        days = (days-1)%365
    if days < 186:
        jm = 1 + days//31
        jd = 1 + days%31
    else:
        jm = 7 + (days-186)//30
        jd = 1 + (days-186)%30
    return f'{jy:04d}/{jm:02d}/{jd:02d}'


def normalize_date_input(value: str | None) -> str | None:
    """Accept Latin/Persian/Arabic digits in Jalali or ISO/Gregorian date; return ISO date."""
    if value is None or not str(value).strip(): return None
    raw = str(value).strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
    raw = raw.replace('-', '/')
    parts = raw.split('/')
    if len(parts) != 3: raise ValueError('تاریخ را به شکل شمسی ۱۴۰۵/۰۸/۰۱ یا میلادی ۲۰۲۶-۱۰-۲۲ وارد کن')
    try: y, m, d = [int(x) for x in parts]
    except ValueError: raise ValueError('تاریخ شامل عدد نامعتبر است')
    if 1200 <= y <= 1600:
        gd = jalali_to_gregorian(y, m, d)
        if gregorian_to_jalali(gd) != f'{y:04d}/{m:02d}/{d:02d}':
            raise ValueError('تاریخ شمسی معتبر نیست؛ روز انتخاب‌شده در این ماه وجود ندارد')
        return gd.isoformat()
    try: return date(y, m, d).isoformat()
    except Exception: raise ValueError('تاریخ میلادی معتبر نیست')


def normalize_datetime_input(day: str | None, clock: str | None = None) -> str | None:
    iso_day = normalize_date_input(day)
    if not iso_day: return None
    if clock and clock.strip():
        t = clock.strip()
        if not re.fullmatch(r'\d{1,2}:\d{2}', t): raise ValueError('ساعت را به شکل 09:30 وارد کن')
        hh, mm = [int(x) for x in t.split(':')]
        if not (0 <= hh <= 23 and 0 <= mm <= 59): raise ValueError('ساعت نامعتبر است')
        return f'{iso_day}T{hh:02d}:{mm:02d}:00'
    return f'{iso_day}T09:00:00'


def display_jalali_datetime(value: str | None) -> str:
    if not value: return ''
    try:
        raw = str(value).replace('Z','')
        dt = datetime.fromisoformat(raw) if 'T' in raw else datetime.combine(date.fromisoformat(raw), datetime.min.time())
        day = gregorian_to_jalali(dt.date())
        return f'{day} {dt:%H:%M}' if 'T' in raw else day
    except Exception: return str(value)

def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS topics(
          id TEXT PRIMARY KEY, title TEXT NOT NULL UNIQUE, description TEXT DEFAULT '',
          features_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chapter_topics(
          chapter_id TEXT PRIMARY KEY REFERENCES chapters(id) ON DELETE CASCADE,
          topic_id TEXT NOT NULL REFERENCES topics(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS personal_item_notes(
          item_id INTEGER PRIMARY KEY REFERENCES items(id) ON DELETE CASCADE,
          bookmarked INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chapters(
          id TEXT PRIMARY KEY, title TEXT NOT NULL, order_num INTEGER NOT NULL DEFAULT 999,
          group_name TEXT NOT NULL DEFAULT 'main', source TEXT DEFAULT 'seed',
          description TEXT DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS items(
          id INTEGER PRIMARY KEY AUTOINCREMENT, chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
          kind TEXT NOT NULL, title TEXT NOT NULL, summary TEXT DEFAULT '', content TEXT DEFAULT '',
          source_status TEXT DEFAULT 'verified', source_file TEXT DEFAULT '', source_uid TEXT DEFAULT '',
          metadata_json TEXT DEFAULT '{}', created_at TEXT NOT NULL,
          UNIQUE(chapter_id, source_uid)
        );
        CREATE TABLE IF NOT EXISTS progress(
          item_id INTEGER PRIMARY KEY REFERENCES items(id) ON DELETE CASCADE,
          completed INTEGER NOT NULL DEFAULT 0, correct_count INTEGER NOT NULL DEFAULT 0,
          wrong_count INTEGER NOT NULL DEFAULT 0, interval_days INTEGER NOT NULL DEFAULT 0,
          ease REAL NOT NULL DEFAULT 2.5, due_at TEXT DEFAULT '', last_reviewed TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS user_accounts(
          username TEXT PRIMARY KEY COLLATE NOCASE, password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'learner' CHECK(role IN ('admin','editor','learner')),
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS assessment_attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          question_item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
          correct INTEGER NOT NULL CHECK(correct IN (0,1)),
          selected_index INTEGER NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_assessment_question_time ON assessment_attempts(question_item_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_assessment_chapter_time ON assessment_attempts(chapter_id, created_at DESC);
        CREATE TABLE IF NOT EXISTS practice_attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL COLLATE NOCASE,
          item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          answer TEXT NOT NULL DEFAULT '',
          self_score INTEGER NOT NULL CHECK(self_score BETWEEN 0 AND 100),
          hints_used INTEGER NOT NULL DEFAULT 0 CHECK(hints_used BETWEEN 0 AND 3),
          duration_seconds INTEGER NOT NULL DEFAULT 0 CHECK(duration_seconds BETWEEN 0 AND 86400),
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_practice_attempts_user_item_time ON practice_attempts(username, item_id, created_at DESC);
        CREATE TABLE IF NOT EXISTS review_history(
          id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          rating TEXT NOT NULL, reviewed_at TEXT NOT NULL, old_interval_days INTEGER NOT NULL DEFAULT 0,
          new_interval_days INTEGER NOT NULL DEFAULT 0, old_ease REAL NOT NULL DEFAULT 2.5,
          new_ease REAL NOT NULL DEFAULT 2.5, duration_seconds INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_review_history_item_time ON review_history(item_id, reviewed_at DESC);
        CREATE TABLE IF NOT EXISTS tasks(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
          status TEXT NOT NULL DEFAULT 'todo', priority INTEGER NOT NULL DEFAULT 2,
          planned_start TEXT DEFAULT '', due_at TEXT DEFAULT '', reminder_at TEXT DEFAULT '',
          estimate_minutes INTEGER NOT NULL DEFAULT 0, actual_minutes INTEGER NOT NULL DEFAULT 0,
          repeat_rule TEXT DEFAULT '', chapter_id TEXT REFERENCES chapters(id) ON DELETE SET NULL,
          item_id INTEGER REFERENCES items(id) ON DELETE SET NULL,
          depends_on_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL, tags_json TEXT DEFAULT '[]',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_schedule ON tasks(planned_start, due_at, status);
        CREATE TABLE IF NOT EXISTS study_plans(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, period_type TEXT NOT NULL,
          start_date TEXT NOT NULL, end_date TEXT NOT NULL, target_minutes INTEGER NOT NULL DEFAULT 0,
          target_cards INTEGER NOT NULL DEFAULT 0, target_questions INTEGER NOT NULL DEFAULT 0,
          active_chapters_json TEXT DEFAULT '[]', notes TEXT DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_study_plans_dates ON study_plans(start_date, end_date);
        CREATE TABLE IF NOT EXISTS time_entries(
          id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
          item_id INTEGER REFERENCES items(id) ON DELETE SET NULL, started_at TEXT NOT NULL,
          ended_at TEXT DEFAULT '', duration_minutes INTEGER NOT NULL DEFAULT 0, note TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_time_entries_start ON time_entries(started_at DESC);
        CREATE TABLE IF NOT EXISTS item_revisions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          changed_at TEXT NOT NULL, title TEXT NOT NULL, summary TEXT DEFAULT '', content TEXT DEFAULT '',
          source_status TEXT DEFAULT 'review_required', metadata_json TEXT DEFAULT '{}', change_reason TEXT DEFAULT 'ویرایش محتوا'
        );
        CREATE INDEX IF NOT EXISTS idx_item_revisions_item_time ON item_revisions(item_id,changed_at DESC);
        CREATE TABLE IF NOT EXISTS daily_activities(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
          time_of_day TEXT DEFAULT '', days_json TEXT NOT NULL DEFAULT '[0,1,2,3,4,5,6]',
          enabled INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 100, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS daily_activity_logs(
          id INTEGER PRIMARY KEY AUTOINCREMENT, activity_id INTEGER NOT NULL REFERENCES daily_activities(id) ON DELETE CASCADE,
          activity_date TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, completed_at TEXT DEFAULT '', note TEXT DEFAULT '',
          UNIQUE(activity_id,activity_date)
        );
        CREATE INDEX IF NOT EXISTS idx_daily_activity_logs_date ON daily_activity_logs(activity_date, activity_id);
        CREATE TABLE IF NOT EXISTS course_blueprints(
          id TEXT PRIMARY KEY, title TEXT NOT NULL, domain_profile TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'draft', request_json TEXT NOT NULL, blueprint_json TEXT NOT NULL,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_course_blueprints_updated ON course_blueprints(updated_at DESC);
        CREATE TABLE IF NOT EXISTS competency_evidence(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL COLLATE NOCASE,
          domain_profile TEXT NOT NULL, competency_id TEXT NOT NULL, competency_title TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'practicing' CHECK(status IN ('not_started','practicing','demonstrated','needs_review')),
          score INTEGER CHECK(score IS NULL OR score BETWEEN 0 AND 100), evidence TEXT NOT NULL DEFAULT '',
          updated_at TEXT NOT NULL, UNIQUE(username,domain_profile,competency_id)
        );
        CREATE INDEX IF NOT EXISTS idx_competency_evidence_user ON competency_evidence(username,domain_profile,status);
        ''')
        # WAL lets the LAN-hosted app safely serve multiple local clients reading while another writes.
        c.execute('PRAGMA journal_mode=WAL')
        # Migrate the historical single-account login to the multi-user table without
        # changing existing hashes or forcing a reset during an in-place upgrade.
        old_user=c.execute("SELECT value FROM settings WHERE key='auth_username'").fetchone()
        old_hash=c.execute("SELECT value FROM settings WHERE key='password_hash'").fetchone()
        if old_hash and str(old_hash['value'] or '').strip():
            legacy_name=str(old_user['value'] if old_user else 'admin').strip() or 'admin'
            c.execute("INSERT OR IGNORE INTO user_accounts(username,password_hash,role,active,created_at,updated_at) VALUES(?,?,'admin',1,?,?)",
                      (legacy_name,str(old_hash['value']),now_iso(),now_iso()))
            c.execute("UPDATE user_accounts SET role='admin',active=1,updated_at=? WHERE username=? COLLATE NOCASE",(now_iso(),legacy_name))
        plan_cols={r['name'] for r in c.execute('PRAGMA table_info(study_plans)').fetchall()}
        if 'parent_id' not in plan_cols:
            c.execute('ALTER TABLE study_plans ADD COLUMN parent_id INTEGER REFERENCES study_plans(id) ON DELETE SET NULL')
        # Fresh installs start empty. Seed the optional IT sample catalog only in explicit dev/test mode.
        # Existing chapter/item/progress rows are never deleted or replaced.
        count = c.execute("SELECT COUNT(*) n FROM chapters").fetchone()["n"]
        seed_sample_catalog = str(os.environ.get('NETWORK_LEARNING_SEED_SAMPLE_CATALOG','')).strip().lower() in {'1','true','yes','on'}
        if seed_sample_catalog:
            for n, title in CHAPTERS:
                c.execute("INSERT OR IGNORE INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)",
                          (f"c{n:02d}", title, n, 'main', 'seed', '', now_iso()))
        current_chapter_count = c.execute("SELECT COUNT(*) n FROM chapters").fetchone()["n"]
        # Keep older installations working, but do not create three predefined subjects on a blank install.
        if seed_sample_catalog or current_chapter_count > 0:
            default_features = {'lessons': True, 'questions': True, 'flashcards': True, 'commands': True,
                                'labs': True, 'images': True, 'sources': True, 'planner': True, 'reports': True}
            c.execute("INSERT OR IGNORE INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                      ('topic_it','فناوری اطلاعات','مجموعهٔ فصل‌های موجود دانشنامهٔ شبکه و فناوری اطلاعات',json.dumps(default_features,ensure_ascii=False),now_iso(),now_iso()))
            c.execute("INSERT OR IGNORE INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                      ('topic_general','مطالب درسی','موضوع مستقل برای درس‌ها و محتوای عمومی',json.dumps({'lessons':True,'questions':True,'flashcards':True,'commands':False,'labs':False,'images':True,'sources':True,'planner':True,'reports':True},ensure_ascii=False),now_iso(),now_iso()))
            c.execute("INSERT OR IGNORE INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                      ('topic_research','پژوهش و مطالعات','موضوع مستقل برای پژوهش، منابع و یادداشت‌ها',json.dumps({'lessons':True,'questions':True,'flashcards':True,'commands':False,'labs':False,'images':True,'sources':True,'planner':True,'reports':True},ensure_ascii=False),now_iso(),now_iso()))
            # Never reassign every chapter on each startup; only the deliberately seeded sample catalog is attached.
            c.execute("INSERT OR IGNORE INTO chapter_topics(chapter_id,topic_id) SELECT id,'topic_it' FROM chapters WHERE source='seed'")
        if seed_sample_catalog and count == 0:
            cid = 'c01'
            for idx, lesson in enumerate(DEMO_LESSONS, 1):
                c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (cid,'lesson',lesson['title'],lesson['summary'],lesson['content'],'demo','نمونه داخلی',f'demo-lesson-{idx}',json.dumps({'level':'مقدماتی','estimated_minutes':8},ensure_ascii=False),now_iso()))
            for idx,(front,back) in enumerate(DEMO_CARDS,1):
                cur=c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (cid,'flashcard',front,back,back,'verified','نمونه داخلی',f'demo-card-{idx}',json.dumps({'front':front,'back':back,'demo':True},ensure_ascii=False),now_iso()))
                c.execute("INSERT INTO progress(item_id,due_at) VALUES(?,?)",(cur.lastrowid,date.today().isoformat()))
            for idx,q in enumerate(DEMO_QUESTIONS,1):
                c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (cid,'question',q['question'],q['explanation'],q['question'],'verified','نمونه داخلی',f'demo-question-{idx}',json.dumps(q,ensure_ascii=False),now_iso()))
        # Fresh installs intentionally remain empty: the learner supplies and validates all course content.
        # No starter chapter, lesson, quiz, flashcard, or generic placeholder chapter introduction is seeded.

        c.commit()

init_db()

@app.get('/', response_class=HTMLResponse)
def home(): return INDEX.read_text(encoding='utf-8')

@app.get('/api/state')
def api_state(topic_id: str = ''):
    with connect() as c:
        chapters = c.execute('''SELECT ch.*, COUNT(DISTINCT CASE WHEN i.kind='lesson' THEN i.id END) lesson_count,
         COUNT(DISTINCT CASE WHEN i.kind='flashcard' THEN i.id END) card_count,
         COUNT(DISTINCT CASE WHEN i.kind='question' THEN i.id END) question_count,
         COUNT(DISTINCT CASE WHEN i.kind='command' THEN i.id END) command_count,
         COUNT(DISTINCT CASE WHEN i.kind='asset' THEN i.id END) asset_count, ct.topic_id, t.title topic_title
         FROM chapters ch LEFT JOIN items i ON i.chapter_id=ch.id LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id LEFT JOIN topics t ON t.id=ct.topic_id WHERE (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct2 WHERE ct2.chapter_id=ch.id AND ct2.topic_id=?)) GROUP BY ch.id
         ORDER BY COALESCE(t.title,'') COLLATE NATURAL_NOCASE, CASE ch.group_name WHEN 'main' THEN 0 ELSE 1 END, ch.order_num, ch.title COLLATE NATURAL_NOCASE, ch.id''',(topic_id,topic_id)).fetchall()
        total_items=c.execute("SELECT COUNT(*) n FROM items i WHERE (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        total_lessons=c.execute("SELECT COUNT(*) n FROM items i WHERE kind='lesson' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        total_cards=c.execute("SELECT COUNT(*) n FROM items i WHERE kind='flashcard' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        due=c.execute("SELECT COUNT(*) n FROM items i LEFT JOIN progress p ON p.item_id=i.id WHERE i.kind='flashcard' AND i.source_status='verified' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)) AND (p.due_at IS NULL OR p.due_at='' OR date(p.due_at)<=date('now','localtime'))",(topic_id,topic_id)).fetchone()['n']
        reviewed=c.execute("SELECT COUNT(*) n FROM progress p JOIN items i ON i.id=p.item_id WHERE p.last_reviewed<>'' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        completed=c.execute("SELECT COUNT(*) n FROM progress p JOIN items i ON i.id=p.item_id WHERE p.completed=1 AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        assets=c.execute("SELECT COUNT(*) n FROM items i WHERE kind='asset' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        task_open=c.execute("SELECT COUNT(*) n FROM tasks t WHERE status IN ('todo','in_progress','waiting') AND (?='' OR t.chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        pending_review=c.execute("SELECT COUNT(*) n FROM items i WHERE source_status IN ('review_required','content_enriched','needs_revision') AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))",(topic_id,topic_id)).fetchone()['n']
        recent=c.execute("SELECT i.id,i.chapter_id,i.kind,i.title,i.summary,i.source_status,i.created_at,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.kind<>'asset' AND i.source_status='verified' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)) ORDER BY i.id DESC LIMIT 6",(topic_id,topic_id)).fetchall()
        next_lesson=c.execute("""SELECT i.id,i.chapter_id,i.kind,i.title,i.summary,i.source_status,i.created_at,ch.title chapter_title
          FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id
          WHERE i.kind='lesson' AND i.source_status='verified' AND COALESCE(p.completed,0)=0 AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))
          ORDER BY ch.order_num, ch.title COLLATE NATURAL_NOCASE, ch.id, chapter_content_seq(i.kind,i.source_uid,i.title,i.metadata_json,i.id), i.id ASC LIMIT 1""",(topic_id,topic_id)).fetchone()
        chapter_rows=[dict(x) for x in chapters]
        topic_chapter_numbers={}
        for row in chapter_rows:
            topic_key=str(row.get('topic_id') or '__unassigned__')
            topic_chapter_numbers[topic_key]=topic_chapter_numbers.get(topic_key,0)+1
            row['chapter_number']=topic_chapter_numbers[topic_key]
        return {'chapters':chapter_rows, 'totals':{'chapters':len(chapters),'lessons':total_lessons,'cards':total_cards,'due':due,'reviewed':reviewed,'completed':completed,'assets':assets,'items':total_items,'tasks_open':task_open,'pending_review':pending_review},'recent':[dict(x) for x in recent], 'next_lesson':dict(next_lesson) if next_lesson else None}

def _fa_to_ascii_digits(value):
    value = str(value or '')
    return value.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'))


def _natural_text_compare(left, right):
    """Case-insensitive natural comparison with Persian/Arabic-Indic digits normalized."""
    def key(value):
        normalized = _fa_to_ascii_digits(str(value or '')).casefold()
        parts = []
        for part in re.split(r'(\d+)', normalized):
            if not part:
                continue
            parts.append((1, int(part)) if part.isdigit() else (0, part))
        return tuple(parts)
    a, b = key(left), key(right)
    return -1 if a < b else (1 if a > b else 0)


def _chapter_record_sequence(row):
    """Return a stable natural sequence for a content record within its chapter/type.

    Sequence hints from authoring tools are preferred, then stable UIDs, then numbered titles.
    Persian/Arabic-Indic numerals are normalized before parsing so they sort numerically too.
    """
    try:
        md = json.loads(row['metadata_json'] or '{}')
    except Exception:
        md = {}
    if not isinstance(md, dict):
        md = {}
    title = _fa_to_ascii_digits(str(row['title'] or '')).strip()
    uid = _fa_to_ascii_digits(str(row['source_uid'] or ''))
    kind = str(row['kind'] or '').lower()
    record_type = str(md.get('record_type') or '').lower()
    is_intro = record_type in {'chapter_intro', 'chapter_introduction', 'book_intro', 'intro'} or bool(re.search(r'^(مقدمه|راهنمای آغاز|پیش‌درآمد)', title))
    if is_intro:
        return -1

    def numeric(value):
        if isinstance(value, bool) or value is None:
            return None
        if isinstance(value, int) and value >= 0:
            return value
        text = _fa_to_ascii_digits(str(value)).strip().replace(',', '').replace('٬', '')
        if re.fullmatch(r'\d{1,9}', text):
            return int(text)
        return None

    # Prefer kind-specific authoring sequence fields over generic ordering metadata.
    specific = {
        'lesson': ('lesson_number', 'lesson_no', 'lesson_index'),
        'flashcard': ('card_number', 'flashcard_number', 'card_index'),
        'question': ('question_number', 'question_no', 'question_index'),
        'command': ('command_number', 'command_index'),
        'lab': ('lab_number', 'scenario_number', 'lab_index'),
        'example': ('example_number', 'example_index'),
        'note': ('note_number', 'note_index'),
    }.get(kind, ())
    keys = specific + ('chapter_sequence', 'content_sequence', 'sequence_number', 'sequence', 'order_num', 'number', 'index')
    for key in keys:
        value = numeric(md.get(key))
        if value is not None:
            return value

    # Recognize explicit kind numbers inside stable UIDs (e.g. c21-lesson-01, q-004).
    uid_patterns = {
        'lesson': r'(?:lesson|درس)[-_ ]*0*(\d{1,6})(?=$|[-_])',
        'flashcard': r'(?:flashcard|cards?|کارت)[-_ ]*0*(\d{1,6})(?=$|[-_])',
        'question': r'(?:questions?|q|سؤال|سوال)[-_ ]*0*(\d{1,6})(?=$|[-_])',
        'note': r'(?:notes?|نکته)[-_ ]*0*(\d{1,6})(?=$|[-_])',
        'example': r'(?:examples?|مثال)[-_ ]*0*(\d{1,6})(?=$|[-_])',
        'lab': r'(?:scenarios?|labs?|آزمایشگاه|سناریو)[-_ ]*0*(\d{1,6})(?=$|[-_])',
        'command': r'(?:commands?|cmd|فرمان)[-_ ]*0*(\d{1,6})(?=$|[-_])',
    }
    match = re.search(uid_patterns.get(kind, r'(?!)'), uid, re.IGNORECASE)
    if match:
        return int(match.group(1))

    title_patterns = {
        'lesson': r'^\s*(?:درس|lesson)\s*0*(\d+)',
        'flashcard': r'^\s*(?:فلش.?کارت|کارت|flashcard|card)\s*0*(\d+)',
        'question': r'^\s*(?:سؤال|سوال|پرسش|question)\s*0*(\d+)',
        'note': r'^\s*نکته\s*0*(\d+)',
        'example': r'^\s*(?:مثال|example)\s*0*(\d+)',
        'lab': r'^\s*(?:سناریو|آزمایشگاه|lab|scenario)\s*0*(\d+)',
        'command': r'^\s*(?:فرمان|دستور|command)\s*0*(\d+)',
    }
    match = re.search(title_patterns.get(kind, r'(?!)'), title, re.IGNORECASE)
    if match:
        return int(match.group(1))

    # Also support numbered filenames/titles such as "01 - Ethernet basics" and "۲. IPv6".
    if kind in {'lesson', 'flashcard', 'question', 'note', 'example', 'lab', 'command'}:
        match = re.match(r'^\s*0*(\d{1,6})(?=\s*(?:[.)،:؛\-–—_]\s*|\s+))', title)
        if match:
            return int(match.group(1))

    # Keep non-numbered legacy records stable and after explicitly numbered content.
    return 1_000_000_000 + int(row['id'])


def _chapter_record_kind_rank(kind):
    return {'lesson': 0, 'flashcard': 1, 'question': 2, 'note': 3, 'example': 4, 'lab': 5, 'command': 6, 'asset': 7}.get(str(kind or ''), 99)


def _chapter_content_sort_key(row):
    return (_chapter_record_kind_rank(row['kind']), _chapter_record_sequence(row), int(row['id']))


def _is_chapter_intro_row(row):
    try:
        md = json.loads(row['metadata_json'] or '{}')
    except Exception:
        md = {}
    title = str(row['title'] or '').strip()
    return str((md or {}).get('record_type') or '').lower() in {'chapter_intro', 'chapter_introduction', 'book_intro', 'intro'} or title.startswith(('مقدمه', 'راهنمای آغاز', 'پیش‌درآمد'))


@app.get('/api/items')
def list_items(chapter_id: str = '', kind: str = '', q: str = '', limit: int = 100, offset: int = 0, topic_id: str = ''):
    limit=max(1,min(limit,1000)); offset=max(0,offset)
    q_clean = (q or '')[:120].casefold()
    with connect() as c:
        if chapter_id:
            # Sort first and number within each chapter/type before kind/text filters and pagination.
            all_rows = c.execute("""SELECT i.*, ch.title chapter_title, p.completed, p.correct_count, p.wrong_count, p.due_at, p.last_reviewed
                FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id
                WHERE i.chapter_id=? AND i.source_status='verified' AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?))""", (chapter_id,topic_id,topic_id)).fetchall()
            ordered = sorted(all_rows, key=_chapter_content_sort_key)
            per_kind = {}
            sequence_map = {}
            label_map = {}
            for row in ordered:
                rid = int(row['id']); kind_name = str(row['kind'] or '')
                if _is_chapter_intro_row(row):
                    sequence_map[rid] = None
                    label_map[rid] = 'مقدمهٔ فصل'
                    continue
                per_kind[kind_name] = per_kind.get(kind_name, 0) + 1
                seq = per_kind[kind_name]
                sequence_map[rid] = seq
                label_map[rid] = {
                    'lesson':'درس', 'flashcard':'فلش‌کارت', 'question':'سؤال', 'note':'نکته',
                    'example':'مثال', 'lab':'آزمایشگاه / سناریو', 'command':'فرمان', 'asset':'رسانه'
                }.get(kind_name, 'محتوا') + ' ' + str(seq)
            filtered = []
            for row in ordered:
                if kind and kind != 'all' and row['kind'] != kind:
                    continue
                if q_clean and not any(q_clean in str(row[k] or '').casefold() for k in ('title','summary','content','source_file')):
                    continue
                item = item_public(row)
                item['display_sequence'] = sequence_map.get(int(row['id']))
                item['display_sequence_label'] = label_map.get(int(row['id']), '')
                filtered.append(item)
            total = len(filtered)
            page = filtered[offset:offset+limit]
            return {'items':page,'count':len(page),'total_count':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}

        where=" WHERE i.source_status='verified'"; args=[]
        if topic_id: where+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; args.append(topic_id)
        if kind and kind!='all': where+=' AND i.kind=?'; args.append(kind)
        if q:
            where+=' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ?)'; pat=f'%{q[:120]}%'; args.extend([pat,pat,pat])
        # IDs ascend within each kind: imports preserve sequence in insertion order. This avoids
        # the previous DESC ordering that displayed Lesson 40 before Lesson 01.
        order=' ORDER BY ch.order_num, ch.title COLLATE NATURAL_NOCASE, ch.id, CASE i.kind WHEN "lesson" THEN 0 WHEN "flashcard" THEN 1 WHEN "question" THEN 2 WHEN "note" THEN 3 WHEN "example" THEN 4 WHEN "lab" THEN 5 WHEN "command" THEN 6 ELSE 7 END, chapter_content_seq(i.kind,i.source_uid,i.title,i.metadata_json,i.id), i.id ASC'
        total=c.execute('SELECT COUNT(*) n FROM items i JOIN chapters ch ON ch.id=i.chapter_id'+where,args).fetchone()['n']
        rows=c.execute("""SELECT i.*, ch.title chapter_title, p.completed, p.correct_count, p.wrong_count, p.due_at, p.last_reviewed
           FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id""" + where + order + ' LIMIT ? OFFSET ?', args+[limit,offset]).fetchall()
        return {'items':[item_public(r) for r in rows], 'count':len(rows), 'total_count':total, 'offset':offset, 'limit':limit, 'has_more':offset+len(rows)<total}

def item_public(r):
    """Return learner-facing item data without leaking quiz answer keys."""
    d=dict(r)
    try: d['metadata']=json.loads(d.get('metadata_json') or '{}')
    except: d['metadata']={}
    d.pop('metadata_json',None)
    if d.get('kind') == 'lab':
        meta=d.get('metadata') if isinstance(d.get('metadata'),dict) else {}
        # Keep staged coaching in the dedicated practice endpoints rather than the generic list.
        for hidden_key in ('hints','solution','rubric'):
            meta.pop(hidden_key, None)
        d['metadata']=meta
    if d.get('kind') == 'question':
        meta=d.get('metadata') if isinstance(d.get('metadata'),dict) else {}
        opts=meta.get('options')
        key=meta.get('correct_index')
        verified=(d.get('source_status') == 'verified' and isinstance(opts,list)
                  and isinstance(key,int) and not isinstance(key,bool) and 0 <= key < len(opts))
        meta.pop('correct_index',None)
        meta.pop('explanation',None)
        meta['has_answer_key']=bool(verified)
        d['metadata']=meta
        # Question explanations can reveal the keyed answer, so they are returned only
        # after the learner submits an answer to /api/assessment/answer.
        d['summary']=''
    return d

class PersonalNoteIn(BaseModel):
    bookmarked: Optional[bool] = None
    note: Optional[str] = None

@app.get('/api/personal/items')
def list_personal_items(topic_id: str = '', q: str = '', bookmarked_only: bool = False):
    sql='''SELECT n.item_id,n.bookmarked,n.note,n.updated_at,i.title,i.kind,i.chapter_id,ch.title chapter_title
      FROM personal_item_notes n JOIN items i ON i.id=n.item_id JOIN chapters ch ON ch.id=i.chapter_id WHERE 1=1'''; args=[]
    if topic_id: sql+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; args.append(topic_id)
    if bookmarked_only: sql+=' AND n.bookmarked=1'
    if q.strip():
        pat='%'+q.strip()[:120]+'%'; sql+=' AND (i.title LIKE ? OR n.note LIKE ?)'; args.extend([pat,pat])
    sql+=' ORDER BY n.bookmarked DESC,n.updated_at DESC'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    return {'items':[dict(r) for r in rows],'count':len(rows)}

@app.get('/api/personal/items/{item_id}')
def get_personal_item(item_id: int):
    with connect() as c:
        row=c.execute('SELECT item_id,bookmarked,note,updated_at FROM personal_item_notes WHERE item_id=?',(item_id,)).fetchone()
    return dict(row) if row else {'item_id':item_id,'bookmarked':0,'note':'','updated_at':''}

@app.put('/api/personal/items/{item_id}')
def save_personal_item(item_id: int, payload: PersonalNoteIn):
    with connect() as c:
        if not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'محتوا پیدا نشد')
        old=c.execute('SELECT * FROM personal_item_notes WHERE item_id=?',(item_id,)).fetchone()
        bookmarked=int(bool(payload.bookmarked)) if payload.bookmarked is not None else int(old['bookmarked']) if old else 0
        note=(str(payload.note)[:12000] if payload.note is not None else (old['note'] if old else ''))
        c.execute('INSERT INTO personal_item_notes(item_id,bookmarked,note,updated_at) VALUES(?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET bookmarked=excluded.bookmarked,note=excluded.note,updated_at=excluded.updated_at',(item_id,bookmarked,note,now_iso())); c.commit()
    return {'ok':True,'item_id':item_id,'bookmarked':bookmarked,'note':note}

@app.get('/api/item/{item_id}')
def get_item(item_id:int):
    with connect() as c:
        r=c.execute('''SELECT i.*,ch.title chapter_title,p.completed,p.correct_count,p.wrong_count,p.due_at,p.last_reviewed
          FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id WHERE i.id=?''',(item_id,)).fetchone()
        if not r: raise HTTPException(404,'مورد پیدا نشد')
        return item_public(r)

@app.get('/api/quiz/questions')
def quiz_questions(chapter_id: str = '', limit: int = 30, topic_id: str = '', difficulty: str = 'all'):
    # Draw a randomized sample only from approved questions with a valid answer key.
    limit=max(1,min(int(limit),100))
    allowed_difficulties={'beginner','intermediate','advanced','expert'}
    difficulty=(difficulty or 'all').strip().lower()
    if difficulty not in allowed_difficulties and difficulty != 'all':
        difficulty='all'
    where=" WHERE i.kind='question' AND i.source_status='verified'"
    args=[]
    if chapter_id:
        where+=' AND i.chapter_id=?'; args.append(chapter_id)
    if topic_id:
        where+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; args.append(topic_id)
    with connect() as c:
        rows=c.execute('''SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id''' + where, args).fetchall()
    eligible=[]
    for row in rows:
        try: md=json.loads(row['metadata_json'] or '{}')
        except Exception: continue
        opts=md.get('options'); key=md.get('correct_index')
        if not (isinstance(opts,list) and len(opts)>=2 and isinstance(key,int) and not isinstance(key,bool) and 0<=key<len(opts)):
            continue
        # Older packs may call the field level or difficulty; accept either.
        row_difficulty=str(md.get('difficulty') or md.get('level') or '').strip().lower()
        aliases={'basic':'beginner','easy':'beginner','medium':'intermediate','normal':'intermediate','hard':'advanced'}
        row_difficulty=aliases.get(row_difficulty,row_difficulty)
        if difficulty != 'all' and row_difficulty != difficulty:
            continue
        eligible.append(row)
    random.SystemRandom().shuffle(eligible)
    sample=eligible[:limit]
    return {'items':[item_public(r) for r in sample], 'available':len(eligible), 'sample_size':len(sample), 'chapter_id':chapter_id,'topic_id':topic_id,'difficulty':difficulty,'limit':limit}


@app.get('/api/review/due')
def review_due(limit:int=50, new_limit:Optional[int]=None, review_limit:Optional[int]=None, chapter_ids:str='', mode:str='due', q:str='', topic_id:str=''):
    # Return only verified cards. mode: due, new, weak, all.
    if new_limit is None:
        try: new_limit=int(get_setting('pref_daily_new_cards_limit','20'))
        except: new_limit=20
    if review_limit is None:
        try: review_limit=int(get_setting('pref_daily_review_limit','100'))
        except: review_limit=100
    new_limit=max(0,min(int(new_limit),500)); review_limit=max(0,min(int(review_limit),500))
    limit=max(1,min(int(limit),500))
    selected_chapters=[x for x in (chapter_ids or '').split(',') if x]
    where=["i.kind='flashcard'", "i.source_status='verified'"]
    args=[]
    if selected_chapters:
        where.append('i.chapter_id IN ('+','.join('?' for _ in selected_chapters)+')'); args.extend(selected_chapters)
    if topic_id:
        where.append('EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'); args.append(topic_id)
    if q.strip():
        pat=f"%{q.strip()[:120]}%"
        where.append('(i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.metadata_json LIKE ?)')
        args.extend([pat,pat,pat,pat])
    if mode=='new':
        where.append("(p.item_id IS NULL OR (COALESCE(p.interval_days,0)=0 AND (p.last_reviewed IS NULL OR p.last_reviewed='')))")
        order=' ORDER BY i.id DESC'
    elif mode=='due':
        where.append("(p.due_at IS NULL OR p.due_at='' OR date(p.due_at)<=date('now','localtime'))")
        order=" ORDER BY COALESCE(p.due_at,'1900-01-01'), i.id DESC"
    elif mode=='weak':
        where.append("p.item_id IS NOT NULL AND COALESCE(p.wrong_count,0)>0")
        order=' ORDER BY COALESCE(p.wrong_count,0) DESC, COALESCE(p.correct_count,0) ASC, i.id DESC'
    elif mode=='all':
        order=' ORDER BY i.id DESC'
    else:
        raise HTTPException(400,'حالت مرور معتبر نیست')
    with connect() as c:
        rows=c.execute('''SELECT i.*,ch.title chapter_title,p.interval_days,p.ease,p.due_at,p.last_reviewed,p.correct_count,p.wrong_count
          FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id
          WHERE '''+' AND '.join(where)+order+' LIMIT ?',args+[limit]).fetchall()
    fresh=[]; due=[]
    for r in rows:
        if not r['last_reviewed'] and int(r['interval_days'] or 0)==0: fresh.append(r)
        else: due.append(r)
    if mode=='new': selected=rows[:min(new_limit or limit,limit)]
    elif mode=='due': selected=due[:review_limit]+fresh[:new_limit]
    else: selected=list(rows)
    return {'cards':[item_public(x) for x in selected[:limit]],'count':min(len(selected),limit),
            'new_cards':sum(1 for r in selected if not r['last_reviewed'] and int(r['interval_days'] or 0)==0),
            'review_cards':sum(1 for r in selected if r['last_reviewed'] or int(r['interval_days'] or 0)>0),
            'mode':mode,'limits':{'new':new_limit,'review':review_limit,'result':limit}}

# Multi-topic workspace: additive APIs; legacy chapters remain in the IT topic by default.
class TopicIn(BaseModel):
    title: str
    description: str = ''
    features: dict[str, bool] = {}

class TopicUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    features: Optional[dict[str, bool]] = None
    chapter_ids: Optional[list[str]] = None

TOPIC_FEATURES = {'lessons','questions','flashcards','commands','labs','images','sources','planner','reports'}

@app.get('/api/topics')
def list_topics():
    with connect() as c:
        rows=c.execute('''SELECT t.*, COUNT(ct.chapter_id) chapter_count FROM topics t
          LEFT JOIN chapter_topics ct ON ct.topic_id=t.id GROUP BY t.id ORDER BY t.created_at,t.title''').fetchall()
    result=[]
    for r in rows:
        try: features=json.loads(r['features_json'] or '{}')
        except Exception: features={}
        result.append({'id':r['id'],'title':r['title'],'description':r['description'],'features':features,
                       'chapter_count':r['chapter_count'],'created_at':r['created_at'],'updated_at':r['updated_at']})
    return {'topics':result}

@app.post('/api/topics')
def create_topic(payload: TopicIn):
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان موضوع الزامی است')
    features={k:bool(v) for k,v in payload.features.items() if k in TOPIC_FEATURES}
    for key in TOPIC_FEATURES: features.setdefault(key, key not in {'commands','labs'})
    tid='t'+hashlib.sha1((title+now_iso()+secrets.token_hex(4)).encode()).hexdigest()[:11]
    now=now_iso()
    try:
        with connect() as c:
            c.execute('INSERT INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)',
                      (tid,title,payload.description.strip(),json.dumps(features,ensure_ascii=False),now,now)); c.commit()
    except sqlite3.IntegrityError: raise HTTPException(409,'موضوعی با همین عنوان وجود دارد')
    return {'ok':True,'id':tid,'title':title,'description':payload.description,'features':features}

@app.put('/api/topics/{topic_id}')
def update_topic(topic_id:str,payload:TopicUpdate):
    with connect() as c:
        row=c.execute('SELECT * FROM topics WHERE id=?',(topic_id,)).fetchone()
        if not row: raise HTTPException(404,'موضوع پیدا نشد')
        title=(payload.title.strip() if payload.title is not None else row['title'])
        if not title: raise HTTPException(400,'عنوان موضوع نمی‌تواند خالی باشد')
        desc=payload.description if payload.description is not None else row['description']
        features=json.loads(row['features_json'] or '{}')
        if payload.features is not None:
            features.update({k:bool(v) for k,v in payload.features.items() if k in TOPIC_FEATURES})
        wanted=None
        if payload.chapter_ids is not None:
            wanted=list(dict.fromkeys(str(x).strip() for x in payload.chapter_ids if str(x).strip()))
            if wanted:
                marks=','.join('?' for _ in wanted)
                valid={r['id'] for r in c.execute(f'SELECT id FROM chapters WHERE id IN ({marks})',wanted).fetchall()}
                missing=[x for x in wanted if x not in valid]
                if missing: raise HTTPException(400,'شناسهٔ فصل نامعتبر است: '+', '.join(missing[:10]))
        try:
            c.execute('UPDATE topics SET title=?,description=?,features_json=?,updated_at=? WHERE id=?',
                      (title,desc,json.dumps(features,ensure_ascii=False),now_iso(),topic_id))
            if wanted is not None:
                current={r['chapter_id'] for r in c.execute('SELECT chapter_id FROM chapter_topics WHERE topic_id=?',(topic_id,)).fetchall()}
                remove=sorted(current-set(wanted))
                if remove:
                    marks=','.join('?' for _ in remove)
                    c.execute(f'DELETE FROM chapter_topics WHERE topic_id=? AND chapter_id IN ({marks})',[topic_id,*remove])
                for cid in wanted:
                    c.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?) ON CONFLICT(chapter_id) DO UPDATE SET topic_id=excluded.topic_id',(cid,topic_id))
            c.commit()
        except sqlite3.IntegrityError: raise HTTPException(409,'موضوعی با همین عنوان وجود دارد')
    return {'ok':True,'id':topic_id,'title':title,'description':desc,'features':features,'assigned_chapters':len(wanted) if wanted is not None else None}

class TopicDeleteIn(BaseModel):
    confirm: bool = False


@app.delete('/api/topics/{topic_id}')
def delete_topic(topic_id: str, payload: TopicDeleteIn):
    if not payload.confirm: raise HTTPException(400,'برای حذف موضوع، confirm=true لازم است.')
    with connect() as c:
        row=c.execute('SELECT id,title FROM topics WHERE id=?',(topic_id,)).fetchone()
        if not row: raise HTTPException(404,'موضوع پیدا نشد')
        detached=int(c.execute('SELECT COUNT(*) n FROM chapter_topics WHERE topic_id=?',(topic_id,)).fetchone()['n'])
        c.execute('DELETE FROM chapter_topics WHERE topic_id=?',(topic_id,))
        c.execute('DELETE FROM topics WHERE id=?',(topic_id,)); c.commit()
    return {'ok':True,'topic_id':topic_id,'title':row['title'],'detached_chapters':detached,'content_deleted':False}


@app.post('/api/topics/{topic_id}/chapters/{chapter_id}')
def assign_chapter_topic(topic_id:str,chapter_id:str):
    with connect() as c:
        if not c.execute('SELECT 1 FROM topics WHERE id=?',(topic_id,)).fetchone(): raise HTTPException(404,'موضوع پیدا نشد')
        if not c.execute('SELECT 1 FROM chapters WHERE id=?',(chapter_id,)).fetchone(): raise HTTPException(404,'فصل پیدا نشد')
        c.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?) ON CONFLICT(chapter_id) DO UPDATE SET topic_id=excluded.topic_id',(chapter_id,topic_id)); c.commit()
    return {'ok':True,'topic_id':topic_id,'chapter_id':chapter_id}

@app.get('/api/topics/{topic_id}/chapters')
def topic_chapters(topic_id:str):
    with connect() as c:
        if not c.execute('SELECT 1 FROM topics WHERE id=?',(topic_id,)).fetchone(): raise HTTPException(404,'موضوع پیدا نشد')
        rows=c.execute('''SELECT ch.*, (SELECT COUNT(*) FROM items i WHERE i.chapter_id=ch.id) item_count
          FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ct.topic_id=? ORDER BY CASE ch.group_name WHEN 'main' THEN 0 ELSE 1 END,ch.order_num,ch.title,ch.id''',(topic_id,)).fetchall()
    chapters=[dict(r) for r in rows]
    for number, chapter in enumerate(chapters,1): chapter['chapter_number']=number
    return {'chapters':chapters}

class TopicChaptersUpdate(BaseModel):
    chapter_ids: list[str] = []

@app.put('/api/topics/{topic_id}/chapters')
def update_topic_chapters(topic_id: str, payload: TopicChaptersUpdate):
    wanted=list(dict.fromkeys(str(x).strip() for x in payload.chapter_ids if str(x).strip()))
    with connect() as c:
        if not c.execute('SELECT 1 FROM topics WHERE id=?',(topic_id,)).fetchone(): raise HTTPException(404,'موضوع پیدا نشد')
        if wanted:
            valid={r['id'] for r in c.execute('SELECT id FROM chapters WHERE id IN ('+','.join('?' for _ in wanted)+')',wanted).fetchall()}
            missing=[x for x in wanted if x not in valid]
            if missing: raise HTTPException(400,'شناسهٔ یک یا چند فصل معتبر نیست: '+', '.join(missing[:10]))
        current={r['chapter_id'] for r in c.execute('SELECT chapter_id FROM chapter_topics WHERE topic_id=?',(topic_id,)).fetchall()}
        remove=sorted(current-set(wanted))
        if remove:
            c.execute('DELETE FROM chapter_topics WHERE topic_id=? AND chapter_id IN ('+','.join('?' for _ in remove)+')',[topic_id,*remove])
        for cid in wanted:
            c.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?) ON CONFLICT(chapter_id) DO UPDATE SET topic_id=excluded.topic_id',(cid,topic_id))
        c.commit()
    return {'ok':True,'topic_id':topic_id,'assigned':len(wanted),'unassigned_from_topic':len(remove)}

class PromptBuildIn(BaseModel):
    topic_id: str
    topic_title: str = ''
    chapter_titles: list[str] = []
    structure_mode: str = 'chapters'
    chapter_numbering_mode: str = 'app_order'
    lesson_count: int = 5
    questions_per_lesson: int = 3
    examples_per_lesson: int = 2
    flashcards_per_lesson: int = 4
    notes_per_chapter: int = 3
    commands_per_chapter: int = 5
    labs_per_chapter: int = 2
    images_per_chapter: int = 2
    include_images: bool = True
    include_sources: bool = True
    include_commands: bool = False
    include_labs: bool = False
    audience: str = 'مقدماتی تا متوسط'
    language: str = 'fa-IR'
    extra_instructions: str = ''
    prompt_profile: str = 'balanced'
    quality_review: bool = True

@app.post('/api/topics/prompt-preview')
def topic_prompt_preview(payload:PromptBuildIn):
    with connect() as c:
        t=c.execute('SELECT * FROM topics WHERE id=?',(payload.topic_id,)).fetchone()
        if not t: raise HTTPException(404,'موضوع پیدا نشد')
    features=json.loads(t['features_json'] or '{}')
    allowed={k:bool(features.get(k,False)) for k in TOPIC_FEATURES}
    topic_label=(payload.topic_title.strip() or t['title'])
    topic_probe=(topic_label+' '+str(t['description'] or '')).casefold()
    if any(k in topic_probe for k in ('mikrotik','network','شبکه','سیسکو','روتر','سوئیچ','امنیت سایبری','cybersecurity','linux','windows server','برنامه‌نویسی','python','asp.net','sql server')):
        domain_profile={'domain':'فناوری و مهندسی','rules':['نسخه و محیط اجرا را مشخص کن','پیش‌نیازها، تنظیمات، فرمان‌های قابل اجرا و خروجی مورد انتظار را بنویس','برای تغییرات پرخطر هشدار و راه بازگشت ارائه کن','آزمایشگاه فقط در محیط مجاز و کنترل‌شده باشد','روش عیب‌یابی و راستی‌آزمایی نتیجه را اضافه کن']}
    elif any(k in topic_probe for k in ('مطهری','جوادی','حوزه','فقه','حدیث','قرآن','اسلام','دین','فلسفه','کلام','تفسیر','روایت','religion','philosophy')):
        domain_profile={'domain':'مطالعات دینی، فلسفی و انسانی','rules':['میان نقل‌قول مستقیم، بازگویی و تحلیل نویسنده تمایز روشن بگذار','نام کتاب، مؤلف، فصل/بخش و صفحه را فقط در صورت اطمینان ثبت کن','هیچ نقل‌قول، انتساب، حدیث یا ارجاعی را جعل نکن؛ موارد نیازمند بررسی را علامت بزن','دیدگاه‌های متفاوت را منصفانه و با زمینهٔ تاریخی/مفهومی توضیح بده','پرسش‌های تحلیلی و مقایسه‌ای بساز و پاسخ را مستدل کن']}
    else:
        domain_profile={'domain':'آموزش عمومی/تخصصی','rules':['اهداف قابل سنجش و پیش‌نیازها را مشخص کن','تعریف دقیق، توضیح مرحله‌ای و مثال حل‌شده ارائه کن','تمرین از ساده به دشوار و معیار ارزیابی پاسخ بساز','خطاهای رایج و بازخورد اصلاحی را اضافه کن','ادعاها و منابع را راستی‌آزمایی کن و منبع ساختگی نساز']}
    outline_titles=[str(x).strip()[:180] for x in payload.chapter_titles if str(x).strip()][:100]
    structure_mode=payload.structure_mode if payload.structure_mode in {'chapters','single_chapter_subsections'} else 'chapters'
    chapter_numbering_mode='app_order'  # Display numbering is always assigned by the application, not the ZIP.
    chapter_titles=outline_titles[:1] if structure_mode=='single_chapter_subsections' else list(outline_titles)
    subchapter_titles=outline_titles[1:] if structure_mode=='single_chapter_subsections' else []
    chapter_prompts=[{'chapter_title':title,'authoring_focus':domain_profile['rules'],'subchapter_titles':subchapter_titles if structure_mode=='single_chapter_subsections' else [],'chapter_specific_requirements':'برای همین فصل، دامنه و واژگان اختصاصی عنوان را استخراج کن؛ از تکرار فصل‌های دیگر جلوگیری کن؛ پیش‌نیاز و خروجی یادگیری این فصل را جداگانه تعریف کن؛ مثال و تمرین باید مستقیماً به همین فصل مربوط باشد. هر سرفصل فرعی را در فرادادهٔ آیتم‌ها نگه دار و فصل مستقل جدید نساز.'} for title in chapter_titles]
    include_commands=bool(payload.include_commands and allowed['commands'])
    include_labs=bool(payload.include_labs and allowed['labs'])
    spec={'schema_version':'1.1','topic':{'id':t['id'],'title':topic_label},
          'structure':{'mode':structure_mode,'outline_titles':outline_titles,'top_level_chapter_titles':chapter_titles,'subchapter_titles':subchapter_titles,
                       'policy':'Only top_level_chapter_titles become entries in chapters[]. Subchapter headings are stored on item metadata; they are not database chapters.'},
          'chapter_numbering':{'mode':chapter_numbering_mode,'rule':'app_order' if chapter_numbering_mode=='app_order' else 'preserve_title_prefix',
                       'policy':'The application exclusively assigns display sequence and order_num; ignore chapter numbers embedded in ZIP metadata, filenames, headings, lesson titles, and content IDs.'},
          'domain_profile':domain_profile,'chapter_prompts':chapter_prompts,'generation':{'chapter_titles':chapter_titles,'outline_titles':outline_titles,'subchapter_titles':subchapter_titles,'lesson_count':max(1,min(payload.lesson_count,100)),
          'questions_per_lesson':max(0,min(payload.questions_per_lesson,30)),'examples_per_lesson':max(0,min(payload.examples_per_lesson,20)),
          'flashcards_per_lesson':max(0,min(payload.flashcards_per_lesson,30)),
          'notes_per_chapter':max(0,min(payload.notes_per_chapter,30)),
          'commands_per_chapter':max(0,min(payload.commands_per_chapter,50)),
          'labs_per_chapter':max(0,min(payload.labs_per_chapter,20)),
          'images_per_chapter':max(0,min(payload.images_per_chapter,30)),
          'audience':payload.audience,'language':payload.language},'features':{
          'lessons':allowed['lessons'],'questions':allowed['questions'],'flashcards':allowed['flashcards'],
          'images':bool(payload.include_images and allowed['images']),'sources':bool(payload.include_sources and allowed['sources']),
          'commands':include_commands,'labs':include_labs,'planner':allowed['planner'],'reports':allowed['reports']},
          'output_contract':{'format':'JSON only','encoding':'UTF-8','no_markdown_fences':True,
          'required_top_level':['format','version','title','chapter_id','chapters','items','topic'],'required_chapter_fields':['id','title','description'],
          'required_item_fields':['chapter_id','kind','title','summary','content','source_status','source_file','source_uid','metadata'],'required_lesson_fields':['title','summary','content','level','estimated_minutes'],
          'required_question_fields':['question','options','correct_index','explanation'],'question_options_count':4,
          'required_flashcard_fields':['front','back'],'required_visual_prompt_fields':['prompt_fa','prompt_en','alt_text','status'],
          'required_review_status':'review_required','source_fields':['title','author_or_organization','url','accessed_at'],'do_not_invent_sources':True},
          'extra_instructions':payload.extra_instructions.strip()}
    prompt_profiles={
      'balanced':{'name':'جامع و متعادل','rules':['مفهوم، مثال، تمرین، مرور و ارزیابی را متوازن پوشش بده.','عمق هر بخش متناسب با سطح مخاطب باشد و از تکرار بپرهیز.']},
      'deep_textbook':{'name':'کتاب درسی عمیق','rules':['از تعریف دقیق، پیش‌نیاز، توضیح مفهومی عمیق، مثال حل‌شده، تمرین پلکانی و خلاصه استفاده کن.','هر ادعای مهم را به بخش یا منبع قابل‌ردیابی وصل کن؛ نقل‌قول و صفحه را جعل نکن.']},
      'troubleshooting':{'name':'عیب‌یابی و تعمیر مرحله‌ای','rules':['برای هر مسئله نشانه‌ها، فرضیه‌ها، تست تفکیک‌کننده، علت ریشه‌ای، راه‌حل و آزمون پس از تعمیر را بنویس.','برای هر مرحله فرمان/ابزار، خروجی نمونه، تفسیر خروجی، معیار ادامه یا توقف، ریسک و rollback ارائه کن.','خطاهای پرتکرار، نکته‌های میدانی، دام‌ها، تصمیم‌درخت و جدول symptom-to-cause اضافه کن.']},
      'commands_scripts':{'name':'فرمان‌ها و اسکریپت‌ها','rules':['برای هر فرمان سیستم‌عامل/محصول، نسخه، سطح دسترسی، پیش‌نیاز، پارامتر، مثال اجرا، خروجی مورد انتظار، روش verify و خطای متداول ثبت کن.','برای PowerShell/Bash/CLI، کد را کامل، قابل اجرا، توضیح‌دار و idempotent تا حد ممکن بنویس؛ حالت dry-run و rollback را اضافه کن.','فرمان‌های مخرب را با هشدار روشن، اثر جانبی و روش بازیابی از فرمان‌های فقط‌خواندنی جدا کن.']},
      'security_dual':{'name':'امنیت تهاجمی مجاز + دفاع','rules':['هر موضوع امنیتی را با مدل تهدید، پیش‌شرط، شواهد قابل مشاهده، سناریوی آزمایشگاهی مجاز و روش دفاع پوشش بده.','برای تست نفوذ، محدودهٔ مجاز، محیط ایزوله، شاخص موفقیت، ثبت شواهد و گزارش اصلاحی مشخص کن؛ از هدف‌گیری اشخاص ثالث خودداری کن.','هم‌زمان تشخیص، پیشگیری، سخت‌سازی، مانیتورینگ، پاسخ‌گویی به رخداد و راستی‌آزمایی اصلاح را توضیح بده.']},
      'source_faithful':{'name':'وفادار به منبع کتاب','rules':['ابتدا ترتیب و واژگان منبع را حفظ کن و هر محتوای افزوده را با برچسب «توضیح تکمیلی» از متن منبع جدا کن.','برای هر بخش، فصل/عنوان/صفحه فقط وقتی منبع واقعاً ارائه کرده ثبت کن؛ صفحه، نقل‌قول یا ارجاع ساختگی ممنوع است.','شکاف‌ها، اصطلاحات مبهم و بخش‌های کم‌کیفیت OCR را به‌عنوان نیازمند بازبینی علامت بزن.']},
      'socratic':{'name':'پرسش‌محور و سقراطی','rules':['با پرسش تشخیصی شروع کن، سپس راهنمایی مرحله‌ای از کم‌کمک به پرکمک ارائه بده.','پاسخ را پشت سر hintها پنهان کن، خطاهای احتمالی فراگیر را توضیح بده و معیار سنجش فهم بساز.','از پرسش‌های باز، مقایسه، انتقال دانش به مسئلهٔ تازه و بازتاب فراشناختی استفاده کن.']},
      'reference_manual':{'name':'مرجع عملیاتی / Runbook','rules':['هر موضوع را به شکل مرجع قابل جست‌وجو با هدف، دامنه، پیش‌نیاز، جدول تصمیم، روش استاندارد، روش شکست و rollback مستند کن.','برای عیب‌یابی از مراحل جمع‌آوری شواهد تا اثبات رفع مشکل بنویس و نقاط توقف امن اضافه کن.','نسخه، پلتفرم، متغیرهای محیطی، نتیجهٔ مورد انتظار، معیار پذیرش و لینک مستندات رسمی را ثبت کن.']},
      'reviewer':{'name':'بازبین و کنترل کیفیت','rules':['بعد از تولید، بازبینی مستقل انجام بده: شکاف پوشش، تکرار، تناقض، ادعای بدون منبع، دستور خطرناک و پاسخ سؤال غلط را فهرست کن.','محتوا را با rubric برای دقت، پوشش، عمق، قابلیت اجرا، منبع و تناسب با سطح مخاطب امتیاز بده.','موارد نامطمئن را قطعی جلوه نده و سؤال/پاسخ/فرمان معیوب را بی‌صدا اصلاح نکن؛ اصلاح پیشنهادی را مشخص کن.']}
    }
    profile_id=payload.prompt_profile if payload.prompt_profile in prompt_profiles else 'balanced'
    spec['prompt_profile']={'id':profile_id,**prompt_profiles[profile_id]}
    spec['quality_review']={'enabled':bool(payload.quality_review),'policy':'خروجی پیش از تحویل از نظر کامل‌بودن ساختار، پوشش، تکرار، منابع، امنیت فرمان‌ها و انسجام آموزشی بازبینی شود.' if payload.quality_review else 'بازبینی خودکار در پرامپت درخواست نشده است؛ بازبینی انسانی همچنان لازم است.'}
    prompt='''نقش: طراح محتوای آموزشی حرفه‌ای و نویسندهٔ همان حوزه. خروجی را فقط به‌شکل JSON معتبر UTF-8 مطابق قرارداد واردسازی زیر تولید کن؛ هیچ متن توضیحی یا Markdown fence بیرون JSON ننویس.

اصل بسیار مهم: JSON و متن پرامپت بالا فقط «دستور و تنظیمات ساخت» هستند، نه محتوای آموزشی. مقدارهایی مانند تعداد درس، تعداد سؤال، سطح مخاطب، دستورالعمل نویسنده، متن پرامپت، توضیحات کنترل‌ها و نمونه‌های ساختاری را عیناً وارد عنوان یا متن درس نکن. فقط محتوای واقعی و قابل تدریس بساز. هر درس باید عنوان اختصاصی، دقیق و طبیعی داشته باشد؛ عنوان‌هایی مثل «درس ۱»، «درس تولیدشده»، «محتوای فصل» یا بازنویسی عنوان موضوع بدون مشخص کردن مفهوم مجاز نیست.

ابتدا `topic`, عنوان‌های `chapters` و تنظیمات `generation` را بخوان. اطلاعات کنترل را فقط در فیلدهای فرادادهٔ مناسب نگه‌دار. ساختار خروجی با قالب واردسازی واقعی برنامه هماهنگ باشد: ریشه شامل `format`, `version`, `title`, `chapter_id`, `chapters`, `items`, `topic`؛ `format` برابر `network-learning-content-pack-v2`. `chapters` فقط فهرست فصل‌های موردنظر است و `items` فقط رکوردهای آموزشی واقعی. هر فصل `id` یکتا، `title` واقعی و `description` موضوعی داشته باشد. هر آیتم باید `chapter_id` یکی از فصل‌های بالا، `kind`, `title`, `summary`, `content`, `source_status` برابر `review_required`, `source_file`, `source_uid` یکتا و پایدار و `metadata` شیء داشته باشد. از `source_uid` پایدار مانند `chapter-slug-kind-001` استفاده کن؛ در هر بسته تکراری نباشد.

برای هر درس از تعدادهای دقیق `generation` استفاده کن: `lesson_count` درس مستقل و غیرتکراری؛ برای هر درس `questions_per_lesson` سؤال، `examples_per_lesson` مثال و `flashcards_per_lesson` فلش‌کارت؛ در هر فصل `notes_per_chapter` نکته/خلاصه. تعدادها را فقط اگر قابلیت مربوطه در `features` فعال است تولید کن. برای سؤال `kind=question`، `metadata.options` دقیقاً چهار گزینهٔ معقول، `metadata.correct_index` عدد صحیح صفرمبنا، `metadata.explanation` توضیح پاسخ، و در صورت امکان `metadata.option_explanations` برای هر گزینه باشد. برای کارت `kind=flashcard`، `metadata.front` و `metadata.back` جدا و کوتاه اجباری است. برای مثال `kind=example` شامل مسئله/سناریو، حل گام‌به‌گام، نتیجه و خطاهای رایج باشد. برای نکته `kind=note` یک خلاصهٔ مستقل و کاربردی بساز، نه کپی کل درس.

برای موضوعات IT/شبکه/برنامه‌نویسی/امنیت، اگر قابلیت‌ها فعال‌اند، علاوه بر درس‌ها `commands_per_chapter` رکورد `kind=command` و `labs_per_chapter` رکورد `kind=lab` تولید کن. دستورها باید پلتفرم و نسخه، پیش‌نیاز، اثر، خروجی مورد انتظار، شیوهٔ راستی‌آزمایی و هشدار تغییر مخرب را توضیح دهند. هر آزمایشگاه باید هدف، توپولوژی/محیط، ابزار و نسخه، آدرس‌دهی یا ورودی، گام‌های اجرا، خروجی مورد انتظار، معیار موفقیت، روش rollback و روش عیب‌یابی داشته باشد. آزمایش‌ها فقط برای محیط شخصی/مجاز و ایزوله طراحی شوند. برای مفاهیم توپولوژی، جریان ترافیک، معماری، پروتکل یا آزمایشگاه، وقتی قابلیت تصویر روشن است دقیقاً `images_per_chapter` دارایی تصویری مرتبط برنامه‌ریزی کن. اگر محیط AI به تولید تصویر واقعی دسترسی دارد، خود تصویر را هم بساز و فایل را به خروجی ضمیمه کن؛ نام فایل نسبی و یکتا مانند `assets/<chapter-slug>/network-topology-01.png` بده و در `metadata.path` فقط وقتی مسیر را بنویس که همان فایل واقعاً در خروجی وجود دارد، سپس `status=generated` ثبت کن. اگر محیط فقط متنی است یا فایل واقعی تولید نمی‌کند، به‌جای وانمودکردن، یک رکورد `kind=asset` با `status=prompt_only_not_generated` و `metadata` شامل `asset_type`, `prompt_fa`, `prompt_en`, `labels_fa`, `labels_en`, `layout`, `aspect_ratio`, `alt_text`, `negative_prompt` بساز؛ مسیر فایل را حذف کن و پرامپت آمادهٔ تولید بده. برچسب‌ها داخل دیاگرام باید فارسی درست با نام انگلیسی پروتکل/فرمان کنار آن داشته باشند؛ از تصویر تزئینی عمومی برای جایگزینی دیاگرام فنی استفاده نکن. در موضوعات غیر فنی محتوا را به‌زور به فرمان یا آزمایشگاه شبکه تبدیل نکن.

هر فصل باید پیش‌نیازها، هدف‌های قابل سنجش، تعریف دقیق، توضیح مفهومی مرحله‌ای، مثال حل‌شده، خطاهای رایج، کاربردها و محدودیت‌ها و معیار تسلط داشته باشد. هر درس باید تعریف و دامنهٔ مستقل و توضیحی عمیق‌تر از خلاصه ارائه دهد. اصطلاحات فنی استاندارد را با نام انگلیسی صحیح در کنار توضیح فارسی بیاور. از محتوای سطحی، تکرار، متن پرکننده و جمله‌هایی که به نویسنده دستور تولید می‌دهند خودداری کن.

منابع فقط واقعی و قابل بررسی باشند؛ URL و مشخصات نشر نساز. اگر منبع را نمی‌توان راستی‌آزمایی کرد، آن را به‌عنوان «نیازمند بررسی انسانی» در metadata علامت بزن، نه به‌صورت مرجع جعلی. تمام رکوردهای تولیدی در وضعیت بازبینی قرار بگیرند؛ هیچ‌چیز خودکار `verified` نشود. قبل از خروجی JSON را parse و اعتبارسنجی کن: همهٔ فصل‌ها شناسه و عنوان داشته باشند، هر آیتم به فصل موجود متصل باشد، UID تکراری نباشد، کلید سؤال در محدودهٔ چهار گزینه باشد، فیلدهای کارت/سؤال/تصویر کامل باشند و نوع محتوا با قابلیت‌های فعال تناقض نداشته باشد. اگر حجم خروجی بیش از توان است، فصل‌ها را کوتاه نکن و تعدادهای مقرر را بی‌صدا حذف نکن؛ خروجی را به چند فایل JSON معتبر جداگانه با نام روشن و سپس فهرست manifest تحویل بده.

قرارداد تحویل بستهٔ نویسندگی: `content_pack.json`, `chapter_catalog.json`, `content_readable.md`, `visual_assets_manifest.json`, `visual_prompts_fa_en.md`, `validation_report.md` و `README_IMPORT_FA.md` را بساز. در فایل راهنما فقط دستورهای ساخت و واردسازی باشند و در `content_pack.json` فقط دادهٔ آموزشی. نمونه‌های قالبی باید `sample_only=true` باشند و هرگز با محتوای واقعی اشتباه نشوند.'''
    if structure_mode=='single_chapter_subsections':
        prompt += '\n\nقانون ساختار انتخاب‌شده: فقط عنوان اول `outline_titles` یک فصل مستقل در `chapters[]` است. عنوان‌های بعدی زیر‌فصل همان فصل هستند؛ برای هر رکوردی که به آن بخش مربوط است `metadata.source_subchapter_title`، `metadata.source_subchapter_slug` و در صورت امکان `metadata.source_subchapter_path` را پر کن. هیچ زیر‌فصل، درس، نکته، آزمایشگاه یا عنوان مطلب را به فصل جدا تبدیل نکن.'
    else:
        prompt += '\n\nقانون ساختار انتخاب‌شده: هر عنوان در `top_level_chapter_titles` یک فصل مستقل است؛ اما عناوین درس، نکته، بخش، موضوع جزئی و زیر‌فصل فقط محتوای داخل فصل‌اند و نباید به فهرست `chapters[]` اضافه شوند.'
    prompt += '\nقانون شماره‌گذاری قطعی: شمارهٔ نمایشی و ترتیب فصل را فقط برنامه تعیین می‌کند. پیشوندهای شماره‌فصل مانند «فصل ۱»، «Chapter 01» و شماره‌های کپی‌شده از بسته را از عنوان فصل حذف کن؛ شمارهٔ ترتیب را از شناسهٔ فصل/درس، نام فایل، فهرست داخل ZIP یا عنوان درس استخراج نکن. این سیاست حتی اگر بسته شمارهٔ متفاوتی اعلام کرده باشد برقرار است.'
    prompt += '\n\nتنظیمات ساخت (فقط مرجع نویسنده؛ این بخش را به محتوای آموزشی کپی نکن):\n'+json.dumps(spec,ensure_ascii=False,indent=2)
    chosen_profile=prompt_profiles[profile_id]
    prompt += '\n\nپروفایل نویسندگی انتخاب‌شده: '+chosen_profile['name']+' (شناسهٔ '+profile_id+').\nقواعد اختصاصی پروفایل:\n'+'\n'.join('- '+rule for rule in chosen_profile['rules'])
    if payload.quality_review:
        prompt += '\n\nدر پایان، کنترل کیفیت مستقل انجام بده و یک بخش گزارش QA داخل metadata بسته ثبت کن: پوشش تعدادهای درخواستی، شناسه‌های یکتا، اتصال همهٔ آیتم‌ها به فصل موجود، منبع‌پذیری ادعاها، تکرار، سطح دشواری، ایمنی فرمان/آزمایشگاه و موارد نامطمئن. هیچ آیتم را خودکار verified نکن.'
    return {'ok':True,'spec':spec,'prompt':prompt,'features_allowed':allowed}

@app.post('/api/topics/prompt-kit')
def topic_prompt_kit(payload:PromptBuildIn):
    built=topic_prompt_preview(payload)
    topic=built['spec']['topic']; spec=built['spec']; prompt=built['prompt']
    titles=spec.get('generation',{}).get('chapter_titles') or []
    chapter_title=titles[0] if titles else 'فصل نمونه — [عنوان فصل]'
    with connect() as c:
        found=c.execute('''SELECT ch.id FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id
            WHERE ct.topic_id=? AND lower(ch.title)=lower(?) ORDER BY ch.order_num,ch.id LIMIT 1''',(str(topic.get('id') or ''),chapter_title)).fetchone()
    sample_cid=str(found['id']) if found else 'sample-'+hashlib.sha256((str(topic.get('id') or '')+'|'+chapter_title).encode('utf-8')).hexdigest()[:12]
    from ai_authoring_kit import build_authoring_zip
    raw=build_authoring_zip(topic,spec,prompt,chapter_title,sample_cid)
    safe_title=re.sub(r'[^a-zA-Z0-9_-]+','_',str(topic.get('title') or 'Topic')).strip('_')[:35] or 'Topic'
    return StreamingResponse(BytesIO(raw),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="AI_Authoring_Kit_{safe_title}.zip"'})

@app.get('/api/authoring-kit/sample-32-chapters')
def get_sample_32_chapter_pack():
    """Serve a unified importable JSON pack for Preview-first import.

    This endpoint never writes to the database. The returned pack has explicit
    chapter IDs, includes all 32 sample chapters and 224 content records, and
    marks every record as requiring human review.
    """
    path = BASE / 'Chapter_Authoring_Kit' / 'All_Chapters_Import_Pack_v1_FA.json'
    if not path.is_file():
        raise HTTPException(404, 'بستهٔ اختیاری ۳۲ فصل در این نسخه پیدا نشد.')
    return FileResponse(path, media_type='application/json', filename='All_Chapters_Import_Pack_v1_FA.json')


class ContentQualityCheckIn(BaseModel):
    content: Any

@app.post('/api/content/quality-check')
def content_quality_check(payload: ContentQualityCheckIn):
    """Deterministic structural QA for generated chapter JSON; never auto-imports or approves content."""
    obj = payload.content
    if isinstance(obj, str):
        try: obj = json.loads(obj)
        except Exception: raise HTTPException(400, 'متن ورودی JSON معتبر نیست؛ ابتدا خروجی کامل JSON را وارد کن.')
    if not isinstance(obj, dict): raise HTTPException(400, 'ریشهٔ محتوا باید یک شیء JSON باشد.')
    chapters = obj.get('chapters')
    if not isinstance(chapters, list) or not chapters:
        raise HTTPException(400, 'آرایهٔ chapters پیدا نشد یا خالی است.')
    errors, warnings, seen_ids, seen_text = [], [], set(), {}
    counts = {'chapters': len(chapters), 'lessons': 0, 'questions': 0, 'cards': 0, 'examples': 0, 'notes': 0, 'labs': 0}
    duplicate_ids, duplicate_content, cross_chapter_duplicates, chapter_reports = [], [], [], []
    def norm(v): return re.sub(r'\s+', ' ', str(v or '')).strip().casefold()
    def add_id(item, label):
        uid = item.get('uid') or item.get('id')
        if uid:
            key = str(uid).strip()
            if key in seen_ids: duplicate_ids.append(key)
            seen_ids.add(key)
    for ci, ch in enumerate(chapters, 1):
        if not isinstance(ch, dict):
            errors.append(f'فصل {ci}: باید شیء JSON باشد.'); continue
        title = str(ch.get('title_fa') or ch.get('title') or '').strip()
        if not title: errors.append(f'فصل {ci}: عنوان خالی است.')
        chapter_counts = {'lessons': 0, 'questions': 0, 'cards': 0, 'examples': 0, 'notes': 0, 'labs': 0}
        banks = [('lessons','lessons'),('questions','questions'),('cards','cards'),('flashcards','cards'),('examples','examples'),('notes','notes'),('labs','labs')]
        for key, bucket in banks:
            arr = ch.get(key, [])
            if arr is None: continue
            if not isinstance(arr, list):
                errors.append(f'{title or ci}: فیلد {key} باید آرایه باشد.'); continue
            for ii, item in enumerate(arr, 1):
                if not isinstance(item, dict): errors.append(f'{title or ci}/{key}/{ii}: رکورد باید شیء باشد.'); continue
                counts[bucket] += 1
                chapter_counts[bucket] += 1
                add_id(item, f'{title}/{key}/{ii}')
                itemtitle = str(item.get('title_fa') or item.get('title') or item.get('question') or item.get('front') or '').strip()
                body = str(item.get('content') or item.get('full_content') or item.get('body_fa') or item.get('summary') or item.get('answer') or item.get('back') or '').strip()
                if bucket in {'lessons','examples','notes','labs'}:
                    if not itemtitle: warnings.append(f'{title}/{key}/{ii}: عنوان یا نام محتوا خالی است.')
                    if len(body) < (120 if bucket == 'lessons' else 30): warnings.append(f'{title}/{key}/{ii}: متن کوتاه است؛ عمق و کاربردپذیری را بازبینی کن.')
                if bucket == 'questions':
                    q = str(item.get('question') or item.get('title') or '').strip()
                    opts = item.get('options')
                    correct = item.get('correct_index')
                    if not q: errors.append(f'{title}/سؤال {ii}: متن سؤال خالی است.')
                    if not isinstance(opts, list) or len(opts) != 4 or any(not str(x).strip() for x in (opts if isinstance(opts,list) else [])):
                        errors.append(f'{title}/سؤال {ii}: دقیقاً چهار گزینهٔ غیرخالی لازم است.')
                    if not isinstance(correct, int) or isinstance(correct, bool) or correct not in range(4): errors.append(f'{title}/سؤال {ii}: correct_index باید عدد ۰ تا ۳ باشد.')
                    if len(str(item.get('explanation') or '').strip()) < 15: warnings.append(f'{title}/سؤال {ii}: توضیح پاسخ کوتاه یا خالی است.')
                if bucket == 'cards':
                    front = str(item.get('front') or item.get('question') or itemtitle).strip()
                    back = str(item.get('back') or item.get('answer') or body).strip()
                    if not front or not back: errors.append(f'{title}/کارت {ii}: روی کارت و پاسخ هر دو لازم‌اند.')
                    if len(front) > 220: warnings.append(f'{title}/کارت {ii}: روی کارت طولانی است؛ آن را به یک مفهوم محدود کن.')
                # Compare normalized item labels across the whole pack. This is an exact-match
                # heuristic only; it does not claim semantic similarity.
                label_value = itemtitle or item.get('question') or item.get('front')
                keytext = re.sub(r'[\W_]+', ' ', norm(label_value), flags=re.UNICODE).strip()
                if keytext and len(keytext) >= 12:
                    item_kind = bucket
                    if keytext in seen_text:
                        first = seen_text[keytext]
                        duplicate_content.append({'text': keytext[:100], 'chapter': title, 'first_chapter': first['chapter'], 'kind': item_kind})
                        if first['chapter'] != title:
                            cross_chapter_duplicates.append({'text': keytext[:100], 'first_chapter': first['chapter'], 'duplicate_chapter': title, 'kind': item_kind})
                    else:
                        seen_text[keytext] = {'chapter': title, 'kind': item_kind}
        if not any(isinstance(ch.get(k), list) and ch.get(k) for k in ('lessons','questions','cards','flashcards','examples','notes','labs')):
            warnings.append(f'{title or "فصل "+str(ci)}: هیچ محتوای آموزشی شناخته‌شده‌ای ندارد.')
        missing = [label for field, label in (('lessons','درس'),('questions','سؤال آزمون'),('cards','فلش‌کارت')) if chapter_counts[field] == 0 and not (field == 'cards' and isinstance(ch.get('flashcards'), list) and ch.get('flashcards'))]
        if missing:
            warnings.append(f'{title or "فصل "+str(ci)}: پوشش ناقص؛ مورد ندارد: {"، ".join(missing)}.')
        chapter_reports.append({'chapter': title or f'فصل {ci}', 'counts': chapter_counts, 'missing_core': missing, 'total_items': sum(chapter_counts.values())})
    if duplicate_ids: errors.append(f'{len(duplicate_ids)} شناسهٔ تکراری پیدا شد.')
    if duplicate_content: warnings.append(f'{len(duplicate_content)} عنوان/پرسش با متن یکسان پس از نرمال‌سازی پیدا شد؛ این بررسی شباهت معنایی را تشخیص نمی‌دهد.')
    if cross_chapter_duplicates: warnings.append(f'{len(cross_chapter_duplicates)} مورد تکراری بین فصل‌ها پیدا شد؛ پیش از حذف، تفاوت هدف آموزشی و زمینه را دستی بررسی کن.')
    total = sum(v for k,v in counts.items() if k != 'chapters')
    score = max(0, min(100, 100 - len(errors)*12 - len(warnings)*3))
    return {'ok': not errors, 'score': score, 'counts': counts, 'total_items': total,
            'errors': errors[:200], 'warnings': warnings[:200], 'duplicate_ids': duplicate_ids[:100],
            'duplicate_content': duplicate_content[:100], 'cross_chapter_duplicates': cross_chapter_duplicates[:100], 'chapter_reports': chapter_reports[:100],
            'notice': 'این بررسی ساختاری و قطعی است؛ صحت علمی، اعتبار منابع و درستی پاسخ‌ها را جایگزین بازبینی انسانی نمی‌کند.'}

class ReviewIn(BaseModel):
    rating:str
    duration_seconds:int=0
@app.post('/api/review/{item_id}')
def review_card(item_id:int, payload:ReviewIn):
    if payload.rating not in {'again','hard','good','easy'}: raise HTTPException(400,'امتیاز مرور نامعتبر است')
    with connect() as c:
        r=c.execute("SELECT * FROM items WHERE id=? AND kind='flashcard'",(item_id,)).fetchone()
        if not r: raise HTTPException(404,'فلش‌کارت پیدا نشد')
        if r['source_status']!='verified': raise HTTPException(409,'این کارت هنوز تأیید نشده و وارد مرور رسمی نمی‌شود.')
        p=c.execute('SELECT * FROM progress WHERE item_id=?',(item_id,)).fetchone()
        interval = p['interval_days'] if p else 0
        ease = p['ease'] if p else 2.5
        correct = p['correct_count'] if p else 0
        wrong = p['wrong_count'] if p else 0
        old_interval, old_ease = interval, ease
        now_dt = user_datetime()
        if payload.rating=='again':
            interval=0; wrong+=1; ease=max(1.3,ease-0.2); due=(now_dt+timedelta(minutes=10)).isoformat(timespec='seconds')
        elif payload.rating=='hard':
            interval=max(1,round(max(1,interval)*1.2)); wrong+=1; ease=max(1.3,ease-0.1); due=(now_dt+timedelta(days=interval)).isoformat(timespec='seconds')
        elif payload.rating=='good':
            interval=1 if interval==0 else (3 if interval==1 else max(interval+1,round(interval*ease))); correct+=1; due=(now_dt+timedelta(days=interval)).isoformat(timespec='seconds')
        else:
            interval=3 if interval==0 else max(4,round(interval*ease*1.3)); correct+=1; ease=min(3.0,ease+0.1); due=(now_dt+timedelta(days=interval)).isoformat(timespec='seconds')
        reviewed_at=now_iso()
        c.execute('''INSERT INTO progress(item_id,correct_count,wrong_count,interval_days,ease,due_at,last_reviewed)
          VALUES(?,?,?,?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET correct_count=excluded.correct_count,wrong_count=excluded.wrong_count,interval_days=excluded.interval_days,ease=excluded.ease,due_at=excluded.due_at,last_reviewed=excluded.last_reviewed''',
          (item_id,correct,wrong,interval,ease,due,reviewed_at))
        c.execute('INSERT INTO review_history(item_id,rating,reviewed_at,old_interval_days,new_interval_days,old_ease,new_ease,duration_seconds) VALUES(?,?,?,?,?,?,?,?)',
          (item_id,payload.rating,reviewed_at,old_interval,interval,old_ease,ease,max(0,min(int(payload.duration_seconds or 0),3600))))
        c.commit()
    return {'ok':True,'due_at':due,'interval_days':interval,'next_review_local':display_jalali_datetime(due)}

class ChapterIn(BaseModel):
    title: str
    group_name: str = 'imported'
    description: str = ''
    order_num: Optional[int] = None
    topic_id: str = ''


@app.post('/api/chapter')
def create_chapter(payload: ChapterIn):
    title = payload.title.strip()
    if not title:
        raise HTTPException(400, 'عنوان فصل الزامی است')
    group = str(payload.group_name or 'imported').strip() or 'imported'
    if group not in {'main', 'imported'}:
        group = 'imported'
    cid = 'x' + hashlib.sha1((title + now_iso() + secrets.token_hex(4)).encode()).hexdigest()[:10]
    with connect() as c:
        topic_id=str(payload.topic_id or '').strip()
        if topic_id and not c.execute('SELECT 1 FROM topics WHERE id=?',(topic_id,)).fetchone():
            raise HTTPException(400,'موضوع انتخاب‌شده معتبر نیست')
        if topic_id:
            duplicate=c.execute('''SELECT 1 FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id
                WHERE lower(ch.title)=lower(?) AND ct.topic_id=? LIMIT 1''',(title,topic_id)).fetchone()
        else:
            duplicate=c.execute('''SELECT 1 FROM chapters ch LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id
                WHERE lower(ch.title)=lower(?) AND ct.chapter_id IS NULL LIMIT 1''',(title,)).fetchone()
        if duplicate: raise HTTPException(409,'فصلی با همین عنوان در همین موضوع وجود دارد')
        if payload.order_num is not None: order=int(payload.order_num)
        elif topic_id: order=c.execute('''SELECT COALESCE(MAX(ch.order_num),0)+1 n FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ch.group_name=? AND ct.topic_id=?''',(group,topic_id)).fetchone()['n']
        else: order=c.execute('''SELECT COALESCE(MAX(ch.order_num),0)+1 n FROM chapters ch LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ch.group_name=? AND ct.chapter_id IS NULL''',(group,)).fetchone()['n']
        c.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(cid,title,max(0,order),group,'manual',payload.description or '',now_iso()))
        if topic_id: c.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?)',(cid,topic_id))
        c.commit()
    return {'ok': True, 'chapter_id': cid, 'title': title, 'order_num': max(0, order), 'group_name': group,'topic_id':topic_id}


class ChapterUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    order_num: Optional[int] = None
    group_name: Optional[str] = None
    topic_id: Optional[str] = None


@app.put('/api/chapter/{chapter_id}')
def update_chapter(chapter_id: str, payload: ChapterUpdate):
    data = payload.dict(exclude_unset=True)
    if not data:
        return {'ok': True, 'changed': 0}
    with connect() as c:
        row = c.execute('SELECT * FROM chapters WHERE id=?', (chapter_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'فصل پیدا نشد')
        fields, values = [], []
        if 'title' in data:
            title = str(data['title'] or '').strip()
            if not title:
                raise HTTPException(400, 'عنوان فصل الزامی است')
            current_topic=c.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(chapter_id,)).fetchone()
            topic_id=str(data.get('topic_id') or '').strip() if 'topic_id' in data else (str(current_topic['topic_id']) if current_topic else '')
            if topic_id and not c.execute('SELECT 1 FROM topics WHERE id=?',(topic_id,)).fetchone(): raise HTTPException(400,'موضوع مقصد معتبر نیست')
            if topic_id:
                dupe=c.execute('''SELECT 1 FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE lower(ch.title)=lower(?) AND ch.id<>? AND ct.topic_id=? LIMIT 1''',(title,chapter_id,topic_id)).fetchone()
            else:
                dupe=c.execute('''SELECT 1 FROM chapters ch LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE lower(ch.title)=lower(?) AND ch.id<>? AND ct.chapter_id IS NULL LIMIT 1''',(title,chapter_id)).fetchone()
            if dupe: raise HTTPException(409,'فصل دیگری با همین عنوان در همین موضوع وجود دارد')
            fields.append('title=?'); values.append(title)
        if 'description' in data:
            fields.append('description=?'); values.append(str(data['description'] or ''))
        if 'order_num' in data and data['order_num'] is not None:
            order = int(data['order_num'])
            if order < 0 or order > 100000:
                raise HTTPException(400, 'شمارهٔ ترتیب فصل باید بین ۰ تا ۱۰۰۰۰۰ باشد')
            fields.append('order_num=?'); values.append(order)
        if 'group_name' in data and data['group_name'] is not None:
            group = str(data['group_name']).strip()
            if group not in {'main', 'imported'}:
                raise HTTPException(400, 'گروه فصل نامعتبر است')
            fields.append('group_name=?'); values.append(group)
        if 'topic_id' in data:
            new_topic=str(data.get('topic_id') or '').strip()
            if new_topic and not c.execute('SELECT 1 FROM topics WHERE id=?',(new_topic,)).fetchone(): raise HTTPException(400,'موضوع مقصد معتبر نیست')
            effective_title=str(data.get('title') or row['title']).strip()
            if new_topic:
                duplicate=c.execute('''SELECT 1 FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id
                    WHERE ch.id<>? AND lower(ch.title)=lower(?) AND ct.topic_id=? LIMIT 1''',(chapter_id,effective_title,new_topic)).fetchone()
            else:
                duplicate=c.execute('''SELECT 1 FROM chapters ch LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id
                    WHERE ch.id<>? AND lower(ch.title)=lower(?) AND ct.chapter_id IS NULL LIMIT 1''',(chapter_id,effective_title)).fetchone()
            if duplicate: raise HTTPException(409,'فصل دیگری با همین عنوان در موضوع مقصد وجود دارد')
            if new_topic:
                c.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?) ON CONFLICT(chapter_id) DO UPDATE SET topic_id=excluded.topic_id',(chapter_id,new_topic))
            else: c.execute('DELETE FROM chapter_topics WHERE chapter_id=?',(chapter_id,))
        if fields:
            values.append(chapter_id)
            c.execute(f"UPDATE chapters SET {','.join(fields)} WHERE id=?", values)
        c.commit()
        result = c.execute('SELECT * FROM chapters WHERE id=?', (chapter_id,)).fetchone()
    return {'ok': True, 'changed': len(fields), 'chapter': dict(result)}


@app.delete('/api/chapter/{chapter_id}')
def delete_chapter(chapter_id: str):
    with connect() as c:
        row = c.execute('SELECT id,title FROM chapters WHERE id=?', (chapter_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'فصل پیدا نشد')
        item_count = c.execute('SELECT COUNT(*) n FROM items WHERE chapter_id=?', (chapter_id,)).fetchone()['n']
        c.execute('DELETE FROM chapters WHERE id=?', (chapter_id,))
        c.commit()
    return {'ok': True, 'chapter_id': chapter_id, 'deleted_items': item_count}

class ItemIn(BaseModel):
    chapter_id:str; kind:str='lesson'; title:str; summary:str=''; content:str=''; source_status:str='review_required'; metadata:dict={}
@app.post('/api/item')
def create_item(payload:ItemIn):
    if payload.kind not in {'lesson','flashcard','question','command','lab','example','note'}: raise HTTPException(400,'نوع محتوا نامعتبر است')
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان الزامی است')
    with connect() as c:
        if not c.execute('SELECT 1 FROM chapters WHERE id=?',(payload.chapter_id,)).fetchone(): raise HTTPException(404,'فصل پیدا نشد')
        uid='manual-'+hashlib.sha1((payload.chapter_id+title+now_iso()).encode()).hexdigest()
        metadata=dict(payload.metadata or {})
        if payload.source_status!='review_required': metadata.setdefault('requested_initial_status',payload.source_status)
        # Creating an item is never an approval action; approval happens in content management.
        cur=c.execute('INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
          (payload.chapter_id,payload.kind,title,payload.summary,payload.content,'review_required','ایجاد دستی',uid,json.dumps(metadata,ensure_ascii=False),now_iso()))
        item_id=cur.lastrowid
        if payload.kind=='flashcard': c.execute('INSERT INTO progress(item_id,due_at) VALUES(?,?)',(item_id,date.today().isoformat()))
        c.commit()
    return {'ok':True,'id':item_id}

class CompleteIn(BaseModel): completed:bool=True
@app.post('/api/item/{item_id}/complete')
def complete_item(item_id:int,payload:CompleteIn):
    with connect() as c:
        if not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'مورد پیدا نشد')
        c.execute('INSERT INTO progress(item_id,completed) VALUES(?,?) ON CONFLICT(item_id) DO UPDATE SET completed=excluded.completed',(item_id,1 if payload.completed else 0)); c.commit()
    return {'ok':True}

@app.post('/api/item/{item_id}/make-card')
def make_card_from_item(item_id:int):
    with connect() as c:
        source=c.execute("SELECT * FROM items WHERE id=? AND kind IN ('lesson','note','example','lab')",(item_id,)).fetchone()
        if not source: raise HTTPException(404,'درس یا مطلب پیدا نشد')
        answer=(source['summary'] or re.sub(r'[#*`|>]+',' ',source['content'] or '').strip())[:1200]
        if not answer: raise HTTPException(400,'برای ساخت کارت، ابتدا خلاصه یا پاسخ مطلب را وارد کن')
        front=f"نکتهٔ کلیدی «{source['title']}» چیست؟"
        uid=f'derived-card-{item_id}'
        exists=c.execute('SELECT id FROM items WHERE chapter_id=? AND source_uid=?',(source['chapter_id'],uid)).fetchone()
        if exists: return {'ok':True,'id':exists['id'],'already_exists':True}
        metadata={'front':front,'back':answer,'derived_from_item_id':item_id}
        cur=c.execute('INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
          (source['chapter_id'],'flashcard',front,answer,answer,'review_required','تبدیل از درس',uid,json.dumps(metadata,ensure_ascii=False),now_iso()))
        c.execute('INSERT INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
        c.commit()
        return {'ok':True,'id':cur.lastrowid,'already_exists':False}

@app.get('/api/activities')
def list_daily_activities(activity_date: str = ''):
    try:
        day=normalize_date_input(activity_date) if activity_date else user_datetime().date().isoformat()
        parsed=date.fromisoformat(day)
    except Exception: raise HTTPException(400,'تاریخ فعالیت نامعتبر است')
    weekday=parsed.weekday()
    with connect() as c:
        rows=c.execute('SELECT * FROM daily_activities WHERE enabled=1 ORDER BY sort_order,id').fetchall()
        logs={r['activity_id']:dict(r) for r in c.execute('SELECT * FROM daily_activity_logs WHERE activity_date=?',(day,)).fetchall()}
    activities=[]
    for row in rows:
        d=dict(row)
        try: days=json.loads(d['days_json'] or '[0,1,2,3,4,5,6]')
        except Exception: days=list(range(7))
        if weekday not in days: continue
        log=logs.get(d['id'],{})
        activities.append({**d,'days':days,'activity_date':day,'completed':bool(log.get('completed',0)),'completed_at':log.get('completed_at',''),'log_note':log.get('note','')})
    return {'activity_date':day,'activity_date_jalali':gregorian_to_jalali(parsed),'activities':activities,'count':len(activities),'completed':sum(1 for a in activities if a['completed'])}

class DailyActivityIn(BaseModel):
    title:str
    description:str=''
    time_of_day:str=''
    days:list[int]=list(range(7))
    enabled:bool=True
    sort_order:int=100

@app.post('/api/activities')
def create_daily_activity(payload: DailyActivityIn):
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان فعالیت الزامی است')
    if any(d not in range(7) for d in payload.days): raise HTTPException(400,'روزهای هفته نامعتبرند')
    if payload.time_of_day and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',payload.time_of_day): raise HTTPException(400,'ساعت باید به شکل HH:MM باشد')
    with connect() as c:
        cur=c.execute('INSERT INTO daily_activities(title,description,time_of_day,days_json,enabled,sort_order,created_at) VALUES(?,?,?,?,?,?,?)',(title,payload.description,payload.time_of_day,json.dumps(sorted(set(payload.days))),int(payload.enabled),payload.sort_order,now_iso()))
        c.commit(); row=c.execute('SELECT * FROM daily_activities WHERE id=?',(cur.lastrowid,)).fetchone()
    d=dict(row); d['days']=json.loads(d.pop('days_json')); return {'ok':True,'activity':d}

@app.patch('/api/activities/{activity_id}')
def update_daily_activity(activity_id:int,payload:dict[str,Any]):
    allowed={'title','description','time_of_day','days','enabled','sort_order'}
    if not payload or set(payload)-allowed: raise HTTPException(400,'فیلد فعالیت نامعتبر است')
    values={}
    for key,value in payload.items():
        if key=='title':
            value=str(value).strip()
            if not value: raise HTTPException(400,'عنوان فعالیت الزامی است')
        if key=='time_of_day' and value and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',str(value)): raise HTTPException(400,'ساعت باید به شکل HH:MM باشد')
        if key=='days':
            if not isinstance(value,list) or any(d not in range(7) for d in value): raise HTTPException(400,'روزهای هفته نامعتبرند')
            key='days_json'; value=json.dumps(sorted(set(value)))
        if key=='enabled': value=int(bool(value))
        values[key]=value
    with connect() as c:
        if not c.execute('SELECT 1 FROM daily_activities WHERE id=?',(activity_id,)).fetchone(): raise HTTPException(404,'فعالیت پیدا نشد')
        c.execute('UPDATE daily_activities SET '+','.join(f'{k}=?' for k in values)+' WHERE id=?',list(values.values())+[activity_id]); c.commit()
        row=c.execute('SELECT * FROM daily_activities WHERE id=?',(activity_id,)).fetchone()
    d=dict(row); d['days']=json.loads(d.pop('days_json')); return {'ok':True,'activity':d}

@app.post('/api/activities/{activity_id}/toggle')
def toggle_daily_activity(activity_id:int,payload:dict[str,Any]):
    try: day=normalize_date_input(str(payload.get('activity_date') or user_datetime().date().isoformat()))
    except Exception: raise HTTPException(400,'تاریخ فعالیت نامعتبر است')
    completed=bool(payload.get('completed'))
    with connect() as c:
        if not c.execute('SELECT 1 FROM daily_activities WHERE id=?',(activity_id,)).fetchone(): raise HTTPException(404,'فعالیت پیدا نشد')
        c.execute('''INSERT INTO daily_activity_logs(activity_id,activity_date,completed,completed_at,note) VALUES(?,?,?,?,?)
          ON CONFLICT(activity_id,activity_date) DO UPDATE SET completed=excluded.completed,completed_at=excluded.completed_at,note=excluded.note''',
          (activity_id,day,int(completed),now_iso() if completed else '',str(payload.get('note') or '')[:2000]))
        c.commit()
    return {'ok':True,'activity_id':activity_id,'activity_date':day,'completed':completed}

@app.delete('/api/activities/{activity_id}')
def delete_daily_activity(activity_id:int):
    with connect() as c:
        cur=c.execute('DELETE FROM daily_activities WHERE id=?',(activity_id,)); c.commit()
        if not cur.rowcount: raise HTTPException(404,'فعالیت پیدا نشد')
    return {'ok':True}

@app.get('/api/export')
def export_all():
    with connect() as c:
        chapters=[dict(r) for r in c.execute('SELECT * FROM chapters ORDER BY order_num,title COLLATE NATURAL_NOCASE,id')]
        items=[]
        for r in c.execute('SELECT * FROM items ORDER BY id'):
            d=dict(r); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); items.append(d)
        progress=[dict(r) for r in c.execute('SELECT * FROM progress')]
        tasks=[dict(r) for r in c.execute('SELECT * FROM tasks ORDER BY id')]
        plans=[]
        for r in c.execute('SELECT * FROM study_plans ORDER BY id'):
            d=dict(r); d['active_chapters']=json.loads(d.pop('active_chapters_json') or '[]'); plans.append(d)
        time_entries=[dict(r) for r in c.execute('SELECT * FROM time_entries ORDER BY id')]
        review_history=[dict(r) for r in c.execute('SELECT * FROM review_history ORDER BY id')]
        assessment_attempts=[dict(r) for r in c.execute('SELECT * FROM assessment_attempts ORDER BY id')]
        practice_attempts=[dict(r) for r in c.execute('SELECT * FROM practice_attempts ORDER BY id')]
        item_revisions=[dict(r) for r in c.execute('SELECT * FROM item_revisions ORDER BY id')]
        daily_activities=[dict(r) for r in c.execute('SELECT * FROM daily_activities ORDER BY sort_order,id')]
        daily_activity_logs=[dict(r) for r in c.execute('SELECT * FROM daily_activity_logs ORDER BY activity_date,id')]
        preferences={r['key']:r['value'] for r in c.execute("SELECT key,value FROM settings WHERE key LIKE 'pref_%'")}
        topics=[]
        for r in c.execute('SELECT * FROM topics ORDER BY created_at,title'):
            d=dict(r)
            try: d['features']=json.loads(d.pop('features_json') or '{}')
            except Exception: d['features']={}
            topics.append(d)
        chapter_topics=[dict(r) for r in c.execute('SELECT chapter_id,topic_id FROM chapter_topics ORDER BY topic_id,chapter_id')]
        course_blueprints=[dict(r) for r in c.execute('SELECT * FROM course_blueprints ORDER BY created_at,id')]
        competency_evidence=[dict(r) for r in c.execute('SELECT * FROM competency_evidence ORDER BY username,domain_profile,competency_id')]
    payload={'format':'network-learning-backup-v2','backup_schema_version':5,'exported_at':now_iso(),'chapters':chapters,'chapter_topics':chapter_topics,'topics':topics,'items':items,'progress':progress,'tasks':tasks,'study_plans':plans,'time_entries':time_entries,'review_history':review_history,'assessment_attempts':assessment_attempts,'practice_attempts':practice_attempts,'item_revisions':item_revisions,'daily_activities':daily_activities,'daily_activity_logs':daily_activity_logs,'course_blueprints':course_blueprints,'competency_evidence':competency_evidence,'preferences':preferences}
    buf=BytesIO(json.dumps(payload,ensure_ascii=False,indent=2).encode('utf-8'))
    return StreamingResponse(buf,media_type='application/json',headers={'Content-Disposition':'attachment; filename="network-learning-backup.json"'})

@app.get('/api/backup/archive')
async def export_backup_archive():
    # Portable backup: full JSON snapshot + media; excludes authentication hash/session secret.
    response=export_all()
    backup_json=b''.join([part async for part in response.body_iterator])
    buf=BytesIO(); manifest={'format':'network-learning-portable-archive-v1','created_at':now_iso(),'files':[]}
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
        zf.writestr('network-learning-backup.json',backup_json)
        manifest['files'].append({'path':'network-learning-backup.json','size':len(backup_json),'sha256':hashlib.sha256(backup_json).hexdigest()})
        if MEDIA.exists():
            for path in MEDIA.rglob('*'):
                if not path.is_file(): continue
                rel=path.relative_to(MEDIA).as_posix()
                arc='media/'+rel
                data=path.read_bytes(); zf.writestr(arc,data)
                manifest['files'].append({'path':arc,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        zf.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    buf.seek(0)
    return StreamingResponse(buf,media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="network-learning-backup-{date.today().isoformat()}.zip"'})

SUPPORTED_IMAGE={'.png','.jpg','.jpeg','.webp','.gif','.svg'}
TEXT_TYPES={'.md','.markdown','.txt','.rst','.log','.conf','.cfg','.yaml','.yml','.ini','.csv'}
MAX_FILE_BYTES=150*1024*1024
MAX_ZIP_FILES=10000
MAX_ITEMS_PER_FILE=8000

def safe_name(name:str):
    raw=Path(name.replace('\\','/')).name
    raw=re.sub(r'[^\w\-. ()\u0600-\u06FF]+','_',raw).strip(' .')
    return (raw or 'file')[:130]

def chapter_for_slug(slug:str, title:str, fallback_title:Optional[str]=None):
    s=(slug+' '+title).lower().replace('‌',' ')
    rules=[
      (['network_fundamentals','مبانی شبکه','osi tcp','tcp_ip'], 'c01'),
      (['cabling_fiber_rack','ethernet_arp','physical_layer'], 'c02'),
      (['ip_address','subnet','ipv6','vlsm'], 'c03'),
      (['tcp_udp_quic','transport_layer','congestion'], 'c04'),
      (['dns','dhcp','ntp','snmp','syslog','aaa_nac','ipam'], 'c05'),
      (['cisco_switching','vlan_stp','etherchannel'], 'c06'),
      (['advanced_routing','ospf_bgp_redistribution','routing_protocol'], 'c07'),
      (['mpls_vrf','multicast','evpn_vxlan','sdn_sdwan_sase'], 'c08'),
      (['nat_acl_firewall','firewall_basics','network_acl'], 'c09'),
      (['fortigate'], 'c10'), (['pfsense','opnsense','sophos'], 'c11'),
      (['enterprise_vpn','ipsec_ssl','wireguard','vpn'], 'c12'),
      (['mikrotik'], 'c13'), (['enterprise_wireless','ptp_ptmp','wireless'], 'c14'),
      (['windows_server','active_directory','windows_dns_dhcp_nps','entra_id','m365_intune'], 'c15'),
      (['linux_','linux','لینوکس'], 'c16'),
      (['endpoint_security','windows_endpoint','zero_trust','zero trust'], 'c17'),
      (['vmware','hyperv','proxmox','docker','kubernetes','virtualization'], 'c18'),
      (['enterprise_storage','backup_disaster','filesystem_storage','storage'], 'c19'),
      (['datacenter','high_availability','load_balancing'], 'c20'),
      (['cloud_networking','cloud_security','aws','azure'], 'c21'),
      (['monitoring','siem','wireshark','elk'], 'c22'),
      (['soc_ir','ethical_hacking','cybersecurity','network_security','incident_response'], 'c23'),
      (['it_automation','ansible','nornir','napalm','netconf'], 'c24'),
      (['python_network_automation','پایتون و اتوماسیون شبکه'], 'c30'),
      (['authorized_network_pentest_lab','تست نفوذ شبکه و آزمایشگاه','network_pentest'], 'c31'),
      (['prompt_engineering_ai','مهندسی پرامپت','prompt engineering'], 'c32'),
      (['python','powershell','bash','cmd'], 'c25'),
      (['database_administration','database_security','database'], 'c26'),
      (['it_operations_noc','documentation_runbooks','runbook','cmdb','hardware_servers','it_architecture'], 'c27'),
      (['git_github','git'], 'c28'), (['command_reference','commands_reference'], 'c29'),
    ]
    for needles,cid in rules:
        if any(n in s for n in needles): return cid
    return None

def ensure_import_chapter(conn, title:str, order_num:int=999, group_name='imported', source='import'):
    title=title.strip()[:250] or 'فصل واردشده'
    # exact title match across main/imported chapters to avoid duplicates
    r=conn.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
    if r: return r['id']
    cid='imp-'+hashlib.sha1(title.encode('utf-8')).hexdigest()[:12]
    if conn.execute('SELECT 1 FROM chapters WHERE id=?',(cid,)).fetchone(): return cid
    conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',
       (cid,title,order_num,group_name,source,'از محتوای واردشده ساخته شده است.',now_iso()))
    return cid

def item_hash(chapter_id, kind, title, content, source_file):
    return hashlib.sha256((chapter_id+'|'+kind+'|'+title+'|'+content+'|'+source_file).encode('utf-8',errors='ignore')).hexdigest()

def add_item(conn, chapter_id, kind, title, summary='', content='', source_status='review_required', source_file='', source_uid='', metadata=None):
    title=(str(title or '').strip() or 'محتوای بدون عنوان')[:500]
    content=str(content or '')[:2000000]; summary=str(summary or '')[:10000]
    if not source_uid: source_uid=item_hash(chapter_id,kind,title,content,source_file)
    # The UNIQUE(chapter_id, source_uid) constraint is the authoritative duplicate guard.
    # Avoid a redundant SELECT for every imported record (large chapters can contain 5,000+ items).
    md=dict(metadata or {})
    cur=conn.execute('INSERT OR IGNORE INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
      (chapter_id,kind,title,summary,content,source_status,source_file,source_uid,json.dumps(md,ensure_ascii=False),now_iso()))
    if cur.rowcount and kind=='flashcard': conn.execute('INSERT OR IGNORE INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
    return cur.rowcount>0

def extract_docx(raw:bytes)->str:
    from docx import Document
    d=Document(BytesIO(raw)); chunks=[]
    for p in d.paragraphs:
        if p.text.strip(): chunks.append(p.text)
    for table in d.tables:
        for row in table.rows: chunks.append(' | '.join(cell.text.replace('\n',' / ') for cell in row.cells))
    return '\n\n'.join(chunks)

def extract_pdf(raw:bytes)->str:
    from pypdf import PdfReader
    reader=PdfReader(BytesIO(raw)); out=[]
    for page in reader.pages:
        out.append(page.extract_text() or '')
    return '\n\n'.join(out)

def infer_title(filename:str, text:str):
    m=re.search(r'^\s*#\s+(.+)$',text,re.M)
    return m.group(1).strip()[:300] if m else Path(filename).stem.replace('_',' ').replace('-',' ')

def get_json(raw:bytes):
    for enc in ('utf-8-sig','utf-8','utf-16'):
        try:return json.loads(raw.decode(enc))
        except Exception: pass
    return None

def validate_image_bytes(filename:str, raw:bytes)->str:
    ext=Path(filename).suffix.lower()
    signatures={
      '.png': (raw.startswith(b'\x89PNG\r\n\x1a\n'), 'image/png'),
      '.jpg': (raw.startswith(b'\xff\xd8\xff'), 'image/jpeg'),
      '.jpeg': (raw.startswith(b'\xff\xd8\xff'), 'image/jpeg'),
      '.gif': (raw.startswith((b'GIF87a',b'GIF89a')), 'image/gif'),
      '.webp': (len(raw)>=12 and raw[:4]==b'RIFF' and raw[8:12]==b'WEBP', 'image/webp'),
    }
    if ext=='.svg':
        text=raw[:200000].decode('utf-8-sig',errors='ignore').lower()
        if '<svg' not in text:
            raise ValueError(f'محتوای «{filename}» با پسوند SVG سازگار نیست.')
        if any(x in text for x in ('<script','javascript:','onload=','onerror=','<foreignobject','href="http',"href='http")):
            raise ValueError(f'SVG «{filename}» شامل محتوای فعال یا مرجع بیرونی است؛ برای ایمنی پذیرفته نشد.')
        return 'image/svg+xml'
    if ext not in signatures:
        raise ValueError(f'قالب تصویر «{ext}» پشتیبانی نمی‌شود.')
    ok, mime=signatures[ext]
    if not ok:
        raise ValueError(f'پسوند فایل «{filename}» با محتوای واقعی آن هم‌خوان نیست یا فایل خراب است. PNG/JPEG/WebP/GIF معتبر انتخاب کن.')
    return mime

def _import_topic_exists(conn, topic_id: str) -> bool:
    return bool(topic_id and conn.execute('SELECT 1 FROM topics WHERE id=?', (str(topic_id),)).fetchone())


def _safe_assign_import_topic(conn, chapter_id: str, topic_id: str, *, only_if_unassigned=True) -> bool:
    # Never silently move an existing chapter to another topic during import.
    if not chapter_id or not _import_topic_exists(conn, topic_id):
        return False
    current = conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?', (chapter_id,)).fetchone()
    if current and only_if_unassigned:
        return False
    conn.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?) ON CONFLICT(chapter_id) DO UPDATE SET topic_id=excluded.topic_id',
                 (chapter_id, topic_id))
    return True


def _import_pack_counts():
    return {'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,
            'skipped':0,'chapters_created':0,'topics_created':0,'needs_review':0,'topic_assignments':0,'errors':[]}


def _next_import_chapter_order(conn, topic_id: str='') -> int:
    """Append an imported chapter after the last chapter in the selected scope."""
    topic_id=str(topic_id or '').strip()
    if topic_id and _import_topic_exists(conn,topic_id):
        row=conn.execute('SELECT COALESCE(MAX(ch.order_num),0)+1 n FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ct.topic_id=?',(topic_id,)).fetchone()
    elif topic_id:
        row=conn.execute('SELECT COALESCE(MAX(order_num),0)+1 n FROM chapters').fetchone()
    else:
        row=conn.execute("SELECT COALESCE(MAX(ch.order_num),0)+1 n FROM chapters ch WHERE NOT EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=ch.id)").fetchone()
    try: return max(1,int(row['n'] or 1))
    except Exception: return 1


def _ensure_scoped_import_chapter(conn, title: str, topic_id: str='', identity: str='') -> str:
    """Only reuse same-title chapters within the selected topic; otherwise create an isolated chapter."""
    title=str(title or 'فصل واردشده').strip()[:250] or 'فصل واردشده'
    topic_id=str(topic_id or '').strip()
    if topic_id and _import_topic_exists(conn,topic_id):
        hit=conn.execute("SELECT ch.id FROM chapters ch JOIN chapter_topics ct ON ct.chapter_id=ch.id WHERE ct.topic_id=? AND lower(ch.title)=lower(?) ORDER BY ch.id LIMIT 1",(topic_id,title)).fetchone()
        if hit: return str(hit['id'])
    token=(topic_id+'|'+str(identity or '')+'|'+title).encode('utf-8',errors='ignore')
    base='imp-'+hashlib.sha256(token).hexdigest()[:14]; cid=base; suffix=1
    while True:
        existing=conn.execute('SELECT id,title FROM chapters WHERE id=?',(cid,)).fetchone()
        if not existing: break
        if str(existing['title']).strip().casefold()==title.casefold():
            assigned=conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(cid,)).fetchone()
            if not assigned or (topic_id and str(assigned['topic_id'])==topic_id): return cid
        suffix+=1; cid=base+'-'+str(suffix)
    order=_next_import_chapter_order(conn,topic_id)
    conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(cid,title,int(order),'imported','isolated-import','فصل ایجادشده از واردسازی ایزوله؛ براساس عنوان به فصل دیگری ادغام نشد.',now_iso()))
    if topic_id and _import_topic_exists(conn,topic_id): conn.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?)',(cid,topic_id))
    return cid


def _ensure_pack_chapter(conn, ch: dict, filename: str, order_default: int=999, target_topic_id: str='', pack_identity: str=''):
    title=str(ch.get('title') or ch.get('title_fa') or ch.get('chapter_title') or '').strip()
    if not title: title=Path(filename).stem.replace('_',' ').replace('-',' ').strip() or 'فصل واردشده'
    title=title[:250]; wanted=str(ch.get('id') or '').strip()
    if wanted:
        existing=conn.execute('SELECT id,title FROM chapters WHERE id=?',(wanted,)).fetchone()
        if existing and str(existing['title']).strip().casefold()==title.casefold():
            assigned=conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(wanted,)).fetchone()
            if not assigned or not target_topic_id or str(assigned['topic_id'])==str(target_topic_id): return wanted,False
        if not existing and re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}',wanted):
            group=str(ch.get('group_name') or 'imported').strip()
            if group not in {'main','imported'}: group='imported'
            # The import sequence, not a chapter number embedded by the AI, controls ordering.
            order=_next_import_chapter_order(conn,target_topic_id)
            conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(wanted,title,order,group,'content-pack',str(ch.get('description') or ''),now_iso()))
            if target_topic_id and _import_topic_exists(conn,target_topic_id): conn.execute('INSERT INTO chapter_topics(chapter_id,topic_id) VALUES(?,?)',(wanted,target_topic_id))
            return wanted,True
    identity='content-pack|'+str(pack_identity or Path(filename).name)+'|'+wanted+'|'+str(ch.get('slug') or '')
    cid=_ensure_scoped_import_chapter(conn,title,target_topic_id,identity)
    src=conn.execute('SELECT source FROM chapters WHERE id=?',(cid,)).fetchone()
    return cid,bool(src and str(src['source'] or '')=='isolated-import')


def _import_unified_pack(conn, data: dict, filename: str, target_chapter: str, target_topic_id: str=''):
    # Import a unified JSON pack with strict chapter isolation and no unsafe c01 fallback.
    counts=_import_pack_counts()
    root_meta=data.get('metadata') if isinstance(data.get('metadata'),dict) else {}
    pack_topic=data.get('topic') if isinstance(data.get('topic'),dict) else {}
    declared_topic_id=str(pack_topic.get('id') or '').strip()
    declared_topic_title=str(pack_topic.get('title') or '').strip()
    root_sources=data.get('sources') if isinstance(data.get('sources'),list) else []
    inherited_source=(root_sources[0] if root_sources and isinstance(root_sources[0],dict) else root_meta.get('source_book') if isinstance(root_meta.get('source_book'),dict) else None)
    resolved_default_topic=''
    if _import_topic_exists(conn,declared_topic_id):
        resolved_default_topic=declared_topic_id
    elif declared_topic_title:
        tr=conn.execute('SELECT id FROM topics WHERE lower(title)=lower(?)',(declared_topic_title,)).fetchone()
        if tr: resolved_default_topic=str(tr['id'])
        elif (not target_topic_id and root_meta.get('generation_mode')=='source_extraction_without_ai' and isinstance(inherited_source,dict)):
            # A book-to-course pack declares a named course. On import, create that topic once
            # (case-insensitive duplicate check above) so its chapters are not left unassigned.
            tid='t'+hashlib.sha1((declared_topic_title+now_iso()+secrets.token_hex(4)).encode()).hexdigest()[:11]
            features={k:(k not in {'commands','labs'}) for k in TOPIC_FEATURES}
            desc='ساخته‌شده از بستهٔ کتاب: '+str(inherited_source.get('title') or filename)+'؛ محتوای واردشده نیازمند بازبینی است.'
            conn.execute('INSERT INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)',
                         (tid,declared_topic_title,desc,json.dumps(features,ensure_ascii=False),now_iso(),now_iso()))
            resolved_default_topic=tid;counts['topics_created']+=1
    raw_chapters=data.get('chapters') if isinstance(data.get('chapters'),list) else []
    raw_items=data.get('items') if isinstance(data.get('items'),list) else []
    ids=[str(ch.get('id') or '').strip() for ch in raw_chapters if isinstance(ch,dict) and str(ch.get('id') or '').strip()]
    repeated=sorted({x for x in ids if ids.count(x)>1})
    if repeated:
        counts['errors'].append(f'{filename}: شناسهٔ فصل در بسته تکراری است: '+', '.join(repeated[:10])); counts['skipped']+=len(raw_items); return counts
    if not raw_chapters and raw_items:
        root_id=str(data.get('chapter_id') or '').strip()
        root_title=str(data.get('chapter_title') or data.get('chapter_title_fa') or '').strip()
        if not root_title:
            root_title=str(data.get('title') or '').strip()
        if not root_title and not root_id:
            counts['errors'].append(f'{filename}: فصل مقصد مشخص نیست؛ `chapters` یا `chapter_id`/`chapter_title` لازم است. هیچ محتوایی وارد نشد.')
            counts['skipped']+=len(raw_items)
            return counts
        raw_chapters=[{'id':root_id or '__single_pack_chapter__','title':root_title or Path(filename).stem.replace('_',' ').replace('-',' '),
                       'order_num':data.get('order_num') or 999,'group_name':'imported'}]
    initial_chapter_ids={str(r['id']) for r in conn.execute('SELECT id FROM chapters').fetchall()}
    chapter_map={}; created_ids=set()
    if target_chapter:
        target_row=conn.execute('SELECT id FROM chapters WHERE id=?',(target_chapter,)).fetchone()
        if not target_row:
            counts['errors'].append(f'{filename}: فصل مقصد انتخاب‌شده پیدا نشد؛ هیچ محتوا وارد نشد.'); counts['skipped']+=len(raw_items); return counts
        assigned=conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(target_chapter,)).fetchone()
        if target_topic_id and _import_topic_exists(conn,target_topic_id) and assigned and str(assigned['topic_id'])!=str(target_topic_id):
            counts['errors'].append(f'{filename}: فصل مقصد به موضوع دیگری متصل است؛ برای جلوگیری از اختلاط، مقصد را هماهنگ کن.'); counts['skipped']+=len(raw_items); return counts
        chapter_map={str(ch.get('id') or '').strip() or (f'__chapter_{idx}__' if len(raw_chapters)==1 else ''):target_chapter for idx,ch in enumerate(raw_chapters,1) if isinstance(ch,dict)}
        if target_topic_id and _import_topic_exists(conn,target_topic_id) and not assigned: _safe_assign_import_topic(conn,target_chapter,target_topic_id,only_if_unassigned=True)
    else:
      for idx,ch in enumerate(raw_chapters,1):
            if not isinstance(ch,dict):
                counts['errors'].append(f'{filename}: یکی از مشخصات فصل‌ها شیء معتبر نیست.')
                continue
            old_id=str(ch.get('id') or '').strip() or (f'__chapter_{idx}__' if len(raw_chapters)==1 else '')
            if not old_id:
                counts['errors'].append(f'{filename}: یکی از فصل‌ها شناسه ندارد و چندفصلی بودن بسته اجازهٔ نگاشت مطمئن نمی‌دهد.')
                continue
            cid,created=_ensure_pack_chapter(conn,ch,filename,idx,target_topic_id,str(data.get('title') or data.get('pack_id') or Path(filename).name))
            chapter_map[old_id]=cid
            if created and cid not in initial_chapter_ids: created_ids.add(cid)
            if cid not in initial_chapter_ids and created: counts['chapters_created']+=1
    if not chapter_map and raw_items:
        counts['errors'].append(f'{filename}: هیچ فصل قابل نگاشتی پیدا نشد؛ محتوا وارد نشد.')
        counts['skipped']+=len(raw_items)
        return counts

    selected_topic=target_topic_id if _import_topic_exists(conn,target_topic_id) else ''
    if not target_chapter:
      for source_ch in raw_chapters:
            if not isinstance(source_ch,dict): continue
            old_ch=str(source_ch.get('id') or '').strip()
            if not old_ch and len(chapter_map)==1: old_ch=next(iter(chapter_map))
            resolved_ch=chapter_map.get(old_ch)
            if not resolved_ch: continue
            currently=conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(resolved_ch,)).fetchone()
            if resolved_ch in created_ids:
                source_topic=str(source_ch.get('topic_id') or '').strip()
                use_topic=selected_topic or (source_topic if _import_topic_exists(conn,source_topic) else '') or resolved_default_topic
                if use_topic and _safe_assign_import_topic(conn,resolved_ch,use_topic,only_if_unassigned=False): counts['topic_assignments']+=1
            elif not currently:
                source_topic=str(source_ch.get('topic_id') or '').strip()
                use_topic=selected_topic or (source_topic if _import_topic_exists(conn,source_topic) else '') or resolved_default_topic
                if use_topic and _safe_assign_import_topic(conn,resolved_ch,use_topic,only_if_unassigned=True): counts['topic_assignments']+=1

    for it in raw_items:
        if not isinstance(it,dict):
            counts['errors'].append(f'{filename}: یک رکورد محتوا شیء معتبر نیست؛ نادیده گرفته شد.')
            counts['skipped']+=1
            continue
        old_cid=str(it.get('chapter_id') or '').strip()
        if target_chapter:
            # Explicitly selected destination overrides every source chapter ID in the pack.
            cid=target_chapter
        elif old_cid in chapter_map:
            cid=chapter_map[old_cid]
        elif len(raw_chapters)==1 and len(set(chapter_map.values()))==1:
            cid=next(iter(set(chapter_map.values())))
            # A single-chapter pack has one unambiguous destination; do not abort it because
            # legacy records carry an old/missing chapter ID. Multi-chapter packs remain strict.
        else:
            counts['errors'].append(f'{filename}: شناسهٔ فصل «{old_cid or "خالی"}» برای رکورد «{str(it.get("title") or "بدون عنوان")[:70]}» در بستهٔ چندفصلی مشخص نیست؛ رکورد وارد نشد.')
            counts['skipped']+=1
            continue
        kind=it.get('kind') or 'lesson'; title=it.get('title') or 'مورد بستهٔ واردشده'
        if kind not in {'lesson','flashcard','question','command','lab','example','note','asset'}: kind='lesson'
        raw_meta=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
        meta=dict(raw_meta); content=str(it.get('content') or '')
        if inherited_source and not isinstance(meta.get('source_reference'),dict):
            meta['source_reference']={k:inherited_source[k] for k in ('title','author','edition','publication_year','publisher','url','isbn','file_name','file_sha256') if inherited_source.get(k)}
        if root_sources and not isinstance(meta.get('sources'),list): meta['sources']=[x for x in root_sources if isinstance(x,dict)]
        # A prompt-only visual is not a real image file. Preserve it as an ordinary
        # reviewable note instead of letting one missing visual abort otherwise valid lessons.
        if kind=='asset':
            visual_status=str(meta.get('output_status') or meta.get('status') or meta.get('generation_status') or '').strip().lower()
            visual_ref=str(meta.get('path') or content or meta.get('file_name') or '').strip()
            if visual_status in {'prompt_only_not_generated','prompt_only','planned','not_generated'} and not visual_ref.startswith('/media/'):
                prompt_fa=str(meta.get('prompt_fa') or '').strip()
                prompt_en=str(meta.get('prompt_en') or '').strip()
                labels_fa=meta.get('labels_fa') or []
                labels_en=meta.get('labels_en') or []
                sections=[]
                if prompt_fa: sections.append('## پرامپت فارسی\n'+prompt_fa)
                if prompt_en: sections.append('## English prompt\n'+prompt_en)
                if labels_fa: sections.append('## برچسب‌های فارسی پیشنهادی\n'+'\n'.join('- '+str(x) for x in labels_fa))
                if labels_en: sections.append('## Suggested English labels\n'+'\n'.join('- '+str(x) for x in labels_en))
                if not sections: sections.append('تصویر هنوز تولید نشده است. برای ساخت تصویر از فرادادهٔ این رکورد استفاده کن و پس از تولید فایل واقعی، آن را دوباره به‌صورت دارایی تصویری وارد کن.')
                content='\n\n'.join(sections)
                meta['visual_prompt_only']=True
                meta['original_asset_type']=meta.get('asset_type') or meta.get('kind') or 'visual'
                meta['output_status']='prompt_only_not_generated'
                kind='note'
                title='پرامپت تصویر: '+str(title)
                summary=str(it.get('summary') or 'راهنمای تولید تصویر؛ فایل تصویر واقعی در بسته موجود نیست.')
        portable_fields={'options','correct_index','candidate_correct_index','answer_key_correct_index','candidate_answer_index','answer_key','answer_index','correct_answer_index','correct_option_index','correct_option','correct_letter','answer_letter','answer_key_explanation','question','explanation','front','back','difficulty','level','tags','domain','platform','product_version','command','risk','when_to_use_fa','expected_result_fa','caution_fa','estimated_minutes','prerequisites','learning_objectives','references','topic','related_lessons','correct_answer','answer'}
        for field in portable_fields:
            if field in it and field not in meta: meta[field]=it[field]
        if kind=='question':
            if 'options' not in meta and isinstance(it.get('choices'),list): meta['options']=it['choices']
            if 'question' not in meta: meta['question']=it.get('question') or it.get('prompt') or it.get('title') or ''
            if 'explanation' not in meta: meta['explanation']=it.get('explanation') or it.get('explain_fa') or it.get('summary') or ''
        elif kind=='flashcard':
            meta.setdefault('front',it.get('front') or it.get('question') or it.get('title') or '')
            meta.setdefault('back',it.get('back') or it.get('answer') or content or it.get('summary') or '')
        if kind=='asset':
            media_path=str(meta.get('path') or content)
            original_name=Path(media_path).name if media_path.startswith('/media/') else str(meta.get('file_name') or '')
            media_name=original_name if original_name and (MEDIA/original_name).is_file() else ''
            if not media_name and original_name:
                for candidate in conn.execute("SELECT chapter_id,title,content,metadata_json FROM items WHERE kind='asset'").fetchall():
                    try: candidate_meta=json.loads(candidate['metadata_json'] or '{}')
                    except Exception: candidate_meta={}
                    candidate_original=Path(str(candidate_meta.get('file_name') or candidate['title'])).name
                    candidate_path=str(candidate_meta.get('path') or candidate['content'] or '')
                    candidate_disk=Path(candidate_path).name if candidate_path.startswith('/media/') else ''
                    if candidate_original==original_name and candidate_disk and (MEDIA/candidate_disk).is_file(): media_name=candidate_disk; break
            if not media_name:
                counts['errors'].append(f'{title}: فایل تصویر «{original_name or media_path}» کنار JSON پیدا نشد؛ تصویر معتبر را هم انتخاب کن.')
                counts['skipped']+=1; continue
            meta['path']=f'/media/{media_name}'; content=meta['path']
            if conn.execute("SELECT 1 FROM items WHERE chapter_id=? AND kind='asset' AND content=? LIMIT 1",(cid,content)).fetchone():
                counts['skipped']+=1; continue
        declared_status=str(it.get('source_status') or 'review_required')
        if declared_status!='review_required': meta.setdefault('imported_declared_status',declared_status)
        uid=str(it.get('source_uid') or it.get('id') or item_hash(cid,kind,str(title),content,filename))
        added=add_item(conn,cid,kind,str(title),str(it.get('summary') or ''),content,'review_required',it.get('source_file') or filename,uid,meta)
        if added:
            key={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','asset':'assets','example':'examples','note':'notes'}.get(kind)
            if key: counts[key]+=1
            counts['needs_review']+=1
        else: counts['skipped']+=1
    return counts


def add_regular_file(conn, filename, raw, target_chapter, source_file=None, status='review_required', target_topic_id=''):
    ext=Path(filename).suffix.lower(); fname=safe_name(filename); source_file=source_file or filename
    if ext in SUPPORTED_IMAGE:
        if not raw:
            raise ValueError(f'تصویر «{filename}» خالی است.')
        if len(raw) > 40 * 1024 * 1024:
            raise ValueError(f'تصویر «{filename}» بیش از ۴۰ مگابایت است.')
        mime = validate_image_bytes(filename, raw)
        digest=hashlib.sha256(raw).hexdigest()[:16]
        stored=f'{digest}_{fname}'
        dest=MEDIA/stored
        if not dest.exists():
            tmp=dest.with_suffix(dest.suffix+'.tmp')
            tmp.write_bytes(raw); tmp.replace(dest)
        added=add_item(conn,target_chapter,'asset',Path(filename).name,'تصویر واردشده',f'/media/{stored}', 'verified' if status=='user' else status, source_file,
                 source_uid='asset:'+hashlib.sha256((target_chapter+digest).encode()).hexdigest(), metadata={'path':f'/media/{stored}','file_name':Path(filename).name,'mime':mime,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        return {'assets':int(added),'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    text=''
    if ext in TEXT_TYPES:
        text=raw.decode('utf-8-sig',errors='replace')
        # A Markdown file stays as a rich lesson; sections/headings remain available in its content.
        title=infer_title(filename,text)
        added=add_item(conn,target_chapter,'lesson',title,'واردشده از فایل متنی',text,status,source_file,metadata={'file_name':Path(filename).name,'format':ext[1:]})
        return {'assets':0,'lessons':int(added),'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    if ext=='.docx':
        try:text=extract_docx(raw)
        except Exception as e: raise ValueError(f'خواندن Word ناموفق بود: {filename}: {e}')
        title=infer_title(filename,text); added=add_item(conn,target_chapter,'lesson',title,'واردشده از Word',text,status,source_file,metadata={'file_name':Path(filename).name,'format':'docx'})
        return {'assets':0,'lessons':int(added),'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    if ext=='.pdf':
        try:text=extract_pdf(raw)
        except Exception as e: raise ValueError(f'خواندن PDF ناموفق بود: {filename}: {e}')
        if not text.strip(): text='متن قابل استخراج پیدا نشد. احتمالاً PDF اسکن‌شده است.'
        title=infer_title(filename,text); added=add_item(conn,target_chapter,'lesson',title,'واردشده از PDF؛ بازبینی متن استخراج‌شده توصیه می‌شود',text,status,source_file,metadata={'file_name':Path(filename).name,'format':'pdf'})
        return {'assets':0,'lessons':int(added),'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    if ext=='.json':
        data=get_json(raw)
        if data is None:
            raise ValueError(f'JSON قابل خواندن نیست: {filename}')
        if isinstance(data,dict) and data.get('format') in {'network-learning-pack-v1','network-learning-content-pack-v1','network-learning-content-pack-v2','network-learning-content-export-v1','network-learning-selected-content-v1'}:
            return _import_unified_pack(conn,data,filename,target_chapter,target_topic_id)
        if isinstance(data,dict) and data.get('format')=='network-learning-item-v1' and isinstance(data.get('item'),dict):
            it=dict(data['item']); old_cid=str(it.get('chapter_id') or '')
            chapter_title=str(it.get('chapter_title') or 'محتوای واردشده')
            if target_chapter:
                cid=target_chapter
            else:
                existing=conn.execute('SELECT title FROM chapters WHERE id=?',(old_cid,)).fetchone() if old_cid else None
                assigned=conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(old_cid,)).fetchone() if existing else None
                compatible=bool(existing and str(existing['title']).strip().casefold()==chapter_title.strip().casefold() and (not assigned or not target_topic_id or str(assigned['topic_id'])==target_topic_id))
                if compatible: cid=old_cid
                else: cid=_ensure_scoped_import_chapter(conn,chapter_title,target_topic_id,'json-item|'+old_cid+'|'+str(it.get('source_uid') or it.get('id') or filename))
            kind=str(it.get('kind') or 'lesson')
            if kind not in {'lesson','flashcard','question','command','lab','example','note','asset'}: kind='lesson'
            md=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
            content=str(it.get('content') or '')
            if kind=='asset':
                media_path=str(md.get('path') or content); original=Path(media_path).name
                existing=None
                for candidate in conn.execute("SELECT title,content,metadata_json FROM items WHERE kind='asset'").fetchall():
                    try: cm=json.loads(candidate['metadata_json'] or '{}')
                    except Exception: cm={}
                    if Path(str(cm.get('file_name') or candidate['title'])).name==original and (MEDIA/Path(str(cm.get('path') or candidate['content'])).name).is_file():
                        existing=Path(str(cm.get('path') or candidate['content'])).name; break
                if existing: md=dict(md); md['path']=f'/media/{existing}'; content=md['path']
                elif media_path.startswith('/media/'):
                    counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':1,'errors':[f'{it.get("title") or filename}: فایل رسانهٔ اصلی همراه این JSON در دسترس نیست.']}
                    return counts
            declared_status=str(it.get('source_status') or 'review_required')
            if declared_status!='review_required': md=dict(md); md.setdefault('imported_declared_status',declared_status)
            added=add_item(conn,cid,kind,str(it.get('title') or 'مورد واردشده'),str(it.get('summary') or ''),content,'review_required',str(it.get('source_file') or filename),str(it.get('source_uid') or it.get('id') or ''),md)
            key_name={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','asset':'assets','example':'examples','note':'notes'}.get(kind)
            counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':int(not added),'needs_review':int(added),'chapters_created':0,'errors':[]}
            if added and key_name: counts[key_name]=1
            return counts
        if isinstance(data,dict) and data.get('format')=='network-learning-backup-v1':
            counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0,'chapters_created':0}
            chapter_map={}; item_map={}
            for ch in data.get('chapters',[]):
                if not isinstance(ch,dict): continue
                title=ch.get('title') or 'فصل پشتیبان'
                existing=conn.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
                if existing: new_cid=existing['id']
                else:
                    wanted=str(ch.get('id') or '')
                    if wanted and not conn.execute('SELECT 1 FROM chapters WHERE id=?',(wanted,)).fetchone():
                        new_cid=wanted
                        conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',
                          (new_cid,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','backup',ch.get('description') or '',now_iso()))
                    else: new_cid=ensure_import_chapter(conn,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','backup')
                    counts['chapters_created']+=1
                chapter_map[str(ch.get('id') or '')]=new_cid
            for it in data.get('items',[]):
                if not isinstance(it,dict): continue
                old_ch=str(it.get('chapter_id') or '')
                cid=chapter_map.get(old_ch) or target_chapter
                kind=it.get('kind') or 'lesson'; title=it.get('title') or 'مورد پشتیبان'
                meta=it.get('metadata') or {}
                old_uid=str(it.get('source_uid') or f"backup-item-{it.get('id','')}")
                existed=conn.execute('SELECT id FROM items WHERE chapter_id=? AND source_uid=?',(cid,old_uid)).fetchone()
                if existed: new_id=existed['id']; counts['skipped']+=1
                else:
                    if kind not in {'lesson','flashcard','question','command','lab','example','note','asset'}: kind='lesson'
                    declared_status=str(it.get('source_status') or 'backup')
                    if declared_status != 'review_required': meta=dict(meta); meta.setdefault('imported_declared_status',declared_status)
                    add_item(conn,cid,kind,title,it.get('summary') or '',it.get('content') or '', 'review_required',it.get('source_file') or filename,old_uid,meta)
                    new=conn.execute('SELECT id FROM items WHERE chapter_id=? AND source_uid=?',(cid,old_uid)).fetchone()
                    new_id=new['id'] if new else None
                    key={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','asset':'assets','example':'examples','note':'notes'}.get(kind)
                    if key: counts[key]+=1
                if new_id is not None: item_map[str(it.get('id') or '')]=new_id
            for pr in data.get('progress',[]):
                if not isinstance(pr,dict): continue
                new_id=item_map.get(str(pr.get('item_id') or ''))
                if new_id is None: continue
                conn.execute('''INSERT INTO progress(item_id,completed,correct_count,wrong_count,interval_days,ease,due_at,last_reviewed) VALUES(?,?,?,?,?,?,?,?)
                 ON CONFLICT(item_id) DO UPDATE SET completed=MAX(progress.completed,excluded.completed),correct_count=MAX(progress.correct_count,excluded.correct_count),wrong_count=MAX(progress.wrong_count,excluded.wrong_count),interval_days=MAX(progress.interval_days,excluded.interval_days),ease=excluded.ease,due_at=excluded.due_at,last_reviewed=excluded.last_reviewed''',
                 (new_id,int(pr.get('completed') or 0),int(pr.get('correct_count') or 0),int(pr.get('wrong_count') or 0),int(pr.get('interval_days') or 0),float(pr.get('ease') or 2.5),pr.get('due_at') or '',pr.get('last_reviewed') or ''))
            return counts
        items=data.get('items',[]) if isinstance(data,dict) else data if isinstance(data,list) else []
        if target_topic_id and _import_topic_exists(conn,target_topic_id): _safe_assign_import_topic(conn,target_chapter,target_topic_id,only_if_unassigned=True)
        kind='lesson'
        lf=Path(filename).name.lower()
        format_kind={
            'network-learning-lessons-v1':'lesson','network-learning-questions-v1':'question',
            'network-learning-flashcards-v1':'flashcard','network-learning-commands-v1':'command',
            'network-learning-labs-v1':'lab','network-learning-examples-v1':'example',
            'network-learning-notes-v1':'note'
        }.get(str(data.get('format') or '') if isinstance(data,dict) else '')
        if format_kind: kind=format_kind
        elif 'question' in lf: kind='question'
        elif 'command' in lf: kind='command'
        elif 'lab' in lf: kind='lab'
        elif 'example' in lf: kind='example'
        elif 'note' in lf: kind='note'
        elif 'flashcard' in lf or 'card' in lf: kind='flashcard'
        elif 'answer_key' in lf or 'manifest' in lf or 'curriculum' in lf: return {'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0}
        counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0}
        if not items and isinstance(data,dict) and any(k in data for k in ('title','title_fa','content','full_content')):
            items=[data]
        if len(items)>MAX_ITEMS_PER_FILE: items=items[:MAX_ITEMS_PER_FILE]
        for it in items:
            if not isinstance(it,dict): continue
            title=it.get('title_fa') or it.get('title') or it.get('prompt') or it.get('question') or it.get('name') or it.get('uid') or 'مورد واردشده'
            content=it.get('full_content') or it.get('content') or it.get('body_fa') or it.get('command') or it.get('prompt') or it.get('question') or ''
            summary=it.get('summary') or it.get('summary_fa') or it.get('when_to_use_fa') or it.get('explanation') or it.get('explain_fa') or ''
            item_kind=kind
            md={k:v for k,v in it.items() if k not in {'full_content','content','body_fa','summary','summary_fa','title_fa','title'}}
            if item_kind=='flashcard':
                md['front']=it.get('front') or it.get('question') or title
                md['back']=it.get('back') or it.get('answer') or content or summary
                content=md['back']; summary=md['back']
            if item_kind=='question':
                # Imported question banks are deliberately not considered validated automatically.
                md['options']=it.get('options',[]); md['correct_index']=it.get('correct_index')
                md['explanation']=it.get('explanation') or it.get('explain_fa') or ''
            uid=it.get('uid') or it.get('id') or item_hash(target_chapter,item_kind,str(title),str(content),source_file)
            declared_status=str(it.get('source_status') or status or 'review_required')
            if declared_status != 'review_required': md.setdefault('imported_declared_status',declared_status)
            # Content from an external file is never marked verified automatically.
            src_status='review_required'
            added=add_item(conn,target_chapter,item_kind,str(title),str(summary),str(content),src_status,source_file,str(uid),md)
            key={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','example':'examples','note':'notes'}.get(item_kind)
            if key and added: counts[key]+=1
            if added: counts['needs_review']=counts.get('needs_review',0)+1
            elif not added: counts['skipped']+=1
        return counts
    return {'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'skipped':0}


def parse_manifest_entries(zf:zipfile.ZipFile, archive_filename: str='', include_subchapters: bool=False):
    """Detect chapter roots without promoting every nested manifest to a chapter.

    Sibling chapter manifests remain independent chapters. A manifest nested inside a
    chapter is treated as a subsection unless its parent is a course container or its path
    clearly identifies an independent chapter. Folder hierarchy takes precedence over a
    loose `type=chapter` field that may have been emitted incorrectly by an authoring tool.
    This prevents lesson/subchapter folders in one-chapter ZIPs from polluting the
    top-level chapter list.
    """
    mapping={}
    nested={}
    infos=[i for i in zf.infolist() if not i.is_dir()]
    normalized_paths={i.filename.replace('\\','/'):i for i in infos}
    bank_names={'lessons.json','questions.json','examples.json','commands.json','labs.json','flashcards.json','cards.json','notes.json'}
    ignored_parts={'answers','assets','images','media','sources','source_archive','authoring','build','windows','android','__pycache__'}
    all_manifests={}
    for info in infos:
        path=info.filename.replace('\\','/')
        if not path.lower().endswith('/manifest.json') and path.lower()!='manifest.json': continue
        try:d=get_json(zf.read(info))
        except Exception:d=None
        if isinstance(d,dict) and (d.get('title_fa') or d.get('title') or d.get('chapter_title')):
            folder=str(PurePosixPath(path).parent)
            title=d.get('title_fa') or d.get('title') or d.get('chapter_title')
            all_manifests[folder]={'title':title,'slug':d.get('slug',''),
                'order':d.get('chapter_order',d.get('order_num',999)),
                'status':d.get('source_status') or d.get('status') or 'review_required',
                '_manifest':d,'_path':folder}

    def is_course_manifest(meta):
        m=meta.get('_manifest') or {}
        kind=str(m.get('entity_type') or m.get('manifest_type') or m.get('package_type') or m.get('type') or '').casefold().replace('-','_')
        return bool(m.get('is_course') or m.get('course_root')) or kind in {'course','book','curriculum','topic','learning_path','subject','course_pack'}

    def looks_like_chapter_folder(folder, parent_folder):
        rel=str(folder)[len(str(parent_folder).rstrip('/')):].strip('/') if parent_folder not in ('','.','') else str(folder)
        parts=[x.casefold() for x in PurePosixPath(rel).parts if x not in ('','.','..')]
        for part in parts:
            if re.match(r'^(?:chapter|chap|ch)[-_ ]*0*\d+',part) or re.match(r'^فصل[-_ ]*0*[0-9۰-۹]+',part):
                return True
            if part in {'chapters','chapter_list','فصل‌ها','فصل ها'}:
                return True
        return False

    for folder,meta in sorted(all_manifests.items(),key=lambda pair:(len(PurePosixPath(pair[0]).parts),pair[0])):
        parent_candidates=[candidate for candidate in all_manifests if candidate != folder and ((candidate=='.' and folder not in ('.','')) or (candidate not in ('','.','..') and folder.startswith(candidate.rstrip('/')+'/')))]
        parent=max(parent_candidates,key=lambda x:len(PurePosixPath(x).parts),default='')
        m=meta.get('_manifest') or {}
        explicit_sub=bool(m.get('is_subchapter') or m.get('is_section')) or str(m.get('entity_type') or m.get('record_type') or m.get('type') or '').casefold() in {'subchapter','sub_chapter','section','lesson','topic_section'}
        explicit_chapter=bool(m.get('is_chapter')) or str(m.get('entity_type') or m.get('record_type') or m.get('type') or '').casefold()=='chapter'
        # Explicit course manifests define a container whose direct child manifests are chapters.
        parent_is_course=bool(parent and is_course_manifest(all_manifests[parent]))
        if parent and not parent_is_course and not looks_like_chapter_folder(folder,parent):
            # The closest parent chapter owns this content; remember the nested title for the tree UI.
            nested[folder]={k:v for k,v in meta.items() if not k.startswith('_')}
            nested[folder]['path']=folder
            nested[folder]['parent_folder']=parent
            nested[folder]['subchapter_title']=str(m.get('subchapter_title') or m.get('section_title') or m.get('lesson_title') or meta.get('title') or '').strip()
        elif explicit_sub and parent:
            nested[folder]={k:v for k,v in meta.items() if not k.startswith('_')}
            nested[folder]['path']=folder
            nested[folder]['parent_folder']=parent
            nested[folder]['subchapter_title']=str(m.get('subchapter_title') or m.get('section_title') or m.get('lesson_title') or meta.get('title') or '').strip()
        else:
            mapping[folder]={k:v for k,v in meta.items() if not k.startswith('_')}

    # If a manifest explicitly describes a course/book/curriculum and has child chapter roots,
    # keep the course manifest as a container only. If it has no chapter children, it remains
    # the single importable chapter root (useful for one-chapter packages).
    for course_folder in [folder for folder, meta in all_manifests.items() if is_course_manifest(meta)]:
        if course_folder not in mapping:
            continue
        has_chapter_children = any(
            other != course_folder and (
                (course_folder in ('', '.') and other not in ('', '.')) or
                (course_folder not in ('', '.') and other.startswith(course_folder.rstrip('/') + '/'))
            )
            for other in mapping
        )
        if has_chapter_children:
            mapping.pop(course_folder, None)

    explicit=set(mapping)
    bank_folders=set()
    for info in infos:
        path=info.filename.replace('\\','/')
        parts=PurePosixPath(path).parts
        if not parts or PurePosixPath(path).name.lower() not in bank_names: continue
        if any(part.lower() in ignored_parts for part in parts[:-1]): continue
        folder=str(PurePosixPath(path).parent)
        if folder in explicit or any(folder.startswith(parent+'/') for parent in explicit if parent not in ('.','')): continue
        if folder not in ('.',''):
            bank_folders.add(folder)
    for folder in sorted(bank_folders):
        if folder in mapping or any(folder.startswith(parent+'/') for parent in explicit if parent not in ('.','')): continue
        target_folder=folder; title=''
        possible=[folder]
        parent=PurePosixPath(folder).parent
        while str(parent) not in ('.',''):
            possible.append(str(parent)); parent=parent.parent
        for candidate_folder in possible:
            found_title=''
            for candidate in (f'{candidate_folder}/README_FA.md',f'{candidate_folder}/README.md',f'{candidate_folder}/readme_fa.txt'):
                obj=normalized_paths.get(candidate)
                if not obj: continue
                try:
                    text_value=zf.read(obj).decode('utf-8-sig',errors='replace')
                    found_title=infer_title(candidate,text_value)
                    if found_title and found_title.lower() not in {'readme','readme fa','محتوا','content'}: break
                    found_title=''
                except Exception: found_title=''
            if found_title:
                target_folder=candidate_folder; title=found_title; break
        if any(target_folder.startswith(parent+'/') for parent in mapping if parent not in ('.','')): continue
        if target_folder in mapping: continue
        if not title:
            basename=PurePosixPath(target_folder).name
            title=basename.replace('_',' ').replace('-',' ').strip()
        mapping[target_folder]={'title':title or 'فصل واردشده از ZIP','slug':PurePosixPath(target_folder).name,'order':999,'status':'review_required','inferred':True}
    root_has_bank=any(str(PurePosixPath(i.filename.replace('\\','/')).parent) in ('.','') and PurePosixPath(i.filename).name.lower() in bank_names for i in infos)
    if root_has_bank and '.' not in mapping:
        root_title=Path(archive_filename).stem.replace('_',' ').replace('-',' ').strip() if archive_filename else 'فصل واردشده از ZIP'
        mapping['.']={'title':root_title or 'فصل واردشده از ZIP','slug':'','order':999,'status':'review_required','inferred':True}

    # Infer roots for document-oriented chapter ZIPs where no canonical bank exists.
    generic_dirs={'content','contents','chapter','chapters','lesson','lessons','notes','examples','documents','document','docs','files',
                  'materials','material','assets','images','media','sources','source_archive','authoring','build','windows','android',
                  'فصل','فصل‌ها','فصل ها','محتوا','درس','درس‌ها','درس ها','یادداشت','یادداشت‌ها','تصاویر','منابع','زیر فصل','زیر‌فصل','زیرفصل'}
    importable_exts=set(TEXT_TYPES)|{'.pdf','.docx'}|set(SUPPORTED_IMAGE)
    ignored_lower={x.lower() for x in ignored_parts}
    for info in infos:
        path=info.filename.replace('\\','/')
        pure=PurePosixPath(path); parts=pure.parts; name=pure.name.lower(); ext=pure.suffix.lower()
        if ext not in importable_exts or name.startswith('readme'): continue
        if any(part.lower() in ignored_lower for part in parts[:-1]): continue
        parent_parts=list(parts[:-1])
        if any('/'.join(parent_parts[:i]) in mapping for i in range(1,len(parent_parts)+1)): continue
        if not parent_parts:
            if '.' not in mapping:
                root_title=Path(archive_filename).stem.replace('_',' ').replace('-',' ').strip() if archive_filename else 'فصل واردشده از ZIP'
                mapping['.']={'title':root_title or 'فصل واردشده از ZIP','slug':'','order':999,'status':'review_required','inferred':True}
            continue
        chosen=None
        for idx in range(len(parent_parts)-1,-1,-1):
            piece=parent_parts[idx]
            if piece.lower() not in generic_dirs and piece.lower() not in ignored_lower and piece not in ('.','..'):
                chosen=idx; break
        if chosen is None: continue
        folder='/'.join(parent_parts[:chosen+1])
        if any(folder==mapped or folder.startswith(mapped+'/') for mapped in mapping if mapped not in ('.','')): continue
        if folder in mapping: continue
        title=''
        for candidate in (f'{folder}/README_FA.md',f'{folder}/README.md',f'{folder}/readme_fa.txt'):
            obj=normalized_paths.get(candidate)
            if obj:
                try: title=infer_title(candidate,zf.read(obj).decode('utf-8-sig',errors='replace'))
                except Exception: title=''
                if title and title.lower() not in {'readme','readme fa','محتوا','content'}: break
                title=''
        if not title: title=PurePosixPath(folder).name.replace('_',' ').replace('-',' ').strip()
        mapping[folder]={'title':title or 'فصل واردشده از ZIP','slug':PurePosixPath(folder).name,'order':999,'status':'review_required','inferred':True}
    return (mapping,nested) if include_subchapters else mapping

def chapter_for_archive_folder(conn, folder, manifest, mode, target_chapter, target_topic_id='', archive_filename=''):
    if mode=='selected': return target_chapter
    if manifest:
        title=str(manifest.get('title') or manifest.get('title_fa') or folder or Path(archive_filename).stem or 'فصل واردشده').strip()
        matched=chapter_for_slug(str(manifest.get('slug','')),title)
        if matched:
            existing=conn.execute('SELECT title FROM chapters WHERE id=?',(matched,)).fetchone()
            assigned=conn.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(matched,)).fetchone()
            topic_ok=(not assigned) or (not target_topic_id) or str(assigned['topic_id'])==str(target_topic_id)
            if existing and str(existing['title']).strip().casefold()==title.casefold() and topic_ok:
                if target_topic_id and _import_topic_exists(conn,target_topic_id): _safe_assign_import_topic(conn,matched,target_topic_id,only_if_unassigned=True)
                return matched
        return _ensure_scoped_import_chapter(conn,title,target_topic_id,'zip|'+Path(archive_filename).name+'|'+str(folder)+'|'+str(manifest.get('slug') or ''))
    parts=[p for p in PurePosixPath(folder).parts if p not in ('.','')]
    title=(parts[-1].replace('_',' ').replace('-',' ') if parts else (Path(archive_filename).stem.replace('_',' ').replace('-',' ') or 'فایل‌های واردشده'))
    return _ensure_scoped_import_chapter(conn,title,target_topic_id,'zip-folder|'+Path(archive_filename).name+'|'+str(folder))

def _nearest_archive_folder(folder: str, mapping: dict):
    current=PurePosixPath(folder)
    while str(current) not in ('.',''):
        if str(current) in mapping: return str(current)
        current=current.parent
    if str(folder) in ('.','') and '.' in mapping: return '.'
    return ''


def validate_content_pack_v2_data(data: dict) -> list[str]:
    """Strict structural validation for the canonical AI content-pack format."""
    errors=[]
    if data.get('format')!='network-learning-content-pack-v2': errors.append('format باید network-learning-content-pack-v2 باشد')
    if not str(data.get('title') or '').strip(): errors.append('عنوان بسته خالی است')
    chapters=data.get('chapters'); items=data.get('items')
    if not isinstance(chapters,list) or not chapters: errors.append('حداقل یک فصل در chapters لازم است'); chapters=[]
    if not isinstance(items,list): errors.append('items باید آرایه باشد'); items=[]
    chapter_ids=[]
    for idx,ch in enumerate(chapters,1):
        if not isinstance(ch,dict): errors.append(f'فصل {idx}: باید شیء باشد'); continue
        cid=str(ch.get('id') or '').strip()
        if not cid: errors.append(f'فصل {idx}: شناسهٔ id خالی است')
        if not str(ch.get('title') or '').strip(): errors.append(f'فصل {idx}: عنوان خالی است')
        if cid in chapter_ids: errors.append(f'شناسهٔ فصل تکراری: {cid}')
        chapter_ids.append(cid)
    known=set(chapter_ids); item_ids=[]; allowed={'lesson','flashcard','question','command','example','lab','note','asset'}
    for idx,it in enumerate(items,1):
        if not isinstance(it,dict): errors.append(f'محتوای {idx}: باید شیء باشد'); continue
        uid=str(it.get('uid') or it.get('id') or '').strip()
        if uid and uid in item_ids: errors.append(f'شناسهٔ محتوا تکراری: {uid}')
        if uid: item_ids.append(uid)
        if str(it.get('chapter_id') or '') not in known: errors.append(f'محتوای {idx}: chapter_id به فصل موجود اشاره نمی‌کند')
        if it.get('kind') not in allowed: errors.append(f'محتوای {idx}: kind نامعتبر است')
        if not str(it.get('title') or '').strip(): errors.append(f'محتوای {idx}: عنوان خالی است')
        meta=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
        if it.get('kind')=='question':
            options=meta.get('options',it.get('options',[])); correct=meta.get('correct_index',it.get('correct_index'))
            if not isinstance(options,list) or len(options)<2: errors.append(f'سؤال {idx}: حداقل دو گزینه لازم است')
            elif not isinstance(correct,int) or isinstance(correct,bool) or not 0<=correct<len(options): errors.append(f'سؤال {idx}: correct_index معتبر نیست')
    if data.get('sample_only') is True or (isinstance(data.get('metadata'),dict) and data['metadata'].get('sample_only') is True):
        errors.append('بستهٔ نمونه/قالب قابل‌واردکردن نیست؛ خروجی نهایی محتوا را انتخاب کن')
    return errors

def import_zip(conn, raw:bytes, filename:str, target_chapter:str, mode:str, target_topic_id: str=''):
    stats={'files_seen':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'assets':0,'skipped':0,'chapters_created':0,'needs_review':0,'errors':[]}
    try: zf=zipfile.ZipFile(BytesIO(raw))
    except Exception: raise ValueError('فایل ZIP معتبر نیست.')
    infos=[i for i in zf.infolist() if not i.is_dir()]
    if len(infos)>MAX_ZIP_FILES: raise ValueError(f'تعداد فایل‌های ZIP بیش از حد مجاز است ({MAX_ZIP_FILES}).')
    total_uncompressed=sum(i.file_size for i in infos)
    if total_uncompressed>500*1024*1024: raise ValueError('حجم بازشدهٔ آرشیو بیش از ۵۰۰ مگابایت است.')
    for info in infos:
        safe_path=PurePosixPath(info.filename.replace('\\','/'))
        if safe_path.is_absolute() or '..' in safe_path.parts:
            raise ValueError(f'مسیر ناامن در ZIP: {info.filename[:120]}')
    # A final AI package uses one canonical content_pack.json and an optional assets/ folder.
    # The authoring-kit ZIP itself contains sample_only=true and is intentionally not importable.
    unified_info=next((i for i in infos if PurePosixPath(i.filename.replace('\\','/')).name.lower()=='content_pack.json'),None)
    if unified_info:
        data=get_json(zf.read(unified_info))
        if not isinstance(data,dict) or data.get('format') not in {'network-learning-content-pack-v2','network-learning-content-pack-v1','network-learning-pack-v1','network-learning-content-export-v1','network-learning-selected-content-v1'}:
            raise ValueError('content_pack.json باید یک بستهٔ محتوای یکپارچهٔ شناخته‌شده باشد.')
        if data.get('sample_only') is True or (isinstance(data.get('metadata'),dict) and data['metadata'].get('sample_only') is True):
            raise ValueError('این ZIP بستهٔ نمونه/قالب است؛ خروجی نهایی محتوا را وارد کن، نه authoring kit را.')
        if data.get('format')=='network-learning-content-pack-v2':
            pack_errors=validate_content_pack_v2_data(data)
            if pack_errors: raise ValueError('اعتبارسنجی بستهٔ محتوای v2 ناموفق بود: '+'؛ '.join(pack_errors[:20]))
        media_map={}; media_basename_counts={}; created_media_paths=[]
        image_infos=[]
        for info in infos:
            rel=info.filename.replace('\\','/'); base=PurePosixPath(rel).name
            if Path(base).suffix.lower() in SUPPORTED_IMAGE and any(part.lower() in {'assets','media','images'} for part in PurePosixPath(rel).parts[:-1]):
                image_infos.append((info,rel,base)); media_basename_counts[base.casefold()]=media_basename_counts.get(base.casefold(),0)+1
        for info,rel,base in image_infos:
            raw_img=zf.read(info)
            if not raw_img or len(raw_img)>40*1024*1024: raise ValueError(f'رسانهٔ «{base}» خالی یا بزرگ‌تر از ۴۰ مگابایت است.')
            mime=validate_image_bytes(base,raw_img)
            digest=hashlib.sha256(raw_img).hexdigest()
            stored=f'{digest[:16]}_{safe_name(base)}'; dest=MEDIA/stored
            if not dest.exists():
                tmp=dest.with_suffix(dest.suffix+'.tmp'); tmp.write_bytes(raw_img); tmp.replace(dest); created_media_paths.append(dest)
            media_map[rel.casefold()]= {'path':f'/media/{stored}','file_name':base,'mime':mime,'bytes':len(raw_img),'sha256':digest}
            if media_basename_counts.get(base.casefold())==1: media_map[base.casefold()]=media_map[rel.casefold()]
        for item in data.get('items',[]) if isinstance(data.get('items'),list) else []:
            if not isinstance(item,dict): continue
            meta=item.get('metadata') if isinstance(item.get('metadata'),dict) else {}
            item['metadata']=meta
            if str(item.get('kind') or '')=='asset':
                candidates=[meta.get('file_name'),meta.get('path'),item.get('content'),item.get('title')]
                hit=None
                for candidate in candidates:
                    if not candidate: continue
                    key=str(candidate).replace('\\','/').lstrip('./').casefold()
                    hit=media_map.get(key) or media_map.get(PurePosixPath(key).name.casefold())
                    if hit: break
                if hit:
                    meta.update({k:v for k,v in hit.items() if k!='path'}); meta['path']=hit['path']; item['content']=hit['path']
            elif str(item.get('kind') or '')=='lesson' and isinstance(item.get('content'),str):
                content=item['content']
                # Rewrite local markdown image references to their validated server media URLs.
                for key,val in media_map.items():
                    if '/' in key and not key.startswith('/media/'):
                        content=content.replace(key,val['path']).replace('./'+key,val['path'])
                for base,val in media_map.items():
                    if '/' not in base and media_basename_counts.get(base)==1:
                        content=content.replace(f'(assets/{base})',f'({val["path"]})').replace(f'![{base}]({base})',f'![{base}]({val["path"]})')
                item['content']=content
        stats=_import_unified_pack(conn,data,filename+'::content_pack.json',target_chapter,target_topic_id)
        if stats.get('errors'):
            for created in created_media_paths:
                try: created.unlink(missing_ok=True)
                except Exception: pass
        stats['files_seen']=1
        return stats
    manifests,subchapters=parse_manifest_entries(zf,filename,include_subchapters=True)
    # Map only actual chapter roots to chapters. Nested manifest files stay as subsection metadata.
    # Map all source folder paths to canonical or imported chapters.
    folder_targets={}
    before_ids={str(r['id']) for r in conn.execute("SELECT id FROM chapters").fetchall()}
    before=len(before_ids)
    for folder,meta in manifests.items():
        folder_targets[folder]=chapter_for_archive_folder(conn,folder,meta,mode,target_chapter,target_topic_id,filename)
        cid=folder_targets[folder]
        if mode!='selected' and target_topic_id and _import_topic_exists(conn,target_topic_id):
            # Assign selected topic only when the chapter currently has no topic; never move it silently.
            _safe_assign_import_topic(conn,cid,target_topic_id,only_if_unassigned=True)
    after=conn.execute("SELECT COUNT(*) n FROM chapters").fetchone()['n']; stats['chapters_created']=max(0,after-before)
    # Build answer maps per folder, but do not mark a source bank as validated unless metadata explicitly says so.
    answers={}
    for info in infos:
        path=info.filename.replace('\\','/'); low=path.lower()
        if low.endswith('/answers/answer_key.json') or low == 'answer_key.json':
            folder='.' if low == 'answer_key.json' else str(PurePosixPath(path).parent.parent)
            try:
                obj=get_json(zf.read(info))
                answers[folder]={str(k):x for x in (obj or {}).get('items',[]) if isinstance(x,dict) for k in (x.get('id'),x.get('uid'),x.get('question_id'),x.get('source_uid')) if k is not None}
            except: pass
    for info in infos:
        path=info.filename.replace('\\','/'); low=path.lower(); name=PurePosixPath(path).name
        if name.lower() in {'manifest_enrichment.json','legacy_manifest.json','answer_key.json'}: continue
        if name.lower() == 'manifest.json':
            # Manifests are parsed before this loop; avoid treating them as lessons.
            continue
        folder=str(PurePosixPath(path).parent)
        # Find nearest ancestor with manifest.
        manifest_folder=None
        p=PurePosixPath(path).parent
        while str(p) not in ('.',''):
            if str(p) in manifests: manifest_folder=str(p); break
            p=p.parent
        subchapter_folder=_nearest_archive_folder(folder,subchapters)
        subchapter_meta=subchapters.get(subchapter_folder,{}) if subchapter_folder else {}
        if mode=='selected': cid=target_chapter
        elif manifest_folder: cid=folder_targets[manifest_folder]
        else:
            routed_folder=_nearest_archive_folder(folder,folder_targets)
            if routed_folder:
                cid=folder_targets[routed_folder]
            else:
                # No silent fallback to c01 in auto mode. A ZIP entry must be associated with a
                # detected chapter ancestor or the whole archive is rolled back by the caller.
                excluded=('/answers/' in low or '/sources/' in low or '/source_archive/' in low or '/authoring/' in low or '/build/' in low or '/windows/' in low or '/android/' in low or '/__pycache__/' in low)
                if name.lower() in {'manifest.json','manifest_enrichment.json','legacy_manifest.json','answer_key.json'} or excluded:
                    continue
                if mode=='selected': cid=target_chapter
                else:
                    stats['errors'].append(f'{path}: مقصد فصل از ساختار ZIP قابل تشخیص نیست؛ فایل به فصل پیش‌فرض افزوده نشد. پوشهٔ مستقل فصل/manifest اضافه کن یا حالت «فصل انتخاب‌شده» را صریحاً انتخاب کن.')
                    stats['files_seen']+=1
                    continue
        if low.endswith('/answers/README_FA.md') or low.endswith('/sources/readme_fa.md') or '/source_archive/' in low or '/authoring/' in low or '/build/' in low or '/windows/' in low or '/android/' in low:
            continue
        is_chapter_readme = name.lower() in {'readme_fa.md','readme.md'} and (manifest_folder is not None) and folder==manifest_folder
        is_subchapter_readme = name.lower() in {'readme_fa.md','readme.md'} and bool(subchapter_folder) and folder==subchapter_folder
        # Ignore non-canonical JSON metadata. Load content from the canonical course-bank filenames.
        if low.endswith('.json'):
            stem=name.lower()
            allowed={'lessons.json','questions.json','examples.json','commands.json','labs.json','flashcards.json','cards.json','notes.json'}
            if stem not in allowed:
                continue
            try: obj=get_json(zf.read(info))
            except Exception as exc:
                stats['errors'].append(f'{path}: خواندن JSON ناموفق بود ({str(exc)[:120]})'); continue
            if not isinstance(obj,dict):
                stats['errors'].append(f'{path}: ریشهٔ فایل JSON باید یک شیء باشد.'); continue
            arr=obj.get('items',[])
            if not isinstance(arr,list):
                stats['errors'].append(f'{path}: فیلد items باید یک آرایه باشد.'); continue
            kind={'lessons.json':'lesson','questions.json':'question','examples.json':'example','commands.json':'command','labs.json':'lab','flashcards.json':'flashcard','cards.json':'flashcard','notes.json':'note'}[stem]
            if len(arr)>MAX_ITEMS_PER_FILE: arr=arr[:MAX_ITEMS_PER_FILE]
            for it in arr:
                if not isinstance(it,dict): continue
                title=it.get('title_fa') or it.get('title') or it.get('prompt') or it.get('question') or it.get('name') or it.get('uid') or 'مورد واردشده'
                content=it.get('full_content') or it.get('content') or it.get('body_fa') or it.get('command') or it.get('prompt') or it.get('question') or ''
                summary=it.get('summary') or it.get('summary_fa') or it.get('when_to_use_fa') or ''
                md={k:v for k,v in it.items() if k not in {'full_content','content','body_fa','summary','summary_fa','title_fa','title'}}
                nested_item_meta=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
                for mk,mv in nested_item_meta.items():
                    md.setdefault(mk,mv)
                explicit_subchapter=(it.get('source_subchapter_title') or it.get('subchapter_title') or it.get('section_title') or
                                     nested_item_meta.get('source_subchapter_title') or nested_item_meta.get('subchapter_title') or nested_item_meta.get('section_title'))
                if explicit_subchapter:
                    md.setdefault('source_subchapter_title',str(explicit_subchapter).strip())
                    explicit_slug=it.get('source_subchapter_slug') or nested_item_meta.get('source_subchapter_slug') or nested_item_meta.get('subchapter_slug')
                    if explicit_slug: md.setdefault('source_subchapter_slug',str(explicit_slug).strip())
                    explicit_path=it.get('source_subchapter_path') or nested_item_meta.get('source_subchapter_path') or nested_item_meta.get('subchapter_path')
                    if explicit_path: md.setdefault('source_subchapter_path',str(explicit_path).strip())
                source_meta=manifests.get(manifest_folder or _nearest_archive_folder(folder,manifests) or '',{})
                if source_meta:
                    md.setdefault('source_chapter_title',source_meta.get('title',''))
                    md.setdefault('source_chapter_slug',source_meta.get('slug',''))
                if subchapter_meta:
                    md.setdefault('source_subchapter_title',subchapter_meta.get('subchapter_title') or subchapter_meta.get('title',''))
                    md.setdefault('source_subchapter_slug',subchapter_meta.get('slug',''))
                    md.setdefault('source_subchapter_path',subchapter_meta.get('path',subchapter_folder))
                if kind=='flashcard': md.update({'front':it.get('front') or it.get('question') or title,'back':it.get('back') or it.get('answer') or content}); content=md['back']; summary=md['back']
                if kind=='question':
                    # Save answer-key information for future validation, but flag templated source banks for human review.
                    md['options']=it.get('options',[]); keymap=answers.get(manifest_folder or '',{}) or answers.get('.',{})
                    key=keymap.get(str(it.get('id') or '')) or keymap.get(str(it.get('uid') or '')) or keymap.get(str(it.get('source_uid') or ''))
                    if key:
                        md['candidate_correct_index']=key.get('correct_index')
                        md['answer_key_explanation']=key.get('explain_fa') or key.get('explanation') or ''
                    md['explanation']=it.get('explanation') or it.get('explain_fa') or ''
                uid=it.get('uid') or it.get('id') or item_hash(cid,kind,str(title),str(content),path)
                declared_status=str(it.get('source_status') or (manifests.get(manifest_folder or '',{}).get('status') or 'review_required'))
                if declared_status != 'review_required': md.setdefault('imported_declared_status',declared_status)
                # Treat every external chapter pack as an unreviewed proposal regardless of its manifest.
                src_status='review_required'
                added=add_item(conn,cid,kind,str(title),str(summary),str(content),src_status,path,str(uid),md)
                if added:
                    k={'lesson':'lessons','question':'questions','example':'examples','command':'commands','lab':'labs','flashcard':'cards','note':'notes'}.get(kind,'skipped'); stats[k]+=1
                    stats['needs_review']+=1
                else: stats['skipped']+=1
            stats['files_seen']+=1
            continue
        if is_chapter_readme or is_subchapter_readme or (Path(name).suffix.lower() in TEXT_TYPES and manifest_folder is None):
            try: rawf=zf.read(info)
            except Exception: continue
            ext=Path(name).suffix.lower()
            if ext in TEXT_TYPES:
                text=rawf.decode('utf-8-sig',errors='replace')
                # Chapter/subchapter readmes become notes attached to the owning chapter.
                if is_chapter_readme or is_subchapter_readme:
                    title=infer_title(name,text) or (subchapter_meta.get('subchapter_title') if is_subchapter_readme else '') or 'راهنمای فصل'
                    md={'format':'markdown'}
                    if is_subchapter_readme:
                        md.update({'source_subchapter_title':subchapter_meta.get('subchapter_title') or subchapter_meta.get('title',''),
                                   'source_subchapter_slug':subchapter_meta.get('slug',''),
                                   'source_subchapter_path':subchapter_meta.get('path',subchapter_folder)})
                    added=add_item(conn,cid,'note',title,'نمای کلی منبع فصل' if is_chapter_readme else 'راهنمای زیر‌فصل',text,'review_required',path,'readme:'+hashlib.sha1(path.encode()).hexdigest(),md)
                    if not added: stats['skipped']+=1
                    else: stats['notes']+=1; stats['needs_review']+=1
                elif name.lower() not in {'readme.md','readme_fa.md'}:
                    counts=add_regular_file(conn,name,rawf,cid,path,'review_required',target_topic_id)
                    for k,v in counts.items(): stats[k]=stats.get(k,0)+v
                stats['files_seen']+=1
            continue
        ext=Path(name).suffix.lower()
        if ext in SUPPORTED_IMAGE:
            rawf=zf.read(info)
            try: counts=add_regular_file(conn,path,rawf,cid,path,'review_required',target_topic_id)
            except Exception as e: stats['errors'].append(f'{path}: {str(e)[:200]}'); stats['files_seen']+=1; continue
            for k,v in counts.items(): stats[k]=stats.get(k,0)+v
            stats['files_seen']+=1; continue
        # Accept user documents inside ZIP; ignore executable/source files for safety.
        if ext in {'.docx','.pdf','.md','.markdown','.txt','.rst','.log','.conf','.cfg','.yaml','.yml','.ini','.csv'}:
            if name.lower().startswith('readme'): continue
            rawf=zf.read(info); counts=add_regular_file(conn,name,rawf,cid,path,'review_required',target_topic_id)
            for k,v in counts.items(): stats[k]=stats.get(k,0)+v
            stats['files_seen']+=1
    return stats

@app.post('/api/import')
async def import_files(files: list[UploadFile]=File(...), target_chapter: str=Form(''), mode: str=Form('auto'), target_topic_id: str=Form('')):
    if mode not in {'auto','selected'}: mode='auto'
    with connect() as c:
        if target_topic_id and not _import_topic_exists(c,target_topic_id): raise HTTPException(400,'موضوع مقصد معتبر نیست؛ لطفاً موضوع را دوباره انتخاب کن.')
        target_valid=bool(target_chapter and c.execute('SELECT 1 FROM chapters WHERE id=?',(target_chapter,)).fetchone())
        if mode=='selected' and not target_valid: raise HTTPException(400,'در حالت «فصل انتخاب‌شده»، ابتدا فصل مقصد معتبر را انتخاب کن.')
        if mode=='selected' and target_topic_id:
            assigned=c.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(target_chapter,)).fetchone()
            if assigned and str(assigned['topic_id'])!=target_topic_id: raise HTTPException(400,'فصل مقصد به موضوع دیگری متصل است. موضوع/فصل مقصد را هماهنگ کن.')
        aggregate={'files_received':0,'files_seen':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'assets':0,'skipped':0,'chapters_created':0,'topics_created':0,'needs_review':0,'topic_assignments':0,'rolled_back_files':0,'errors':[]}
        files=sorted(files,key=lambda up: 0 if Path(safe_name(up.filename or 'upload')).suffix.lower() in SUPPORTED_IMAGE else 1)
        for index,up in enumerate(files,1):
            aggregate['files_received']+=1
            name=safe_name(up.filename or 'upload')
            raw=await up.read()
            if len(raw)>MAX_FILE_BYTES:
                aggregate['errors'].append(f'{name}: حجم فایل از حد ۱۵۰ مگابایت بیشتر است.'); continue
            savepoint=f'import_file_{index}'
            c.execute(f'SAVEPOINT {savepoint}')
            try:
                if Path(name).suffix.lower()=='.zip':
                    stats=import_zip(c,raw,name,target_chapter,mode,target_topic_id)
                else:
                    parsed=None; is_unified=False
                    if Path(name).suffix.lower()=='.json':
                        parsed=get_json(raw)
                        is_unified=isinstance(parsed,dict) and parsed.get('format') in {'network-learning-pack-v1','network-learning-content-pack-v1','network-learning-content-pack-v2','network-learning-content-export-v1','network-learning-selected-content-v1','network-learning-backup-v1'}
                    destination=target_chapter if mode=='selected' and target_valid else ''
                    # Auto mode must never reuse a chapter selected earlier in the UI.
                    if not is_unified and mode=='auto':
                        inferred=infer_title(name,raw.decode('utf-8-sig',errors='replace')) if Path(name).suffix.lower() in TEXT_TYPES else Path(name).stem.replace('_',' ').replace('-',' ')
                        destination=_ensure_scoped_import_chapter(c,inferred or Path(name).stem,target_topic_id,'single-file|'+name+'|'+hashlib.sha256(raw).hexdigest())
                    if isinstance(parsed,dict) and parsed.get('format')=='network-learning-backup-v1':
                        raise ValueError('این فایل پشتیبان کامل است؛ آن را از «تنظیمات ← بازیابی کامل» بازیابی کن، نه به‌عنوان محتوای فصل.')
                    stats=add_regular_file(c,name,raw,destination,name,'user',target_topic_id) if not (is_unified and isinstance(parsed,dict) and parsed.get('format') in {'network-learning-pack-v1','network-learning-content-pack-v1','network-learning-content-pack-v2','network-learning-content-export-v1','network-learning-selected-content-v1'}) else _import_unified_pack(c,parsed,name,destination,target_topic_id)
                    if not destination and not is_unified: raise ValueError('مقصد فصل مشخص نشد؛ ابتدا موضوع/فصل بساز یا حالت فصل انتخاب‌شده را انتخاب کن.')
                    if destination and target_topic_id and _import_topic_exists(c,target_topic_id): _safe_assign_import_topic(c,destination,target_topic_id,only_if_unassigned=True)
                    stats['files_seen']=1
                file_errors=list(stats.get('errors') or []) if isinstance(stats,dict) else []
                if file_errors:
                    c.execute(f'ROLLBACK TO SAVEPOINT {savepoint}')
                    c.execute(f'RELEASE SAVEPOINT {savepoint}')
                    aggregate['rolled_back_files']+=1
                    aggregate['errors'].extend([f'{name}: {str(x)[:260]}' for x in file_errors])
                    aggregate['skipped']+=int(stats.get('skipped',0) or 0)
                    continue
                c.execute(f'RELEASE SAVEPOINT {savepoint}')
                for k,v in stats.items():
                    if k=='errors': continue
                    elif isinstance(v,int): aggregate[k]=aggregate.get(k,0)+v
            except Exception as e:
                c.execute(f'ROLLBACK TO SAVEPOINT {savepoint}')
                c.execute(f'RELEASE SAVEPOINT {savepoint}')
                aggregate['rolled_back_files']+=1
                aggregate['errors'].append(f'{name}: واردسازی این فایل لغو شد و هیچ تغییر آن ثبت نشد: {str(e)[:240]}')
        c.commit()
    return {'ok':not bool(aggregate['errors']),'summary':aggregate}

def _normalize_import_label(value: str) -> str:
    value=str(value or '').casefold().replace('\u200c','').replace('\u200f','').replace('\u200e','')
    return re.sub(r'[^\w\u0600-\u06ff]+','',value)


@app.get('/api/import/audit')
def audit_import_placement(limit:int=1000):
    # Read-only heuristic scan; never changes imported records.
    limit=max(1,min(int(limit or 1000),5000))
    with connect() as c:
        rows=c.execute('''SELECT i.id,i.chapter_id,i.kind,i.title,i.source_file,i.source_uid,i.metadata_json,i.created_at,
             ch.title chapter_title,ch.group_name,ch.source chapter_source,t.id topic_id,t.title topic_title
          FROM items i JOIN chapters ch ON ch.id=i.chapter_id
          LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id LEFT JOIN topics t ON t.id=ct.topic_id
          WHERE COALESCE(i.source_file,'')<>'' ORDER BY i.id DESC LIMIT ?''',(limit,)).fetchall()
    groups={}; suspects=[]; recent_items=[]; scanned=0
    bank_names={'lessons.json','questions.json','examples.json','commands.json','labs.json','flashcards.json','cards.json','notes.json'}
    ignored={'answers','assets','images','media','sources','source_archive','authoring','build','windows','android'}
    for row in rows:
        d=dict(row); scanned+=1
        if len(recent_items)<250:
            recent_items.append({'item_id':d['id'],'title':d['title'],'chapter_id':d['chapter_id'],'chapter_title':d['chapter_title'],
                                 'topic_title':d.get('topic_title') or '', 'source_file':d.get('source_file') or '', 'created_at':d.get('created_at') or ''})
        try: md=json.loads(d.get('metadata_json') or '{}')
        except Exception: md={}
        if not isinstance(md,dict): md={}
        src=str(d.get('source_file') or '').replace('\\','/')
        parts=PurePosixPath(src).parts
        expected=str(md.get('source_chapter_title') or '').strip()
        rule=''
        if expected and _normalize_import_label(expected)!=_normalize_import_label(d['chapter_title']):
            rule='عنوان فصل منبع با فصل مقصد متفاوت است'
        elif parts and PurePosixPath(src).name.lower() in bank_names and len(parts)>=2:
            folder=PurePosixPath(src).parent.name
            if folder.lower() not in ignored and _normalize_import_label(folder) and _normalize_import_label(folder) not in _normalize_import_label(d['chapter_title']):
                if d.get('group_name')=='main' or str(d.get('chapter_source') or '')=='seed':
                    rule='بانکِ داخل پوشهٔ فصل در فصل اصلی موجود ذخیره شده است (نیازمند بررسی)'
        key=(src,d['chapter_id'],d['chapter_title'],d.get('topic_id') or '',d.get('topic_title') or '')
        if key not in groups:
            groups[key]={'source_file':src,'chapter_id':d['chapter_id'],'chapter_title':d['chapter_title'],'topic_id':d.get('topic_id') or '',
                         'topic_title':d.get('topic_title') or '', 'count':0,'latest_item_id':d['id'],'suspected':False,'reason':''}
        groups[key]['count']+=1
        if rule:
            groups[key]['suspected']=True; groups[key]['reason']=rule
            if len(suspects)<100:
                suspects.append({'item_id':d['id'],'title':d['title'],'source_file':src,'chapter_id':d['chapter_id'],
                                 'chapter_title':d['chapter_title'],'topic_title':d.get('topic_title') or '', 'reason':rule})
    grouped=list(groups.values())
    grouped.sort(key=lambda g:(not g['suspected'],-g['latest_item_id']))
    with connect() as c:
        orphan_rows=c.execute('''SELECT ch.id,ch.title,COUNT(i.id) item_count FROM chapters ch
          LEFT JOIN chapter_topics ct ON ct.chapter_id=ch.id LEFT JOIN items i ON i.chapter_id=ch.id
          WHERE ct.chapter_id IS NULL GROUP BY ch.id HAVING COUNT(i.id)>0 ORDER BY item_count DESC,ch.title LIMIT 100''').fetchall()
        repair_chapters=c.execute('SELECT id,title FROM chapters ORDER BY order_num,title').fetchall()
    return {'ok':True,'read_only':True,'scanned_items':scanned,'groups':grouped[:250],'suspected_misroutes':suspects,'recent_source_items':recent_items,
            'unassigned_chapters':[dict(r) for r in orphan_rows], 'chapters_for_repair':[dict(r) for r in repair_chapters],
            'note':'این گزارش فقط نشانه‌های احتمالی را پیدا می‌کند؛ تطبیق پوشه و عنوان تشخیص قطعی نیست و هیچ داده‌ای را تغییر نمی‌دهد.'}


def _prepare_import_repair(data, conn):
    if not isinstance(data,dict): raise HTTPException(400,'بدنهٔ درخواست معتبر نیست.')
    raw_ids=data.get('item_ids')
    target=str(data.get('target_chapter_id') or '').strip()
    if not isinstance(raw_ids,list) or not raw_ids: raise HTTPException(400,'حداقل یک رکورد را انتخاب کن.')
    if len(raw_ids)>500: raise HTTPException(400,'در هر بار حداکثر ۵۰۰ رکورد را می‌توان منتقل کرد.')
    try: ids=list(dict.fromkeys(int(x) for x in raw_ids if int(x)>0))
    except Exception: raise HTTPException(400,'شناسهٔ رکوردها باید عدد صحیح مثبت باشد.')
    if len(ids)!=len(raw_ids): raise HTTPException(400,'شناسهٔ تکراری یا نامعتبر در فهرست انتخاب‌شده وجود دارد.')
    if not target or not conn.execute('SELECT 1 FROM chapters WHERE id=?',(target,)).fetchone():
        raise HTTPException(400,'فصل مقصد معتبر نیست.')
    marks=','.join('?' for _ in ids)
    rows=[dict(r) for r in conn.execute(f'''SELECT i.id,i.chapter_id,i.source_uid,i.title,i.kind,ch.title chapter_title
                           FROM items i JOIN chapters ch ON ch.id=i.chapter_id
                           WHERE i.id IN ({marks})''',ids).fetchall()]
    if len(rows)!=len(ids): raise HTTPException(404,'یک یا چند رکورد انتخاب‌شده دیگر وجود ندارد؛ ممیزی را تازه کن.')
    moving=[dict(r) for r in rows if str(r['chapter_id'])!=target]
    selected_uids={}
    conflicts=[]
    for row in rows:
        uid=str(row.get('source_uid') or '')
        if not uid: continue
        selected_uids.setdefault(uid,[]).append(row['id'])
        if str(row['chapter_id'])==target: continue
        hit=conn.execute('SELECT id,title FROM items WHERE chapter_id=? AND source_uid=? AND id NOT IN ('+marks+') LIMIT 1',[target,uid,*ids]).fetchone()
        if hit:
            conflicts.append({'source_uid':uid,'item_id':row['id'],'title':row['title'],'conflict_item_id':hit['id'],'conflict_title':hit['title'],'reason':'در فصل مقصد رکوردی با همین source_uid وجود دارد.'})
    for uid,uid_ids in selected_uids.items():
        if len(uid_ids)>1:
            conflicts.append({'source_uid':uid,'item_ids':uid_ids,'reason':'چند رکورد انتخاب‌شده source_uid یکسان دارند و در مقصد قابل ثبت هم‌زمان نیستند.'})
    by_source={}
    for row in rows:
        key=(row['chapter_id'],row['chapter_title'])
        by_source[key]=by_source.get(key,0)+1
    return {'target_chapter_id':target,'target_chapter_title':conn.execute('SELECT title FROM chapters WHERE id=?',(target,)).fetchone()['title'],
            'item_ids':ids,'items_found':len(rows),'items_to_move':len(moving),'already_in_target':len(rows)-len(moving),
            'source_chapters':[{'chapter_id':key[0],'chapter_title':key[1],'count':count} for key,count in by_source.items()],
            'conflicts':conflicts,'ready':bool(moving) and not conflicts,'read_only':True}


@app.post('/api/import/audit/repair-preview')
async def preview_import_repair(request: Request):
    try: data=await request.json()
    except Exception: raise HTTPException(400,'بدنه باید JSON معتبر باشد.')
    with connect() as c:
        plan=_prepare_import_repair(data,c)
    return plan


@app.post('/api/import/audit/repair')
async def apply_import_repair(request: Request):
    try: data=await request.json()
    except Exception: raise HTTPException(400,'بدنه باید JSON معتبر باشد.')
    if data.get('confirm') is not True: raise HTTPException(400,'برای اعمال انتقال، تأیید صریح لازم است.')
    import sqlite3 as _sqlite3
    with connect() as c:
        plan=_prepare_import_repair(data,c)
        if not plan['ready']:
            raise HTTPException(409,{'message':'انتقال قابل اجرا نیست؛ تعارض‌ها را برطرف کن یا مقصد دیگری انتخاب کن.','plan':plan})
        backup_dir=DATA/'backups'; backup_dir.mkdir(exist_ok=True)
        snapshot=backup_dir/f"pre-import-repair-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.sqlite"
        try:
            dst=_sqlite3.connect(snapshot)
            c.backup(dst); dst.close()
        except Exception as e:
            try: dst.close()
            except Exception: pass
            try: snapshot.unlink(missing_ok=True)
            except Exception: pass
            raise HTTPException(500,f'ساخت Snapshot پیش از انتقال ناموفق بود؛ هیچ رکوردی منتقل نشد: {str(e)[:180]}')
        moved=0; stamp=now_iso()
        try:
            c.execute('SAVEPOINT manual_import_repair')
            for item_id in plan['item_ids']:
                row=c.execute('SELECT chapter_id,metadata_json FROM items WHERE id=?',(item_id,)).fetchone()
                if not row or str(row['chapter_id'])==plan['target_chapter_id']: continue
                try: md=json.loads(row['metadata_json'] or '{}')
                except Exception: md={}
                if not isinstance(md,dict): md={}
                md['last_manual_move']={'from_chapter_id':str(row['chapter_id']),'to_chapter_id':plan['target_chapter_id'],'at':stamp,'reason':'explicitly confirmed after import audit'}
                c.execute('UPDATE items SET chapter_id=?,metadata_json=? WHERE id=?',(plan['target_chapter_id'],json.dumps(md,ensure_ascii=False),item_id))
                moved+=1
            c.execute('RELEASE SAVEPOINT manual_import_repair')
            c.commit()
        except Exception as e:
            try: c.execute('ROLLBACK TO SAVEPOINT manual_import_repair'); c.execute('RELEASE SAVEPOINT manual_import_repair'); c.rollback()
            except Exception: pass
            raise HTTPException(409,f'انتقال به‌طور کامل لغو شد؛ هیچ جابه‌جایی نیمه‌کاره‌ای ثبت نشد. خطا: {str(e)[:180]}')
    return {'ok':True,'moved':moved,'target_chapter_id':plan['target_chapter_id'],'target_chapter_title':plan['target_chapter_title'],
            'snapshot':snapshot.name,'progress_and_review_history_preserved':True,
            'note':'شناسهٔ رکوردها و جدول پیشرفت/تاریخچه حفظ شد؛ انتقال فقط برای موارد انتخاب‌شده انجام شد.'}


@app.get('/media/{filename:path}')
def media_file(filename:str):
    # Support nested paths for portable backups and future Android sync while preventing traversal.
    raw=str(filename or '').replace('\\','/')
    rel=PurePosixPath(raw)
    if not raw or rel.is_absolute() or '..' in rel.parts or any(part in {'', '.'} for part in rel.parts):
        raise HTTPException(404,'رسانه پیدا نشد')
    path=(MEDIA.joinpath(*rel.parts)).resolve()
    base=MEDIA.resolve()
    if (path != base and base not in path.parents) or not path.exists() or not path.is_file():
        raise HTTPException(404,'رسانه پیدا نشد')
    return FileResponse(path, media_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')


# --- Content workflow, chapter export, planning and time tracking (v0.4) ---
CONTENT_STATUSES = {'review_required','content_enriched','verified','needs_revision','rejected'}
CONTENT_LEVELS = {'beginner','intermediate','advanced','expert'}
CONTENT_KINDS = {'lesson','flashcard','question','command','lab','example','note','asset'}


def content_manager_row(row):
    d = dict(row)
    try: d['metadata'] = json.loads(d.pop('metadata_json', '{}') or '{}')
    except Exception: d['metadata'] = {}
    d['difficulty'] = d['metadata'].get('difficulty') or d['metadata'].get('level') or 'intermediate'
    d['source_status_label'] = {
        'review_required':'در انتظار تأیید', 'content_enriched':'تکمیل‌شده؛ نیازمند تأیید',
        'verified':'تأییدشده', 'needs_revision':'نیازمند اصلاح', 'rejected':'ردشده', 'demo':'نمونهٔ نمایشی'
    }.get(d.get('source_status'), d.get('source_status',''))
    return d


@app.get('/api/management/item/{item_id}')
def management_item_detail(item_id:int):
    # Return full content metadata to the authenticated single-user content manager.
    with connect() as c:
        row=c.execute('SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.id=?',(item_id,)).fetchone()
    if not row: raise HTTPException(404,'محتوا پیدا نشد')
    d=dict(row)
    try: d['metadata']=json.loads(d.pop('metadata_json') or '{}')
    except Exception: d['metadata']={}
    d['difficulty']=d['metadata'].get('difficulty') or d['metadata'].get('level') or 'intermediate'
    return d


@app.get('/api/content/summary')
def content_summary(topic_id: str = ''):
    topic_id=str(topic_id or '').strip()
    scoped=" AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=items.chapter_id AND ct.topic_id=?)" if topic_id else ''
    args=[topic_id] if topic_id else []
    with connect() as c:
        statuses = {r['source_status']: r['n'] for r in c.execute('SELECT source_status, COUNT(*) n FROM items WHERE 1=1'+scoped+' GROUP BY source_status',args)}
        levels = {}
        rows = c.execute("SELECT metadata_json FROM items WHERE kind<>'asset'"+scoped,args).fetchall()
        for row in rows:
            try: md=json.loads(row['metadata_json'] or '{}')
            except Exception: md={}
            lv=md.get('difficulty') or md.get('level') or 'بدون سطح'
            levels[lv]=levels.get(lv,0)+1
        by_kind = {r['kind']: r['n'] for r in c.execute('SELECT kind,COUNT(*) n FROM items WHERE 1=1'+scoped+' GROUP BY kind',args)}
    return {'statuses':statuses,'levels':levels,'by_kind':by_kind,'topic_id':topic_id}


@app.get('/api/management/items')
def management_items(chapter_id:str='', chapter_ids:str='', kind:str='', status:str='', level:str='', q:str='', limit:int=300, offset:int=0, topic_id:str=''):
    limit=max(1,min(limit,1000)); offset=max(0,offset)
    sql='''SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE 1=1'''
    args=[]
    if topic_id: sql+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; args.append(topic_id)
    selected_chapters=[x for x in (chapter_ids or '').split(',') if x]
    if selected_chapters:
        sql+=' AND i.chapter_id IN ('+','.join('?' for _ in selected_chapters)+')'; args.extend(selected_chapters)
    elif chapter_id: sql+=' AND i.chapter_id=?'; args.append(chapter_id)
    if kind and kind!='all': sql+=' AND i.kind=?'; args.append(kind)
    if status=='pending':
        sql+=" AND i.source_status IN ('review_required','content_enriched','needs_revision')"
    elif status and status!='all':
        sql+=' AND i.source_status=?'; args.append(status)
    if q:
        pat=f'%{q[:160]}%'; sql+=' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.source_file LIKE ?)'; args.extend([pat,pat,pat,pat])
    sql+=' ORDER BY ch.order_num, ch.title COLLATE NATURAL_NOCASE, ch.id, CASE i.kind WHEN "lesson" THEN 0 WHEN "flashcard" THEN 1 WHEN "question" THEN 2 WHEN "note" THEN 3 WHEN "example" THEN 4 WHEN "lab" THEN 5 WHEN "command" THEN 6 ELSE 7 END, chapter_content_seq(i.kind,i.source_uid,i.title,i.metadata_json,i.id), i.id ASC'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    filtered=[]
    for row in rows:
        item=content_manager_row(row)
        if level and level!='all' and item.get('difficulty')!=level: continue
        filtered.append(item)
    total=len(filtered)
    page=filtered[offset:offset+limit]
    return {'items':page,'count':len(page),'total_count':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


class ItemUpdate(BaseModel):
    title: Optional[str] = None
    kind: Optional[str] = None
    summary: Optional[str] = None
    content: Optional[str] = None
    source_status: Optional[str] = None
    chapter_id: Optional[str] = None
    metadata: Optional[dict] = None
    difficulty: Optional[str] = None


@app.put('/api/item/{item_id}')
def update_item(item_id:int, payload:ItemUpdate):
    data = payload.dict(exclude_unset=True)
    if not data: return {'ok':True,'changed':0}
    with connect() as c:
        row=c.execute('SELECT * FROM items WHERE id=?',(item_id,)).fetchone()
        if not row: raise HTTPException(404,'محتوا پیدا نشد')
        # Preserve the previous version before applying edits, so accidental overwrites are reversible.
        if any(k in data for k in ('title','kind','summary','content','source_status','metadata','difficulty','chapter_id')):
            c.execute('INSERT INTO item_revisions(item_id,changed_at,title,summary,content,source_status,metadata_json,change_reason) VALUES(?,?,?,?,?,?,?,?)',
              (item_id,now_iso(),row['title'],row['summary'],row['content'],row['source_status'],row['metadata_json'] or '{}','پیش از ویرایش'))
        fields=[]; values=[]
        md=json.loads(row['metadata_json'] or '{}')
        if not isinstance(md, dict): md={}
        if 'metadata' in data and data['metadata'] is not None:
            if not isinstance(data['metadata'], dict): raise HTTPException(400,'ساختار فراداده نامعتبر است')
            md.update(data['metadata'])
        if 'difficulty' in data and data['difficulty'] is not None:
            if data['difficulty'] not in CONTENT_LEVELS: raise HTTPException(400,'سطح محتوا نامعتبر است')
            md['difficulty']=data['difficulty']
        new_kind = str(data.get('kind') or row['kind'])
        new_status = str(data.get('source_status') or row['source_status'])
        if new_kind not in CONTENT_KINDS: raise HTTPException(400,'نوع محتوا نامعتبر است')
        if new_status not in CONTENT_STATUSES | {'demo','user'}: raise HTTPException(400,'وضعیت محتوا نامعتبر است')
        if new_status == 'verified' and new_kind == 'question':
            opts=md.get('options'); key=md.get('correct_index')
            if not isinstance(opts,list) or len(opts)<2 or any(not str(x or '').strip() for x in opts):
                raise HTTPException(400,'برای تأیید سؤال، دست‌کم دو گزینهٔ کامل لازم است')
            if isinstance(key,bool) or not isinstance(key,int) or not (0 <= key < len(opts)):
                raise HTTPException(400,'برای تأیید سؤال، کلید پاسخ معتبر لازم است')
        if new_status == 'verified' and new_kind == 'flashcard':
            if not str(md.get('front') or data.get('title') or row['title']).strip() or not str(md.get('back') or data.get('content') or data.get('summary') or row['content'] or row['summary']).strip():
                raise HTTPException(400,'برای تأیید فلش‌کارت، روی کارت و پشت کارت هر دو باید کامل باشند')
        for field in ('title','kind','summary','content','source_status','chapter_id'):
            if field in data:
                value=data[field]
                if field=='title' and not str(value or '').strip(): raise HTTPException(400,'عنوان خالی نمی‌تواند باشد')
                if field=='chapter_id' and not c.execute('SELECT 1 FROM chapters WHERE id=?',(value,)).fetchone(): raise HTTPException(404,'فصل مقصد پیدا نشد')
                fields.append(f'{field}=?'); values.append(value.strip() if field in {'title','kind'} else value)
        if 'metadata' in data or 'difficulty' in data or (new_status == 'verified' and new_kind in {'question','flashcard'}):
            fields.append('metadata_json=?'); values.append(json.dumps(md,ensure_ascii=False))
        if fields:
            values.append(item_id); c.execute(f"UPDATE items SET {','.join(fields)} WHERE id=?",values)
        c.commit()
    return {'ok':True,'changed':len(fields)}


@app.delete('/api/item/{item_id}')
def delete_item(item_id: int):
    with connect() as c:
        row=c.execute('SELECT id,title FROM items WHERE id=?',(item_id,)).fetchone()
        if not row: raise HTTPException(404,'محتوا پیدا نشد')
        c.execute('DELETE FROM items WHERE id=?',(item_id,))
        c.commit()
    return {'ok':True,'id':item_id,'title':row['title']}


@app.get('/api/item/{item_id}/neighbors')
def item_neighbors(item_id: int):
    with connect() as c:
        current=c.execute('SELECT * FROM items WHERE id=?',(item_id,)).fetchone()
        if not current: raise HTTPException(404,'محتوا پیدا نشد')
        rows=c.execute("SELECT * FROM items WHERE chapter_id=? AND kind<>'asset'",(current['chapter_id'],)).fetchall()
    ordered=sorted(rows,key=_chapter_content_sort_key)
    index=next((i for i,row in enumerate(ordered) if int(row['id'])==item_id),-1)
    def brief(row):
        if not row: return None
        return {'id':int(row['id']),'title':row['title'],'kind':row['kind'],'source_status':row['source_status']}
    prev=ordered[index-1] if index>0 else None
    nxt=ordered[index+1] if 0<=index<len(ordered)-1 else None
    return {'current_id':item_id,'previous':brief(prev),'next':brief(nxt),'position':index+1 if index>=0 else None,'total':len(ordered)}


@app.get('/api/item/{item_id}/revisions')
def list_item_revisions(item_id:int):
    with connect() as c:
        if not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'محتوا پیدا نشد')
        rows=c.execute('SELECT id,item_id,changed_at,title,summary,source_status,change_reason FROM item_revisions WHERE item_id=? ORDER BY id DESC LIMIT 50',(item_id,)).fetchall()
    return {'revisions':[dict(r) for r in rows]}


@app.post('/api/item/{item_id}/restore-revision/{revision_id}')
def restore_item_revision(item_id:int,revision_id:int):
    with connect() as c:
        current=c.execute('SELECT * FROM items WHERE id=?',(item_id,)).fetchone()
        rev=c.execute('SELECT * FROM item_revisions WHERE id=? AND item_id=?',(revision_id,item_id)).fetchone()
        if not current or not rev: raise HTTPException(404,'محتوا یا نسخه پیدا نشد')
        c.execute('INSERT INTO item_revisions(item_id,changed_at,title,summary,content,source_status,metadata_json,change_reason) VALUES(?,?,?,?,?,?,?,?)',
          (item_id,now_iso(),current['title'],current['summary'],current['content'],current['source_status'],current['metadata_json'] or '{}','پیش از بازیابی نسخه'))
        c.execute('UPDATE items SET title=?,summary=?,content=?,source_status=?,metadata_json=? WHERE id=?',
          (rev['title'],rev['summary'],rev['content'],rev['source_status'],rev['metadata_json'],item_id))
        c.commit()
    return {'ok':True,'restored_revision_id':revision_id}


class BulkItemsIn(BaseModel):
    ids: list[int]
    action: str
    value: Optional[str] = None
    target_chapter: Optional[str] = None


@app.post('/api/items/bulk')
def bulk_items(payload:BulkItemsIn):
    ids=list(dict.fromkeys(int(x) for x in payload.ids if int(x)>0))[:2000]
    if not ids: raise HTTPException(400,'ابتدا محتوا انتخاب کن')
    action=payload.action
    if action not in {'status','level','make_cards','duplicate','delete'}: raise HTTPException(400,'عملیات گروهی نامعتبر است')
    if action=='status' and payload.value not in CONTENT_STATUSES: raise HTTPException(400,'وضعیت نامعتبر است')
    if action=='level' and payload.value not in CONTENT_LEVELS: raise HTTPException(400,'سطح نامعتبر است')
    changed=0; skipped=0; unchanged=0; created=[]; changed_ids=[]; unchanged_ids=[]; skipped_details=[]; promoted_answer_keys=0
    with connect() as c:
        before_statuses={r['source_status']:r['n'] for r in c.execute('SELECT source_status,COUNT(*) n FROM items GROUP BY source_status')}
        placeholders=','.join('?' for _ in ids)
        rows=c.execute(f'SELECT * FROM items WHERE id IN ({placeholders}) ORDER BY id',ids).fetchall()
        matched_ids={int(r['id']) for r in rows}
        missing_ids=[item_id for item_id in ids if item_id not in matched_ids]
        if action=='delete':
            c.execute(f'DELETE FROM items WHERE id IN ({placeholders})',ids); changed=c.rowcount
            changed_ids=[int(r['id']) for r in rows]
        else:
            for row in rows:
                try: md=json.loads(row['metadata_json'] or '{}')
                except Exception: md={}
                if not isinstance(md,dict): md={}
                if action=='status':
                    target=payload.value
                    if row['source_status']==target:
                        unchanged+=1; unchanged_ids.append(int(row['id']))
                        continue
                    if target=='verified' and row['kind']=='question':
                        opts=md.get('options')
                        if not isinstance(opts,list) or len(opts)<2 or any(not str(o or '').strip() for o in opts):
                            skipped+=1; skipped_details.append({'id':row['id'],'title':row['title'],'reason':'گزینه‌های سؤال ناقص است یا کمتر از دو گزینه دارد.'}); continue
                        def answer_index(value):
                            if isinstance(value,bool) or value is None: return None
                            if isinstance(value,int): return value
                            if isinstance(value,float) and value.is_integer(): return int(value)
                            normalized=_fa_to_ascii_digits(str(value)).strip()
                            if re.fullmatch(r'\d{1,4}',normalized): return int(normalized)
                            # Accept A/B/C/D/E key notation only when it maps unambiguously
                            # to a zero-based option index. Do not infer from ambiguous prose.
                            if re.fullmatch(r'[A-Ea-e]',normalized): return ord(normalized.upper())-ord('A')
                            return None
                        key=answer_index(md.get('correct_index'))
                        if key is None or not (0<=key<len(opts)):
                            candidate=None
                            candidate_names=(
                                'candidate_correct_index','answer_key_correct_index','candidate_answer_index',
                                'answer_index','correct_answer_index','correct_option_index','correct_option',
                                'correct_letter','answer_letter','answer_key','correct_answer','answer'
                            )
                            # Some exported packs store a whole answer-key object instead of a scalar.
                            candidates=[]
                            for candidate_name in candidate_names:
                                value=md.get(candidate_name)
                                if isinstance(value,dict):
                                    for nested_name in ('correct_index','answer_index','index','correct_option_index','correct_option','letter','answer','value'):
                                        if nested_name in value: candidates.append(value[nested_name])
                                elif value is not None:
                                    candidates.append(value)
                            option_strings=[str(o or '').strip() for o in opts]
                            for raw_candidate in candidates:
                                candidate=answer_index(raw_candidate)
                                if candidate is not None and 0<=candidate<len(opts): break
                                candidate=None
                                # An exact, unique answer-text match is safe; fuzzy matching is not.
                                answer_text=str(raw_candidate or '').strip()
                                matches=[idx for idx,text_value in enumerate(option_strings) if answer_text and text_value.casefold()==answer_text.casefold()]
                                if len(matches)==1:
                                    candidate=matches[0]; break
                            if candidate is None:
                                skipped+=1; skipped_details.append({'id':row['id'],'title':row['title'],'reason':'کلید پاسخ معتبر پیدا نشد؛ شماره، حرف گزینه و متن دقیق گزینه بررسی شدند.'}); continue
                            md['correct_index']=candidate
                            if not (md.get('explanation') or '').strip() and md.get('answer_key_explanation'):
                                md['explanation']=md['answer_key_explanation']
                            c.execute('UPDATE items SET metadata_json=? WHERE id=?',(json.dumps(md,ensure_ascii=False),row['id']))
                            promoted_answer_keys+=1
                    if target=='verified' and row['kind']=='flashcard':
                        front=md.get('front') or row['title']; back=md.get('back') or row['content'] or row['summary']
                        if not str(front or '').strip() or not str(back or '').strip():
                            skipped+=1; skipped_details.append({'id':row['id'],'title':row['title'],'reason':'روی کارت یا پشت کارت خالی است.'}); continue
                    c.execute('UPDATE items SET source_status=? WHERE id=?',(target,row['id'])); changed+=1; changed_ids.append(int(row['id']))
                elif action=='level':
                    md['difficulty']=payload.value
                    c.execute('UPDATE items SET metadata_json=? WHERE id=?',(json.dumps(md,ensure_ascii=False),row['id'])); changed+=1; changed_ids.append(int(row['id']))
                elif action=='duplicate':
                    newcid=payload.target_chapter or row['chapter_id']
                    if not c.execute('SELECT 1 FROM chapters WHERE id=?',(newcid,)).fetchone(): skipped+=1; continue
                    newuid=f"copy-{row['id']}-{secrets.token_hex(5)}"
                    cur=c.execute('''INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?)''',(newcid,row['kind'],row['title']+' — کپی',row['summary'],row['content'],'content_enriched',row['source_file'],newuid,json.dumps(md,ensure_ascii=False),now_iso()))
                    if row['kind']=='flashcard': c.execute('INSERT OR IGNORE INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
                    created.append(cur.lastrowid); changed+=1; changed_ids.append(int(row['id']))
                elif action=='make_cards':
                    if row['kind'] not in {'lesson','example','lab','note','command'}: skipped+=1; continue
                    back=(row['summary'] or re.sub(r'[#*`|>]+',' ',row['content'] or '').strip())[:1600]
                    if not back: skipped+=1; continue
                    uid=f'bulk-derived-card-{row["id"]}'
                    if c.execute('SELECT 1 FROM items WHERE chapter_id=? AND source_uid=?',(row['chapter_id'],uid)).fetchone(): skipped+=1; continue
                    front=f'نکتهٔ کلیدی: {row["title"]} چیست؟'
                    cardmd={'front':front,'back':back,'difficulty':md.get('difficulty','intermediate'),'derived_from_item_id':row['id']}
                    cur=c.execute('''INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at)
                      VALUES(?,?,?,?,?,?,?,?,?,?)''',(row['chapter_id'],'flashcard',front,back,back,'content_enriched','تولید کارت گروهی',uid,json.dumps(cardmd,ensure_ascii=False),now_iso()))
                    c.execute('INSERT OR IGNORE INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
                    created.append(cur.lastrowid); changed+=1; changed_ids.append(int(row['id']))
        c.commit()
        after_statuses={r['source_status']:r['n'] for r in c.execute('SELECT source_status,COUNT(*) n FROM items GROUP BY source_status')}
    status_delta={key:after_statuses.get(key,0)-before_statuses.get(key,0) for key in set(before_statuses)|set(after_statuses)}
    return {'ok':True,'requested':len(ids),'matched':len(rows),'missing':len(missing_ids),'missing_ids':missing_ids,
            'changed':changed,'changed_ids':changed_ids[:2000],'unchanged':unchanged,'unchanged_ids':unchanged_ids[:2000],
            'skipped':skipped,'created_ids':created,'skipped_details':skipped_details[:100],
            'promoted_answer_keys':promoted_answer_keys,'status_counts':after_statuses,'status_delta':status_delta}


@app.post('/api/items/export-selected')
def export_selected_items(payload:BulkItemsIn):
    ids=list(dict.fromkeys(int(x) for x in payload.ids if int(x)>0))[:2000]
    if not ids: raise HTTPException(400,'محتوایی انتخاب نشده است')
    with connect() as c:
        marks=','.join('?' for _ in ids)
        rows=c.execute(f'SELECT * FROM items WHERE id IN ({marks}) ORDER BY chapter_id,kind,id',ids).fetchall()
        chapters={r['id']:dict(r) for r in c.execute(f'SELECT * FROM chapters WHERE id IN (SELECT DISTINCT chapter_id FROM items WHERE id IN ({marks}))',ids).fetchall()}
    items=[]
    for r in rows:
        d=dict(r); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); items.append(d)
    return {'format':'network-learning-selected-content-v1','exported_at':now_iso(),'chapters':list(chapters.values()),'items':items}


@app.get('/api/content/export')
def export_content(chapter_id:str='', chapter_ids:str='', kind:str='', status:str='', level:str='', q:str=''):
    sql='''SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE 1=1'''
    args=[]
    selected_chapters=[x for x in (chapter_ids or '').split(',') if x]
    if selected_chapters:
        sql+=' AND i.chapter_id IN ('+','.join('?' for _ in selected_chapters)+')'; args.extend(selected_chapters)
    elif chapter_id: sql+=' AND i.chapter_id=?'; args.append(chapter_id)
    if kind and kind!='all': sql+=' AND i.kind=?'; args.append(kind)
    if status and status!='all': sql+=' AND i.source_status=?'; args.append(status)
    if q:
        pat=f'%{q[:120]}%'; sql+=' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ?)'; args.extend([pat,pat,pat])
    sql+=' ORDER BY i.chapter_id,i.kind,i.id'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    if level and level!='all':
        filtered=[]
        for row in rows:
            try: md=json.loads(row['metadata_json'] or '{}')
            except Exception: md={}
            if (md.get('difficulty') or md.get('level') or 'intermediate')==level: filtered.append(row)
        rows=filtered
    items=[]; chapters={}
    for row in rows:
        d=dict(row); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); items.append(d)
        if row['chapter_id'] not in chapters:
            with connect() as c2: ch=c2.execute('SELECT * FROM chapters WHERE id=?',(row['chapter_id'],)).fetchone()
            if ch: chapters[row['chapter_id']]=dict(ch)
    payload=json.dumps({'format':'network-learning-content-export-v1','exported_at':now_iso(),'chapters':list(chapters.values()),'items':items},ensure_ascii=False,indent=2).encode('utf-8')
    suffix='-'.join([chapter_id or 'all-chapters',kind or 'all-content',status or 'all-status'])[:80]
    return Response(payload,media_type='application/json; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="content-{suffix}.json"'})


@app.get('/api/item/{item_id}/export')
def export_item(item_id:int):
    with connect() as c:
        row=c.execute('SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.id=?',(item_id,)).fetchone()
    if not row: raise HTTPException(404,'محتوا پیدا نشد')
    d=dict(row); d['metadata']=json.loads(d.pop('metadata_json') or '{}')
    payload=json.dumps({'format':'network-learning-item-v1','item':d},ensure_ascii=False,indent=2).encode('utf-8')
    return Response(payload,media_type='application/json; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="item-{item_id}.json"'})


def chapter_bank_item(row):
    d=dict(row); md=json.loads(d.pop('metadata_json') or '{}')
    uid=d.get('source_uid') or f'item-{d["id"]}'
    common={'uid':uid,'source_status':d['source_status'],'difficulty':md.get('difficulty') or md.get('level') or 'intermediate',**md}
    if d['kind']=='lesson': return {**common,'title_fa':d['title'],'summary_fa':d['summary'],'full_content':d['content'],'estimated_minutes':md.get('estimated_minutes',15)}
    if d['kind']=='flashcard': return {**common,'id':uid,'front':md.get('front') or d['title'],'back':md.get('back') or d['content'] or d['summary'],'topic':md.get('topic','')}
    if d['kind']=='question': return {**common,'id':uid,'title_fa':d['title'],'question':md.get('question') or d['title'],'options':md.get('options',[]),'correct_index':md.get('correct_index'),'explanation':md.get('explanation') or d['summary'],'domain':md.get('domain','')}
    if d['kind']=='command': return {**common,'id':uid,'title_fa':d['title'],'command':md.get('command') or d['content'],'content':d['content'],'summary_fa':d['summary'],'platform':md.get('platform',''), 'product_version':md.get('product_version',''), 'when_to_use_fa':md.get('when_to_use_fa',''), 'expected_result_fa':md.get('expected_result_fa',''), 'caution_fa':md.get('caution_fa','')}
    if d['kind']=='lab': return {**common,'id':uid,'title_fa':d['title'],'summary_fa':d['summary'],'full_content':d['content'],'estimated_minutes':md.get('estimated_minutes',30)}
    if d['kind']=='example': return {**common,'id':uid,'title_fa':d['title'],'prompt':md.get('prompt') or d['summary'],'content':d['content']}
    if d['kind']=='note': return {**common,'id':uid,'title_fa':d['title'],'summary_fa':d['summary'],'content':d['content'],'domain':md.get('domain',''),'topic':md.get('topic',''),'focus':md.get('focus','')}
    return None


@app.get('/api/chapter/{chapter_id}/overview')
def chapter_overview(chapter_id:str):
    with connect() as c:
        chapter=c.execute('SELECT * FROM chapters WHERE id=?',(chapter_id,)).fetchone()
        if not chapter: raise HTTPException(404,'فصل پیدا نشد')
        rows=c.execute('SELECT kind,source_status,metadata_json FROM items WHERE chapter_id=?',(chapter_id,)).fetchall()
    statuses={}; kinds={}; levels={}
    for r in rows:
        statuses[r['source_status']]=statuses.get(r['source_status'],0)+1; kinds[r['kind']]=kinds.get(r['kind'],0)+1
        try: md=json.loads(r['metadata_json'] or '{}')
        except Exception: md={}
        level=md.get('difficulty') or md.get('level') or 'بدون سطح'; levels[level]=levels.get(level,0)+1
    return {'chapter':dict(chapter),'total_items':len(rows),'statuses':statuses,'kinds':kinds,'levels':levels}


@app.get('/api/chapter/{chapter_id}/outline')
def chapter_content_outline(chapter_id:str):
    """Return a lightweight, all-status outline so the manager can expand a chapter without downloading full lesson bodies."""
    with connect() as c:
        chapter=c.execute('SELECT id,title,order_num,group_name FROM chapters WHERE id=?',(chapter_id,)).fetchone()
        if not chapter: raise HTTPException(404,'فصل پیدا نشد')
        rows=c.execute("""SELECT id,kind,title,source_status,metadata_json,source_file
            FROM items WHERE chapter_id=?
            ORDER BY CASE kind WHEN 'lesson' THEN 0 WHEN 'flashcard' THEN 1 WHEN 'question' THEN 2 WHEN 'note' THEN 3 WHEN 'example' THEN 4 WHEN 'lab' THEN 5 WHEN 'command' THEN 6 ELSE 7 END,
              chapter_content_seq(kind,source_uid,title,metadata_json,id), id ASC""",(chapter_id,)).fetchall()
    status_labels={'review_required':'در انتظار تأیید','content_enriched':'تکمیل‌شده؛ نیازمند تأیید','verified':'تأییدشده','needs_revision':'نیازمند اصلاح','rejected':'ردشده','demo':'نمونهٔ نمایشی','user':'کاربر'}
    items=[]
    for row in rows:
        try: md=json.loads(row['metadata_json'] or '{}')
        except Exception: md={}
        items.append({'id':int(row['id']),'kind':row['kind'],'title':row['title'],'source_status':row['source_status'],
                      'source_status_label':status_labels.get(row['source_status'],row['source_status'] or ''),
                      'difficulty':md.get('difficulty') or md.get('level') or 'بدون سطح','source_file':row['source_file'] or '',
                      'source_subchapter_title':md.get('source_subchapter_title') or md.get('subchapter_title') or md.get('section_title') or '',
                      'source_subchapter_path':md.get('source_subchapter_path') or md.get('subchapter_path') or '',
                      'source_subchapter_slug':md.get('source_subchapter_slug') or ''})
    return {'chapter':dict(chapter),'total_count':len(items),'items':items}


@app.get('/api/chapter/{chapter_id}/export')
def export_chapter_pack(chapter_id:str):
    with connect() as c:
        chapter=c.execute('SELECT * FROM chapters WHERE id=?',(chapter_id,)).fetchone()
        if not chapter: raise HTTPException(404,'فصل پیدا نشد')
        rows=c.execute('SELECT * FROM items WHERE chapter_id=? ORDER BY id',(chapter_id,)).fetchall()
    ch=dict(chapter); folder=f'ch{int(ch["order_num"]):02d}_{re.sub(r"[^a-zA-Z0-9_-]+","_",ch["title"]).strip("_")[:40] or chapter_id}'
    manifest={'title_fa':ch['title'],'slug':re.sub(r'[^a-z0-9_]+','_',ch['title'].lower()).strip('_') or chapter_id,'chapter_order':ch['order_num'],'source_status':'review_required','description_fa':ch.get('description') or 'بستهٔ صادرشده از دانشنامه؛ وضعیت محتوا برای بازبینی حفظ شده است.'}
    banks={'lessons.json':('network-learning-lessons-v1','lesson'),'questions.json':('network-learning-questions-v1','question'),'flashcards.json':('network-learning-flashcards-v1','flashcard'),'commands.json':('network-learning-commands-v1','command'),'labs.json':('network-learning-labs-v1','lab'),'examples.json':('network-learning-examples-v1','example'),'notes.json':('network-learning-notes-v1','note')}
    payloads={name:{'format':fmt,'items':[]} for name,(fmt,_) in banks.items()}
    for row in rows:
        obj=chapter_bank_item(row)
        if not obj: continue
        for name,(_,kind) in banks.items():
            if row['kind']==kind: payloads[name]['items'].append(obj); break
    all_markdown=['# '+ch['title'],'',f'> صادرشده در {now_iso()}', '', '## فهرست محتوا']
    for row in rows:
        if row['kind'] in {'lesson','note','example','lab','command'}:
            all_markdown += ['', '## '+row['title'], '', row['content'] or row['summary'] or '']
    buf=BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr(f'{folder}/manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        z.writestr(f'{folder}/chapter_reference.md','\n'.join(all_markdown))
        for name,obj in payloads.items(): z.writestr(f'{folder}/{name}',json.dumps(obj,ensure_ascii=False,indent=2))
        for row in rows:
            if row['kind']=='asset':
                try: md=json.loads(row['metadata_json'] or '{}')
                except Exception: md={}
                disk=Path(str(md.get('path') or row['content'])).name
                media=MEDIA/disk
                if media.is_file(): z.writestr(f'{folder}/assets/{safe_name(md.get("file_name") or disk)}',media.read_bytes())
        z.writestr(f'{folder}/README_FA.md','این بسته از داخل دانشنامه صادر شده است. پس از تغییر، پیش از انتشار وضعیت فنی رکوردها را بازبینی کنید.')
    fname=f'chapter-{chapter_id}-content-pack.zip'
    return StreamingResponse(BytesIO(buf.getvalue()),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{fname}"'})


def _extract_preview_subchapters(items):
    """Return unique explicit subsection labels carried by unified-pack item metadata."""
    found=[]; seen=set()
    for it in items if isinstance(items,list) else []:
        if not isinstance(it,dict): continue
        md=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
        title=str(it.get('source_subchapter_title') or it.get('subchapter_title') or it.get('section_title') or
                  md.get('source_subchapter_title') or md.get('subchapter_title') or md.get('section_title') or '').strip()
        if not title: continue
        chapter=str(it.get('chapter_id') or '')
        key=(chapter,title.casefold())
        if key in seen: continue
        seen.add(key)
        found.append({'folder':str(md.get('source_subchapter_path') or md.get('subchapter_path') or ''),
                      'title':title,'slug':str(md.get('source_subchapter_slug') or md.get('subchapter_slug') or ''),
                      'parent_folder':chapter,'chapter_id':chapter})
    return found


@app.post('/api/import/preview')
async def preview_import(files: list[UploadFile]=File(...), mode: str=Form('auto'), target_topic_id: str=Form(''), target_chapter: str=Form('')):
    result={'files_received':0,'total_bytes':0,'files':[],'chapters':[],'subchapters':[],'counts':{'lessons':0,'questions':0,'cards':0,'commands':0,'labs':0,'examples':0,'notes':0,'assets':0,'other':0},'warnings':[],'errors':[],'duplicate_uids':0}
    if mode not in {'auto','selected'}: mode='auto'
    with connect() as c:
        if target_topic_id and not _import_topic_exists(c,target_topic_id): result['errors'].append('موضوع مقصد معتبر نیست؛ لطفاً موضوع را دوباره انتخاب کن.')
        if mode=='selected':
            if not target_chapter or not c.execute('SELECT 1 FROM chapters WHERE id=?',(target_chapter,)).fetchone(): result['errors'].append('در حالت «فصل انتخاب‌شده»، ابتدا فصل مقصد معتبر را انتخاب کن.')
            elif target_topic_id:
                assigned=c.execute('SELECT topic_id FROM chapter_topics WHERE chapter_id=?',(target_chapter,)).fetchone()
                if assigned and str(assigned['topic_id'])!=target_topic_id: result['errors'].append('فصل مقصد به موضوع دیگری متصل است؛ برای جلوگیری از اختلاط، مقصد را هماهنگ کن.')
    seen_uids=set(); manifest_folders=set()
    for up in files:
        result['files_received']+=1; name=safe_name(up.filename or 'upload'); raw=await up.read(); result['total_bytes']+=len(raw)
        if len(raw)>MAX_FILE_BYTES:
            result['errors'].append(f'{name}: از سقف ۱۵۰ مگابایت بیشتر است'); continue
        ext=Path(name).suffix.lower(); file_info={'name':name,'bytes':len(raw),'type':ext or 'بدون پسوند'}
        if ext=='.zip':
            try:
                with zipfile.ZipFile(BytesIO(raw)) as z:
                    infos=[i for i in z.infolist() if not i.is_dir()]
                    if len(infos)>MAX_ZIP_FILES:
                        result['errors'].append(f'{name}: تعداد فایل‌های ZIP از سقف مجاز بیشتر است'); continue
                    file_info['contained_files']=len(infos)
                    if sum(i.file_size for i in infos)>500*1024*1024:
                        result['errors'].append(f'{name}: حجم بازشدهٔ آرشیو بیش از ۵۰۰ مگابایت است'); continue
                    found=[]
                    unified_info=next((i for i in infos if PurePosixPath(i.filename.replace('\\','/')).name.lower()=='content_pack.json'),None)
                    if unified_info:
                        try:
                            obj=get_json(z.read(unified_info))
                            if not isinstance(obj,dict) or obj.get('format') not in {'network-learning-content-pack-v2','network-learning-content-pack-v1','network-learning-pack-v1','network-learning-content-export-v1','network-learning-selected-content-v1'}:
                                raise ValueError('قالب بستهٔ یکپارچه شناخته‌شده نیست')
                            if obj.get('sample_only') is True or (isinstance(obj.get('metadata'),dict) and obj['metadata'].get('sample_only') is True):
                                result['errors'].append(f'{name}: این ZIP قالب/نمونهٔ authoring kit است؛ خروجی نهایی محتوا را انتخاب کن.')
                            chapters=[ch for ch in obj.get('chapters',[]) if isinstance(ch,dict)]
                            if not chapters and obj.get('items'):
                                title=str(obj.get('chapter_title') or obj.get('title') or '').strip()
                                if title: chapters=[{'id':obj.get('chapter_id') or '__single__','title':title}]
                                else: result['errors'].append(f'{name}: content_pack.json فاقد فصل مشخص است.')
                            result['chapters'].extend([{'folder':str(ch.get('id') or ''),'title':ch.get('title') or ch.get('title_fa') or 'فصل واردشده','slug':ch.get('slug',''),'chapter_order':ch.get('order_num') or ch.get('chapter_order'),'status':'review_required'} for ch in chapters])
                            pack_subchapters=_extract_preview_subchapters(obj.get('items',[]))
                            file_info['detected_subchapters']=pack_subchapters
                            result['subchapters'].extend(pack_subchapters)
                            if pack_subchapters: result['warnings'].append(f'{name}: {len(pack_subchapters)} زیر‌فصل از فرادادهٔ محتوای بسته شناسایی شد؛ این‌ها فصل مستقل نیستند.')
                            kind_map={'lesson':'lessons','question':'questions','flashcard':'cards','command':'commands','lab':'labs','example':'examples','note':'notes','asset':'assets'}
                            local_uids=set()
                            for it in obj.get('items',[]) if isinstance(obj.get('items'),list) else []:
                                if not isinstance(it,dict): result['errors'].append(f'{name}: رکورد محتوا در content_pack.json شیء نیست.'); continue
                                result['counts'][kind_map.get(it.get('kind'),'other')]+=1
                                uid=it.get('source_uid') or it.get('uid') or it.get('id')
                                if uid is not None:
                                    k=(str(it.get('chapter_id') or ''),str(uid))
                                    if k in local_uids: result['duplicate_uids']+=1
                                    local_uids.add(k)
                            file_info['detected_chapters']=[{'folder':str(ch.get('id') or ''),'title':ch.get('title') or ch.get('title_fa') or 'فصل واردشده','slug':ch.get('slug',''),'chapter_order':ch.get('order_num') or ch.get('chapter_order'),'status':'review_required'} for ch in chapters]
                            file_info['unified_pack']=True
                            asset_paths={i.filename.replace('\\','/') for i in infos if Path(PurePosixPath(i.filename).name).suffix.lower() in SUPPORTED_IMAGE}
                            referenced=set()
                            for it in obj.get('items',[]) if isinstance(obj.get('items'),list) else []:
                                if isinstance(it,dict) and it.get('kind')=='asset':
                                    md=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
                                    referenced.add(PurePosixPath(str(md.get('file_name') or md.get('path') or it.get('content') or '')).name.casefold())
                            missing=sorted(x for x in referenced if x and not any(PurePosixPath(y).name.casefold()==x for y in asset_paths))
                            if missing: result['warnings'].append(f'{name}: {len(missing)} فایل رسانهٔ ارجاع‌شده داخل ZIP پیدا نشد: '+', '.join(missing[:5]))
                        except Exception as exc: result['errors'].append(f'{name}: content_pack.json نامعتبر است ({str(exc)[:140]})')
                        result['files'].append(file_info)
                        continue
                    for info in infos:
                        path=info.filename.replace('\\','/'); low=path.lower(); base=PurePosixPath(path).name.lower()
                        if PurePosixPath(path).is_absolute() or '..' in PurePosixPath(path).parts:
                            result['warnings'].append(f'{name}: مسیر غیرعادی داخل ZIP: {path[:100]}'); continue
                        if base=='manifest.json':
                            try:
                                m=get_json(z.read(info)); folder=str(PurePosixPath(path).parent)
                                if not isinstance(m,dict) or not (m.get('title_fa') or m.get('title')): raise ValueError('عنوان فصل پیدا نشد')
                                found.append({'folder':folder,'title':m.get('title_fa') or m.get('title') or folder,'slug':m.get('slug',''),'chapter_order':m.get('chapter_order'),'status':m.get('source_status') or m.get('status') or 'review_required'})
                                manifest_folders.add(folder)
                            except Exception as exc: result['errors'].append(f'{name}: manifest نامعتبر در {path} ({str(exc)[:100]})')
                        elif base in {'lessons.json','questions.json','examples.json','commands.json','labs.json','flashcards.json','cards.json','notes.json'}:
                            try:
                                obj=get_json(z.read(info))
                                if not isinstance(obj,dict): raise ValueError('ریشهٔ JSON باید شیء باشد')
                                arr=obj.get('items')
                                if not isinstance(arr,list): raise ValueError('فیلد items باید آرایه باشد')
                                k={'lessons.json':'lessons','questions.json':'questions','examples.json':'examples','commands.json':'commands','labs.json':'labs','flashcards.json':'cards','cards.json':'cards','notes.json':'notes'}[base]
                                result['counts'][k]+=len(arr)
                                for it in arr:
                                    if isinstance(it,dict):
                                        uid=it.get('uid') or it.get('id')
                                        if uid:
                                            key=(str(PurePosixPath(path).parent),str(uid))
                                            if key in seen_uids: result['duplicate_uids']+=1
                                            seen_uids.add(key)
                                    else: result['warnings'].append(f'{name}: یک رکورد غیرشیء در {path} نادیده گرفته می‌شود.')
                            except Exception as exc: result['errors'].append(f'{name}: JSON بانک {path} قابل خواندن نیست ({str(exc)[:100]})')
                        elif base=='answer_key.json' or '/answers/' in low:
                            continue
                        elif Path(base).suffix in SUPPORTED_IMAGE: result['counts']['assets']+=1
                        elif Path(base).suffix in TEXT_TYPES or Path(base).suffix in {'.docx','.pdf'}: result['counts']['other']+=1
                    # Match the importer's exact destination inference.
                    mapped,nested_subchapters=parse_manifest_entries(z,name,include_subchapters=True)
                    found=[{'folder':folder,'title':meta.get('title',''),'slug':meta.get('slug',''),'chapter_order':meta.get('order'),'status':meta.get('status','review_required'),'inferred':bool(meta.get('inferred'))} for folder,meta in mapped.items()]
                    found_subchapters=[{'folder':folder,'title':meta.get('subchapter_title') or meta.get('title',''),'slug':meta.get('slug',''),'parent_folder':meta.get('parent_folder','')} for folder,meta in nested_subchapters.items()]
                    file_info['detected_subchapters']=found_subchapters
                    result['subchapters'].extend(found_subchapters)
                    if found_subchapters:
                        result['warnings'].append(f'{name}: {len(found_subchapters)} زیر‌فصل شناسایی شد؛ این عنوان‌ها به‌عنوان بخش‌های درون فصل نمایش داده می‌شوند، نه فصل مستقل.')
                    if mode=='auto':
                        excluded_parts={'answers','sources','source_archive','authoring','build','windows','android','__pycache__'}
                        importable_exts=set(TEXT_TYPES)|{'.pdf','.docx'}|set(SUPPORTED_IMAGE)|{'.json'}
                        for zinfo in infos:
                            zp=zinfo.filename.replace('\\','/'); zpath=PurePosixPath(zp); zbase=zpath.name.lower(); zext=zpath.suffix.lower()
                            if zext not in importable_exts or zbase in {'manifest.json','manifest_enrichment.json','legacy_manifest.json','answer_key.json'} or zbase.startswith('readme'): continue
                            if any(part.lower() in excluded_parts for part in zpath.parts[:-1]): continue
                            zfolder=str(zpath.parent)
                            routed=(zfolder in mapped) or any(zfolder.startswith(m+'/') for m in mapped if m not in ('.','')) or (zfolder in ('.','') and '.' in mapped)
                            # Root files belong to the inferred root chapter. A nested file must have
                            # a matching inferred/manifest ancestor; otherwise don't risk cross-chapter import.
                            if not routed:
                                result['errors'].append(f'{name}: مقصد فصل برای «{zp[:100]}» قابل تشخیص نیست؛ واردسازی خودکار ایمن نیست.')
                    file_info['detected_chapters']=found; result['chapters'].extend(found)
            except zipfile.BadZipFile:
                result['errors'].append(f'{name}: فایل ZIP معتبر نیست')
        elif ext=='.json':
            try:
                obj=get_json(raw)
                if obj is None: raise ValueError()
                unified_formats={'network-learning-pack-v1','network-learning-content-pack-v1','network-learning-content-pack-v2','network-learning-content-export-v1','network-learning-selected-content-v1','network-learning-backup-v1'}
                bank_formats={'network-learning-lessons-v1':'lessons','network-learning-questions-v1':'questions','network-learning-flashcards-v1':'cards','network-learning-commands-v1':'commands','network-learning-labs-v1':'labs','network-learning-examples-v1':'examples','network-learning-notes-v1':'notes'}
                if isinstance(obj,dict) and obj.get('format') in unified_formats and isinstance(obj.get('items'),list):
                    found=[]
                    src_chapters=[ch for ch in (obj.get('chapters') or []) if isinstance(ch,dict)]
                    if not src_chapters and obj.get('items'):
                        root_id=str(obj.get('chapter_id') or '').strip()
                        root_title=str(obj.get('chapter_title') or obj.get('chapter_title_fa') or obj.get('title') or '').strip()
                        if root_id or root_title:
                            src_chapters=[{'id':root_id or '__single_pack_chapter__','title':root_title or Path(name).stem}]
                        else:
                            result['errors'].append(f'{name}: فصل مشخص نیست؛ برای جلوگیری از ورود اشتباه به فصل دیگر، بسته رد شد.')
                    for ch in src_chapters:
                        found.append({'folder':str(ch.get('id') or ''),'title':ch.get('title') or ch.get('title_fa') or 'فصل واردشده','slug':ch.get('slug',''),'chapter_order':ch.get('order_num') or ch.get('chapter_order'),'status':'review_required'})
                    chapter_id_list=[str(ch.get('id') or '').strip() for ch in src_chapters if str(ch.get('id') or '').strip()]
                    chapter_ids=set(chapter_id_list)
                    repeated_chapter_ids=sorted({x for x in chapter_id_list if chapter_id_list.count(x)>1})
                    if repeated_chapter_ids: result['errors'].append(f'{name}: شناسهٔ فصل تکراری در JSON: '+', '.join(repeated_chapter_ids[:10]))
                    if len(chapter_ids)>1 and mode!='selected':
                        unknown=sorted({str(it.get('chapter_id') or '').strip() for it in obj['items'] if isinstance(it,dict) and (not str(it.get('chapter_id') or '').strip() or str(it.get('chapter_id') or '').strip() not in chapter_ids)})
                        if unknown: result['errors'].append(f'{name}: شناسه‌های فصل نامشخص/خالی برای بستهٔ چندفصلی: '+', '.join((x or '<خالی>') for x in unknown[:8]))
                    file_info['detected_chapters']=found; result['chapters'].extend(found)
                    json_subchapters=_extract_preview_subchapters(obj.get('items',[]))
                    file_info['detected_subchapters']=json_subchapters
                    result['subchapters'].extend(json_subchapters)
                    if json_subchapters: result['warnings'].append(f'{name}: {len(json_subchapters)} زیر‌فصل از فرادادهٔ محتوای بسته شناسایی شد؛ این‌ها فصل مستقل نیستند.')
                    local_uids=set()
                    kind_map={'lesson':'lessons','question':'questions','flashcard':'cards','command':'commands','lab':'labs','example':'examples','note':'notes','asset':'assets'}
                    for it in obj['items']:
                        if not isinstance(it,dict): result['errors'].append(f'{name}: رکورد غیرشیء در بانک محتوا'); continue
                        bucket=kind_map.get(it.get('kind'),'other'); result['counts'][bucket]+=1
                        uid=it.get('source_uid') or it.get('uid') or it.get('id')
                        if uid is not None:
                            key=(str(it.get('chapter_id') or ''),str(uid))
                            if key in local_uids: result['duplicate_uids']+=1
                            local_uids.add(key)
                elif isinstance(obj,dict) and obj.get('format')=='network-learning-item-v1' and isinstance(obj.get('item'),dict):
                    it=obj['item']; bucket={'lesson':'lessons','question':'questions','flashcard':'cards','command':'commands','lab':'labs','example':'examples','note':'notes','asset':'assets'}.get(it.get('kind'),'other')
                    result['counts'][bucket]+=1
                    if it.get('chapter_title') or it.get('chapter_id'):
                        result['chapters'].append({'folder':str(it.get('chapter_id') or ''),'title':it.get('chapter_title') or 'محتوای واردشده','slug':'','chapter_order':None,'status':'review_required'})
                elif isinstance(obj,dict) and isinstance(obj.get('items'),list):
                    stem=name.lower(); k=bank_formats.get(str(obj.get('format') or ''),{'lessons.json':'lessons','questions.json':'questions','examples.json':'examples','commands.json':'commands','labs.json':'labs','flashcards.json':'cards','cards.json':'cards','notes.json':'notes','answer_key.json':'other'}.get(stem,'other'))
                    result['counts'][k]+=len(obj['items'])
                    if stem=='answer_key.json': result['warnings'].append(f'{name}: این فایل فقط کلید پاسخ است؛ باید داخل همان ZIP در مسیر answers/answer_key.json کنار بانک سؤال باشد تا به سؤال‌ها پیوند داده شود.')
                else: result['counts']['other']+=1
            except Exception: result['errors'].append(f'{name}: JSON معتبر نیست')
        elif ext in SUPPORTED_IMAGE: result['counts']['assets']+=1
        else: result['counts']['other']+=1
        result['files'].append(file_info)
    if result['files_received'] and not result['chapters'] and mode=='auto':
        result['warnings'].append('فصل قابل تشخیص پیدا نشد؛ ورود مبهم به فصل‌های موجود مجاز نیست. نام/شناسهٔ فصل را در بسته مشخص کن یا ZIP را با پوشهٔ مستقل فصل بساز.')
    result['target_topic_id']=target_topic_id
    if result['duplicate_uids']: result['warnings'].append(f'{result["duplicate_uids"]} شناسهٔ تکراری داخل ZIP پیدا شد؛ موارد تکراری در زمان ورود نادیده گرفته می‌شوند.')
    result['ready']=not result['errors']
    return result


class TaskCreate(BaseModel):
    title: str
    description: str = ''
    priority: int = 2
    planned_date: str = ''
    planned_time: str = ''
    due_date: str = ''
    due_time: str = ''
    reminder_date: str = ''
    reminder_time: str = ''
    estimate_minutes: int = 0
    actual_minutes: int = 0
    repeat_rule: str = ''
    chapter_id: str = ''
    item_id: Optional[int] = None
    depends_on_id: Optional[int] = None
    tags: list[str] = []


def task_public(row):
    d=dict(row)
    try: d['tags']=json.loads(d.pop('tags_json') or '[]')
    except Exception: d['tags']=[]
    for field in ('planned_start','due_at','reminder_at'):
        d[field+'_jalali']=display_jalali_datetime(d.get(field))
    return d


@app.get('/api/tasks')
def list_tasks(status:str='', chapter_id:str='', date_from:str='', date_to:str='', q:str='', topic_id:str=''):
    sql='''SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE 1=1'''; args=[]
    if status and status!='all': sql+=' AND t.status=?'; args.append(status)
    if topic_id: sql+=' AND (t.chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?) OR (t.chapter_id IS NULL AND t.item_id IN (SELECT i.id FROM items i JOIN chapter_topics ct ON ct.chapter_id=i.chapter_id WHERE ct.topic_id=?)))'; args.extend([topic_id,topic_id])
    if chapter_id: sql+=' AND t.chapter_id=?'; args.append(chapter_id)
    if date_from:
        try: df=normalize_date_input(date_from); sql+=' AND (date(t.planned_start)>=date(?) OR t.planned_start="")'; args.append(df)
        except Exception as e: raise HTTPException(400,str(e))
    if date_to:
        try: dt=normalize_date_input(date_to); sql+=' AND (date(t.planned_start)<=date(?) OR t.planned_start="")'; args.append(dt)
        except Exception as e: raise HTTPException(400,str(e))
    if q:
        pat=f'%{q[:120]}%'; sql+=' AND (t.title LIKE ? OR t.description LIKE ? OR t.tags_json LIKE ?)'; args.extend([pat,pat,pat])
    sql+=' ORDER BY CASE t.status WHEN "in_progress" THEN 0 WHEN "todo" THEN 1 WHEN "waiting" THEN 2 ELSE 3 END, CASE WHEN t.due_at="" THEN 1 ELSE 0 END, t.due_at, t.planned_start, t.priority ASC, t.id DESC'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    return {'tasks':[task_public(r) for r in rows],'count':len(rows)}


@app.get('/api/tasks/{task_id}')
def get_task(task_id: int):
    with connect() as c:
        row=c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE t.id=?',(task_id,)).fetchone()
    if not row: raise HTTPException(404,'کار پیدا نشد')
    return {'task':task_public(row)}


@app.post('/api/tasks')
def create_task(payload:TaskCreate):
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان کار الزامی است')
    if payload.priority not in {1,2,3,4}: raise HTTPException(400,'اولویت باید بین ۱ تا ۴ باشد')
    try:
        planned=normalize_datetime_input(payload.planned_date,payload.planned_time)
        due=normalize_datetime_input(payload.due_date,payload.due_time)
        reminder=normalize_datetime_input(payload.reminder_date,payload.reminder_time)
    except Exception as e: raise HTTPException(400,str(e))
    with connect() as c:
        chapter=payload.chapter_id or None
        if chapter and not c.execute('SELECT 1 FROM chapters WHERE id=?',(chapter,)).fetchone(): raise HTTPException(404,'فصل انتخاب‌شده پیدا نشد')
        if payload.item_id and not c.execute('SELECT 1 FROM items WHERE id=?',(payload.item_id,)).fetchone(): raise HTTPException(404,'محتوای مرتبط پیدا نشد')
        if payload.depends_on_id and not c.execute('SELECT 1 FROM tasks WHERE id=?',(payload.depends_on_id,)).fetchone(): raise HTTPException(404,'کار پیش‌نیاز پیدا نشد')
        ts=now_iso()
        cur=c.execute('''INSERT INTO tasks(title,description,status,priority,planned_start,due_at,reminder_at,estimate_minutes,actual_minutes,repeat_rule,chapter_id,item_id,depends_on_id,tags_json,created_at,updated_at)
          VALUES(?,?,'todo',?,?,?,?,?,?,?,?,?,?,?,?,?)''',(title,payload.description,payload.priority,planned or '',due or '',reminder or '',max(0,min(int(payload.estimate_minutes),1000000)),max(0,min(int(payload.actual_minutes),1000000)),payload.repeat_rule,chapter,payload.item_id,payload.depends_on_id,json.dumps([x.strip() for x in payload.tags if x.strip()],ensure_ascii=False),ts,ts))
        c.commit(); tid=cur.lastrowid
        row=c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE t.id=?',(tid,)).fetchone()
    return {'ok':True,'task':task_public(row)}


@app.patch('/api/tasks/{task_id}')
def update_task(task_id:int, payload:dict[str,Any]):
    allowed={'title','description','status','priority','planned_date','planned_time','due_date','due_time','reminder_date','reminder_time','estimate_minutes','actual_minutes','repeat_rule','chapter_id','item_id','depends_on_id','tags'}
    if not payload or set(payload)-allowed: raise HTTPException(400,'فیلد یا دادهٔ نامعتبر است')
    with connect() as c:
        old=c.execute('SELECT * FROM tasks WHERE id=?',(task_id,)).fetchone()
        if not old: raise HTTPException(404,'کار پیدا نشد')
        vals={k:v for k,v in payload.items()}
        if 'status' in vals:
            if vals['status'] not in {'todo','in_progress','waiting','completed','cancelled'}: raise HTTPException(400,'وضعیت کار نامعتبر است')
            if vals['status']=='completed' and old['depends_on_id']:
                dep=c.execute('SELECT status FROM tasks WHERE id=?',(old['depends_on_id'],)).fetchone()
                if dep and dep['status']!='completed': raise HTTPException(400,'ابتدا کار پیش‌نیاز را تکمیل کن')
        if 'priority' in vals and int(vals['priority']) not in {1,2,3,4}: raise HTTPException(400,'اولویت نامعتبر است')
        for field in ('estimate_minutes','actual_minutes'):
            if field in vals:
                try: vals[field]=max(0,min(int(vals[field]),1000000))
                except Exception: raise HTTPException(400,f'{field} باید عدد صحیح نامنفی باشد')
        if 'title' in vals:
            vals['title']=str(vals['title']).strip()
            if not vals['title']: raise HTTPException(400,'عنوان کار نمی‌تواند خالی باشد')
        if 'repeat_rule' in vals and vals['repeat_rule'] not in {'','daily','weekly','monthly'}: raise HTTPException(400,'قاعدهٔ تکرار نامعتبر است')
        if 'planned_date' in vals or 'planned_time' in vals:
            day=vals.pop('planned_date', old['planned_start'][:10] if old['planned_start'] else '')
            clock=vals.pop('planned_time', old['planned_start'][11:16] if old['planned_start'] and 'T' in old['planned_start'] else '')
            vals['planned_start']=normalize_datetime_input(day,clock) or ''
        for k in ('due','reminder'):
            dk=k+'_date'; tk=k+'_time'; field=k+'_at'
            if dk in vals or tk in vals:
                oldval=old[field] or ''
                day=vals.pop(dk, oldval[:10] if oldval else '')
                clock=vals.pop(tk, oldval[11:16] if oldval and 'T' in oldval else '')
                vals[field]=normalize_datetime_input(day,clock) or ''
        if 'tags' in vals: vals['tags_json']=json.dumps(vals.pop('tags') or [],ensure_ascii=False)
        if 'chapter_id' in vals: vals['chapter_id']=vals['chapter_id'] or None
        if 'item_id' in vals: vals['item_id']=vals['item_id'] or None
        if 'depends_on_id' in vals and vals['depends_on_id']==task_id: raise HTTPException(400,'یک کار نمی‌تواند پیش‌نیاز خودش باشد')
        for fk,table in [('chapter_id','chapters'),('item_id','items'),('depends_on_id','tasks')]:
            if vals.get(fk) and not c.execute(f'SELECT 1 FROM {table} WHERE id=?',(vals[fk],)).fetchone(): raise HTTPException(404,'مرجع انتخاب‌شده پیدا نشد')
        # Reject dependency cycles (A -> B -> A) rather than creating impossible work graphs.
        dependency=vals.get('depends_on_id',old['depends_on_id'])
        if dependency not in (None,'',0):
            cursor_id=int(dependency); visited=set()
            while cursor_id:
                if cursor_id==task_id: raise HTTPException(400,'این پیش‌نیاز یک چرخه ایجاد می‌کند؛ زنجیرهٔ کارها باید بدون چرخه باشد')
                if cursor_id in visited: raise HTTPException(400,'زنجیرهٔ پیش‌نیازهای موجود چرخه دارد؛ ابتدا آن را اصلاح کن')
                visited.add(cursor_id)
                dep_row=c.execute('SELECT depends_on_id FROM tasks WHERE id=?',(cursor_id,)).fetchone()
                if not dep_row: break
                next_id=dep_row['depends_on_id']
                cursor_id=int(next_id) if next_id not in (None,'',0) else 0
            if 'depends_on_id' in vals: vals['depends_on_id']=int(dependency)
        elif 'depends_on_id' in vals:
            vals['depends_on_id']=None
        vals['updated_at']=now_iso()
        keys=list(vals); c.execute('UPDATE tasks SET '+','.join(k+'=?' for k in keys)+' WHERE id=?',[vals[k] for k in keys]+[task_id])
        # A recurring task creates the next occurrence only when it transitions to completed.
        if vals.get('status')=='completed' and old['status']!='completed' and old['repeat_rule'] in {'daily','weekly','monthly'}:
            def shift_stamp(stamp, rule):
                if not stamp: return ''
                try:
                    dt=datetime.fromisoformat(stamp)
                    if rule=='daily': dt += timedelta(days=1)
                    elif rule=='weekly': dt += timedelta(days=7)
                    else:
                        y=dt.year+(1 if dt.month==12 else 0); m=1 if dt.month==12 else dt.month+1
                        import calendar as _calendar
                        dt=dt.replace(year=y,month=m,day=min(dt.day,_calendar.monthrange(y,m)[1]))
                    return dt.isoformat(timespec='seconds')
                except Exception: return ''
            c.execute('''INSERT INTO tasks(title,description,status,priority,planned_start,due_at,reminder_at,estimate_minutes,actual_minutes,repeat_rule,chapter_id,item_id,depends_on_id,tags_json,created_at,updated_at)
              VALUES(?,?,'todo',?,?,?,?,?,0,?,?,?,?,?,?,?)''',
              (old['title'],old['description'],old['priority'],shift_stamp(old['planned_start'],old['repeat_rule']),shift_stamp(old['due_at'],old['repeat_rule']),shift_stamp(old['reminder_at'],old['repeat_rule']),old['estimate_minutes'],old['repeat_rule'],old['chapter_id'],old['item_id'],task_id,old['tags_json'],now_iso(),now_iso()))
        c.commit()
        row=c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE t.id=?',(task_id,)).fetchone()
    return {'ok':True,'task':task_public(row)}


@app.delete('/api/tasks/{task_id}')
def delete_task(task_id:int):
    with connect() as c:
        cur=c.execute('DELETE FROM tasks WHERE id=?',(task_id,)); c.commit()
        if not cur.rowcount: raise HTTPException(404,'کار پیدا نشد')
    return {'ok':True}


class PlanCreate(BaseModel):
    title:str
    period_type:str='week'
    start_date:str
    end_date:str
    target_minutes:int=0
    target_cards:int=0
    target_questions:int=0
    active_chapters:list[str]=[]
    notes:str=''
    parent_id:Optional[int]=None


@app.get('/api/plans')
def list_plans():
    with connect() as c: rows=c.execute('SELECT * FROM study_plans ORDER BY start_date DESC,id DESC').fetchall()
    output=[]
    for r in rows:
        d=dict(r); d['active_chapters']=json.loads(d.pop('active_chapters_json') or '[]'); d['start_date_jalali']=display_jalali_datetime(d['start_date']); d['end_date_jalali']=display_jalali_datetime(d['end_date']); output.append(d)
    return {'plans':output}


@app.post('/api/plans')
def create_plan(payload:PlanCreate):
    if payload.period_type not in {'day','week','month','year','custom'}: raise HTTPException(400,'نوع بازه نامعتبر است')
    try: start=normalize_date_input(payload.start_date); end=normalize_date_input(payload.end_date)
    except Exception as e: raise HTTPException(400,str(e))
    if not start or not end or end<start: raise HTTPException(400,'بازهٔ تاریخ برنامه نامعتبر است')
    with connect() as c:
        for ch in payload.active_chapters:
            if not c.execute('SELECT 1 FROM chapters WHERE id=?',(ch,)).fetchone(): raise HTTPException(400,f'فصل {ch} پیدا نشد')
        if payload.parent_id is not None:
            parent=c.execute('SELECT id,period_type,start_date,end_date FROM study_plans WHERE id=?',(payload.parent_id,)).fetchone()
            if not parent: raise HTTPException(404,'هدف والد پیدا نشد')
            if start < parent['start_date'] or end > parent['end_date']: raise HTTPException(400,'بازهٔ هدف فرزند باید در بازهٔ هدف والد قرار گیرد')
            ranks={'year':0,'month':1,'week':2,'day':3,'custom':-1}
            if parent['period_type']!='custom' and payload.period_type!='custom' and ranks[parent['period_type']]>ranks[payload.period_type]: raise HTTPException(400,'هدف والد باید هم‌سطح یا بلندمدت‌تر از هدف فرزند باشد')
        cur=c.execute('''INSERT INTO study_plans(title,period_type,start_date,end_date,target_minutes,target_cards,target_questions,active_chapters_json,notes,created_at,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
          (payload.title.strip() or 'برنامهٔ مطالعه',payload.period_type,start,end,max(0,payload.target_minutes),max(0,payload.target_cards),max(0,payload.target_questions),json.dumps(payload.active_chapters,ensure_ascii=False),payload.notes,now_iso(),payload.parent_id))
        c.commit(); pid=cur.lastrowid
    return {'ok':True,'id':pid,'start_date':start,'end_date':end}


@app.delete('/api/plans/{plan_id}')
def delete_plan(plan_id:int):
    with connect() as c:
        cur=c.execute('DELETE FROM study_plans WHERE id=?',(plan_id,)); c.commit()
        if not cur.rowcount: raise HTTPException(404,'برنامه پیدا نشد')
    return {'ok':True}


@app.get('/api/time/active')
def active_timer():
    with connect() as c:
        row=c.execute('''SELECT te.*,t.title task_title,i.title item_title FROM time_entries te LEFT JOIN tasks t ON t.id=te.task_id LEFT JOIN items i ON i.id=te.item_id WHERE te.ended_at='' ORDER BY te.id DESC LIMIT 1''').fetchone()
    if not row: return {'active':False}
    d=dict(row); d['elapsed_seconds']=max(0,int((user_datetime()-datetime.fromisoformat(d['started_at'])).total_seconds()))
    return {'active':True,'entry':d}


@app.post('/api/time/start')
def start_timer(payload:dict[str,Any]):
    task_id=payload.get('task_id'); item_id=payload.get('item_id'); note=str(payload.get('note') or '')[:500]
    with connect() as c:
        active=c.execute("SELECT id FROM time_entries WHERE ended_at='' LIMIT 1").fetchone()
        if active: raise HTTPException(400,'یک زمان‌سنج فعال است؛ ابتدا آن را متوقف کن')
        if task_id and not c.execute('SELECT 1 FROM tasks WHERE id=?',(task_id,)).fetchone(): raise HTTPException(404,'کار پیدا نشد')
        if item_id and not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'محتوا پیدا نشد')
        start=now_iso(); cur=c.execute('INSERT INTO time_entries(task_id,item_id,started_at,ended_at,duration_minutes,note) VALUES(?,?,?,\'\',0,?)',(task_id,item_id,start,note))
        if task_id: c.execute("UPDATE tasks SET status='in_progress',updated_at=? WHERE id=? AND status='todo'",(now_iso(),task_id))
        c.commit()
    return {'ok':True,'entry_id':cur.lastrowid,'started_at':start}


@app.post('/api/time/stop')
def stop_timer():
    with connect() as c:
        row=c.execute("SELECT * FROM time_entries WHERE ended_at='' ORDER BY id DESC LIMIT 1").fetchone()
        if not row: raise HTTPException(400,'زمان‌سنج فعالی وجود ندارد')
        end=user_datetime(); start=datetime.fromisoformat(row['started_at']); seconds=max(0,int((end-start).total_seconds())); minutes=max(1,round(seconds/60))
        c.execute('UPDATE time_entries SET ended_at=?,duration_minutes=? WHERE id=?',(end.isoformat(timespec='seconds'),minutes,row['id']))
        if row['task_id']: c.execute('UPDATE tasks SET actual_minutes=actual_minutes+?,updated_at=? WHERE id=?',(minutes,now_iso(),row['task_id']))
        c.commit()
    return {'ok':True,'duration_minutes':minutes,'duration_seconds':seconds}


@app.get('/api/reports/weekly')
def weekly_report():
    today=user_datetime().date(); since_sat=(today.weekday()+2)%7; start=today-timedelta(days=since_sat); end=start+timedelta(days=6)
    with connect() as c:
        entries=c.execute('SELECT started_at,duration_minutes,task_id,item_id FROM time_entries WHERE ended_at<>\'\' AND date(started_at)>=date(?) AND date(started_at)<=date(?)',(start.isoformat(),end.isoformat())).fetchall()
        tasks=c.execute('SELECT status,estimate_minutes,actual_minutes,planned_start,due_at FROM tasks WHERE (date(planned_start)>=date(?) AND date(planned_start)<=date(?)) OR (date(due_at)>=date(?) AND date(due_at)<=date(?))',(start.isoformat(),end.isoformat(),start.isoformat(),end.isoformat())).fetchall()
        cards=c.execute('SELECT COUNT(*) n FROM review_history WHERE date(reviewed_at)>=date(?) AND date(reviewed_at)<=date(?)',(start.isoformat(),end.isoformat())).fetchone()['n']
        questions=c.execute('SELECT COUNT(*) n, SUM(correct) correct FROM assessment_attempts WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)',(start.isoformat(),end.isoformat())).fetchone()
        plans=c.execute('SELECT * FROM study_plans WHERE date(start_date)<=date(?) AND date(end_date)>=date(?)',(end.isoformat(),start.isoformat())).fetchall()
    actual=sum(int(r['duration_minutes'] or 0) for r in entries); estimate=sum(int(r['estimate_minutes'] or 0) for r in tasks); completed=sum(1 for r in tasks if r['status']=='completed')
    target_minutes=sum(int(r['target_minutes'] or 0) for r in plans if r['period_type']=='week')
    target_cards=sum(int(r['target_cards'] or 0) for r in plans if r['period_type']=='week')
    target_questions=sum(int(r['target_questions'] or 0) for r in plans if r['period_type']=='week')
    return {'start_date':start.isoformat(),'end_date':end.isoformat(),'start_jalali':gregorian_to_jalali(start),'end_jalali':gregorian_to_jalali(end),'actual_minutes':actual,'estimated_task_minutes':estimate,'planned_tasks':len(tasks),'completed_tasks':completed,'completed_cards':cards,'answered_questions':int(questions['n'] or 0),'correct_questions':int(questions['correct'] or 0),'targets':{'minutes':target_minutes,'cards':target_cards,'questions':target_questions},'progress':{'minutes':round(actual/target_minutes*100) if target_minutes else None,'cards':round(cards/target_cards*100) if target_cards else None,'questions':round(int(questions['n'] or 0)/target_questions*100) if target_questions else None}}


@app.get('/api/calendar/tasks')
def calendar_tasks(start_date: str, end_date: str, chapter_id: str = '', status: str = 'all', q: str = ''):
    try:
        start=normalize_date_input(start_date); end=normalize_date_input(end_date)
    except Exception as e: raise HTTPException(400,str(e))
    if not start or not end or end < start: raise HTTPException(400,'بازهٔ تقویم معتبر نیست')
    where=['((date(t.planned_start) BETWEEN date(?) AND date(?)) OR (date(t.due_at) BETWEEN date(?) AND date(?)) OR (date(t.reminder_at) BETWEEN date(?) AND date(?)))']
    args=[start,end,start,end,start,end]
    if chapter_id: where.append('t.chapter_id=?'); args.append(chapter_id)
    if status and status!='all': where.append('t.status=?'); args.append(status)
    if q:
        p=f'%{q[:120]}%'; where.append('(t.title LIKE ? OR t.description LIKE ? OR t.tags_json LIKE ?)'); args.extend([p,p,p])
    with connect() as c:
        sql = "SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE " + ' AND '.join(where) + " ORDER BY COALESCE(NULLIF(t.planned_start,''),NULLIF(t.due_at,''),NULLIF(t.reminder_at,'')), t.priority, t.id"
        rows=c.execute(sql,args).fetchall()
    return {'start_date':start,'end_date':end,'tasks':[task_public(r) for r in rows],'count':len(rows)}


@app.get('/api/reports/summary')
def report_summary(date_from: str = '', date_to: str = '', chapter_id: str = '', status: str = 'all', topic_id: str = ''):
    today=user_datetime().date()
    try:
        end=normalize_date_input(date_to) if date_to else today.isoformat()
        start=normalize_date_input(date_from) if date_from else (today-timedelta(days=29)).isoformat()
    except Exception as e: raise HTTPException(400,str(e))
    if not start or not end or end < start: raise HTTPException(400,'بازهٔ گزارش معتبر نیست')
    clauses=['date(created_at) BETWEEN date(?) AND date(?)']; base_args=[start,end]
    ch_clause=' AND chapter_id=?' if chapter_id else ''; ch_args=[chapter_id] if chapter_id else []
    with connect() as c:
        time_sql="SELECT COALESCE(SUM(te.duration_minutes),0) minutes, COUNT(*) sessions FROM time_entries te LEFT JOIN items ti ON ti.id=te.item_id LEFT JOIN tasks tt ON tt.id=te.task_id WHERE te.ended_at<>'' AND date(te.started_at) BETWEEN date(?) AND date(?)"; time_args=list(base_args)
        if topic_id: time_sql+=" AND (ti.chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?) OR tt.chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?))"; time_args.extend([topic_id,topic_id])
        time_rows=c.execute(time_sql,time_args).fetchone()
        task_where='((date(planned_start) BETWEEN date(?) AND date(?)) OR (date(due_at) BETWEEN date(?) AND date(?)))'; task_args=[start,end,start,end]
        if chapter_id: task_where+=' AND chapter_id=?'; task_args.append(chapter_id)
        if topic_id: task_where+=' AND chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?)'; task_args.append(topic_id)
        if status and status!='all': task_where+=' AND status=?'; task_args.append(status)
        tasks=c.execute('SELECT status,priority,estimate_minutes,actual_minutes,planned_start,due_at,chapter_id FROM tasks WHERE '+task_where,task_args).fetchall()
        review_sql='''SELECT COUNT(*) n, COUNT(DISTINCT rh.item_id) unique_cards, SUM(CASE WHEN rh.rating IN ('good','easy') THEN 1 ELSE 0 END) successful FROM review_history rh JOIN items i ON i.id=rh.item_id WHERE date(rh.reviewed_at) BETWEEN date(?) AND date(?) AND i.source_status='verified' '''
        review_args=[start,end]
        if chapter_id: review_sql+=' AND i.chapter_id=?'; review_args.append(chapter_id)
        if topic_id: review_sql+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; review_args.append(topic_id)
        reviews=c.execute(review_sql,review_args).fetchone()
        question_sql='''SELECT COUNT(*) n, SUM(a.correct) correct, COUNT(DISTINCT a.question_item_id) unique_questions FROM assessment_attempts a JOIN items i ON i.id=a.question_item_id WHERE date(a.created_at) BETWEEN date(?) AND date(?)'''
        qargs=[start,end]
        if chapter_id: question_sql+=' AND a.chapter_id=?'; qargs.append(chapter_id)
        if topic_id: question_sql+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; qargs.append(topic_id)
        questions=c.execute(question_sql,qargs).fetchone()
        weak_sql='''SELECT ch.id chapter_id,ch.title chapter_title,COALESCE(json_extract(i.metadata_json,'$.domain'),json_extract(i.metadata_json,'$.topic'),'عمومی') topic,COUNT(*) attempts,ROUND(100.0*AVG(a.correct),1) accuracy FROM assessment_attempts a JOIN items i ON i.id=a.question_item_id JOIN chapters ch ON ch.id=a.chapter_id WHERE date(a.created_at) BETWEEN date(?) AND date(?)'''
        wargs=[start,end]
        if chapter_id: weak_sql+=' AND a.chapter_id=?'; wargs.append(chapter_id)
        if topic_id: weak_sql+=' AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)'; wargs.append(topic_id)
        weak_sql+=' GROUP BY ch.id,topic HAVING COUNT(*)>=2 ORDER BY accuracy ASC,attempts DESC LIMIT 20'
        weak=c.execute(weak_sql,wargs).fetchall()
        daily_time_sql="SELECT date(te.started_at) d,COALESCE(SUM(te.duration_minutes),0) minutes,COUNT(*) sessions FROM time_entries te LEFT JOIN items ti ON ti.id=te.item_id LEFT JOIN tasks tt ON tt.id=te.task_id WHERE te.ended_at<>'' AND date(te.started_at) BETWEEN date(?) AND date(?)"; dtargs=list(base_args)
        if topic_id: daily_time_sql+=" AND (ti.chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?) OR tt.chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?))"; dtargs.extend([topic_id,topic_id])
        daily_time=c.execute(daily_time_sql+" GROUP BY date(te.started_at) ORDER BY d",dtargs).fetchall()
        daily_review_sql="SELECT date(rh.reviewed_at) d,COUNT(*) n FROM review_history rh JOIN items i ON i.id=rh.item_id WHERE date(rh.reviewed_at) BETWEEN date(?) AND date(?)"; drargs=list(base_args)
        if topic_id: daily_review_sql+=" AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)"; drargs.append(topic_id)
        daily_reviews=c.execute(daily_review_sql+" GROUP BY date(rh.reviewed_at)",drargs).fetchall()
        daily_question_sql="SELECT date(a.created_at) d,COUNT(*) n,SUM(a.correct) correct FROM assessment_attempts a JOIN items i ON i.id=a.question_item_id WHERE date(a.created_at) BETWEEN date(?) AND date(?)"; dqargs=list(base_args)
        if topic_id: daily_question_sql+=" AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)"; dqargs.append(topic_id)
        daily_questions=c.execute(daily_question_sql+" GROUP BY date(a.created_at)",dqargs).fetchall()
        content_where=' WHERE 1=1'; content_args=[]
        if chapter_id: content_where+=' AND chapter_id=?'; content_args.append(chapter_id)
        if topic_id: content_where+=' AND chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?)'; content_args.append(topic_id)
        content=c.execute('SELECT kind,source_status,COUNT(*) n FROM items'+content_where+' GROUP BY kind,source_status',content_args).fetchall()
    statuses={}; priorities={}; total_est=sum(int(r['estimate_minutes'] or 0) for r in tasks); task_actual=sum(int(r['actual_minutes'] or 0) for r in tasks)
    for r in tasks: statuses[r['status']]=statuses.get(r['status'],0)+1; priorities[str(r['priority'])]=priorities.get(str(r['priority']),0)+1
    content_summary={}
    for r in content: content_summary.setdefault(r['kind'],{})[r['source_status']]=r['n']
    return {
      'period':{'start':start,'end':end,'start_jalali':gregorian_to_jalali(date.fromisoformat(start)),'end_jalali':gregorian_to_jalali(date.fromisoformat(end)),'timezone':user_timezone_name()},
      'time':{'minutes':int(time_rows['minutes'] or 0),'sessions':int(time_rows['sessions'] or 0),'task_actual_minutes':task_actual,'task_estimate_minutes':total_est,'variance_minutes':task_actual-total_est},
      'tasks':{'total':len(tasks),'by_status':statuses,'by_priority':priorities,'overdue':sum(1 for r in tasks if r['status'] not in {'completed','cancelled'} and r['due_at'] and r['due_at'][:10]<today.isoformat()),'completion_percent':round(100*statuses.get('completed',0)/len(tasks),1) if tasks else None},
      'review':{'attempts':int(reviews['n'] or 0),'unique_cards':int(reviews['unique_cards'] or 0),'successful_ratings':int(reviews['successful'] or 0)},
      'assessment':{'attempts':int(questions['n'] or 0),'correct':int(questions['correct'] or 0),'unique_questions':int(questions['unique_questions'] or 0),'accuracy':round(100*int(questions['correct'] or 0)/int(questions['n'] or 1),1) if questions['n'] else None},
      'weak_topics':[dict(r) for r in weak], 'daily_time':[dict(r) for r in daily_time], 'daily_reviews':[dict(r) for r in daily_reviews], 'daily_questions':[dict(r) for r in daily_questions], 'content_status':content_summary
    }


@app.get('/api/reports/export')
def export_topic_report(topic_id: str = '', date_from: str = '', date_to: str = '', chapter_id: str = '', status: str = 'all'):
    report=report_summary(date_from=date_from,date_to=date_to,chapter_id=chapter_id,status=status,topic_id=topic_id)
    with connect() as c:
        topic=c.execute('SELECT id,title,description FROM topics WHERE id=?',(topic_id,)).fetchone() if topic_id else None
        chapters=c.execute('''SELECT ch.id,ch.title,COUNT(i.id) item_count,
          SUM(CASE WHEN i.kind='lesson' THEN 1 ELSE 0 END) lessons,
          SUM(CASE WHEN i.kind='question' THEN 1 ELSE 0 END) questions,
          SUM(CASE WHEN i.kind='flashcard' THEN 1 ELSE 0 END) flashcards
          FROM chapters ch LEFT JOIN items i ON i.chapter_id=ch.id
          WHERE (?='' OR ch.id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?))
          AND (?='' OR ch.id=?) GROUP BY ch.id ORDER BY ch.order_num,ch.title''',(topic_id,topic_id,chapter_id,chapter_id)).fetchall()
    payload={'format':'network-learning-topic-report-v1','exported_at':now_iso(),'topic':dict(topic) if topic else {'id':'','title':'همهٔ موضوع‌ها'},'chapters':[dict(x) for x in chapters],'report':report}
    data=json.dumps(payload,ensure_ascii=False,indent=2).encode('utf-8')
    return Response(data,media_type='application/json; charset=utf-8',headers={'Content-Disposition':'attachment; filename="topic-learning-report.json"'})

@app.get('/api/reports/progress-comparison')
def progress_comparison(topic_id: str = '', days: int = 30):
    days=max(7,min(int(days),365)); today=user_datetime().date(); split=today-timedelta(days=days//2); start=today-timedelta(days=days)
    with connect() as c:
        def get_period(a,b):
            topic_clause=" AND EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)" if topic_id else ''
            args=[a.isoformat(),b.isoformat()]+([topic_id] if topic_id else [])
            q=c.execute("SELECT COUNT(*) attempts,COALESCE(SUM(a.correct),0) correct,COUNT(DISTINCT a.question_item_id) unique_questions FROM assessment_attempts a JOIN items i ON i.id=a.question_item_id WHERE date(a.created_at) BETWEEN date(?) AND date(?)"+topic_clause,args).fetchone()
            r=c.execute("SELECT COUNT(*) n,COUNT(DISTINCT rh.item_id) cards FROM review_history rh JOIN items i ON i.id=rh.item_id WHERE date(rh.reviewed_at) BETWEEN date(?) AND date(?)"+topic_clause.replace('i.chapter_id','i.chapter_id'),args).fetchone()
            targs=[a.isoformat(),b.isoformat()]+([topic_id] if topic_id else [])
            t=c.execute("SELECT COUNT(*) n,SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) completed FROM tasks WHERE date(COALESCE(NULLIF(planned_start,''),NULLIF(due_at,''))) BETWEEN date(?) AND date(?)"+(" AND chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?)" if topic_id else ''),targs).fetchone()
            return {'from':a.isoformat(),'to':b.isoformat(),'question_attempts':int(q['attempts'] or 0),'correct':int(q['correct'] or 0),'accuracy':round(100*int(q['correct'] or 0)/int(q['attempts']),1) if q['attempts'] else None,'unique_questions':int(q['unique_questions'] or 0),'reviews':int(r['n'] or 0),'unique_cards':int(r['cards'] or 0),'tasks':int(t['n'] or 0),'completed_tasks':int(t['completed'] or 0)}
        return {'topic_id':topic_id,'days':days,'previous':get_period(start,split-timedelta(days=1)),'current':get_period(split,today),'note':'مقایسه بر پایهٔ رویدادهای ثبت‌شده در دو نیمهٔ بازه است؛ مقدار صفر لزوماً به معنی افت یادگیری نیست.'}

@app.get('/api/commands/catalog')
def command_catalog(q:str='', chapter_id:str='', platform:str='all', risk:str='all', verified_only:bool=False, limit:int=100, offset:int=0):
    limit=max(1,min(int(limit),300)); offset=max(0,int(offset))
    where=["i.kind='command'"]; args=[]
    if chapter_id: where.append('i.chapter_id=?'); args.append(chapter_id)
    if verified_only: where.append("i.source_status='verified'")
    if q.strip():
        pat=f'%{q.strip()[:120]}%'; where.append('(i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.metadata_json LIKE ?)'); args.extend([pat,pat,pat,pat])
    if platform!='all': where.append("(json_extract(i.metadata_json,'$.platform')=? OR json_extract(i.metadata_json,'$.vendor')=? OR json_extract(i.metadata_json,'$.os')=?)"); args.extend([platform,platform,platform])
    if risk!='all': where.append("json_extract(i.metadata_json,'$.risk')=?"); args.append(risk)
    where_sql=' WHERE '+' AND '.join(where)
    with connect() as c:
        total=c.execute('SELECT COUNT(*) n FROM items i'+where_sql,args).fetchone()['n']
        rows=c.execute('SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id'+where_sql+' ORDER BY i.source_status ASC,i.title COLLATE NOCASE LIMIT ? OFFSET ?',args+[limit,offset]).fetchall()
    return {'items':[item_public(r) for r in rows],'count':len(rows),'total_count':total,'offset':offset,'limit':limit,'has_more':offset+len(rows)<total}


@app.get('/api/export/tasks')
def export_tasks():
    with connect() as c:
        tasks=[task_public(r) for r in c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id ORDER BY planned_start,id')]
        plans=[]
        for r in c.execute('SELECT * FROM study_plans ORDER BY start_date,id'):
            d=dict(r); d['active_chapters']=json.loads(d.pop('active_chapters_json') or '[]'); plans.append(d)
        entries=[dict(r) for r in c.execute('SELECT * FROM time_entries ORDER BY id')]
    payload=json.dumps({'format':'network-learning-planning-v1','exported_at':now_iso(),'tasks':tasks,'plans':plans,'time_entries':entries},ensure_ascii=False,indent=2).encode('utf-8')
    return Response(payload,media_type='application/json; charset=utf-8',headers={'Content-Disposition':'attachment; filename="learning-planning.json"'})


# ---- Universal learning architecture / course builder v0.05 -----------------------
def _learning_profiles():
    path=BASE/'config'/'learning_profiles_fa.json'
    try:
        raw=json.loads(path.read_text(encoding='utf-8'))
        return raw.get('profiles',{}) if isinstance(raw,dict) else {}
    except Exception:
        return {}

COURSE_LEVELS={'beginner':'مبتدی','intermediate':'متوسط','advanced':'پیشرفته','expert':'خبره'}
COURSE_GOALS={'understanding':'فهم عمیق','exam':'آمادگی آزمون','practice':'کسب مهارت عملی','research':'مطالعه و پژوهش تخصصی'}
COURSE_FORMATS={'text':'متن‌محور','quiz':'آزمون‌محور','lab':'تمرین و پروژه‌محور','mixed':'ترکیبی'}

@app.get('/api/learning/architecture')
def learning_architecture():
    profiles=_learning_profiles()
    return {'ok':True,'architecture_version':1,'app_version':APP_VERSION,'profiles':profiles,
      'shared_capabilities':['مدیریت موضوع و فصل','مطالعه و یادداشت شخصی','فلش‌کارت و مرور فاصله‌دار','آزمون و تاریخچه تلاش','تمرین و پاسخ‌نامه مرحله‌ای','برنامه‌ریز و زمان‌سنج','جست‌وجو و گزارش','پشتیبان و بازیابی','واردسازی و بازبینی محتوا'],
      'domain_specific_capabilities':{k:v.get('tools',[]) for k,v in profiles.items()},
      'assessment_dimensions':{'knowledge':'دانش و درک','execution':'اجرای عملی','reasoning':'تحلیل و استدلال','communication':'گزارش و ارتباط','safety':'ایمنی و رعایت محدوده'},
      'content_contract':'network-learning-content-pack-v2','backup_schema_version':5}

class CourseBlueprintIn(BaseModel):
    title: str
    domain_profile: str
    level: str = 'beginner'
    goal: str = 'practice'
    format: str = 'mixed'
    language: str = 'fa-IR'
    chapter_count: int = 8
    weekly_hours: float = 6
    audience_notes: str = ''
    environment: str = 'محیط محلی، مجاز و کنترل‌شده'
    include_practice: bool = True
    include_quiz: bool = True
    include_flashcards: bool = True
    include_project: bool = True
    sources_required: bool = True
    extra_instructions: str = ''
    prompt_model: str = 'comprehensive'
    depth: str = 'deep'
    scope: str = ''
    prerequisites: str = ''
    platforms: str = ''
    include_troubleshooting: bool = True
    include_commands: bool = True
    include_pitfalls: bool = True
    include_security: bool = True
    include_verification: bool = True
    include_variants: bool = True
    outline_titles: str = ''

PROMPT_MODELS={
 'comprehensive':'جامع چندبُعدی', 'troubleshooting':'عیب‌یابی و تعمیر گام‌به‌گام',
 'commands':'مرجع فرمان و اسکریپت', 'security_dual':'امنیت: ارزیابی کنترل‌شده و دفاع',
 'textbook':'کتاب درسی و آموزش مفهومی', 'project':'پروژه‌محور با تحویل‌دادنی',
 'research':'پژوهش و منابع قابل‌ردیابی', 'mixed':'ترکیب سفارشی چند الگو'}
PROMPT_MODEL_GUIDANCE={
 'comprehensive':'همهٔ ابعاد مفهومی، عملی، تشخیصی، امنیتی، ارزیابی و نگهداشت را متوازن پوشش بده.',
 'troubleshooting':'برای هر مشکل: نشانه‌ها، محدودهٔ اثر، فرضیه‌ها از محتمل به کم‌احتمال، جمع‌آوری شواهد، آزمون کم‌خطر، تشخیص ریشه‌ای، تعمیر مرحله‌ای، راستی‌آزمایی پس از تعمیر، rollback، ثبت گزارش و پیشگیری را بیاور. قبل از تغییر مخرب نسخهٔ پشتیبان و تأیید انسانی را الزام کن.',
 'commands':'برای هر فرمان: سیستم‌عامل/محصول و نسخه، هدف، نحو، پارامترها، سطح دسترسی، پیش‌نیاز، مثال واقعی با دادهٔ ساختگی، خروجی نمونه، تفسیر، خطاهای رایج، اثر جانبی، روش تأیید و روش بازگشت را درج کن. PowerShell، CMD، Linux shell و CLI محصول را فقط در صورت ارتباط پوشش بده؛ دستورهای خطرناک را علامت‌گذاری کن.',
 'security_dual':'هر موضوع امنیتی را در دو مسیر دفاع و ارزیابی مجاز آموزش بده: مدل تهدید، پیش‌شرط‌ها، شواهد، بازتولید محدود در آزمایشگاه ایزوله با دادهٔ ساختگی، تشخیص، لاگ، کاهش ریسک، اصلاح، آزمون مجدد و قواعد توقف. از هدف واقعی یا راهنمای عملی سوءاستفاده غیرمجاز استفاده نکن.',
 'textbook':'تعریف دقیق، شهود، مدل ذهنی، واژه‌نامه، مثال حل‌شده، مثال نقض، برداشت غلط، تمرین تدریجی، سؤال مفهومی، جمع‌بندی و آزمون پایان فصل ارائه کن.',
 'project':'خروجی نهایی قابل‌تحویل، مراحل، backlog، معیار پذیرش، معماری، محدودیت‌ها، تست‌ها، مستندات، گزارش نقص، دمو، rollback و روبریک امتیازدهی تعیین کن.',
 'research':'پرسش پژوهش، روش، محدوده، واژه‌های جست‌وجو، منابع اولیه، تاریخ دسترسی، سطح شواهد، اختلاف منابع، محدودیت و شکاف دانشی را گزارش کن. منبع یا نقل‌قول ساختگی ممنوع است؛ اگر منبع قابل‌تأیید نیست، آن را نامشخص اعلام کن.',
 'mixed':'الگوهای مفهومی، مرجع فرمان، عیب‌یابی، امنیت دفاعی، تمرین، پروژه و پژوهش را با توجه به موضوع ترکیب کن؛ بخش‌های غیرمرتبط را صریحاً «نامرتبط» علامت بزن و همه را به‌صورت مصنوعی وارد نکن.'}


def _course_blueprint_build(payload: CourseBlueprintIn, profile: dict):
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان دوره الزامی است')
    if payload.level not in COURSE_LEVELS: raise HTTPException(400,'سطح دوره نامعتبر است')
    if payload.goal not in COURSE_GOALS: raise HTTPException(400,'هدف دوره نامعتبر است')
    if payload.format not in COURSE_FORMATS: raise HTTPException(400,'قالب دوره نامعتبر است')
    if payload.prompt_model not in PROMPT_MODELS: raise HTTPException(400,'الگوی پرامپت نامعتبر است')
    if payload.depth not in {'deep','reference','progressive'}: raise HTTPException(400,'عمق محتوا نامعتبر است')
    outline_titles=[x.strip().lstrip('#').strip() for x in re.split(r'[\r\n]+',payload.outline_titles or '') if x.strip()]
    if len(outline_titles)>32: raise HTTPException(400,'حداکثر ۳۲ عنوان فصل قابل ثبت است')
    if not outline_titles and not 3 <= payload.chapter_count <= 32: raise HTTPException(400,'تعداد فصل باید بین ۳ تا ۳۲ باشد؛ یا عنوان‌های دلخواه را در فهرست فصل‌ها بنویس')
    if not 1 <= payload.weekly_hours <= 60: raise HTTPException(400,'زمان هفتگی باید بین ۱ تا ۶۰ ساعت باشد')
    chapters_source=profile.get('chapters') or []
    if not chapters_source: chapters_source=['مبانی و تعیین سطح','مفاهیم اصلی','تمرین هدایت‌شده','کاربرد و پروژه','مرور و ارزیابی']
    chapter_titles=outline_titles or [chapters_source[idx] if idx < len(chapters_source) else f'کاربرد پیشرفته و تمرین تلفیقی {idx+1}' for idx in range(payload.chapter_count)]
    chapters=[]
    for idx,base_title in enumerate(chapter_titles):
        chapter_id=f'ch-{idx+1:02d}'
        outcomes=[f'بتواند مفهوم «{base_title}» را با زبان خود توضیح دهد',f'بتواند یک فعالیت متناسب با هدف «{COURSE_GOALS[payload.goal]}» را انجام دهد']
        activities=[]
        if payload.format in ('text','mixed'): activities.append('درس تشریحی و مثال حل‌شده')
        if payload.include_practice and payload.format in ('lab','mixed'): activities.append('تمرین هدایت‌شده و سپس تمرین مستقل')
        if payload.include_quiz: activities.append('آزمون کوتاه با توضیح پاسخ')
        if payload.include_flashcards: activities.append('فلش‌کارت و مرور فاصله‌دار')
        if payload.include_project and idx==len(chapter_titles)-1: activities.append('پروژهٔ تلفیقی با روبریک')
        chapters.append({'id':chapter_id,'order':idx+1,'title':base_title,'estimated_hours':round(max(1,(40/len(chapter_titles))/max(1,payload.weekly_hours/6)),1),
          'prerequisites':[f'ch-{idx:02d}'] if idx else [],'learning_outcomes':outcomes,'activity_types':activities,
          'domain_tools':profile.get('tools',[]),'assessment_dimensions':profile.get('assessment',[])})
    competencies=[]
    for i,dim in enumerate(profile.get('assessment',[]),1):
        competencies.append({'id':f'comp-{i:02d}','title':dim,'evidence_required':'پاسخ یا خروجی قابل‌بررسی از تمرین مستقل','statuses':['not_started','practicing','demonstrated','needs_review']})
    rubric=[{'dimension':'دانش و درک مفاهیم','weight':20},{'dimension':'اجرای عملی یا تحلیل متن/مسئله','weight':30},{'dimension':'تحلیل و استدلال','weight':25},{'dimension':'گزارش، ارجاع و توضیح','weight':15},{'dimension':'ایمنی، اخلاق و محدوده','weight':10}]
    if payload.domain_profile=='cybersecurity':
        rubric[-1]['mandatory_gate']=True
        rubric[-1]['rule']='هرگونه خروج از محدودهٔ مجاز یا آسیب‌رسانی، مستقل از نمره، مانع قبولی است.'
    blueprint={'format':'network-learning-course-blueprint-v1','title':title,'domain_profile':payload.domain_profile,'domain_title':profile.get('title','حوزهٔ عمومی'),
      'level':payload.level,'level_label':COURSE_LEVELS[payload.level],'goal':payload.goal,'goal_label':COURSE_GOALS[payload.goal],
      'learning_format':payload.format,'format_label':COURSE_FORMATS[payload.format],'language':payload.language,'estimated_weekly_hours':payload.weekly_hours,
      'prompt_model':payload.prompt_model,'prompt_model_label':PROMPT_MODELS[payload.prompt_model],'depth':payload.depth,
      'scope':payload.scope.strip(),'outline_titles':chapter_titles,'prerequisites_notes':payload.prerequisites.strip(),'platforms':payload.platforms.strip(),
      'content_coverage':{'troubleshooting':payload.include_troubleshooting,'commands_and_scripts':payload.include_commands,'pitfalls_and_tips':payload.include_pitfalls,'security_offense_defense':payload.include_security,'verification_and_rollback':payload.include_verification,'alternative_scenarios':payload.include_variants},
      'audience_notes':payload.audience_notes.strip(),'environment':payload.environment.strip(),'profile_template':profile.get('template','general_competency'),
      'shared_tools':['پیش‌آزمون تعیین سطح','اهداف قابل‌سنجش','یادداشت و ارجاع','جست‌وجو','تاریخچهٔ تلاش','مرور فاصله‌دار','برنامهٔ روزانه','پشتیبان‌گیری'],
      'domain_tools':profile.get('tools',[]),'assessment_dimensions':profile.get('assessment',[]),'competencies':competencies,'chapters':chapters,
      'rubric':rubric,'pass_policy':{'suggested_total_score':80,'requires_independent_practice':bool(payload.include_practice),'safety_gate':payload.domain_profile=='cybersecurity'},
      'content_requirements':{'lesson_explanation':True,'worked_example':True,'guided_practice':bool(payload.include_practice),'independent_practice':bool(payload.include_practice),'quiz':bool(payload.include_quiz),'flashcards':bool(payload.include_flashcards),'project':bool(payload.include_project),'source_citations':bool(payload.sources_required),'answer_key_separate':True,'false_positives_and_limits':payload.domain_profile in ('cybersecurity','network_it','virtualization')},
      'authoring_notes':payload.extra_instructions.strip()}
    depth_label={'deep':'عمیق و کامل','reference':'مرجع جامع و قابل مراجعه','progressive':'مرحله‌ای از پایه تا پیشرفته'}[payload.depth]
    prompt=f"""نقش: طراح برنامهٔ درسی، نویسندهٔ فنی، مدرس عملی و ارزیاب سخت‌گیر.
الگوی منتخب: {PROMPT_MODELS[payload.prompt_model]}
راهنمای الگو: {PROMPT_MODEL_GUIDANCE[payload.prompt_model]}
عمق محتوا: {depth_label}

مشخصات دوره
- عنوان: {title}
- حوزه: {profile.get('title')}
- سطح شروع: {COURSE_LEVELS[payload.level]}
- هدف: {COURSE_GOALS[payload.goal]}
- قالب: {COURSE_FORMATS[payload.format]}
- زبان: {payload.language}
- ساعت هفتگی: {payload.weekly_hours}
- پیش‌زمینه: {payload.audience_notes or 'ابتدا تعیین سطح کن؛ پیش‌فرض نساز'}
- محدوده و سرفصل‌های الزامی: {payload.scope or 'از پروفایل تخصصی و هدف دوره استنتاج کن، سپس پوشش را در ماتریس پوشش ثبت کن'}
- پیش‌نیازهای مشخص‌شده: {payload.prerequisites or 'پیش‌آزمون تشخیصی بساز و پیش‌نیازها را صریح اعلام کن'}
- پلتفرم/نسخه/ابزار: {payload.platforms or 'نسخه را حدس نزن؛ در صورت وابستگی به نسخه، نسخهٔ هدف و تاریخ اعتبار را اعلام کن'}
- محیط: {payload.environment}

الزامات جامعیت — هر مورد مرتبط را پوشش بده و برای موارد نامرتبط دلیل بیاور:
1) مبانی و مدل ذهنی؛ تعریف اصطلاحات، پیش‌نیازها، چرایی و نحوهٔ کار، محدودیت‌ها و وابستگی‌ها.
2) آموزش مرحله‌ای از پایه تا سطح انتخابی؛ مثال حل‌شده، مثال نقض، سناریوهای ساده/واقعی/ترکیبی و تمرین با راهنمایی تدریجی.
3) عیب‌یابی و تعمیر: نشانه، اثر، فرضیه، جمع‌آوری شواهد، ابزار تشخیص، درخت تصمیم، ترتیب آزمون از کم‌خطر به پرخطر، علت ریشه‌ای، اصلاح، راستی‌آزمایی، rollback، گزارش و پیشگیری.
4) فرمان‌ها و اسکریپت‌ها در صورت ارتباط: PowerShell، CMD، Bash و CLI محصول؛ نسخه/ماژول لازم، سطح دسترسی، ورودی، خروجی نمونه، تفسیر، خطاهای رایج، اثر جانبی، روش تست و بازگشت. برای Active Directory/Domain در صورت ارتباط، cmdletهای مرتبط با کاربران/گروه‌ها، DNS، DHCP، GPO، سرویس‌ها، رویدادها و عیب‌یابی را با دادهٔ ساختگی و اصل کمترین دسترسی توضیح بده. فرمان‌ها را بدون توضیح اجراپذیر و بی‌قید ارائه نکن.
5) خطاها و باگ‌ها: پیام خطا، علت‌های محتمل، نحوهٔ تفکیک علت‌ها، بازتولید در محیط آزمایش، راهکار اصلاح، آزمون regression و شرایطی که نیاز به escalation دارد.
6) نکته‌ها، قلق‌ها، میانبرهای امن، best practice، ضدالگوها، برداشت‌های اشتباه، تله‌های آزمون، اشتباه‌های رایج و روش جلوگیری از تکرار.
7) امنیت: ریسک، سوءاستفادهٔ محتمل و نشانه‌های کشف، hardening، لاگ و مانیتورینگ، کنترل پیشگیرانه/کاشف/پاسخ‌گو و اعتبارسنجی اصلاح. تست نفوذ فقط در محدودهٔ مجاز و آزمایشگاه ایزوله؛ هیچ هدف واقعی یا اقدام غیرمجاز پیشنهاد نکن.
8) ارزیابی: سؤال دانشی، سناریوی تشخیصی، تمرین مستقل، آزمون عملی، پاسخ تشریحی جداگانه، معیار قبولی روشن و روبریک. پاسخ را بلافاصله زیر صورت سؤال قرار نده؛ کلید پاسخ را در بخش مجزا بگذار.
9) منابع: مستندات رسمی و منابع اولیهٔ قابل‌ردیابی. نام/URL/نسخه/تاریخ را فقط وقتی مطمئنی ثبت کن؛ منبع، خروجی فرمان، نتیجهٔ تست یا نقل‌قول ساختگی نساز. اگر دسترسی به منبع نداری، این محدودیت را آشکار کن.
10) پوشش را با ماتریس «موضوع × نوع محتوا × سطح × وضعیت» گزارش کن؛ هیچ سرفصل الزامی را بی‌صدا حذف نکن. محتوا باید برای استفادهٔ مرجع، جست‌وجو و مرور آینده ساختاربندی شود.

سوئیچ‌های محتوایی انتخاب‌شده:
{json.dumps({'troubleshooting':payload.include_troubleshooting,'commands_and_scripts':payload.include_commands,'pitfalls_and_tips':payload.include_pitfalls,'security_offense_defense':payload.include_security,'verification_and_rollback':payload.include_verification,'alternative_scenarios':payload.include_variants,'practice':payload.include_practice,'quiz':payload.include_quiz,'flashcards':payload.include_flashcards,'project':payload.include_project,'traceable_sources':payload.sources_required},ensure_ascii=False,indent=2)}

پروفایل تخصصی:
{json.dumps(profile,ensure_ascii=False,indent=2)}

طرح ساختاری — ترتیب و شناسهٔ فصل‌ها را بدون اجازه تغییر نده:
{json.dumps(blueprint,ensure_ascii=False,indent=2)}

قرارداد خروجی: یک ZIP قابل‌واردکردن در برنامه با content_pack.json مطابق network-learning-content-pack-v2؛ فصل‌ها و آیتم‌ها شناسهٔ پایدار و یکتا داشته باشند و chapter_id هر آیتم به فصل موجود اشاره کند. هر سؤال چندگزینه‌ای باید گزینه‌ها، correct_index صفرمبنا و توضیح هر گزینه را داشته باشد. هر آزمایشگاه باید پیش‌نیاز، محدودهٔ مجاز، گام‌ها، شواهد مورد انتظار، راهنمایی مرحله‌ای، پاسخ تشریحی جدا، معیار قبولی و پاک‌سازی محیط داشته باشد. همهٔ محتوا source_status=review_required بماند. بسته را قبل از تحویل parse و اعتبارسنجی کن و گزارش خطا/کمبود بده.

قواعد: دقت و پوشش مهم‌تر از پرکردن مصنوعی تعداد است. اگر موضوعی به نسخه، محصول، مقررات یا منابع روز وابسته است، آن را تاریخ‌دار کن. واقعیت، فرض، پیشنهاد و مورد نیازمند بررسی انسانی را جدا کن. پاسخ ناقص را «کامل» معرفی نکن.

دستور اضافه:
{payload.extra_instructions or 'ندارد'}"""
    return blueprint,prompt

def _book_source_info(title: str, author: str='', edition: str='', publication_year: str='', publisher: str='', source_url: str='', isbn: str='', file_name: str='', file_sha256: str='', file_format: str='', chapter_title: str='') -> dict:
    return {k:v for k,v in {
        'title':title.strip(), 'author':author.strip(), 'edition':edition.strip(),
        'publication_year':publication_year.strip(), 'publisher':publisher.strip(),
        'url':source_url.strip(), 'isbn':isbn.strip(), 'file_name':file_name,
        'file_sha256':file_sha256, 'file_format':file_format, 'chapter_title':chapter_title
    }.items() if v}


def _read_book_upload(filename: str, raw: bytes) -> tuple[str, dict]:
    ext=Path(filename).suffix.lower()
    if len(raw)>30*1024*1024:
        raise HTTPException(413,'فایل منبع بیش از ۳۰ مگابایت است.')
    if ext not in {'.pdf','.docx','.txt','.md','.markdown','.rst'}:
        raise HTTPException(415,'نوع فایل پشتیبانی نمی‌شود؛ از PDF متنی، DOCX، TXT، Markdown یا RST استفاده کن. EPUB/HTML و PDF اسکن‌شده بدون OCR در این مرحله پشتیبانی نمی‌شوند.')
    if ext=='.pdf':
        try:
            from pypdf import PdfReader
            reader=PdfReader(BytesIO(raw))
            if len(reader.pages)>10000: raise HTTPException(413,'تعداد صفحات PDF بسیار زیاد است.')
            text='\n\n'.join((p.extract_text() or '') for p in reader.pages)
            page_count=len(reader.pages)
        except HTTPException: raise
        except Exception as exc: raise HTTPException(400,'خواندن PDF ناموفق بود: '+str(exc)[:240])
        info={'file_format':'pdf','page_count':page_count,'extraction_method':'pypdf text extraction; no OCR'}
    elif ext=='.docx':
        try: text=extract_docx(raw)
        except Exception as exc: raise HTTPException(400,'خواندن DOCX ناموفق بود: '+str(exc)[:240])
        info={'file_format':'docx','page_count':None,'extraction_method':'python-docx paragraphs and tables'}
    else:
        text=raw.decode('utf-8-sig',errors='replace')
        info={'file_format':ext.lstrip('.'),'page_count':None,'extraction_method':'UTF-8 text decode'}
    if len(text)>12_000_000: raise HTTPException(413,'متن استخراج‌شده از ۱۲ میلیون نویسه بیشتر است؛ فایل را به چند بخش تقسیم کن.')
    if len(text.strip())<80:
        raise HTTPException(422,'متن قابل‌استفاده کافی استخراج نشد. اگر PDF تصویری/اسکن‌شده است، ابتدا با ابزار OCR مورداعتماد به متن قابل جست‌وجو تبدیلش کن.')
    info.update({'file_name':Path(filename).name,'file_sha256':hashlib.sha256(raw).hexdigest(),'character_count':len(text),'word_count':len(re.findall(r'\S+',text))})
    return text,info


def _book_heading_candidates(text: str) -> list[tuple[int,str]]:
    candidates=[]
    patterns=[
        r'(?m)^\s{0,3}#{1,3}\s+(.{2,180}?)\s*#*\s*$',
        r'(?im)^\s*(?:فصل|بخش|درس|chapter|part|unit|section)\s*(?:شماره\s*)?(?:[۰-۹0-9]+|[IVXLC]+)?\s*[:：.\-–—)]?\s+.{2,180}$',
        r'(?m)^\s*(?:[۰-۹0-9]{1,2}(?:\.[۰-۹0-9]{1,2}){0,2})\s+[\u0600-\u06FFA-Za-z].{2,160}$'
    ]
    for pi,pat in enumerate(patterns):
        for m in re.finditer(pat,text):
            line=(m.group(1) if pi==0 else m.group(0)).strip().strip('#').strip()
            if len(line)>180: continue
            if line and not any(abs(m.start()-p[0])<8 for p in candidates): candidates.append((m.start(),line))
    candidates.sort(key=lambda x:x[0])
    seen=set(); out=[]
    for pos,title in candidates:
        key=re.sub(r'\W+','',title).lower()
        if key and key not in seen:
            seen.add(key); out.append((pos,title))
    return out[:32]


def _split_book_text(text: str, mode: str, title_lines: str, target_count: int) -> tuple[list[dict], list[str]]:
    warnings=[]
    detected=_book_heading_candidates(text)
    manual=[x.strip().lstrip('#').strip() for x in re.split(r'[\r\n]+',title_lines or '') if x.strip()]
    manual=manual[:32]
    if manual:
        positions=[]
        for heading in manual:
            idx=text.find(heading)
            if idx<0: idx=text.lower().find(heading.lower())
            if idx<0:
                positions=[]; warnings.append('برخی عنوان‌های دستی عیناً در متن منبع پیدا نشدند؛ تقسیم متن به‌صورت تقریبی بر اساس بندها انجام شد.'); break
            positions.append((idx,heading))
        if positions and positions==sorted(positions,key=lambda x:x[0]) and len({p[0] for p in positions})==len(positions):
            parts=[]
            if positions[0][0]>0: parts.append({'title':'مقدمه و بخش پیش از اولین عنوان','text':text[:positions[0][0]].strip()})
            for i,(pos,heading) in enumerate(positions):
                end=positions[i+1][0] if i+1<len(positions) else len(text)
                parts.append({'title':heading,'text':text[pos:end].strip()})
            parts=[p for p in parts if p['text']]
            return parts[:32],warnings
    if mode=='manual' and not manual:
        warnings.append('حالت دستی انتخاب شده اما عنوانی وارد نشده است؛ تقسیم تقریبی انجام شد. عنوان‌ها را قبل از واردکردن بازبینی کن.')
    if mode=='auto' and len(detected)>=2:
        parts=[]
        if detected[0][0]>0: parts.append({'title':'مقدمه','text':text[:detected[0][0]].strip()})
        for i,(pos,heading) in enumerate(detected):
            end=detected[i+1][0] if i+1<len(detected) else len(text)
            chunk=text[pos:end].strip()
            if chunk: parts.append({'title':heading,'text':chunk})
        parts=[p for p in parts if p['text']]
        return parts[:32],warnings
    if mode=='auto': warnings.append('عنوان فصل‌های قابل‌اعتماد به‌طور خودکار تشخیص داده نشد؛ متن به بخش‌های تقریبی تقسیم شد. عنوان‌ها را قبل از واردکردن بازبینی کن.')
    paras=[p.strip() for p in re.split(r'\n\s*\n+',text) if p.strip()]
    if not paras: paras=[text.strip()]
    n=max(1,min(32,target_count or 8)); total=sum(len(p) for p in paras); target=max(1,total/n)
    groups=[]; cur=[]; size=0
    for p in paras:
        if cur and size>=target and len(groups)<n-1:
            groups.append('\n\n'.join(cur)); cur=[]; size=0
        cur.append(p); size+=len(p)
    if cur: groups.append('\n\n'.join(cur))
    return [{'title':f'بخش {i+1:02d} — نیازمند نام‌گذاری و بازبینی','text':chunk} for i,chunk in enumerate(groups)],warnings


def _text_sentences(text: str, limit: int=4) -> list[str]:
    compact=re.sub(r'\s+',' ',text).strip()
    bits=re.split(r'(?<=[.!؟?])\s+|(?<=۔)\s+',compact)
    return [b.strip() for b in bits if len(b.strip())>=24][:limit]


@app.post('/api/course-builder/book/inspect')
async def inspect_book_source(file: UploadFile=File(...), book_title: str=Form(''), author: str=Form(''), edition: str=Form(''), publication_year: str=Form(''), publisher: str=Form(''), source_url: str=Form(''), isbn: str=Form(''), split_mode: str=Form('auto'), chapter_count: int=Form(8), chapter_titles: str=Form('')):
    raw=await file.read(30*1024*1024+1)
    text,info=_read_book_upload(file.filename or 'source.txt',raw)
    if source_url.strip() and not re.match(r'^https?://[^\s]+$',source_url.strip(),re.I): raise HTTPException(400,'نشانی منبع باید با http:// یا https:// آغاز شود.')
    parts,warnings=_split_book_text(text,split_mode,chapter_titles,chapter_count)
    info.update({'title':book_title.strip() or infer_title(file.filename or 'source',text),'author':author.strip(),'edition':edition.strip(),'publication_year':publication_year.strip(),'publisher':publisher.strip(),'isbn':isbn.strip(),'source_url':source_url.strip(),'detected_headings':[x[1] for x in _book_heading_candidates(text)[:32]],'planned_chapters':[{'order':i+1,'title':p['title'],'characters':len(p['text']),'words':len(re.findall(r'\S+',p['text']))} for i,p in enumerate(parts)],'warnings':warnings,'generation_mode':'source_extraction_without_ai','notice':'این ابزار متن منبع را استخراج و تقسیم می‌کند؛ بدون مدل زبانی، خلاصهٔ معنایی/توضیح تکمیلی/تأیید صحت تولید نمی‌کند.'})
    return {'ok':True,'source':info}


@app.post('/api/course-builder/book-to-pack')
async def book_to_course_pack(file: UploadFile=File(...), book_title: str=Form(''), author: str=Form(''), edition: str=Form(''), publication_year: str=Form(''), publisher: str=Form(''), source_url: str=Form(''), isbn: str=Form(''), topic_title: str=Form('مطالعه از منبع'), split_mode: str=Form('auto'), chapter_count: int=Form(8), chapter_titles: str=Form(''), include_source_text: bool=Form(True), include_extracts: bool=Form(True), include_glossary: bool=Form(False), include_definition_cards: bool=Form(False), include_review_questions: bool=Form(True)):
    raw=await file.read(30*1024*1024+1)
    text,info=_read_book_upload(file.filename or 'source.txt',raw)
    if source_url.strip() and not re.match(r'^https?://[^\s]+$',source_url.strip(),re.I): raise HTTPException(400,'نشانی منبع باید با http:// یا https:// آغاز شود.')
    if split_mode not in {'auto','manual','count'}: split_mode='auto'
    if not 1<=chapter_count<=32: raise HTTPException(400,'تعداد فصل باید بین ۱ تا ۳۲ باشد.')
    if not any((include_source_text,include_extracts,include_glossary,include_definition_cards,include_review_questions)):
        raise HTTPException(400,'حداقل یک نوع خروجی را انتخاب کن.')
    parts,warnings=_split_book_text(text,split_mode,chapter_titles,chapter_count)
    if not parts: raise HTTPException(422,'هیچ بخش قابل‌ساختی از متن استخراج نشد.')
    title=book_title.strip() or infer_title(file.filename or 'source',text)
    source=_book_source_info(title,author,edition,publication_year,publisher,source_url,isbn,info['file_name'],info['file_sha256'],info['file_format'])
    pack={'format':'network-learning-content-pack-v2','version':2,'title':title,'description':'بستهٔ استخراج متن منبع بدون تولید هوش مصنوعی؛ همهٔ موارد برای بازبینی انسانی علامت‌گذاری شده‌اند.','metadata':{'generator':'Network Learning v0.06 Book-to-Course','generation_mode':'source_extraction_without_ai','requires_human_review':True,'sample_only':False,'source_book':source,'extraction':{k:info.get(k) for k in ('file_format','extraction_method','character_count','word_count','page_count')},'warnings':warnings,'copyright_reminder':'واردکردن و توزیع متن کتاب باید با مجوز و حقوق استفادهٔ شما سازگار باشد.'},'sources':[source] if source else [],'topic':{'title':topic_title.strip() or 'مطالعه از منبع'},'chapters':[],'items':[]}
    for idx,part in enumerate(parts,1):
        cid=f'book-ch-{idx:02d}'
        ch_title=part['title'][:220]
        pack['chapters'].append({'id':cid,'title':ch_title,'order_num':idx,'group_name':'book_import','description':'استخراج مستقیم از منبع؛ پیش از مطالعه باید عنوان‌بندی و پوشش بازبینی شود.'})
        src_ref=dict(source); src_ref['chapter_title']=ch_title
        def add_item(kind,item_title,content='',summary='',metadata=None):
            pack['items'].append({'uid':f'{cid}-{len(pack["items"])+1:04d}','chapter_id':cid,'kind':kind,'title':item_title[:240],'summary':summary[:2000],'content':content,'source_status':'review_required','source_file':info['file_name'],'metadata':{'source_reference':src_ref,'source_status':'review_required','needs_human_review':True,'generation_mode':'source_extraction_without_ai',**(metadata or {})}})
        chunk=part['text']
        if include_source_text:
            # Split content blocks to keep each item manageable while preserving exact extracted source text.
            cursor=0; seg=1
            while cursor<len(chunk):
                end=min(len(chunk),cursor+150000)
                if end<len(chunk):
                    boundary=chunk.rfind('\n\n',cursor,end)
                    if boundary>cursor+80000: end=boundary
                excerpt=chunk[cursor:end]
                add_item('lesson',ch_title if seg==1 else f'{ch_title} — ادامهٔ {seg}',excerpt,'متن استخراج‌شدهٔ مستقیم از منبع؛ نه بازنویسی یا راستی‌آزمایی‌شده.',{'record_type':'source_text','segment':seg,'source_extraction_exact':True})
                cursor=end; seg+=1
        if include_extracts:
            sentences=_text_sentences(chunk,4)
            if sentences: add_item('note',f'جمله‌های منتخب — {ch_title}','\n\n'.join('- '+s for s in sentences),'چند جملهٔ منتخب با قاعدهٔ استخراج متنی؛ خلاصهٔ معناییِ تولیدشده توسط AI نیست.',{'record_type':'extractive_sentences','citation_text':' '.join(sentences)})
        if include_review_questions:
            add_item('note',f'پرسش‌های مرور — {ch_title}','\n'.join(f'{n}. {q}' for n,q in enumerate(['هدف اصلی این بخش چیست؟ با نقل محل مربوط از منبع پاسخ بده.','سه اصطلاح یا ادعای کلیدی این بخش کدام‌اند؟ محل آن‌ها را مشخص کن.','کدام نکته هنوز مبهم است و با کدام منبع معتبر باید بررسی شود؟'],1)),'پرسش‌های باز برای یادگیری و ارجاع به متن؛ پاسخ/کلید خودکار تولید نشده است.',{'record_type':'review_prompts','answer_key_generated':False})
        if include_glossary or include_definition_cards:
            terms=[]
            for line in chunk.splitlines():
                m=re.match(r'^\s{0,3}(?:[-*]\s*)?([^:：]{2,80})[:：]\s*(.{15,350})\s*$',line.strip())
                if m: terms.append((m.group(1).strip(),m.group(2).strip()))
                if len(terms)>=20: break
            if not terms:
                for m in re.finditer(r'([^\n.؟]{2,70}?)\s+(?:عبارت است از|به معنی|یعنی)\s+([^\n.؟]{10,250})',chunk):
                    terms.append((m.group(1).strip(),m.group(2).strip()))
                    if len(terms)>=20: break
            for term,definition in terms:
                if include_glossary: add_item('note','واژه‌نامه: '+term,definition,'تعریف استخراج‌شده از الگوی متنی؛ ممکن است ناقص یا نادرست تشخیص داده شده باشد.',{'record_type':'extractive_glossary','term':term,'citation_text':term+' — '+definition})
                if include_definition_cards: add_item('flashcard',term,definition,'فلش‌کارت استخراجی؛ پیش از استفاده صحت تعریف را بازبینی کن.',{'record_type':'extractive_definition_card','front':term,'back':definition,'difficulty':'intermediate'})
    errs=validate_content_pack_v2_data(pack)
    if errs: raise HTTPException(500,'ساخت بسته نامعتبر شد: '+'؛ '.join(errs[:8]))
    outline={'format':'network-learning-book-outline-v1','title':title,'source':source,'split_mode':split_mode,'warnings':warnings,'chapters':[{'id':x['id'],'title':x['title'],'order':x['order_num']} for x in pack['chapters']]}
    report={'ok':True,'generation_mode':'source_extraction_without_ai','requires_human_review':True,'validated':True,'validation_errors':errs,'warnings':warnings,'chapter_count':len(pack['chapters']),'item_count':len(pack['items']),'source':info,'notice':'ساختار ZIP معتبر است؛ کامل‌بودن علمی، مجازبودن توزیع متن و صحت استخراج به‌صورت خودکار تأیید نشده‌اند.'}
    out=BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('content_pack.json',json.dumps(pack,ensure_ascii=False,indent=2))
        zf.writestr('source_manifest.json',json.dumps({'format':'network-learning-source-manifest-v1','sources':[source],'source_file_sha256':info['file_sha256'],'original_file_embedded':False},ensure_ascii=False,indent=2))
        zf.writestr('outline.json',json.dumps(outline,ensure_ascii=False,indent=2))
        zf.writestr('validation_report.json',json.dumps(report,ensure_ascii=False,indent=2))
        zf.writestr('README_IMPORT_FA.md','این ZIP شامل content_pack.json و ساختار قابل‌واردکردن Network Learning است. ابتدا در صفحهٔ واردکردن محتوا پیش‌نمایش و اعتبارسنجی را اجرا کن. این بسته متن منبع را استخراج کرده و با کمک AI بازنویسی نکرده است. موارد review_required هستند. فایل اصلی کتاب داخل ZIP قرار ندارد. حقوق نشر و مجوز استفاده را رعایت کن. PDF اسکن‌شده OCR نمی‌شود.\n')
    out.seek(0)
    filename_safe=re.sub(r'[^A-Za-z0-9._-]+','_',Path(file.filename or 'book').stem)[:80] or 'book'
    return Response(content=out.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="Network_Learning_Book_Course_{filename_safe}.zip"','X-Content-Pack-Chapters':str(len(pack['chapters'])),'X-Content-Pack-Items':str(len(pack['items'])),'X-Content-Pack-Validated':'true'})


@app.get('/api/course-builder/profiles')
def course_builder_profiles():
    return {'ok':True,'profiles':_learning_profiles(),'levels':COURSE_LEVELS,'goals':COURSE_GOALS,'formats':COURSE_FORMATS,'prompt_models':PROMPT_MODELS,'prompt_model_guidance':PROMPT_MODEL_GUIDANCE}

@app.post('/api/course-builder/preview')
def course_builder_preview(payload:CourseBlueprintIn):
    profiles=_learning_profiles(); profile=profiles.get(payload.domain_profile)
    if not profile: raise HTTPException(400,'پروفایل حوزه پیدا نشد')
    blueprint,prompt=_course_blueprint_build(payload,profile)
    return {'ok':True,'blueprint':blueprint,'prompt':prompt}

@app.post('/api/course-builder/blueprints')
def course_builder_save(payload:CourseBlueprintIn):
    profiles=_learning_profiles(); profile=profiles.get(payload.domain_profile)
    if not profile: raise HTTPException(400,'پروفایل حوزه پیدا نشد')
    blueprint,prompt=_course_blueprint_build(payload,profile)
    bid='bp_'+hashlib.sha256((payload.title.strip()+now_iso()+secrets.token_hex(6)).encode()).hexdigest()[:20]
    now=now_iso(); req=payload.model_dump() if hasattr(payload,'model_dump') else payload.dict()
    blueprint['prompt']=prompt
    with connect() as c:
        c.execute('INSERT INTO course_blueprints(id,title,domain_profile,status,request_json,blueprint_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
          (bid,payload.title.strip(),payload.domain_profile,'draft',json.dumps(req,ensure_ascii=False),json.dumps(blueprint,ensure_ascii=False),now,now)); c.commit()
    return {'ok':True,'id':bid,'title':payload.title.strip(),'status':'draft','blueprint':blueprint,'prompt':prompt,'created_at':now}

@app.get('/api/course-builder/blueprints')
def course_builder_list():
    with connect() as c: rows=c.execute('SELECT id,title,domain_profile,status,created_at,updated_at FROM course_blueprints ORDER BY updated_at DESC').fetchall()
    return {'ok':True,'blueprints':[dict(r) for r in rows]}

@app.get('/api/course-builder/blueprints/{blueprint_id}')
def course_builder_get(blueprint_id:str):
    with connect() as c: row=c.execute('SELECT * FROM course_blueprints WHERE id=?',(blueprint_id,)).fetchone()
    if not row: raise HTTPException(404,'طرح دوره پیدا نشد')
    d=dict(row)
    for k in ('request_json','blueprint_json'):
        try: d[k.replace('_json','')]=json.loads(d.pop(k) or '{}')
        except Exception: d[k.replace('_json','')]={}
    return d

@app.delete('/api/course-builder/blueprints/{blueprint_id}')
def course_builder_delete(blueprint_id:str):
    with connect() as c: cur=c.execute('DELETE FROM course_blueprints WHERE id=?',(blueprint_id,)); c.commit()
    if not cur.rowcount: raise HTTPException(404,'طرح دوره پیدا نشد')
    return {'ok':True,'deleted_id':blueprint_id}

class ContentPackValidationIn(BaseModel):
    pack: dict

@app.post('/api/course-builder/validate-pack')
def course_builder_validate_pack(payload:ContentPackValidationIn):
    data=payload.pack; errors=[]; warnings=[]
    if data.get('format')!='network-learning-content-pack-v2': errors.append('format باید network-learning-content-pack-v2 باشد')
    if not str(data.get('title') or '').strip(): errors.append('عنوان بسته خالی است')
    chapters=data.get('chapters'); items=data.get('items')
    if not isinstance(chapters,list) or not chapters: errors.append('حداقل یک فصل در chapters لازم است'); chapters=[]
    if not isinstance(items,list): errors.append('items باید آرایه باشد'); items=[]
    chids=[]
    for i,ch in enumerate(chapters,1):
        if not isinstance(ch,dict): errors.append(f'فصل {i}: باید شیء باشد'); continue
        cid=str(ch.get('id') or '').strip(); title=str(ch.get('title') or '').strip()
        if not cid: errors.append(f'فصل {i}: شناسهٔ id خالی است')
        if not title: errors.append(f'فصل {i}: عنوان خالی است')
        if cid in chids: errors.append(f'شناسهٔ فصل تکراری: {cid}')
        chids.append(cid)
    known=set(chids); item_ids=[]
    allowed={'lesson','flashcard','question','command','example','lab','note','asset'}
    for i,it in enumerate(items,1):
        if not isinstance(it,dict): errors.append(f'محتوای {i}: باید شیء باشد'); continue
        iid=str(it.get('uid') or it.get('id') or '').strip()
        if iid and iid in item_ids: errors.append(f'شناسهٔ محتوا تکراری: {iid}')
        if iid: item_ids.append(iid)
        if str(it.get('chapter_id') or '') not in known: errors.append(f'محتوای {i}: chapter_id به فصل موجود اشاره نمی‌کند')
        if it.get('kind') not in allowed: errors.append(f'محتوای {i}: kind نامعتبر است')
        if not str(it.get('title') or '').strip(): errors.append(f'محتوای {i}: عنوان خالی است')
        meta=it.get('metadata') if isinstance(it.get('metadata'),dict) else {}
        if it.get('kind')=='question':
            opts=meta.get('options',it.get('options',[])); ci=meta.get('correct_index',it.get('correct_index'))
            if not isinstance(opts,list) or len(opts)<2: errors.append(f'سؤال {i}: حداقل دو گزینه لازم است')
            elif not isinstance(ci,int) or isinstance(ci,bool) or not 0<=ci<len(opts): errors.append(f'سؤال {i}: correct_index معتبر نیست')
            if not (meta.get('explanation') or it.get('explanation')): warnings.append(f'سؤال {i}: توضیح پاسخ ندارد')
        if it.get('kind')=='lab':
            for field in ('objective','hints','solution','rubric','safety_scope'):
                if not meta.get(field): warnings.append(f'آزمایشگاه {i}: فیلد metadata.{field} پیشنهاد می‌شود')
    if data.get('sample_only') is True: warnings.append('این بسته به‌عنوان نمونه علامت‌گذاری شده و نباید محتوای نهایی تلقی شود')
    return {'ok':not errors,'format':data.get('format',''),'title':data.get('title',''),'chapter_count':len(chapters),'item_count':len(items),'errors':errors,'warnings':warnings,'import_status':'review_required' if not errors else 'valid_for_import_review','note':'اعتبارسنجی ساختاری و پیوندهاست؛ صحت علمی محتوا یا امنیت فرمان‌ها را تضمین نمی‌کند.'}

class CompetencyEvidenceIn(BaseModel):
    domain_profile: str
    competency_id: str
    competency_title: str
    status: str = 'practicing'
    score: Optional[int] = None
    evidence: str = ''

@app.get('/api/learning/competencies')
def learning_competencies(domain_profile:str, request:Request):
    profiles=_learning_profiles(); profile=profiles.get(domain_profile)
    if not profile: raise HTTPException(400,'پروفایل حوزه پیدا نشد')
    username=session_username(request.cookies.get(SESSION_COOKIE))
    with connect() as c: rows=c.execute('SELECT * FROM competency_evidence WHERE username=? COLLATE NOCASE AND domain_profile=?',(username,domain_profile)).fetchall()
    saved={r['competency_id']:dict(r) for r in rows}
    items=[]
    for i,title in enumerate(profile.get('assessment',[]),1):
        cid=f'comp-{i:02d}'; items.append({'competency_id':cid,'title':title,**saved.get(cid,{'status':'not_started','score':None,'evidence':'','updated_at':''})})
    return {'ok':True,'domain_profile':domain_profile,'items':items,'counts':{status:sum(1 for x in items if x.get('status')==status) for status in ('not_started','practicing','demonstrated','needs_review')}}

@app.post('/api/learning/competencies/evidence')
def save_competency_evidence(payload:CompetencyEvidenceIn, request:Request):
    profiles=_learning_profiles(); profile=profiles.get(payload.domain_profile)
    if not profile: raise HTTPException(400,'پروفایل حوزه پیدا نشد')
    if payload.status not in {'not_started','practicing','demonstrated','needs_review'}: raise HTTPException(400,'وضعیت شایستگی نامعتبر است')
    if payload.score is not None and not 0<=payload.score<=100: raise HTTPException(400,'نمره باید بین ۰ تا ۱۰۰ باشد')
    allowed={f'comp-{i:02d}':title for i,title in enumerate(profile.get('assessment',[]),1)}
    if payload.competency_id not in allowed: raise HTTPException(400,'شناسهٔ شایستگی متعلق به این پروفایل نیست')
    title=allowed[payload.competency_id]; evidence=payload.evidence.strip()
    if len(evidence)>5000: raise HTTPException(413,'شرح شواهد بیش از ۵۰۰۰ نویسه است')
    username=session_username(request.cookies.get(SESSION_COOKIE)); now=now_iso()
    with connect() as c:
        c.execute("""INSERT INTO competency_evidence(username,domain_profile,competency_id,competency_title,status,score,evidence,updated_at) VALUES(?,?,?,?,?,?,?,?)
          ON CONFLICT(username,domain_profile,competency_id) DO UPDATE SET competency_title=excluded.competency_title,status=excluded.status,score=excluded.score,evidence=excluded.evidence,updated_at=excluded.updated_at""",
          (username,payload.domain_profile,payload.competency_id,title,payload.status,payload.score,evidence,now)); c.commit()
    return {'ok':True,'username':username,'domain_profile':payload.domain_profile,'competency_id':payload.competency_id,'title':title,'status':payload.status,'score':payload.score,'updated_at':now}

@app.get('/api/health')
def health(): return {'ok':True,'app':'Network Learning App','version':APP_VERSION,'time':now_iso()}

@app.get('/api/network/status')
def network_status(request: Request):
    # This reports candidate LAN URLs for trusted local-network use; it never opens the firewall.
    import socket, ipaddress
    port = int(request.url.port or 82)
    configured_port = int(get_setting('net_port','82') or 82)
    ips=set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_STREAM):
            ip=info[4][0]
            if ip and not ip.startswith('127.') and not ip.startswith('169.254.'):
                try:
                    if ipaddress.ip_address(ip).is_private: ips.add(ip)
                except ValueError: pass
    except Exception: pass
    try:
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.connect(('192.0.2.1',80)); ip=sock.getsockname()[0]; sock.close()
        if ip and not ip.startswith('127.') and not ip.startswith('169.254.'): ips.add(ip)
    except Exception: pass
    bind_host=get_setting('net_bind_host','0.0.0.0') or '0.0.0.0'
    if bind_host in {'127.0.0.1','::1'}: ips=set()
    urls=[f'http://{ip}:{port}' for ip in sorted(ips)]
    return {'ok':True,'hostname':socket.gethostname(),'port':port,'active_port':port,'configured_port':configured_port,'restart_required':configured_port!=port,'lan_urls':urls,'loopback_url':f'http://127.0.0.1:{port}','transport':'http','warning':'فقط در شبکهٔ خصوصی و مورد اعتماد استفاده کن؛ سرور را روی اینترنت عمومی باز نکن. رمز شش‌کاراکتری برای شبکهٔ غیرقابل‌اعتماد کافی نیست.'}

_SYNC_FILE_HASH_CACHE: dict[str, tuple[int, int, str]] = {}
def _sync_file_sha256(path: Path) -> str:
    stat=path.stat(); key=str(path.resolve()); cached=_SYNC_FILE_HASH_CACHE.get(key)
    if cached and cached[0]==stat.st_size and cached[1]==stat.st_mtime_ns: return cached[2]
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): digest.update(block)
    value=digest.hexdigest(); _SYNC_FILE_HASH_CACHE[key]=(stat.st_size,stat.st_mtime_ns,value); return value

@app.get('/api/sync/manifest')
def sync_manifest():
    # Read-only chapter and media manifest for the future Android client; hashes identify changed content/assets.
    result=[]
    with connect() as c:
        chapters=c.execute('SELECT * FROM chapters ORDER BY order_num,title COLLATE NATURAL_NOCASE,id').fetchall()
        for ch in chapters:
            rows=c.execute("SELECT kind,title,summary,content,source_status,source_uid,metadata_json,created_at FROM items WHERE chapter_id=? AND source_status='verified' ORDER BY kind,source_uid,id",(ch['id'],)).fetchall()
            canonical=[dict(r) for r in rows]
            digest=hashlib.sha256(json.dumps(canonical,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
            result.append({'id':ch['id'],'title':ch['title'],'order_num':ch['order_num'],'group_name':ch['group_name'],'description':ch['description'],'item_count':len(rows),'content_hash':digest})
    media_files=[]
    if MEDIA.exists():
        for path in sorted(MEDIA.rglob('*')):
            if not path.is_file(): continue
            try:
                rel=path.relative_to(MEDIA).as_posix(); stat=path.stat()
                media_files.append({'path':rel,'size':stat.st_size,'sha256':_sync_file_sha256(path),'url':'/media/'+rel})
            except OSError: continue
    return {'ok':True,'format':'network-learning-sync-v1','generated_at':now_iso(),'chapters':result,'media_files':media_files}

@app.get('/api/sync/chapter/{chapter_id}')
def sync_chapter(chapter_id: str):
    with connect() as c:
        ch=c.execute('SELECT * FROM chapters WHERE id=?',(chapter_id,)).fetchone()
        if not ch: raise HTTPException(404,'فصل پیدا نشد')
        items=[]
        for r in c.execute("SELECT * FROM items WHERE chapter_id=? AND source_status='verified' ORDER BY kind,chapter_content_seq(kind,source_uid,title,metadata_json,id),id",(chapter_id,)):
            item=dict(r); item['metadata']=json.loads(item.pop('metadata_json') or '{}'); items.append(item)
    return {'ok':True,'format':'network-learning-sync-chapter-v1','chapter':dict(ch),'items':items}


# ---- Local single-user password gate -------------------------------------------------
# This protects a locally hosted learning workspace; it is not a replacement for an
# internet-facing identity provider or multi-user access-control system.
SESSION_COOKIE = 'nl_session'
SESSION_SECONDS = 15 * 60
PBKDF2_ROUNDS = 310_000
LOGIN_FAILURES: dict[str, list[float]] = {}
AUTH_EXEMPT = {'/', '/api/auth/status', '/api/auth/setup', '/api/auth/login', '/api/auth/logout', '/api/health', '/favicon.ico'}

def get_setting(key:str, default:str='') -> str:
    with connect() as c:
        r=c.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        return str(r['value']) if r else default

def set_setting(key:str, value:str):
    global _TIMEZONE_CACHE
    with connect() as c:
        c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,str(value)))
        c.commit()
    if key == 'pref_timezone':
        candidate = str(value or 'Asia/Tehran')
        try:
            ZoneInfo(candidate)
            _TIMEZONE_CACHE = candidate
        except Exception:
            _TIMEZONE_CACHE = 'Asia/Tehran'

def auth_secret()->bytes:
    value=get_setting('auth_secret')
    if not value:
        value=secrets.token_hex(32); set_setting('auth_secret',value)
    return bytes.fromhex(value)

def password_hash(password:str, salt:bytes|None=None)->str:
    salt=salt or os.urandom(16)
    dk=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,PBKDF2_ROUNDS,dklen=32)
    return f'pbkdf2_sha256${PBKDF2_ROUNDS}${salt.hex()}${dk.hex()}'

def password_matches(password:str, stored:str)->bool:
    try:
        alg,rounds,salt_hex,expected=stored.split('$',3)
        if alg!='pbkdf2_sha256': return False
        actual=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),bytes.fromhex(salt_hex),int(rounds),dklen=32).hex()
        return hmac.compare_digest(actual,expected)
    except Exception:
        return False

def create_session_token(username:str|None=None)->str:
    username=str(username or get_setting('auth_username','admin') or 'admin')
    # Pipe-delimited claims keep allowed usernames (including dots) unambiguous.
    payload=f'{int(time.time())+SESSION_SECONDS}|{username}|{secrets.token_urlsafe(18)}'
    sig=hmac.new(auth_secret(),payload.encode(),hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f'{payload}.{sig}'.encode()).decode().rstrip('=')

def _session_claims(token:str|None):
    if not token: return None
    try:
        raw=base64.urlsafe_b64decode(token+'='*((4-len(token)%4)%4)).decode()
        # New token format: expiry|username|nonce.signature; accept historical signed
        # expiry.nonce.signature tokens during a rolling upgrade.
        if '|' in raw:
            payload,sig=raw.rsplit('.',1)
            expiry,username,nonce=payload.split('|',2)
        else:
            expiry,nonce,sig=raw.split('.',2)
            payload=f'{expiry}.{nonce}'
            username=get_setting('auth_username','admin') or 'admin'
        if int(expiry)<int(time.time()): return None
        expected=hmac.new(auth_secret(),payload.encode(),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig,expected): return None
        return {'username':username,'expires_at':int(expiry)}
    except Exception:
        return None

def session_username(token:str|None)->str:
    claims=_session_claims(token)
    return str(claims['username']) if claims else ''

def account_for_username(username:str):
    try:
        with connect() as c:
            row=c.execute('SELECT username,role,active FROM user_accounts WHERE username=? COLLATE NOCASE',(str(username),)).fetchone()
            return dict(row) if row else None
    except Exception:
        return None

def account_role(username:str)->str:
    account=account_for_username(username)
    return str(account.get('role') or 'learner') if account else 'learner'

def valid_session(token:str|None)->bool:
    claims=_session_claims(token)
    if not claims: return False
    # Existing installations always migrate the one original account at startup.
    account=account_for_username(str(claims['username']))
    if not account: return False
    if not int(account.get('active') or 0): return False
    return True

def _require_admin(request:Request):
    if not valid_session(request.cookies.get(SESSION_COOKIE)):
        raise HTTPException(401,'ابتدا وارد شو')
    username=session_username(request.cookies.get(SESSION_COOKIE))
    if account_role(username)!='admin':
        raise HTTPException(403,'این عملیات فقط برای مدیر برنامه مجاز است.')
    return username

def auth_configured()->bool:
    return bool(get_setting('password_hash'))

@app.middleware('http')
async def local_auth_middleware(request:Request, call_next):
    path=request.url.path
    if path.startswith('/static/') or path in AUTH_EXEMPT:
        return await call_next(request)
    if not auth_configured():
        return JSONResponse({'detail':'ابتدا رمز برنامه را تنظیم کن.'},status_code=401)
    token=request.cookies.get(SESSION_COOKIE)
    if not valid_session(token):
        return JSONResponse({'detail':'نشست معتبر نیست؛ دوباره وارد شو.'},status_code=401)
    username=session_username(token); role=account_role(username); method=request.method.upper()
    if role=='editor' and (path.startswith('/api/users') or path.startswith('/api/network/config') or (path=='/api/settings' and method!='GET') or path.startswith('/api/restore') or path.startswith('/api/backup/archive')):
        return JSONResponse({'detail':'این تنظیم سیستمی فقط برای مدیر برنامه مجاز است.'},status_code=403)
    if role=='learner' and method in {'POST','PUT','PATCH','DELETE'}:
        learner_mutations=(
            r'^/api/item/\d+/complete$', r'^/api/item/\d+/personal-note$',
            r'^/api/review/[^/]+$', r'^/api/quiz/(?:answer|submit)$',
            r'^/api/assessment/(?:answer|submit)$', r'^/api/practice/attempts$', r'^/api/learning/competencies/evidence$', r'^/api/tasks/\d+/complete$',
            r'^/api/auth/(?:activity|logout|change-password)$'
        )
        if not any(re.match(pattern,path) for pattern in learner_mutations):
            return JSONResponse({'detail':'حساب مطالعه‌گر اجازهٔ تغییر ساختار دوره یا تنظیمات را ندارد.'},status_code=403)
    return await call_next(request)

@app.middleware('http')
async def network_ip_filter_middleware(request:Request, call_next):
    """Apply the optional IP/CIDR ACL at the HTTP boundary; deny rules win.

    Loopback stays available for recovery from a mistaken LAN ACL. When ACL is
    enabled, an unexpected settings/parser failure must not silently fail open.
    """
    import ipaddress
    peer=request.client.host if request.client else ''
    try:
        ip=ipaddress.ip_address(peer.split('%',1)[0])
    except ValueError:
        # A request with no parseable peer cannot be admitted under an enabled ACL.
        try:
            enabled=get_setting('net_acl_enabled','0').strip().lower() in {'1','true','yes','on'}
        except Exception:
            return JSONResponse({'detail':'خواندن سیاست شبکه ممکن نیست؛ دسترسی غیرمحلی موقتاً بسته شد.'},status_code=503)
        if enabled:
            return JSONResponse({'detail':'نشانی IP درخواست قابل اعتبارسنجی نیست.'},status_code=403)
        return await call_next(request)
    if ip.is_loopback:
        return await call_next(request)
    try:
        enabled=get_setting('net_acl_enabled','0').strip().lower() in {'1','true','yes','on'}
        if not enabled:
            return await call_next(request)
        def parse_rules(raw):
            nets=[]
            for part in re.split(r'[\s,;]+',str(raw or '').strip()):
                if not part: continue
                try: nets.append(ipaddress.ip_network(part,strict=False))
                except ValueError:
                    # Invalid rules should never be silently ignored at the access boundary.
                    raise ValueError('invalid stored IP/CIDR rule')
            return nets
        deny=parse_rules(get_setting('net_denylist',''))
        allow=parse_rules(get_setting('net_allowlist',''))
        if any(ip.version==net.version and ip in net for net in deny):
            return JSONResponse({'detail':'دسترسی این IP توسط سیاست شبکه مسدود شده است.'},status_code=403)
        if allow and not any(ip.version==net.version and ip in net for net in allow):
            return JSONResponse({'detail':'این IP در فهرست مجاز شبکه قرار ندارد.'},status_code=403)
        if not allow and get_setting('net_require_allowlist','0').strip().lower() in {'1','true','yes','on'}:
            return JSONResponse({'detail':'فهرست مجاز فعال است اما شبکهٔ مجازی تعریف نشده است.'},status_code=403)
    except Exception:
        return JSONResponse({'detail':'خواندن یا اعتبارسنجی سیاست شبکه ممکن نیست؛ دسترسی غیرمحلی موقتاً بسته شد.'},status_code=503)
    return await call_next(request)

class PasswordSetupIn(BaseModel):
    username: str = 'admin'
    password: str

class LoginIn(BaseModel):
    username: str = 'admin'
    password: str


def _validate_auth_username(value: str) -> str:
    value=str(value or '').strip()
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{3,40}',value):
        raise HTTPException(400,'نام کاربری باید ۳ تا ۴۰ نویسه و شامل حروف انگلیسی، عدد، نقطه، خط تیره یا زیرخط باشد.')
    return value

@app.get('/api/auth/status')
def auth_status(request:Request):
    configured=auth_configured()
    peer=request.client.host if request.client else ''
    setup_local_only=(not configured and peer not in {'127.0.0.1','::1','localhost'})
    token=request.cookies.get(SESSION_COOKIE); username=session_username(token) if valid_session(token) else (get_setting('auth_username','admin') or 'admin')
    return {'configured':configured,'authenticated':bool(configured and valid_session(token)), 'password_format':get_setting('password_length','legacy'),'setup_local_only':setup_local_only,'login_username':get_setting('auth_username','admin') or 'admin','username':username,'role':account_role(username) if configured else 'admin','creator':'مهندس مسعود جوکار'}

@app.post('/api/auth/setup')
def auth_setup(payload:PasswordSetupIn, request:Request):
    # First-time setup is permitted only from this Windows host; otherwise any device
    # on the LAN could race to claim a fresh server before its owner sets a password.
    peer = request.client.host if request.client else ''
    if peer not in {'127.0.0.1', '::1', 'localhost'}:
        raise HTTPException(403,'تنظیم اولیهٔ رمز فقط از خود رایانهٔ میزبان و با آدرس http://127.0.0.1:82 مجاز است.')
    if auth_configured(): raise HTTPException(409,'رمز قبلاً تنظیم شده است؛ از فرم ورود استفاده کن.')
    username=_validate_auth_username(payload.username)
    if not 12<=len(payload.password)<=256: raise HTTPException(400,'رمز اولیه باید حداقل ۱۲ و حداکثر ۲۵۶ نویسه داشته باشد.')
    set_setting('auth_username',username)
    pass_hash=password_hash(payload.password)
    set_setting('password_hash',pass_hash)
    set_setting('password_length','strong')
    with connect() as c:
        c.execute("INSERT OR REPLACE INTO user_accounts(username,password_hash,role,active,created_at,updated_at) VALUES(?,?,'admin',1,?,?)",(username,pass_hash,now_iso(),now_iso())); c.commit()
    response=JSONResponse({'ok':True,'message':'رمز تنظیم شد.','username':username,'role':'admin'})
    response.set_cookie(SESSION_COOKIE,create_session_token(username),httponly=True,samesite='strict',secure=False,max_age=SESSION_SECONDS,path='/')
    return response

@app.post('/api/auth/login')
def auth_login(payload:LoginIn, request:Request):
    if not auth_configured(): raise HTTPException(409,'ابتدا رمز برنامه را ایجاد کن.')
    client=request.client.host if request.client else 'local'
    now=time.time(); recent=[x for x in LOGIN_FAILURES.get(client,[]) if now-x<900]
    if len(recent)>=5:
        LOGIN_FAILURES[client]=recent
        raise HTTPException(429,'به‌دلیل چند تلاش ناموفق، ورود برای ۱۵ دقیقه محدود شده است.')
    expected_username=get_setting('auth_username','admin') or 'admin'
    username=str(payload.username or '').strip()
    with connect() as c:
        account=c.execute('SELECT username,password_hash,role,active FROM user_accounts WHERE username=? COLLATE NOCASE',(username,)).fetchone()
    if account:
        username_ok=bool(int(account['active'] or 0))
        stored_hash=str(account['password_hash'] or '')
        # The original primary account uses the application's historical password policy;
        # additional users are created with longer passwords by the user-management API.
        if hmac.compare_digest(username.casefold(),expected_username.casefold()):
            pwd_format=get_setting('password_length','legacy')
            if pwd_format=='6':
                password_ok=(len(payload.password)==6 and bool(re.fullmatch(r'[A-Za-z0-9]{6}',payload.password)) and password_matches(payload.password,stored_hash)); must_change=False
            elif pwd_format=='strong':
                password_ok=(12<=len(payload.password)<=256 and password_matches(payload.password,stored_hash)); must_change=False
            else:
                password_ok=(6<len(payload.password)<=256 and password_matches(payload.password,stored_hash)); must_change=password_ok
        else:
            password_ok=password_matches(payload.password,stored_hash); must_change=False
    else:
        username_ok=hmac.compare_digest(username.casefold(),expected_username.casefold())
        pwd_format=get_setting('password_length','legacy')
        if pwd_format=='6':
            password_ok=(len(payload.password)==6 and bool(re.fullmatch(r'[A-Za-z0-9]{6}',payload.password)) and password_matches(payload.password,get_setting('password_hash'))); must_change=False
        elif pwd_format=='strong':
            password_ok=(12<=len(payload.password)<=256 and password_matches(payload.password,get_setting('password_hash'))); must_change=False
        else:
            password_ok=(6<len(payload.password)<=256 and password_matches(payload.password,get_setting('password_hash'))); must_change=password_ok
    matched=bool(username_ok and password_ok)
    if not matched:
        recent.append(now); LOGIN_FAILURES[client]=recent
        raise HTTPException(401,'نام کاربری یا رمز عبور نادرست است، یا حساب غیرفعال است.')
    LOGIN_FAILURES.pop(client,None)
    role=account_role(username)
    response=JSONResponse({'ok':True,'message':'ورود موفق بود.','requires_password_change':must_change,'username':username,'role':role})
    response.set_cookie(SESSION_COOKIE,create_session_token(username),httponly=True,samesite='strict',secure=False,max_age=SESSION_SECONDS,path='/')
    return response

@app.post('/api/auth/change-password')
def auth_change_password(payload:dict[str,str], request:Request):
    token=request.cookies.get(SESSION_COOKIE)
    if not valid_session(token): raise HTTPException(401,'ابتدا وارد شو')
    current=str(payload.get('current_password') or '')
    new=str(payload.get('new_password') or '')
    username=session_username(token)
    with connect() as c:
        account=c.execute('SELECT password_hash FROM user_accounts WHERE username=? COLLATE NOCASE',(username,)).fetchone()
    stored=str(account['password_hash'] if account else get_setting('password_hash'))
    if not password_matches(current,stored): raise HTTPException(401,'رمز فعلی درست نیست')
    if not 12<=len(new)<=256: raise HTTPException(400,'رمز جدید باید حداقل ۱۲ و حداکثر ۲۵۶ نویسه داشته باشد')
    new_hash=password_hash(new)
    with connect() as c:
        c.execute('UPDATE user_accounts SET password_hash=?,updated_at=? WHERE username=? COLLATE NOCASE',(new_hash,now_iso(),username))
        if username.casefold()==(get_setting('auth_username','admin') or 'admin').casefold():
            c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',('password_hash',new_hash))
            c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',('password_length','strong'))
        c.commit()
    return {'ok':True,'message':'رمز قوی جدید با موفقیت ذخیره شد'}

@app.post('/api/auth/activity')
def auth_activity(request: Request):
    """Refresh the signed local session only when the authenticated client reports user activity."""
    if not valid_session(request.cookies.get(SESSION_COOKIE)):
        raise HTTPException(401,'نشست منقضی شده است؛ دوباره وارد شو.')
    response=JSONResponse({'ok':True,'expires_in_seconds':SESSION_SECONDS})
    response.set_cookie(SESSION_COOKIE,create_session_token(session_username(request.cookies.get(SESSION_COOKIE))),httponly=True,samesite='strict',secure=False,max_age=SESSION_SECONDS,path='/')
    return response


@app.post('/api/auth/logout')
def auth_logout():
    response=JSONResponse({'ok':True})
    response.delete_cookie(SESSION_COOKIE,path='/')
    return response


# ---- Local network and user administration ----------------------------------------
import ipaddress as _ipaddress

NETWORK_DEFAULTS={'port':82,'bind_host':'0.0.0.0','acl_enabled':False,'require_allowlist':False,'allowlist':'','denylist':''}

def _network_config_public():
    return {
      'port':int(get_setting('net_port','82') or 82),
      'bind_host':get_setting('net_bind_host','0.0.0.0') or '0.0.0.0',
      'acl_enabled':get_setting('net_acl_enabled','0').lower() in {'1','true','yes','on'},
      'require_allowlist':get_setting('net_require_allowlist','0').lower() in {'1','true','yes','on'},
      'allowlist':get_setting('net_allowlist',''), 'denylist':get_setting('net_denylist',''),
      'restart_required':True,
      'note':'تغییر پورت یا آدرس bind پس از راه‌اندازی مجدد سرور اعمال می‌شود؛ ACL IP بدون restart اعمال می‌شود.'
    }

def _parse_network_rules(value, label):
    if isinstance(value,list): raw='\n'.join(str(x) for x in value)
    else: raw=str(value or '')
    parts=[x.strip() for x in re.split(r'[\r\n,;]+',raw) if x.strip()]
    if len(parts)>200: raise HTTPException(400,f'حداکثر ۲۰۰ قانون برای {label} مجاز است.')
    normalized=[]
    for part in parts:
        try: net=_ipaddress.ip_network(part,strict=False)
        except ValueError: raise HTTPException(400,f'IP/CIDR نامعتبر در {label}: {part[:80]}')
        token=str(net)
        if token not in normalized: normalized.append(token)
    return '\n'.join(normalized)

@app.get('/api/network/config')
def get_network_config(request:Request):
    _require_admin(request)
    return {'ok':True,'network':_network_config_public()}

@app.put('/api/network/config')
def save_network_config(payload:dict[str,Any], request:Request):
    _require_admin(request)
    allowed={'port','bind_host','acl_enabled','require_allowlist','allowlist','denylist'}
    if not isinstance(payload,dict) or set(payload)-allowed or not payload: raise HTTPException(400,'فیلدهای تنظیمات شبکه نامعتبر است.')
    current=_network_config_public(); cfg={**current,**payload}
    def as_bool(value): return value if isinstance(value,bool) else str(value).strip().lower() in {'1','true','yes','on'}
    cfg['acl_enabled']=as_bool(cfg.get('acl_enabled')); cfg['require_allowlist']=as_bool(cfg.get('require_allowlist'))
    try: port=int(cfg['port'])
    except Exception: raise HTTPException(400,'پورت باید عدد صحیح باشد.')
    if not 1<=port<=65535: raise HTTPException(400,'پورت باید بین 1 و 65535 باشد.')
    host=str(cfg['bind_host'] or '').strip()
    if host not in {'0.0.0.0','127.0.0.1','::','::1'}:
        try: _ipaddress.ip_address(host)
        except ValueError: raise HTTPException(400,'Bind host باید 0.0.0.0، آدرس loopback یا یک IP معتبر باشد.')
    allow=_parse_network_rules(cfg['allowlist'],'فهرست مجاز'); deny=_parse_network_rules(cfg['denylist'],'فهرست مسدود')
    if bool(cfg['require_allowlist']) and not allow: raise HTTPException(400,'فهرست مجاز اجباری است اما هیچ IP یا CIDR وارد نشده است.')
    if bool(cfg['acl_enabled']):
        peer=request.client.host if request.client else ''
        try: peer_ip=_ipaddress.ip_address(peer.split('%',1)[0])
        except ValueError: peer_ip=None
        if peer_ip and not peer_ip.is_loopback:
            deny_nets=[_ipaddress.ip_network(x,strict=False) for x in deny.splitlines() if x.strip()]
            allow_nets=[_ipaddress.ip_network(x,strict=False) for x in allow.splitlines() if x.strip()]
            if any(peer_ip.version==net.version and peer_ip in net for net in deny_nets):
                raise HTTPException(400,'IP فعلی شما در فهرست مسدود قرار دارد؛ ابتدا آن را از فهرست حذف کن.')
            if allow_nets and not any(peer_ip.version==net.version and peer_ip in net for net in allow_nets):
                raise HTTPException(400,'IP فعلی شما در فهرست مجاز نیست؛ برای جلوگیری از قطع دسترسی، IP/CIDR خود را اضافه کن.')
    clean={'net_port':str(port),'net_bind_host':host,'net_acl_enabled':'1' if bool(cfg['acl_enabled']) else '0',
           'net_require_allowlist':'1' if bool(cfg['require_allowlist']) else '0','net_allowlist':allow,'net_denylist':deny}
    with connect() as c:
        for key,value in clean.items(): c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value))
        c.commit()
    return {'ok':True,'network':_network_config_public(),'message':'تنظیمات ذخیره شد. پورت و bind host پس از راه‌اندازی مجدد اعمال می‌شوند.'}

@app.get('/api/users')
def list_user_accounts(request:Request):
    _require_admin(request)
    with connect() as c:
        rows=c.execute("SELECT username,role,active,created_at,updated_at FROM user_accounts ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'editor' THEN 1 ELSE 2 END,username COLLATE NOCASE").fetchall()
    return {'users':[dict(r) for r in rows]}

@app.post('/api/users')
def create_user_account(payload:dict[str,Any], request:Request):
    _require_admin(request)
    allowed={'username','password','role','active'}
    if not isinstance(payload,dict) or set(payload)-allowed: raise HTTPException(400,'فیلدهای حساب نامعتبر است.')
    username=_validate_auth_username(str(payload.get('username') or ''))
    password=str(payload.get('password') or '')
    if len(password)<12 or len(password)>256: raise HTTPException(400,'رمز حساب جدید باید حداقل ۱۲ و حداکثر ۲۵۶ نویسه باشد.')
    role=str(payload.get('role') or 'learner')
    if role not in {'admin','editor','learner'}: raise HTTPException(400,'نقش حساب نامعتبر است.')
    if 'active' in payload and not isinstance(payload['active'],bool): raise HTTPException(400,'وضعیت active باید true یا false باشد.')
    active=1 if payload.get('active',True) else 0; now=now_iso(); hashed=password_hash(password)
    try:
        with connect() as c:
            c.execute('INSERT INTO user_accounts(username,password_hash,role,active,created_at,updated_at) VALUES(?,?,?,?,?,?)',(username,hashed,role,active,now,now)); c.commit()
    except sqlite3.IntegrityError: raise HTTPException(409,'نام کاربری قبلاً ثبت شده است.')
    return {'ok':True,'user':{'username':username,'role':role,'active':bool(active),'created_at':now,'updated_at':now}}

@app.patch('/api/users/{username}')
def update_user_account(username:str, payload:dict[str,Any], request:Request):
    admin=_require_admin(request)
    allowed={'role','active','password'}
    if not isinstance(payload,dict) or not payload or set(payload)-allowed: raise HTTPException(400,'فیلدهای تغییر حساب نامعتبر است.')
    role=payload.get('role'); active=payload.get('active'); password=payload.get('password')
    if role is not None and role not in {'admin','editor','learner'}: raise HTTPException(400,'نقش حساب نامعتبر است.')
    if active is not None and not isinstance(active,bool): raise HTTPException(400,'وضعیت حساب باید true یا false باشد.')
    if password is not None and not 12<=len(str(password))<=256: raise HTTPException(400,'رمز جدید باید حداقل ۱۲ نویسه داشته باشد.')
    with connect() as c:
        target=c.execute('SELECT username,role,active FROM user_accounts WHERE username=? COLLATE NOCASE',(username,)).fetchone()
        if not target: raise HTTPException(404,'حساب پیدا نشد.')
        new_role=role or target['role']; new_active=int(active) if active is not None else int(target['active'])
        if str(target['username']).casefold()==admin.casefold() and (new_role!='admin' or not new_active): raise HTTPException(400,'نمی‌توان حساب مدیر واردشده را به نقش پایین‌تر برد یا غیرفعال کرد.')
        if target['role']=='admin' and (new_role!='admin' or not new_active):
            admins=c.execute("SELECT COUNT(*) n FROM user_accounts WHERE role='admin' AND active=1").fetchone()['n']
            if admins<=1: raise HTTPException(400,'حداقل یک مدیر فعال باید باقی بماند.')
        sets=['role=?','active=?','updated_at=?']; args=[new_role,new_active,now_iso()]
        if password is not None: sets.append('password_hash=?'); args.append(password_hash(str(password)))
        args.append(target['username'])
        c.execute('UPDATE user_accounts SET '+','.join(sets)+' WHERE username=? COLLATE NOCASE',args); c.commit()
        row=c.execute('SELECT username,role,active,created_at,updated_at FROM user_accounts WHERE username=? COLLATE NOCASE',(target['username'],)).fetchone()
    return {'ok':True,'user':dict(row)}

@app.delete('/api/users/{username}')
def delete_user_account(username:str, request:Request):
    admin=_require_admin(request)
    with connect() as c:
        row=c.execute('SELECT username,role FROM user_accounts WHERE username=? COLLATE NOCASE',(username,)).fetchone()
        if not row: raise HTTPException(404,'حساب پیدا نشد.')
        if str(row['username']).casefold()==admin.casefold(): raise HTTPException(400,'حسابی که با آن وارد شده‌ای قابل حذف نیست.')
        if row['role']=='admin':
            count=c.execute("SELECT COUNT(*) n FROM user_accounts WHERE role='admin' AND active=1").fetchone()['n']
            if count<=1: raise HTTPException(400,'حداقل یک مدیر فعال باید باقی بماند.')
        c.execute('DELETE FROM user_accounts WHERE username=? COLLATE NOCASE',(row['username'],)); c.commit()
    return {'ok':True,'deleted':username}

# ---- Optional offline Persian speech synthesis ------------------------------------
_TTS_VOICE = None
_TTS_VOICE_PATH = None
_TTS_VOICE_LOCK = __import__('threading').Lock()
TTS_MODEL = BASE / 'models' / 'mana-persian-piper' / 'fa_IR-mana-medium.onnx'
TTS_CONFIG = Path(str(TTS_MODEL) + '.json')

class TTSSynthesizeIn(BaseModel):
    text: str

# Piper is intentionally isolated from the main app runtime. Newer Python versions may
# run FastAPI successfully while the ONNX Runtime wheel for that Python is unavailable.
PIPER_WORKER_SCRIPT = BASE / 'tts_worker.py'
PIPER_WORKER_CANDIDATES = [
    BASE / '.tts-venv' / 'Scripts' / 'python.exe',
    BASE / '.piper-venv' / 'Scripts' / 'python.exe',
    BASE / 'piper-venv' / 'Scripts' / 'python.exe',
    BASE / '.venv-tts' / 'Scripts' / 'python.exe',
]
PIPER_CONFIGURED_INTERPRETER = BASE / 'piper_python_path.txt'

def _piper_worker_candidate_paths():
    candidates=list(PIPER_WORKER_CANDIDATES)
    if PIPER_CONFIGURED_INTERPRETER.is_file():
        try:
            configured=Path(PIPER_CONFIGURED_INTERPRETER.read_text(encoding='utf-8').strip().strip('\"'))
            if str(configured).strip(): candidates.append(configured)
        except Exception:
            pass
    return candidates

def _piper_worker_label(candidate: Path) -> str:
    try:
        if candidate.resolve().is_relative_to(BASE.resolve()):
            return candidate.resolve().relative_to(BASE.resolve()).parts[0]
    except Exception:
        pass
    return 'configured-system-python'

_PIPER_PROBE_CODE = r"""import json,sys,struct
v=sys.version_info[:2]
info={'python':sys.version.split()[0],'bits':struct.calcsize('P')*8,'compatible_python':(3,11)<=v<=(3,14),'gil_enabled':(not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()),'piper':False,'onnxruntime':False,'error':''}
try:
 from piper import PiperVoice
 info['piper']=PiperVoice is not None
 import onnxruntime
 info['onnxruntime']=True
except Exception as e:
 info['error']=type(e).__name__+': '+str(e)[:140]
info['ok']=bool(info['compatible_python'] and info['bits']==64 and info['gil_enabled'] and info['piper'] and info['onnxruntime'])
print(json.dumps(info,ensure_ascii=False))
raise SystemExit(0 if info['ok'] else 1)
"""

def _piper_worker_probe():
    """Return (usable interpreter path or None, per-candidate diagnostic list).

    Probe local sidecar environments and an explicitly configured compatible
    system interpreter. A model file alone never counts as a ready voice engine.
    """
    diagnostics=[]
    if not PIPER_WORKER_SCRIPT.is_file():
        return None, ['فایل tts_worker.py پیدا نشد.']
    for candidate in _piper_worker_candidate_paths():
        label=_piper_worker_label(candidate)
        if not candidate.is_file():
            diagnostics.append(f'{label}: فایل Python پیدا نشد.')
            continue
        try:
            result=subprocess.run([str(candidate),'-c',_PIPER_PROBE_CODE],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=8,cwd=str(BASE))
            output=(result.stdout or '').strip().splitlines()
            info=json.loads(output[-1]) if output else {}
            if result.returncode==0 and info.get('ok'):
                return candidate, diagnostics
            reason=info.get('error') or f"Python {info.get('python','نامشخص')}؛ {info.get('bits','?')}بیتی؛ Piper={info.get('piper')}؛ ONNX={info.get('onnxruntime')}"
            diagnostics.append(f'{label}: {reason}')
        except Exception as exc:
            diagnostics.append(f'{label}: {type(exc).__name__}: {str(exc)[:100]}')
    return None, diagnostics

def _piper_worker_available() -> bool:
    return _piper_worker_probe()[0] is not None

@app.get('/api/tts/status')
def tts_status():
    model_present=TTS_MODEL.is_file() and TTS_CONFIG.is_file()
    size=TTS_MODEL.stat().st_size if TTS_MODEL.is_file() else 0
    worker_path, worker_diagnostics=_piper_worker_probe()
    direct_available=False
    direct_reason=''
    try:
        import piper  # noqa: F401
        import onnxruntime  # noqa: F401
        direct_available=True
    except Exception as exc:
        direct_reason=f'{type(exc).__name__}: {str(exc)[:140]}'
    available=bool(model_present and (direct_available or worker_path is not None))
    if not model_present:
        reason='فایل مدل یا فایل تنظیمات Mana موجود نیست. ابزار تشخیص، مسیر مدل را بررسی می‌کند.'
    elif available:
        reason='صدای فارسی آفلاین آماده است.'
    else:
        current_py=f'Python {sys.version.split()[0]} ({struct.calcsize("P")*8}-bit)'
        reason=f'مدل صوتی موجود است، اما موتور Piper/ONNX بارگذاری نشده است. نسخهٔ محیط اصلی: {current_py}. اگر خطا «DLL load failed» است، Microsoft Visual C++ Redistributable 2015–2022 نسخهٔ x64 را از صفحهٔ رسمی مایکروسافت نصب/Repair کن؛ سپس setup_mana_piper.bat را اجرا کن. جزئیات دقیق در worker_diagnostics و لاگ نصب نمایش داده می‌شود.'
    return {
        'piper_available':available, 'model_present':model_present, 'model_size_bytes':size,
        'reason':reason, 'browser_tts_available':True, 'fully_offline':available,
        'separate_worker':worker_path is not None, 'worker_runtime':_piper_worker_label(worker_path) if worker_path else '',
        'main_python_version':sys.version.split()[0], 'main_python_bits':struct.calcsize('P')*8,
        'main_python_executable':str(sys.executable),
        'main_python_piper_import':direct_available, 'main_python_import_error':direct_reason,
        'worker_diagnostics':worker_diagnostics[:6],
    }

@app.get('/api/diagnostics/system')
def diagnostics_system():
    """Authenticated support snapshot: environment and health checks without secrets or absolute paths."""
    import platform, shutil
    checks=[]
    def add(name,ok,detail='',severity='info'):
        checks.append({'name':name,'ok':bool(ok),'detail':str(detail)[:320],'severity':severity if ok else ('error' if severity!='warning' else 'warning')})
    add('app_root',BASE.is_dir(),'ریشهٔ برنامه قابل دسترسی است.' if BASE.is_dir() else 'پوشهٔ برنامه پیدا نشد.')
    add('tts_worker_script',PIPER_WORKER_SCRIPT.is_file(),'فایل worker موجود است.' if PIPER_WORKER_SCRIPT.is_file() else 'فایل tts_worker.py وجود ندارد.')
    model_ok=TTS_MODEL.is_file(); config_ok=TTS_CONFIG.is_file(); model_size=TTS_MODEL.stat().st_size if model_ok else 0
    model_hash=''; model_hash_ok=False
    if model_ok:
        try:
            h=hashlib.sha256()
            with TTS_MODEL.open('rb') as f:
                for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
            model_hash=h.hexdigest(); model_hash_ok=(model_hash=='e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126')
        except Exception as exc: model_hash_error=type(exc).__name__
    else: model_hash_error=''
    add('tts_model',model_ok,f'فایل مدل: {model_size:,} بایت' if model_ok else 'فایل مدل Mana پیدا نشد.', 'info' if model_ok else 'error')
    add('tts_model_hash',model_hash_ok,('SHA-256 با مقدار شناخته‌شده برابر است.' if model_hash_ok else ('SHA-256 با مقدار شناخته‌شده برابر نیست.' if model_hash else 'هش مدل محاسبه نشد.')), 'info' if model_hash_ok else 'warning')
    config_valid=False
    if config_ok:
        try:
            cfg=json.loads(TTS_CONFIG.read_text(encoding='utf-8')); config_valid=isinstance(cfg,dict) and bool(cfg)
        except Exception: config_valid=False
    add('tts_model_config',config_ok and config_valid,'فایل تنظیمات مدل JSON معتبر است.' if config_ok and config_valid else ('فایل تنظیمات مدل JSON نامعتبر است.' if config_ok else 'فایل fa_IR-mana-medium.onnx.json وجود ندارد.'),'info' if config_ok and config_valid else 'error')
    def safe_diag(value):
        value=str(value or '')
        value=re.sub(r'(?i)[A-Z]:\\[^\r\n]*','<PATH>',value)
        value=re.sub(r'(?i)(password|token|secret|authorization)=?[^\s,;]+',r'\1=<REDACTED>',value)
        return value[:320]
    direct_ok=False; direct_error=''
    try:
        from piper import PiperVoice as _PV  # noqa: F401
        import onnxruntime as _ORT  # noqa: F401
        direct_ok=True
    except Exception as exc: direct_error=safe_diag(f'{type(exc).__name__}: {str(exc)[:180]}')
    worker_path,worker_errors=_piper_worker_probe()
    add('main_python_piper',direct_ok,safe_diag(direct_error or f'Python {sys.version.split()[0]} ({struct.calcsize("P")*8}-bit)'), 'info' if direct_ok else 'warning')
    add('isolated_piper_worker',worker_path is not None,(_piper_worker_label(worker_path) if worker_path else 'هیچ محیط جداگانهٔ Piper قابل بارگذاری نیست؛ جزئیات را در زیر ببین.'),'info' if worker_path else ('warning' if direct_ok else 'error'))
    db_ok=False; db_integrity='نامشخص'; db_counts={}; db_error=''
    try:
        with connect() as c:
            db_integrity=str(c.execute('PRAGMA quick_check').fetchone()[0])
            db_ok=db_integrity.lower()=='ok'
            table_names={r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            for table in ('topics','chapters','items','user_accounts','course_blueprints','competency_evidence'):
                if table in table_names:
                    try: db_counts[table]=int(c.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0])
                    except Exception: db_counts[table]=None
    except Exception as exc: db_error=safe_diag(f'{type(exc).__name__}: {str(exc)[:180]}')
    add('database',db_ok,db_integrity if not db_error else db_error,'info' if db_ok else 'error')
    try:
        usage=shutil.disk_usage(BASE); free_bytes=int(usage.free)
    except Exception: free_bytes=None
    add('disk_space',free_bytes is not None and free_bytes>250*1024*1024,(f'{free_bytes/1024/1024:.0f} MiB آزاد در درایو برنامه.' if free_bytes is not None else 'فضای آزاد قابل بررسی نیست.'),'info' if free_bytes and free_bytes>250*1024*1024 else 'warning')
    setup_log=BASE/'logs'/'piper_setup.log'; log_tail=[]
    if setup_log.is_file():
        try:
            lines=setup_log.read_text(encoding='utf-8',errors='replace').splitlines()[-14:]
            for line in lines:
                line=re.sub(r'(?i)[A-Z]:\\[^\r\n]*', '<PATH>', line)
                line=re.sub(r'(?i)(password|token|secret|authorization)=?[^\s,;]+',r'\1=<REDACTED>',line)
                log_tail.append(line[:300])
        except Exception: log_tail=['خواندن لاگ نصب ممکن نشد.']
    return {
      'ok':all(x['ok'] for x in checks if x['severity']=='error'),'app_version':APP_VERSION,
      'runtime':{'python':sys.version.split()[0],'bits':struct.calcsize('P')*8,'platform':platform.platform(),'executable_name':Path(sys.executable).name},
      'tts':{'model_present':model_ok,'model_size_bytes':model_size,'model_sha256':model_hash,'model_hash_matches_expected':model_hash_ok,'config_present':config_ok,'config_valid':config_valid,'main_import_ok':direct_ok,'main_import_error':safe_diag(direct_error),'worker_available':worker_path is not None,'worker_runtime':_piper_worker_label(worker_path) if worker_path else '', 'worker_diagnostics':[re.sub(r'(?i)[A-Z]:\\[^\r\n]*','<PATH>',str(x))[:320] for x in worker_errors[:8]]},
      'database':{'ok':db_ok,'integrity':db_integrity,'counts':db_counts,'error':db_error},
      'disk':{'free_bytes':free_bytes},'checks':checks,'piper_setup_log_tail':log_tail,
      'privacy_note':'گزارش API رمزها، Cookie، متن درس‌ها و مسیر کامل فایل‌ها را برنمی‌گرداند.'
    }

@app.post('/api/tts/synthesize')
def tts_synthesize(payload: TTSSynthesizeIn):
    text_value=str(payload.text or '').strip()
    if not text_value: raise HTTPException(400,'متنی برای خواندن ارسال نشده است.')
    if len(text_value)>20000: raise HTTPException(413,'متن برای یک نوبت خواندن بیش از حد طولانی است؛ آن را به بخش‌های کوتاه‌تر تقسیم کن.')
    if not TTS_MODEL.is_file() or not TTS_CONFIG.is_file(): raise HTTPException(503,'مدل آفلاین Mana Persian Piper نصب نشده است.')
    global _TTS_VOICE, _TTS_VOICE_PATH
    with _TTS_VOICE_LOCK:
        try:
            import piper  # noqa: F401
            direct=True
        except Exception:
            direct=False
        if direct:
            try:
                if _TTS_VOICE is None or _TTS_VOICE_PATH != str(TTS_MODEL):
                    from piper import PiperVoice
                    _TTS_VOICE=PiperVoice.load(str(TTS_MODEL)); _TTS_VOICE_PATH=str(TTS_MODEL)
                import wave
                wav=BytesIO()
                with wave.open(wav,'wb') as wav_file: _TTS_VOICE.synthesize_wav(text_value,wav_file)
                wav.seek(0)
                return StreamingResponse(wav,media_type='audio/wav',headers={'Cache-Control':'no-store','Content-Disposition':'inline; filename=persian-speech.wav'})
            except Exception as exc:
                # Do not fail if the main CPython is newer than the ONNX wheel; try the isolated worker.
                direct_error=type(exc).__name__
        else: direct_error='PythonRuntimeMismatch'
        worker_path, worker_diagnostics = _piper_worker_probe()
        if worker_path is not None:
            try:
                result=subprocess.run([str(worker_path),str(PIPER_WORKER_SCRIPT)],input=json.dumps({'text':text_value,'model':str(TTS_MODEL)},ensure_ascii=False),capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240,cwd=str(BASE))
                if result.returncode!=0: raise RuntimeError((result.stderr or result.stdout or 'خطای worker')[:250])
                out=json.loads(result.stdout or '{}')
                if not out.get('wav_base64'): raise RuntimeError('worker دادهٔ صوتی برنگرداند')
                import base64
                wav_bytes=base64.b64decode(out['wav_base64'],validate=True)
                return StreamingResponse(BytesIO(wav_bytes),media_type='audio/wav',headers={'Cache-Control':'no-store','Content-Disposition':'inline; filename=persian-speech.wav'})
            except Exception as exc:
                raise HTTPException(503,'ساخت صدا با محیط جداگانه ناموفق بود: '+type(exc).__name__+'؛ '+str(exc)[:180])
        detail='؛ '.join(worker_diagnostics[:3])
        raise HTTPException(503,'مدل حاضر است اما موتور Piper آماده نیست. '+direct_error+('؛ '+detail if detail else '')+'؛ پس از نصب Python سازگار ۶۴بیتی، setup_mana_piper.bat را دوباره اجرا کن.')

# ---- Evidence-based learning level --------------------------------------------------
class AssessmentAnswerIn(BaseModel):
    question_id:int
    selected_index:int

@app.post('/api/assessment/answer')
def assessment_answer(payload:AssessmentAnswerIn):
    with connect() as c:
        row=c.execute("SELECT id,chapter_id,metadata_json,source_status,summary FROM items WHERE id=? AND kind='question'",(payload.question_id,)).fetchone()
        if not row: raise HTTPException(404,'سؤال پیدا نشد.')
        if row['source_status'] != 'verified':
            raise HTTPException(409,'فقط سؤال تأییدشده می‌تواند در آزمون و سنجش سطح استفاده شود.')
        try: meta=json.loads(row['metadata_json'] or '{}')
        except Exception: meta={}
        key=meta.get('correct_index')
        options=meta.get('options')
        if not isinstance(options,list) or not isinstance(key,int) or isinstance(key,bool) or not (0 <= key < len(options)):
            raise HTTPException(409,'کلید پاسخ سؤال معتبر نیست.')
        if payload.selected_index<0 or payload.selected_index>=len(options): raise HTTPException(400,'گزینهٔ انتخاب‌شده معتبر نیست.')
        correct=int(payload.selected_index==key)
        c.execute('INSERT INTO assessment_attempts(question_item_id,chapter_id,correct,selected_index,created_at) VALUES(?,?,?,?,?)',
                  (row['id'],row['chapter_id'],correct,payload.selected_index,now_iso()))
        c.commit()
    # The answer key and explanation are disclosed only after an answer is submitted.
    return {'ok':True,'correct':bool(correct),'correct_index':key,
            'explanation':str(meta.get('explanation') or row['summary'] or '')}

class PracticeAttemptIn(BaseModel):
    item_id: int
    answer: str
    self_score: int
    hints_used: int = 0
    duration_seconds: int = 0

@app.get('/api/practice/lab/{item_id}')
def practice_lab_detail(item_id:int):
    with connect() as c:
        row=c.execute("SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.id=? AND i.kind='lab' AND i.source_status='verified'",(item_id,)).fetchone()
        if not row: raise HTTPException(404,'تمرین تأییدشده پیدا نشد.')
        item=dict(row)
        try: meta=json.loads(item.get('metadata_json') or '{}')
        except Exception: meta={}
        safe={k:v for k,v in meta.items() if k not in {'hints','solution','rubric'}}
        item.pop('metadata_json',None); item['metadata']=safe
        return item

@app.get('/api/practice/lab/{item_id}/hint')
def practice_lab_hint(item_id:int, step:int=1):
    if step not in (1,2,3): raise HTTPException(400,'راهنمایی باید ۱، ۲ یا ۳ باشد.')
    with connect() as c:
        row=c.execute("SELECT metadata_json FROM items WHERE id=? AND kind='lab' AND source_status='verified'",(item_id,)).fetchone()
        if not row: raise HTTPException(404,'تمرین پیدا نشد.')
        try: meta=json.loads(row['metadata_json'] or '{}')
        except Exception: meta={}
        hints=meta.get('hints') if isinstance(meta.get('hints'),list) else []
        if len(hints)<step: raise HTTPException(404,'این راهنمایی موجود نیست.')
        return {'ok':True,'item_id':item_id,'step':step,'hint':str(hints[step-1])}

@app.get('/api/practice/lab/{item_id}/solution')
def practice_lab_solution(item_id:int, request:Request):
    username=session_username(request.cookies.get(SESSION_COOKIE))
    with connect() as c:
        row=c.execute("SELECT metadata_json FROM items WHERE id=? AND kind='lab' AND source_status='verified'",(item_id,)).fetchone()
        if not row: raise HTTPException(404,'تمرین پیدا نشد.')
        attempts=c.execute('SELECT COUNT(*) n FROM practice_attempts WHERE username=? COLLATE NOCASE AND item_id=?',(username,item_id)).fetchone()['n']
        if not attempts: raise HTTPException(409,'برای دیدن پاسخ تشریحی، ابتدا پاسخ خودت را ثبت کن.')
        try: meta=json.loads(row['metadata_json'] or '{}')
        except Exception: meta={}
        return {'ok':True,'solution':str(meta.get('solution') or ''),'rubric':meta.get('rubric') or []}

@app.get('/api/practice/summary')
def practice_summary(request:Request):
    username=session_username(request.cookies.get(SESSION_COOKIE))
    with connect() as c:
        rows=c.execute('''SELECT i.id item_id,COUNT(pa.id) attempts,MAX(pa.created_at) last_attempt,
          (SELECT pa2.self_score FROM practice_attempts pa2 WHERE pa2.username=? COLLATE NOCASE AND pa2.item_id=i.id ORDER BY pa2.id DESC LIMIT 1) latest_score,
          (SELECT pa2.hints_used FROM practice_attempts pa2 WHERE pa2.username=? COLLATE NOCASE AND pa2.item_id=i.id ORDER BY pa2.id DESC LIMIT 1) latest_hints
          FROM items i LEFT JOIN practice_attempts pa ON pa.item_id=i.id AND pa.username=? COLLATE NOCASE
          WHERE i.kind='lab' AND i.source_status='verified' GROUP BY i.id''',(username,username,username)).fetchall()
        total=c.execute('SELECT COUNT(*) n FROM practice_attempts WHERE username=? COLLATE NOCASE',(username,)).fetchone()['n']
        avg=c.execute('SELECT AVG(self_score) a FROM practice_attempts WHERE username=? COLLATE NOCASE',(username,)).fetchone()['a']
    return {'ok':True,'username':username,'total_attempts':total,'average_self_score':round(float(avg),1) if avg is not None else None,'labs':{str(r['item_id']):dict(r) for r in rows}}

@app.post('/api/practice/attempts')
def save_practice_attempt(payload:PracticeAttemptIn, request:Request):
    username=session_username(request.cookies.get(SESSION_COOKIE))
    answer=str(payload.answer or '').strip()
    if len(answer)<10: raise HTTPException(400,'پاسخ باید دست‌کم ۱۰ نویسه داشته باشد تا قابل ارزیابی باشد.')
    if len(answer)>10000: raise HTTPException(413,'پاسخ از سقف ۱۰٬۰۰۰ نویسه بیشتر است.')
    if not 0<=payload.self_score<=100: raise HTTPException(400,'امتیاز باید بین ۰ تا ۱۰۰ باشد.')
    if not 0<=payload.hints_used<=3: raise HTTPException(400,'تعداد راهنمایی باید بین ۰ تا ۳ باشد.')
    if not 0<=payload.duration_seconds<=86400: raise HTTPException(400,'مدت تمرین نامعتبر است.')
    with connect() as c:
        row=c.execute("SELECT id FROM items WHERE id=? AND kind='lab' AND source_status='verified'",(payload.item_id,)).fetchone()
        if not row: raise HTTPException(404,'تمرین تأییدشده پیدا نشد.')
        cur=c.execute('INSERT INTO practice_attempts(username,item_id,answer,self_score,hints_used,duration_seconds,created_at) VALUES(?,?,?,?,?,?,?)',
                       (username,payload.item_id,answer,payload.self_score,payload.hints_used,payload.duration_seconds,now_iso()))
        c.commit()
        count=c.execute('SELECT COUNT(*) n FROM practice_attempts WHERE username=? COLLATE NOCASE AND item_id=?',(username,payload.item_id)).fetchone()['n']
    return {'ok':True,'attempt_id':cur.lastrowid,'item_id':payload.item_id,'attempt_count':count,'self_score':payload.self_score,'message':'پاسخ و خودارزیابی در پایگاه داده ثبت شد؛ امتیاز، خودارزیابی است و تصحیح خودکار نیست.'}

def level_for(accuracy:float)->tuple[str,str]:
    if accuracy>=0.85: return ('پیشرفته','در این نمونه، فهم مفاهیم سنجیده‌شده قوی است؛ برای تأیید، سناریوهای عملی هم لازم‌اند.')
    if accuracy>=0.70: return ('میانی','بخش اصلی مفاهیم درست پاسخ داده شده؛ مرور نکات اشتباه و آزمایشگاه پیشنهاد می‌شود.')
    if accuracy>=0.50: return ('در حال شکل‌گیری','مفاهیم پایه تا حدی تثبیت شده‌اند؛ درس و مرور هدفمند مفید است.')
    return ('پایه','بهتر است درس‌های پایه و مثال‌های حل‌شده مرور شوند و آزمون دوباره انجام شود.')

@app.get('/api/assessment/level')
def assessment_level(topic_id: str = ''):
    with connect() as c:
        # Only the latest answer per question counts, so repeats cannot artificially inflate confidence.
        rows=c.execute('''SELECT aa.question_item_id,aa.chapter_id,aa.correct,aa.created_at,ch.title chapter_title
          FROM assessment_attempts aa JOIN chapters ch ON ch.id=aa.chapter_id
          WHERE aa.id=(SELECT aa2.id FROM assessment_attempts aa2 WHERE aa2.question_item_id=aa.question_item_id ORDER BY aa2.id DESC LIMIT 1)
          AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=aa.chapter_id AND ct.topic_id=?))
          ORDER BY aa.id DESC''',(topic_id,topic_id)).fetchall()
    global_n=len(rows); global_correct=sum(int(r['correct']) for r in rows); chapter_map={}
    for r in rows:
        ch=chapter_map.setdefault(r['chapter_id'],{'chapter_id':r['chapter_id'],'title':r['chapter_title'],'total':0,'correct':0})
        ch['total']+=1; ch['correct']+=int(r['correct'])
    by_chapter=[]
    for ch in chapter_map.values():
        acc=ch['correct']/ch['total'] if ch['total'] else 0
        level,advice=level_for(acc)
        by_chapter.append({**ch,'accuracy':round(acc*100,1),'level':level if ch['total']>=15 else 'هنوز داده کافی نیست','advice':advice,'sample_sufficient':ch['total']>=15})
    enough=(global_n>=30 and len(chapter_map)>=3)
    if enough:
        acc=global_correct/global_n; level,advice=level_for(acc)
        overall={'available':True,'level':level,'accuracy':round(acc*100,1),'answered_unique':global_n,'chapters_tested':len(chapter_map),'advice':advice,'caveat':'برآورد آموزشی از پاسخ‌های ثبت‌شده است، نه مدرک رسمی یا سنجش کامل مهارت عملی.'}
    else:
        overall={'available':False,'level':'هنوز قابل تعیین نیست','accuracy':round(global_correct/global_n*100,1) if global_n else None,'answered_unique':global_n,'chapters_tested':len(chapter_map),'minimum_questions':30,'minimum_chapters':3,'advice':'برای برآورد کلی، دست‌کم ۳۰ سؤال یکتا از حداقل ۳ فصل پاسخ بده. برای سنجش فنی کامل، آزمایشگاه عملی هم اضافه خواهد شد.'}
    return {'overall':overall,'by_chapter':sorted(by_chapter,key=lambda x:x['title'])}

# --- Search, weak-topic report, personal preferences and full restore ------------------
@app.get('/api/search')
def global_search(q:str='', limit:int=60, topic_id:str=''):
    q=str(q or '').strip()[:160]
    if not q: return {'query':'','items':[],'chapters':[],'tasks':[]}
    like=f'%{q}%'; limit=max(1,min(150,int(limit)))
    with connect() as c:
        chapters=[dict(r) for r in c.execute("SELECT id,title,order_num FROM chapters WHERE title LIKE ? AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=chapters.id AND ct.topic_id=?)) ORDER BY order_num,title COLLATE NATURAL_NOCASE,id LIMIT ?", (like,topic_id,topic_id,min(limit,30)))]
        rows=c.execute('''SELECT i.id,i.chapter_id,ch.title chapter_title,i.kind,i.title,i.summary,i.content,i.source_status,i.source_file,i.metadata_json\n          FROM items i JOIN chapters ch ON ch.id=i.chapter_id\n          WHERE i.source_status='verified' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.source_file LIKE ?) AND (?='' OR EXISTS (SELECT 1 FROM chapter_topics ct WHERE ct.chapter_id=i.chapter_id AND ct.topic_id=?)) ORDER BY i.id DESC LIMIT ?''',(like,like,like,like,topic_id,topic_id,limit)).fetchall()
        item_results=[]
        for r in rows:
            d=dict(r); md=json.loads(d.pop('metadata_json') or '{}'); d['difficulty']=md.get('difficulty') or md.get('level') or 'intermediate'; item_results.append(d)
        tasks=[dict(r) for r in c.execute("SELECT id,title,description,status,priority,planned_start,due_at,chapter_id FROM tasks WHERE (title LIKE ? OR description LIKE ?) AND (?='' OR chapter_id IN (SELECT chapter_id FROM chapter_topics WHERE topic_id=?)) ORDER BY CASE status WHEN 'todo' THEN 0 ELSE 1 END,id DESC LIMIT 30",(like,like,topic_id,topic_id))]
    return {'query':q,'items':item_results,'chapters':chapters,'tasks':tasks}


@app.get('/api/reports/weak-topics')
def weak_topics(limit:int=10, topic_id:str=''):
    limit=max(1,min(30,int(limit)))
    with connect() as c:
        rows=c.execute('''SELECT aa.question_item_id,aa.chapter_id,aa.correct,aa.created_at,ch.title chapter_title,i.title question_title,i.metadata_json\n          FROM assessment_attempts aa JOIN chapters ch ON ch.id=aa.chapter_id JOIN items i ON i.id=aa.question_item_id\n          WHERE aa.id=(SELECT aa2.id FROM assessment_attempts aa2 WHERE aa2.question_item_id=aa.question_item_id ORDER BY aa2.id DESC LIMIT 1)\n          ORDER BY aa.id DESC''').fetchall()
    topics=[]
    for r in rows:
        md=json.loads(r['metadata_json'] or '{}'); tags=md.get('tags') or []
        topics.append({'question_item_id':r['question_item_id'],'chapter_id':r['chapter_id'],'chapter_title':r['chapter_title'],'question_title':r['question_title'],'correct':int(r['correct']),'topic':(tags[0] if tags else r['chapter_title'])})
    # Group by chapter/topic; show only groups with enough evidence to avoid over-interpreting one question.
    grouped={}
    for x in topics:
        k=(x['chapter_id'],x['topic']); g=grouped.setdefault(k,{'chapter_id':x['chapter_id'],'chapter_title':x['chapter_title'],'topic':x['topic'],'total':0,'correct':0,'recent_errors':[]})
        g['total']+=1; g['correct']+=x['correct']
        if not x['correct'] and len(g['recent_errors'])<3: g['recent_errors'].append(x['question_title'])
    out=[]
    for g in grouped.values():
        g['accuracy']=round(100*g['correct']/g['total'],1); g['error_rate']=round(100-g['accuracy'],1)
        if g['total']>=2: out.append(g)
    out.sort(key=lambda x:(x['accuracy'], -x['total']))
    return {'available':bool(out),'minimum_evidence':2,'total_unique_questions':len(topics),'topics':out[:limit],'note':'رتبه‌بندی صرفاً از آخرین پاسخ هر سؤال یکتا ساخته شده است؛ موضوعی با کمتر از دو سؤال وارد رتبه‌بندی نمی‌شود.'}


DEFAULT_PREFERENCES={
 'wake_time':'07:30','focus_start':'09:00','focus_end':'18:00','daily_capacity_minutes':'120',
 'timezone':'Asia/Tehran','notification_mode':'browser_when_open','daily_new_cards_limit':'20',
 'daily_review_limit':'100','week_starts_on':'saturday','theme':'light','app_title':'دانشنامه جامع شبکه',
 'app_font_family':'tahoma','study_font_family':'tahoma','study_font_size':'18','study_line_height':'2.0','study_content_width':'960','app_density':'comfortable'
}

@app.get('/api/settings')
def get_preferences(request:Request):
    with connect() as c: rows=c.execute("SELECT key,value FROM settings WHERE key LIKE 'pref_%'").fetchall()
    prefs=dict(DEFAULT_PREFERENCES)
    for r in rows:
        k=r['key'][5:]
        if k in DEFAULT_PREFERENCES: prefs[k]=r['value']
    token=request.cookies.get(SESSION_COOKIE); current_username=session_username(token) if valid_session(token) else (get_setting('auth_username','admin') or 'admin')
    return {'preferences':prefs,'login_username':get_setting('auth_username','admin') or 'admin','current_username':current_username,'role':account_role(current_username),'supported_timezones':['Europe/Amsterdam','Asia/Tehran','UTC','Europe/Berlin','America/New_York'],'note':'یادآوری مرورگر فقط هنگام باز بودن برنامه قابل اتکاست؛ اعلان در حالت بسته به PWA/سرویس اعلان نیاز دارد.'}


@app.put('/api/settings')
def save_preferences(payload:dict[str,Any], request:Request):
    request_token=request.cookies.get(SESSION_COOKIE); request_username=session_username(request_token)
    request_was_admin=bool(valid_session(request_token) and account_role(request_username)=='admin')
    allowed=set(DEFAULT_PREFERENCES)|{'login_username'}
    if not payload or set(payload)-allowed: raise HTTPException(400,'تنظیم ناشناخته است')
    if 'login_username' in payload and str(payload.get('login_username') or '').strip().casefold()!=(get_setting('auth_username','admin') or 'admin').casefold() and request_username.casefold()!=(get_setting('auth_username','admin') or 'admin').casefold():
        raise HTTPException(403,'تغییر نام کاربری اصلی فقط هنگام ورود با همان حساب اصلی مجاز است.')
    clean={}; login_username=None
    for k,v in payload.items():
        v=str(v).strip()
        if k=='login_username':
            login_username=_validate_auth_username(v)
            continue
        if k=='app_title':
            v=v[:80]
            if not v: raise HTTPException(400,'عنوان برنامه نمی‌تواند خالی باشد.')
        if len(v)>160: raise HTTPException(400,f'مقدار {k} بیش از حد طولانی است')
        if k in {'daily_capacity_minutes','daily_new_cards_limit','daily_review_limit'}:
            try: n=int(v)
            except: raise HTTPException(400,f'{k} باید عدد باشد')
            if not (0<=n<=1440): raise HTTPException(400,f'{k} خارج از محدوده است')
            v=str(n)
        if k=='week_starts_on' and v not in {'saturday','sunday','monday'}: raise HTTPException(400,'شروع هفته نامعتبر است')
        if k=='notification_mode' and v not in {'off','browser_when_open','browser_and_email'}: raise HTTPException(400,'روش یادآوری نامعتبر است')
        if k=='theme' and v not in {'light','dark','system'}: raise HTTPException(400,'تم نامعتبر است')
        font_keys={'app_font_family','study_font_family'}
        allowed_fonts={'system','tahoma','segoe','vazirmatn','noto_naskh','iransans','arial'}
        if k in font_keys and v not in allowed_fonts: raise HTTPException(400,'فونت انتخاب‌شده پشتیبانی نمی‌شود.')
        if k=='study_font_size':
            try: n=int(v)
            except Exception: raise HTTPException(400,'اندازهٔ فونت باید عدد باشد.')
            if not 14<=n<=28: raise HTTPException(400,'اندازهٔ فونت باید بین ۱۴ و ۲۸ باشد.')
            v=str(n)
        if k=='study_line_height' and v not in {'1.6','1.75','1.85','2.0','2.15','2.3'}: raise HTTPException(400,'فاصلهٔ خطوط نامعتبر است.')
        if k=='study_content_width' and v not in {'760','860','960','1080','1200','100%'}: raise HTTPException(400,'عرض متن نامعتبر است.')
        if k=='app_density' and v not in {'compact','comfortable','spacious'}: raise HTTPException(400,'تراکم رابط نامعتبر است.')
        if k=='timezone':
            from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
            try: ZoneInfo(v)
            except Exception: raise HTTPException(400,'منطقهٔ زمانی نامعتبر است')
        if k in {'wake_time','focus_start','focus_end'} and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',v): raise HTTPException(400,'زمان باید به شکل HH:MM باشد')
        clean[k]=v
    with connect() as c:
        for k,v in clean.items(): c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',('pref_'+k,v))
        if login_username is not None:
            current_username=get_setting('auth_username','admin') or 'admin'
            collision=c.execute('SELECT 1 FROM user_accounts WHERE username=? COLLATE NOCASE AND username<>? COLLATE NOCASE',(login_username,current_username)).fetchone()
            if collision: raise HTTPException(409,'این نام کاربری قبلاً به حساب دیگری اختصاص یافته است.')
            c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',('auth_username',login_username))
            # Practice history is keyed to the account name in this schema; carry it
            # across a permitted login-name change instead of orphaning the learner's work.
            c.execute('UPDATE practice_attempts SET username=? WHERE username=? COLLATE NOCASE',(login_username,current_username))
            c.execute('UPDATE user_accounts SET username=?,updated_at=? WHERE username=? COLLATE NOCASE',(login_username,now_iso(),current_username))
        c.commit()
    final_username=login_username or get_setting('auth_username','admin') or 'admin'
    result=JSONResponse({'ok':True,'preferences':{**DEFAULT_PREFERENCES,**clean},'login_username':final_username})
    if login_username is not None and request_was_admin:
        result.set_cookie(SESSION_COOKIE,create_session_token(final_username),httponly=True,samesite='strict',secure=False,max_age=SESSION_SECONDS,path='/')
    return result


@app.get('/api/backup/status')
def backup_status():
    with connect() as c:
        counts={name:c.execute('SELECT COUNT(*) n FROM '+table).fetchone()['n'] for name,table in [('chapters','chapters'),('topics','topics'),('topic_assignments','chapter_topics'),('items','items'),('progress','progress'),('review_history','review_history'),('assessment_attempts','assessment_attempts'),('practice_attempts','practice_attempts'),('tasks','tasks'),('plans','study_plans'),('course_blueprints','course_blueprints'),('competency_evidence','competency_evidence')]}
    media_count=media_bytes=0
    if MEDIA.exists():
        for f in MEDIA.rglob('*'):
            if f.is_file(): media_count+=1; media_bytes+=f.stat().st_size
    backup_dir=DATA/'backups'; latest=None
    if backup_dir.exists():
        candidates=sorted([*backup_dir.glob('pre-restore-*.sqlite'),*backup_dir.glob('pre-import-repair-*.sqlite')],key=lambda x:x.stat().st_mtime,reverse=True)
        if candidates: latest={'name':candidates[0].name,'size_bytes':candidates[0].stat().st_size,'modified_at':datetime.fromtimestamp(candidates[0].stat().st_mtime).isoformat(timespec='seconds')}
    return {'ok':True,'format':'network-learning-backup-v2','backup_schema_version':5,'counts':counts,'database_size_bytes':DB.stat().st_size if DB.exists() else 0,'media_count':media_count,'media_size_bytes':media_bytes,'latest_pre_restore_snapshot':latest,'includes_topics_and_assignments':True,'includes_progress_and_history':True,'excludes_authentication_secrets':True}

@app.post('/api/restore/preview')
async def preview_full_backup(file:UploadFile=File(...)):
    raw=await file.read()
    if len(raw)>300*1024*1024: raise HTTPException(413,'فایل پشتیبان بیش از ۳۰۰ مگابایت است')
    payload_raw=raw; media_names=[]; archive_names=[]; warnings=[]
    if zipfile.is_zipfile(BytesIO(raw)):
        try:
            with zipfile.ZipFile(BytesIO(raw)) as zf:
                infos=zf.infolist()
                if len(infos)>12000 or sum(x.file_size for x in infos)>700*1024*1024: raise HTTPException(413,'محتوای ZIP از سقف مجاز فراتر رفته است')
                if any(PurePosixPath(x.filename).is_absolute() or '..' in PurePosixPath(x.filename).parts for x in infos): raise HTTPException(400,'مسیر غیرمجاز در ZIP مشاهده شد')
                json_names=[n for n in zf.namelist() if PurePosixPath(n).name in {'network-learning-backup.json','backup.json'}]
                if not json_names: raise HTTPException(400,'فایل network-learning-backup.json در ZIP پیدا نشد')
                manifest_names=[n for n in zf.namelist() if PurePosixPath(n).name=='manifest.json']
                if manifest_names:
                    try:
                        manifest=json.loads(zf.read(manifest_names[0]).decode('utf-8'))
                        for entry in manifest.get('files',[]):
                            name=str(entry.get('path') or '')
                            if not name or name not in zf.namelist(): raise ValueError('missing')
                            content=zf.read(name)
                            if len(content)!=int(entry.get('size',-1)) or hashlib.sha256(content).hexdigest()!=entry.get('sha256'): raise ValueError('checksum')
                    except Exception: raise HTTPException(400,'اعتبارسنجی checksum ناموفق است؛ فایل ناقص یا تغییرکرده است')
                payload_raw=zf.read(json_names[0]); archive_names=[n for n in zf.namelist() if not n.endswith('/')]; media_names=[n for n in archive_names if n.startswith('media/')]
        except zipfile.BadZipFile: raise HTTPException(400,'فایل ZIP پشتیبان آسیب‌دیده است')
    data=get_json(payload_raw)
    if not isinstance(data,dict) or data.get('format')!='network-learning-backup-v2': raise HTTPException(400,'قالب باید network-learning-backup-v2 باشد')
    required=('chapters','items','progress','tasks','study_plans','time_entries','review_history')
    if any(not isinstance(data.get(k,[]),list) for k in required): raise HTTPException(400,'یکی از فهرست‌های پشتیبان آرایهٔ معتبر نیست')
    chapters=data.get('chapters') or []; items=data.get('items') or []; topics=data.get('topics') or []; assignments=data.get('chapter_topics') or []
    errors=[]
    if not isinstance(data.get('course_blueprints',[]),list) or not isinstance(data.get('competency_evidence',[]),list): errors.append('فهرست طرح‌های دوره یا شواهد شایستگی آرایهٔ معتبر نیست')
    # Empty-workspace backups are valid when all content-linked lists are empty.
    chapter_ids=[str(x.get('id') or '') for x in chapters if isinstance(x,dict)]; item_ids=[str(x.get('id')) for x in items if isinstance(x,dict) and x.get('id') is not None]; topic_ids=[str(x.get('id') or '') for x in topics if isinstance(x,dict)]
    if len(chapter_ids)!=len(set(chapter_ids)): errors.append('شناسهٔ فصل تکراری است')
    if topics and len(topic_ids)!=len(set(topic_ids)): errors.append('شناسهٔ موضوع تکراری است')
    cset=set(chapter_ids); iset=set(item_ids); tset=set(topic_ids)
    if any(not isinstance(x,dict) or str(x.get('chapter_id') or '') not in cset for x in items): errors.append('محتوایی به فصل موجود پیوند ندارد')
    if any(not isinstance(x,dict) or str(x.get('item_id')) not in iset for x in (data.get('progress') or [])): warnings.append('برخی رکوردهای پیشرفت به محتوای موجود پیوند ندارند')
    for link in assignments:
        if not isinstance(link,dict) or str(link.get('chapter_id') or '') not in cset or (tset and str(link.get('topic_id') or '') not in tset): errors.append('پیوند موضوع/فصل نامعتبر است'); break
    return {'ok':not errors,'format':data.get('format'),'backup_schema_version':data.get('backup_schema_version',2),'exported_at':data.get('exported_at',''),'counts':{'chapters':len(chapters),'topics':len(topics),'topic_assignments':len(assignments),'items':len(items),'progress':len(data.get('progress') or []),'review_history':len(data.get('review_history') or []),'assessment_attempts':len(data.get('assessment_attempts') or []),'practice_attempts':len(data.get('practice_attempts') or []),'tasks':len(data.get('tasks') or []),'study_plans':len(data.get('study_plans') or []),'course_blueprints':len(data.get('course_blueprints') or []),'competency_evidence':len(data.get('competency_evidence') or []),'media_files':len(media_names)},'errors':errors,'warnings':warnings,'zip_files':len(archive_names),'message':'ساختار و checksum معتبر است؛ این بررسی محتوای آموزشی را تأیید نمی‌کند.' if not errors else 'فایل برای بازیابی ایمن نیست.'}

@app.post('/api/restore')
async def restore_full_backup(file:UploadFile=File(...), mode:str=Form('replace')):
    if mode!='replace': raise HTTPException(400,'نسخهٔ فعلی فقط بازیابی کامل و صریح را می‌پذیرد؛ برای ادغام، از واردکردن ZIP فصل استفاده کن.')
    raw=await file.read()
    if len(raw)>300*1024*1024: raise HTTPException(413,'فایل پشتیبان بیش از ۳۰۰ مگابایت است')
    archive_media={}
    payload_raw=raw
    if zipfile.is_zipfile(BytesIO(raw)):
        try:
            with zipfile.ZipFile(BytesIO(raw)) as zf:
                infos=zf.infolist()
                if len(infos)>12000 or sum(x.file_size for x in infos)>700*1024*1024: raise HTTPException(413,'محتوای استخراج‌شدهٔ ZIP از حد مجاز بزرگ‌تر است')
                json_names=[n for n in zf.namelist() if PurePosixPath(n).name in {'network-learning-backup.json','backup.json'}]
                if not json_names: raise HTTPException(400,'در ZIP فایل network-learning-backup.json یا backup.json پیدا نشد')
                # If a manifest exists, verify every listed entry before using the backup.
                manifest_names=[n for n in zf.namelist() if PurePosixPath(n).name=='manifest.json']
                if manifest_names:
                    try:
                        manifest=json.loads(zf.read(manifest_names[0]).decode('utf-8'))
                        for entry in manifest.get('files',[]):
                            name=str(entry.get('path') or '')
                            if not name or name not in zf.namelist(): raise ValueError('missing file')
                            content=zf.read(name)
                            if len(content)!=int(entry.get('size',-1)) or hashlib.sha256(content).hexdigest()!=entry.get('sha256'):
                                raise ValueError('checksum mismatch')
                    except Exception:
                        raise HTTPException(400,'اعتبارسنجی فایل پشتیبان ناموفق بود؛ فایل ناقص یا تغییر کرده است.')
                payload_raw=zf.read(json_names[0])
                for info in infos:
                    p=PurePosixPath(info.filename)
                    if info.is_dir() or p.is_absolute() or '..' in p.parts or not info.filename.startswith('media/'): continue
                    if info.file_size>MAX_FILE_BYTES: raise HTTPException(413,'یک فایل رسانه‌ای بیش از حد مجاز است')
                    rel='/'.join(p.parts[1:])
                    if rel and len(p.parts)>=2: archive_media[rel]=zf.read(info.filename)
        except zipfile.BadZipFile:
            raise HTTPException(400,'فایل ZIP پشتیبان آسیب‌دیده است')
    data=get_json(payload_raw)
    if not isinstance(data,dict) or data.get('format')!='network-learning-backup-v2': raise HTTPException(400,'فایل باید خروجی کامل JSON یا ZIP پشتیبان نسخهٔ ۲ باشد')
    if not isinstance(data.get('chapters'),list): raise HTTPException(400,'فهرست فصل پشتیبان باید آرایه باشد')
    required_lists=('items','progress','tasks','study_plans','time_entries','review_history')
    if any(not isinstance(data.get(k,[]),list) for k in required_lists): raise HTTPException(400,'ساختار یکی از جدول‌های پشتیبان نامعتبر است')
    chapter_ids={str(x.get('id') or '') for x in data.get('chapters',[]) if isinstance(x,dict)}
    item_ids={str(x.get('id')) for x in data.get('items',[]) if isinstance(x,dict) and x.get('id') is not None}
    if any(not isinstance(x,dict) or str(x.get('chapter_id') or '') not in chapter_ids for x in data.get('items',[])): raise HTTPException(400,'محتوایی به فصل موجود در پشتیبان پیوند ندارد')
    if any(not isinstance(x,dict) or str(x.get('item_id')) not in item_ids for x in data.get('progress',[])): raise HTTPException(400,'رکورد پیشرفت به محتوای موجود در پشتیبان پیوند ندارد')
    # Keep a binary snapshot of the current local DB before replacing it.
    import sqlite3 as _sqlite3
    backup_dir=DATA/'backups'; backup_dir.mkdir(exist_ok=True)
    snapshot=backup_dir/f"pre-restore-{datetime.now().strftime('%Y%m%d-%H%M%S')}.sqlite"
    try:
        src=connect(); dst=_sqlite3.connect(snapshot); src.backup(dst); dst.close(); src.close()
    except Exception as e:
        try: snapshot.unlink(missing_ok=True)
        except: pass
        raise HTTPException(500,f'ساخت نسخهٔ قبل از بازیابی ناموفق بود: {e}')
    try:
        with connect() as c:
            # Explicit replace; authentication material is intentionally preserved on this device.
            c.execute('PRAGMA defer_foreign_keys=ON')
            c.execute('DELETE FROM chapter_topics')
            if isinstance(data.get('topics'),list): c.execute('DELETE FROM topics')
            for table in ('competency_evidence','course_blueprints','daily_activity_logs','daily_activities','practice_attempts','assessment_attempts','review_history','item_revisions','time_entries','tasks','study_plans','progress','items','chapters'):
                c.execute(f'DELETE FROM {table}')
            for topic in data.get('topics',[]) if isinstance(data.get('topics'),list) else []:
                if not isinstance(topic,dict) or not topic.get('id') or not topic.get('title'): continue
                features=topic.get('features') if isinstance(topic.get('features'),dict) else {}
                c.execute('INSERT INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)',(str(topic['id']),str(topic['title']),str(topic.get('description') or ''),json.dumps(features,ensure_ascii=False),topic.get('created_at') or now_iso(),topic.get('updated_at') or now_iso()))
            for ch in data['chapters']:
                c.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(
                    ch['id'],ch['title'],int(ch.get('order_num') or 999),ch.get('group_name') or 'main',ch.get('source') or 'restore',ch.get('description') or '',ch.get('created_at') or now_iso()))
            known_topic_ids={r['id'] for r in c.execute('SELECT id FROM topics').fetchall()}
            if isinstance(data.get('chapter_topics'),list):
                for link in data.get('chapter_topics',[]):
                    if not isinstance(link,dict): continue
                    cid=str(link.get('chapter_id') or ''); tid=str(link.get('topic_id') or '')
                    if cid in chapter_ids and tid in known_topic_ids: c.execute('INSERT OR IGNORE INTO chapter_topics(chapter_id,topic_id) VALUES(?,?)',(cid,tid))
            else:
                c.execute("INSERT OR IGNORE INTO topics(id,title,description,features_json,created_at,updated_at) VALUES(?,?,?,?,?,?)",('topic_it','فناوری اطلاعات','مجموعهٔ فصل‌های موجود دانشنامهٔ شبکه و فناوری اطلاعات',json.dumps({'lessons':True,'questions':True,'flashcards':True,'commands':True,'labs':True,'images':True,'sources':True,'planner':True,'reports':True},ensure_ascii=False),now_iso(),now_iso()))
                c.execute("INSERT OR IGNORE INTO chapter_topics(chapter_id,topic_id) SELECT id,'topic_it' FROM chapters")
            for it in data.get('items',[]):
                md=it.get('metadata',{}) or {}
                c.execute('INSERT INTO items(id,chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(
                    it.get('id'),it['chapter_id'],it['kind'],it['title'],it.get('summary') or '',it.get('content') or '',it.get('source_status') or 'review_required',it.get('source_file') or '',it.get('source_uid') or '',json.dumps(md,ensure_ascii=False),it.get('created_at') or now_iso()))
            for row in data.get('progress',[]):
                c.execute('INSERT INTO progress(item_id,completed,correct_count,wrong_count,interval_days,ease,due_at,last_reviewed) VALUES(?,?,?,?,?,?,?,?)',(
                    row['item_id'],row.get('completed',0),row.get('correct_count',0),row.get('wrong_count',0),row.get('interval_days',0),row.get('ease',2.5),row.get('due_at') or '',row.get('last_reviewed') or ''))
            for t in data.get('tasks',[]):
                c.execute('''INSERT INTO tasks(id,title,description,status,priority,planned_start,due_at,reminder_at,estimate_minutes,actual_minutes,repeat_rule,chapter_id,item_id,depends_on_id,tags_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
                    t.get('id'),t['title'],t.get('description') or '',t.get('status') or 'todo',t.get('priority',2),t.get('planned_start') or '',t.get('due_at') or '',t.get('reminder_at') or '',t.get('estimate_minutes',0),t.get('actual_minutes',0),t.get('repeat_rule') or '',t.get('chapter_id'),t.get('item_id'),t.get('depends_on_id'),t.get('tags_json') or json.dumps(t.get('tags') or [],ensure_ascii=False),t.get('created_at') or now_iso(),t.get('updated_at') or now_iso()))
            for pl in data.get('study_plans',[]):
                active=pl.get('active_chapters_json') or json.dumps(pl.get('active_chapters') or [],ensure_ascii=False)
                c.execute('INSERT INTO study_plans(id,title,period_type,start_date,end_date,target_minutes,target_cards,target_questions,active_chapters_json,notes,created_at,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(
                    pl.get('id'),pl['title'],pl.get('period_type') or 'week',pl['start_date'],pl['end_date'],pl.get('target_minutes',0),pl.get('target_cards',0),pl.get('target_questions',0),active,pl.get('notes') or '',pl.get('created_at') or now_iso(),pl.get('parent_id')))
            for te in data.get('time_entries',[]):
                c.execute('INSERT INTO time_entries(id,task_id,item_id,started_at,ended_at,duration_minutes,note) VALUES(?,?,?,?,?,?,?)',(
                    te.get('id'),te.get('task_id'),te.get('item_id'),te['started_at'],te.get('ended_at') or '',te.get('duration_minutes',0),te.get('note') or ''))
            for rh in data.get('review_history',[]):
                c.execute('INSERT INTO review_history(id,item_id,rating,reviewed_at,old_interval_days,new_interval_days,old_ease,new_ease,duration_seconds) VALUES(?,?,?,?,?,?,?,?,?)',(
                    rh.get('id'),rh['item_id'],rh['rating'],rh['reviewed_at'],rh.get('old_interval_days',0),rh.get('new_interval_days',0),rh.get('old_ease',2.5),rh.get('new_ease',2.5),rh.get('duration_seconds',0)))
            for aa in data.get('assessment_attempts',[]):
                c.execute('INSERT INTO assessment_attempts(id,question_item_id,chapter_id,correct,selected_index,created_at) VALUES(?,?,?,?,?,?)',(
                    aa.get('id'),aa['question_item_id'],aa['chapter_id'],aa['correct'],aa.get('selected_index',0),aa.get('created_at') or now_iso()))
            for pa in data.get('practice_attempts',[]):
                c.execute('INSERT INTO practice_attempts(id,username,item_id,answer,self_score,hints_used,duration_seconds,created_at) VALUES(?,?,?,?,?,?,?,?)',(
                    pa.get('id'),pa.get('username') or '',pa['item_id'],pa.get('answer') or '',int(pa.get('self_score',0)),int(pa.get('hints_used',0)),int(pa.get('duration_seconds',0)),pa.get('created_at') or now_iso()))
            for rv in data.get('item_revisions',[]):
                c.execute('INSERT INTO item_revisions(id,item_id,changed_at,title,summary,content,source_status,metadata_json,change_reason) VALUES(?,?,?,?,?,?,?,?,?)',(
                    rv.get('id'),rv['item_id'],rv.get('changed_at') or now_iso(),rv['title'],rv.get('summary') or '',rv.get('content') or '',rv.get('source_status') or 'review_required',rv.get('metadata_json') or '{}',rv.get('change_reason') or 'بازیابی نسخه'))
            for a in data.get('daily_activities',[]):
                c.execute('INSERT INTO daily_activities(id,title,description,time_of_day,days_json,enabled,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?)',(
                    a.get('id'),a['title'],a.get('description') or '',a.get('time_of_day') or '',a.get('days_json') or json.dumps(a.get('days') or list(range(7))),int(a.get('enabled',1)),int(a.get('sort_order',100)),a.get('created_at') or now_iso()))
            for al in data.get('daily_activity_logs',[]):
                c.execute('INSERT INTO daily_activity_logs(id,activity_id,activity_date,completed,completed_at,note) VALUES(?,?,?,?,?,?)',(
                    al.get('id'),al['activity_id'],al['activity_date'],int(al.get('completed',0)),al.get('completed_at') or '',al.get('note') or ''))
            for bp in data.get('course_blueprints',[]) if isinstance(data.get('course_blueprints'),list) else []:
                if not isinstance(bp,dict) or not bp.get('id') or not bp.get('title'): continue
                c.execute('INSERT INTO course_blueprints(id,title,domain_profile,status,request_json,blueprint_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',(str(bp['id']),str(bp['title']),str(bp.get('domain_profile') or 'general_research'),str(bp.get('status') or 'draft'),str(bp.get('request_json') or '{}'),str(bp.get('blueprint_json') or '{}'),str(bp.get('created_at') or now_iso()),str(bp.get('updated_at') or now_iso())))
            for ce in data.get('competency_evidence',[]) if isinstance(data.get('competency_evidence'),list) else []:
                if not isinstance(ce,dict) or not ce.get('username') or not ce.get('domain_profile') or not ce.get('competency_id'): continue
                c.execute('INSERT INTO competency_evidence(username,domain_profile,competency_id,competency_title,status,score,evidence,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(username,domain_profile,competency_id) DO UPDATE SET competency_title=excluded.competency_title,status=excluded.status,score=excluded.score,evidence=excluded.evidence,updated_at=excluded.updated_at',(str(ce['username']),str(ce['domain_profile']),str(ce['competency_id']),str(ce.get('competency_title') or ce['competency_id']),str(ce.get('status') or 'practicing'),ce.get('score'),str(ce.get('evidence') or ''),str(ce.get('updated_at') or now_iso())))
            # Replace only learning preferences; keep the current password and session secret.
            c.execute("DELETE FROM settings WHERE key LIKE 'pref_%'")
            prefs=data.get('preferences') or {}
            for k,v in prefs.items():
                # Version 2 exports preserve the historical database keys (pref_timezone),
                # while external backups may use plain preference names (timezone).
                normalized_key = k[5:] if str(k).startswith('pref_') else str(k)
                if normalized_key in DEFAULT_PREFERENCES:
                    c.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',('pref_'+normalized_key,str(v)))
            c.commit()
    except Exception as e:
        raise HTTPException(400,f'بازیابی انجام نشد؛ پایگاه داده به نسخهٔ قبل دست‌نخورده مانده و Snapshot ذخیره شد: {str(e)[:260]}')
    restored_media=0
    for rel,content in archive_media.items():
        try:
            safe_parts=PurePosixPath(rel)
            if safe_parts.is_absolute() or '..' in safe_parts.parts: continue
            dest=MEDIA.joinpath(*safe_parts.parts)
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(content); restored_media+=1
        except Exception:
            continue
    return {'ok':True,'mode':'replace','chapters':len(data['chapters']),'items':len(data.get('items',[])),'tasks':len(data.get('tasks',[])),'plans':len(data.get('study_plans',[])),'daily_activities':len(data.get('daily_activities',[])),'restored_media':restored_media,'restored_snapshot':snapshot.name,'note':'رمز ورود محلی عمداً از دستگاه فعلی حفظ شد.'}


# ---- First-run content packs: idempotent seeding ------------------------------------
def seed_one_pack(pack_dir: Path, setting_key: str, expected_title: str | None = None):
    bundle_path=pack_dir/'import_bundle.json'
    if not bundle_path.exists() or get_setting(setting_key)=='done': return
    try: bundle=json.loads(bundle_path.read_text(encoding='utf-8'))
    except Exception: return
    if bundle.get('format')!='network-learning-pack-v1': return
    with connect() as c:
        chapter_map={}
        for ch in bundle.get('chapters',[]):
            title=str(ch.get('title') or ch.get('title_fa') or expected_title or 'فصل واردشده')
            existing=c.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
            if existing: cid=existing['id']
            else:
                wanted=str(ch.get('id') or '')
                if wanted and not c.execute('SELECT 1 FROM chapters WHERE id=?',(wanted,)).fetchone(): cid=wanted
                else: cid=ensure_import_chapter(c,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','content-pack')
                if not c.execute('SELECT 1 FROM chapters WHERE id=?',(cid,)).fetchone():
                    c.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(cid,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','content-pack',ch.get('description') or '',now_iso()))
            chapter_map[str(ch.get('id') or '')]=cid
        for it in bundle.get('items',[]):
            if not isinstance(it,dict): continue
            oldcid=str(it.get('chapter_id') or '')
            cid=chapter_map.get(oldcid) or (oldcid if c.execute('SELECT 1 FROM chapters WHERE id=?',(oldcid,)).fetchone() else 'c01')
            kind=it.get('kind') or 'lesson'; title=it.get('title') or 'مورد بدون عنوان'
            content=it.get('content') or ''; meta=dict(it.get('metadata') or {})
            if kind=='asset':
                media_dir=pack_dir/'assets'
                original=Path(str(meta.get('file_name') or content)).name
                src=media_dir/original
                if src.is_file():
                    dest_name=safe_name(src.name); dest=MEDIA/dest_name
                    if not dest.exists(): dest.write_bytes(src.read_bytes())
                    meta['path']=f'/media/{dest_name}'; meta['file_name']=src.name; content=meta['path']
                elif str(meta.get('path','')).startswith('/media/'):
                    continue
            add_item(c,cid,kind,title,it.get('summary') or '',content,it.get('source_status') or 'review_required',it.get('source_file') or bundle_path.name,str(it.get('source_uid') or ''),meta)
        c.commit()
    set_setting(setting_key,'done')


def seed_packaged_content():
    """Optionally seed bundled content for a developer/demo install only.

    A normal first launch must be empty: a user creates a topic, then chooses
    chapters/content to import after preview. Existing database rows are never
    deleted by this switch. Set NETWORK_LEARNING_SEED_PACKAGED_CONTENT=1 only
    when deliberately creating a demo/test database.
    """
    enabled = str(os.environ.get('NETWORK_LEARNING_SEED_PACKAGED_CONTENT', '')).strip().lower() in {'1','true','yes','on'}
    if not enabled:
        return
    seed_one_pack(BASE/'content_pack'/'chapter01','chapter01_pack_v1',CHAPTERS[0][1])
    seed_one_pack(BASE/'content_pack'/'chapter21','chapter21_sample_v1',CHAPTERS[20][1])
    seed_one_pack(BASE/'content_pack'/'chapter30','chapter30_deep_pack_v3',CHAPTERS[29][1])
    seed_one_pack(BASE/'content_pack'/'chapter31','chapter31_deep_pack_v3',CHAPTERS[30][1])
    seed_one_pack(BASE/'content_pack'/'chapter32','chapter32_deep_pack_v3',CHAPTERS[31][1])


seed_packaged_content()
