@echo off
setlocal EnableExtensions
if not "%~1"=="" set "NL_PORT=%~1"
if not defined NL_PORT set "NL_PORT=82"
for /f "delims=0123456789" %%A in ("%NL_PORT%") do (
  echo ERROR: Port must be numeric.
  pause
  exit /b 1
)
if %NL_PORT% LSS 1 (
  echo ERROR: Port must be between 1 and 65535.
  pause
  exit /b 1
)
if %NL_PORT% GTR 65535 (
  echo ERROR: Port must be between 1 and 65535.
  pause
  exit /b 1
)
net session >nul 2>&1
if not %errorlevel%==0 (
  echo Right-click this file and choose "Run as administrator".
  echo Optional: pass the same port used by run_windows.bat, for example allow_lan_firewall.bat 8080.
  pause
  exit /b 1
)
set "RULE=NetworkLearning-LAN-%NL_PORT%"
netsh advfirewall firewall delete rule name="%RULE%" >nul 2>&1
netsh advfirewall firewall add rule name="%RULE%" dir=in action=allow protocol=TCP localport=%NL_PORT% profile=private description="Allow Network Learning only on Windows Private network profile"
if errorlevel 1 (
  echo Firewall rule could not be created for TCP %NL_PORT%.
  pause
  exit /b 1
)
echo Firewall rule created for Private profile only on TCP %NL_PORT%.
echo Do not change this to Public profile and do not port-forward it to the Internet.
pause
