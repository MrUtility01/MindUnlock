﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo ============================================================
echo Network Learning App - Optional Offline Persian Piper setup
echo The main app Python environment will not be modified.
echo If setup fails, run debug_logs_windows.bat to collect redacted diagnostics.
echo ============================================================
if not exist app.py (
  echo ERROR: Run this file from the extracted project folder.
  if not defined NL_PIPER_NO_PAUSE pause
  exit /b 1
)
set "MODEL_SCRIPT=%~dp0download_mana_persian_piper_model.py"
if not exist "%MODEL_SCRIPT%" (
  echo ERROR: Missing download_mana_persian_piper_model.py
  if not defined NL_PIPER_NO_PAUSE pause
  exit /b 1
)
rem The model downloader only needs Python's standard library. Use whichever app
rem runtime is already prepared instead of assuming .venv always exists.
set "MODEL_PY="
if exist ".portable-python\python.exe" set "MODEL_PY=.portable-python\python.exe"
if not defined MODEL_PY if exist ".venv\Scripts\python.exe" set "MODEL_PY=.venv\Scripts\python.exe"
if not defined MODEL_PY (
  where python >nul 2>nul
  if not errorlevel 1 set "MODEL_PY=python"
)
if not defined MODEL_PY (
  echo ERROR: No Python runtime was found for the model downloader.
  echo First run run_windows.bat or prepare the development environment.
  if not defined NL_PIPER_NO_PAUSE pause
  exit /b 1
)
"%MODEL_PY%" "%MODEL_SCRIPT%" --target "%CD%"
if errorlevel 1 (
  echo Model download failed. Check Internet access and retry.
  if not defined NL_PIPER_NO_PAUSE pause
  exit /b 1
)
rem Reuse a working Piper venv even when its base Python is no longer registered in the launcher.
if exist .tts-venv\Scripts\python.exe (
  .tts-venv\Scripts\python.exe -c "import sys,struct,piper,onnxruntime; raise SystemExit(0 if (3,11)<=sys.version_info[:2]<(3,15) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
  if not errorlevel 1 goto install_done
)
rem Reuse the previously configured system interpreter before searching PATH/py again.
if exist piper_python_path.txt (
  set "TTS_CONFIGURED_PY="
  for /f "usebackq delims=" %%P in ("piper_python_path.txt") do set "TTS_CONFIGURED_PY=%%P"
  if defined TTS_CONFIGURED_PY (
    "%TTS_CONFIGURED_PY%" -c "import sys,struct,piper,onnxruntime; raise SystemExit(0 if (3,11)<=sys.version_info[:2]<(3,15) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
    if not errorlevel 1 (
      set "TTS_PY="%TTS_CONFIGURED_PY%""
      echo Reusing the previously configured system Piper runtime.
      goto configured_runtime_ready
    )
  )
)
set "TTS_PY="
rem Optional override for Python 3.11-3.14 installed outside the Python Launcher / PATH.
if defined NL_TTS_PYTHON (
  echo Checking Python override from NL_TTS_PYTHON...
  "%NL_TTS_PYTHON%" -c "import sys,struct; raise SystemExit(0 if (3,11)<=sys.version_info[:2]<(3,15) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
  if not errorlevel 1 set "TTS_PY="%NL_TTS_PYTHON%""
  if not defined TTS_PY echo NL_TTS_PYTHON is not a compatible 64-bit CPython 3.11-3.14; automatic discovery will be tried.
)
rem Prefer the default Python only if no explicit override succeeded.
if not defined TTS_PY (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys,struct; raise SystemExit(0 if (3,11)<=sys.version_info[:2]<(3,15) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
    if not errorlevel 1 set "TTS_PY=python"
  )
)
rem If the default Python is too new, try registered side-by-side runtimes.
for %%V in (3.14 3.13 3.12 3.11) do (
  if not defined TTS_PY (
    py -%%V -c "import sys,struct; raise SystemExit(0 if sys.version_info[:2] == tuple(map(int,'%%V'.split('.'))) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
    if not errorlevel 1 set "TTS_PY=py -%%V"
  )
)
if not defined TTS_PY (
  echo.
  echo Model downloaded, but no compatible 64-bit Python 3.11-3.14 was found.
  echo The main app may continue to run with its own Python, but the current
  echo ONNX Runtime release does not publish a CPython 3.15 wheel yet.
  echo Install standard Python 3.14 x64, then run this file again.
  echo If installed in a custom path, set NL_TTS_PYTHON to its full python.exe path first.
  echo Browser-based speech can still work if a local Persian voice is installed.
  if not defined NL_PIPER_NO_PAUSE pause
  exit /b 2
)
echo Using optional speech runtime: !TTS_PY!
if exist .tts-venv\Scripts\python.exe (
  set "TTS_BACKUP=.tts-venv_backup_%RANDOM%"
  echo Existing optional environment is incomplete or incompatible.
  echo Preserving old optional environment as !TTS_BACKUP! ...
  move .tts-venv !TTS_BACKUP! >nul
  if errorlevel 1 goto setup_error
)
rem Reuse a compatible system Python which already has Piper and ONNX Runtime installed.
!TTS_PY! -c "import piper,onnxruntime; print('Existing Piper packages are usable')" >nul 2>nul
if not errorlevel 1 goto configured_runtime_ready
rem Do not keep a stale system-Python path when building a new local sidecar environment.
del /q piper_python_path.txt >nul 2>nul
!TTS_PY! -m venv .tts-venv
if errorlevel 1 goto setup_error
set "PIP_OK="
for %%M in ("https://pypi.org/simple" "https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple") do (
  set "INDEX=%%~M"
  echo Trying package index: !INDEX!
  .tts-venv\Scripts\python.exe -m pip install --disable-pip-version-check --retries 1 --timeout 20 --only-binary=:all: --prefer-binary --index-url "!INDEX!" piper-tts
  if not errorlevel 1 set "PIP_OK=1"
  if defined PIP_OK goto install_done
)
echo Installation failed from available indexes.
goto setup_error
:install_done
.tts-venv\Scripts\python.exe -c "from piper import PiperVoice; import onnxruntime; print('Piper runtime ready')"
if errorlevel 1 goto setup_error
del /q piper_python_path.txt >nul 2>nul
goto setup_success

:configured_runtime_ready
!TTS_PY! -c "from piper import PiperVoice; import onnxruntime; print('Existing system Piper runtime ready')"
if errorlevel 1 goto setup_error
!TTS_PY! -c "import sys; print(sys.executable)" > "piper_python_path.txt"
if errorlevel 1 goto setup_error
echo Stored configured interpreter path in piper_python_path.txt.
goto setup_success

:setup_success
echo.
echo SUCCESS: The optional speech runtime is ready.
echo Restart run_windows.bat, then Settings - Offline Persian speech - Check status.
echo TTS model stays inside models\mana-persian-piper; no Internet is needed to synthesize speech after setup.
  if not defined NL_PIPER_NO_PAUSE pause
exit /b 0
:setup_error
echo.
echo ERROR: Optional Piper setup failed. The main learning app environment was not changed.
echo.
echo Running a diagnostic import to identify Python / ONNX Runtime / DLL errors:
if exist .tts-venv\Scripts\python.exe .tts-venv\Scripts\python.exe -c "import sys; print('Python:',sys.version); import piper; print('piper import: OK'); import onnxruntime; print('onnxruntime import: OK')"
if errorlevel 1 (
  echo.
  echo If the error says DLL load failed for onnxruntime_pybind11_state, install or repair Microsoft Visual C++ Redistributable 2015-2022 x64 from Microsoft's official site, restart Windows if requested, then rerun setup_mana_piper.bat.
  echo Official download page: https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist
  echo Do not copy random DLL files into the application folder.
)
echo Check available disk space and Internet access only if the failure occurred during download.
  if not defined NL_PIPER_NO_PAUSE pause
exit /b 1
