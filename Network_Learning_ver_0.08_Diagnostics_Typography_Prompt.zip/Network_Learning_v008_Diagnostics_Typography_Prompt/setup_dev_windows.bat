﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo ============================================================
echo Network Learning ver 0.08 - Development Environment Setup
echo This prepares a local .venv for running and testing the app.
echo It does NOT build the final offline portable package.
echo ============================================================

set "PY_CMD="
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys,struct; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<(3,16) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  where py >nul 2>nul
  if not errorlevel 1 (
    for %%V in (3.15 3.14 3.13 3.12 3.11 3.10) do (
      if not defined PY_CMD (
        py -%%V -c "import sys,struct; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<(3,16) and struct.calcsize('P')==8 and (not hasattr(sys,'_is_gil_enabled') or sys._is_gil_enabled()) else 1)" >nul 2>nul
        if not errorlevel 1 set "PY_CMD=py -%%V"
      )
    )
  )
)
if not defined PY_CMD goto no_python
echo Selected Python: !PY_CMD!

if exist ".venv\Scripts\python.exe" (
  .venv\Scripts\python.exe -c "import sys; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<(3,16) and sys.maxsize>2**32 else 1)" >nul 2>nul
  if errorlevel 1 (
    set "OLD_VENV=.venv_backup_%RANDOM%"
    echo Existing .venv has an incompatible runtime; preserving it as !OLD_VENV!.
    move .venv "!OLD_VENV!" >nul
    if errorlevel 1 goto venv_error
  )
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating project-local development environment...
  !PY_CMD! -m venv .venv
  if errorlevel 1 goto venv_error
)

rem ensurepip seeds pip from the selected Python installation; it does not fetch pip from the Internet.
.venv\Scripts\python.exe -m ensurepip --upgrade
if errorlevel 1 goto pip_bootstrap_error
.venv\Scripts\python.exe -m pip --version
if errorlevel 1 goto pip_bootstrap_error

rem Try a user-specified index first, then PyPI and public mirrors. Retry only once per mirror.
if defined PIP_INDEX_URL (
  echo Trying configured PIP_INDEX_URL...
  .venv\Scripts\python.exe -m pip install --disable-pip-version-check --retries 1 --timeout 25 --only-binary=:all: -r requirements.txt --index-url "%PIP_INDEX_URL%"
  if not errorlevel 1 goto dependencies_ready
  echo Configured package index failed; trying fallback indexes.
)
for %%M in ("https://pypi.org/simple" "https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple" "https://repo.huaweicloud.com/repository/pypi/simple" "https://mirrors.aliyun.com/pypi/simple/") do (
  echo.
  echo Trying package index: %%~M
  .venv\Scripts\python.exe -m pip install --disable-pip-version-check --retries 1 --timeout 25 --only-binary=:all: -r requirements.txt --index-url "%%~M"
  if not errorlevel 1 goto dependencies_ready
  echo This index failed; trying the next one.
)
goto package_error

:dependencies_ready
echo.
.venv\Scripts\python.exe -c "import fastapi,uvicorn,multipart,docx,pypdf; print('DEPENDENCIES_OK')"
if errorlevel 1 goto dependency_check_error
.venv\Scripts\python.exe -m pip check
if errorlevel 1 goto dependency_check_error
echo.
echo SUCCESS: development environment is ready.
echo Next command: run_windows.bat
exit /b 0

:no_python
echo.
echo ERROR: No compatible standard 64-bit CPython 3.10-3.15 was found.
echo Install standard CPython from python.org, then run this script again.
pause
exit /b 1
:venv_error
echo.
echo ERROR: Could not create .venv. Check folder permissions and Python installation.
pause
exit /b 1
:pip_bootstrap_error
echo.
echo ERROR: pip could not be initialized from the local Python installation using ensurepip.
echo No pip bootstrap download was attempted. Repair or reinstall standard CPython, then retry.
pause
exit /b 1
:package_error
echo.
echo ERROR: Dependencies could not be downloaded from the configured indexes.
echo Review Internet/proxy/firewall access or configure PIP_INDEX_URL.
echo Existing database and learning data were not deleted.
pause
exit /b 1
:dependency_check_error
echo.
echo ERROR: Dependency smoke test or pip check failed. Review the messages above.
pause
exit /b 1
