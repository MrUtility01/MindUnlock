﻿# Build a relocatable Windows x64 runtime for Network Learning.
# Network is required only while preparing this folder; the finished folder runs offline.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Root = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$RuntimeVersion = '3.13.17'
$RuntimeMinor = '3.13'
$RuntimeDir = Join-Path $Root '.portable-python'
$Python = Join-Path $RuntimeDir 'python.exe'
$ReadyFile = Join-Path $Root '.portable-ready.json'
$ModelDir = Join-Path $Root 'models\mana-persian-piper'
$Model = Join-Path $ModelDir 'fa_IR-mana-medium.onnx'
$Config = Join-Path $ModelDir 'fa_IR-mana-medium.onnx.json'
$ExpectedModelHash = 'e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126'
$LogPath = Join-Path $Root 'portable_setup.log'
$OldSslCertFile = $env:SSL_CERT_FILE
# Raise pip's network timeouts for slow or intermittently reachable package mirrors.
# Preserve the caller's environment and restore it in finally below.
$OldPipTimeout = $env:PIP_TIMEOUT
$OldPipDefaultTimeout = $env:PIP_DEFAULT_TIMEOUT
$OldPipRetries = $env:PIP_RETRIES
$env:PIP_TIMEOUT = '90'
$env:PIP_DEFAULT_TIMEOUT = '90'
$env:PIP_RETRIES = '8'

function Write-SetupLog([string]$Message) {
    $line = '[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $Message
    try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 } catch {}
    Write-Host $Message
}

function Test-Imports([string]$Exe, [string]$Code) {
    if (!(Test-Path -LiteralPath $Exe -PathType Leaf)) { return $false }
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        # Redirect native stderr into the success stream: Windows PowerShell 5.1 can
        # otherwise turn a child's first stderr line into a terminating NativeCommandError.
        $output = @(& $Exe -c $Code 2>&1)
        $exitCode = $LASTEXITCODE
        if ($exitCode -ne 0) {
            Write-SetupLog ('Runtime check failed (exit ' + $exitCode + '): ' + (($output | ForEach-Object { [string]$_ }) -join ' | '))
            return $false
        }
        return $true
    } catch {
        Write-SetupLog ('Runtime check exception: ' + $_.Exception.ToString())
        return $false
    } finally {
        $ErrorActionPreference = $oldPreference
    }
}

function Invoke-NativeLogged([string]$Exe, [string[]]$Arguments, [string]$Step) {
    Write-SetupLog ('--- ' + $Step + ' ---')
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $output = @(& $Exe @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
    } catch {
        $output = @($_.Exception.ToString())
        $exitCode = 1
    } finally {
        $ErrorActionPreference = $oldPreference
    }
    foreach ($item in $output) {
        $line = [string]$item
        try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 } catch {}
        Write-Host $line
    }
    Write-SetupLog ($Step + ' exit code: ' + $exitCode)
    if ($exitCode -ne 0) {
        throw ($Step + ' failed with exit code ' + $exitCode + '. Full output is in ' + $LogPath)
    }
}

function Test-Ready {
    if (!(Test-Path -LiteralPath $ReadyFile) -or !(Test-Path -LiteralPath $Model) -or !(Test-Path -LiteralPath $Config)) { return $false }
    if (!(Test-Imports $Python "import sys; assert sys.version_info[:2] == (3,13); assert sys.maxsize > 2**32")) { return $false }
    if (!(Test-Imports $Python 'import fastapi,uvicorn,multipart,docx,pypdf,piper,onnxruntime')) { return $false }
    $hash = (Get-FileHash -LiteralPath $Model -Algorithm SHA256).Hash.ToLowerInvariant()
    return ($hash -eq $ExpectedModelHash)
}

function Set-EmbeddedPythonPaths([string]$Dir) {
    $pth = Get-ChildItem -LiteralPath $Dir -Filter 'python*._pth' -File | Select-Object -First 1
    if (!$pth) { throw "Python embeddable path file was not found in: $Dir" }
    $lines = @(Get-Content -LiteralPath $pth.FullName)
    # Embedded Python uses python*._pth isolation; include the application working directory
    # so imports such as `import app` and `import launch_server` resolve from the project root.
    if (!($lines | Where-Object { $_.Trim() -eq '.' })) { $lines += '.' }
    if (!($lines | Where-Object { $_.Trim() -eq 'Lib\site-packages' })) { $lines += 'Lib\site-packages' }
    $lines = @($lines | Where-Object { $_.Trim() -notmatch '^#\s*import\s+site\s*$' -and $_.Trim() -ne 'import site' })
    $lines += 'import site'
    Set-Content -LiteralPath $pth.FullName -Value $lines -Encoding Ascii
    New-Item -ItemType Directory -Path (Join-Path $Dir 'Lib\site-packages') -Force | Out-Null
}

# Make the underlying error reproducible: each attempt starts a clean text log.
Set-Content -LiteralPath $LogPath -Value ('Network Learning portable setup log; ' + (Get-Date -Format 'o')) -Encoding UTF8
Write-SetupLog ('Project folder: ' + $Root)
Write-SetupLog ('Expected runtime: CPython ' + $RuntimeVersion + ' x64')

Push-Location $Root
try {
    if (Test-Ready) {
        Write-SetupLog 'Portable runtime, app packages, and offline Persian voice are already valid.'
        Write-Host ('Log: ' + $LogPath) -ForegroundColor DarkGray
        exit 0
    }
    if (Test-Path -LiteralPath $ReadyFile) {
        Write-SetupLog 'Removing stale readiness marker because the full runtime check did not pass.'
        Remove-Item -LiteralPath $ReadyFile -Force
    }
    if (!(Test-Path (Join-Path $Root 'requirements.txt')) -or !(Test-Path (Join-Path $Root 'app.py'))) {
        throw 'Run this script from the application root folder; app.py and requirements.txt are required.'
    }
    $Cache = Join-Path $Root '.portable-cache'
    New-Item -ItemType Directory -Path $Cache -Force | Out-Null

    if (Test-Path -LiteralPath $Python -PathType Leaf) {
        if (!(Test-Imports $Python "import sys; assert sys.version_info[:2] == (3,13); assert sys.maxsize > 2**32")) {
            $OldRuntime = Join-Path $Root ('.portable-python_backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
            Write-SetupLog ('Existing portable Python is incompatible; preserving it as ' + $OldRuntime)
            Move-Item -LiteralPath $RuntimeDir -Destination $OldRuntime
        }
    }

    if (!(Test-Path -LiteralPath $Python -PathType Leaf)) {
        $RuntimeDownloaded = $false
        $Zip = ''
        $TempRuntime = Join-Path $Root '.portable-python.installing'
        foreach ($CandidateVersion in @('3.13.17','3.13.16')) {
            $CandidateZip = Join-Path $Cache "python-$CandidateVersion-embed-amd64.zip"
            $CandidateUrl = "https://www.python.org/ftp/python/$CandidateVersion/python-$CandidateVersion-embed-amd64.zip"
            try {
                if (Test-Path -LiteralPath $CandidateZip) { Remove-Item -LiteralPath $CandidateZip -Force }
                Write-SetupLog ("Downloading official embedded CPython $CandidateVersion x64 from python.org...")
                Invoke-WebRequest -UseBasicParsing -Uri $CandidateUrl -OutFile $CandidateZip -TimeoutSec 180
                if (!(Test-Path $CandidateZip) -or (Get-Item $CandidateZip).Length -lt 5MB) { throw 'Downloaded Python ZIP is too small.' }
                $Zip = $CandidateZip
                $RuntimeVersion = $CandidateVersion
                $RuntimeDownloaded = $true
                break
            } catch {
                Write-SetupLog ("Download of CPython $CandidateVersion failed: " + $_.Exception.ToString())
            }
        }
        if (!$RuntimeDownloaded) { throw 'Could not download an official CPython 3.13 x64 embeddable package. Check access to python.org.' }
        if (Test-Path $TempRuntime) { Remove-Item -LiteralPath $TempRuntime -Recurse -Force }
        Expand-Archive -LiteralPath $Zip -DestinationPath $TempRuntime -Force
        $TempPython = Join-Path $TempRuntime 'python.exe'
        if (!(Test-Path $TempPython)) { throw 'python.exe was not found in the official package.' }
        Set-EmbeddedPythonPaths $TempRuntime
        Invoke-NativeLogged $TempPython @('-c', "import sys; assert sys.version_info[:2] == (3,13); assert sys.maxsize > 2**32; print(sys.version)") 'Initial portable Python smoke test'
        $OldRuntime = Join-Path $Root ('.portable-python_backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
        if (Test-Path $RuntimeDir) { Move-Item -LiteralPath $RuntimeDir -Destination $OldRuntime }
        Move-Item -LiteralPath $TempRuntime -Destination $RuntimeDir
    }

    Set-EmbeddedPythonPaths $RuntimeDir
    if (!(Test-Imports $Python "import sys; assert sys.version_info[:2] == (3,13); assert sys.maxsize > 2**32")) {
        throw 'The portable runtime is not CPython 3.13 x64 or cannot start. See portable_setup.log.'
    }

    $GetPip = Join-Path $Cache 'get-pip.py'
    if (!(Test-Imports $Python 'import pip')) {
        # Reuse a valid cached bootstrap script to avoid a needless extra download.
        # Retry transient network failures; the old default pip timeout was only 15 seconds.
        $BootstrapValid = (Test-Path -LiteralPath $GetPip -PathType Leaf)
        if ($BootstrapValid) {
            $BootstrapValid = ((Get-Item -LiteralPath $GetPip).Length -ge 100KB)
        }
        if (!$BootstrapValid) {
            for ($DownloadAttempt = 1; $DownloadAttempt -le 4; $DownloadAttempt++) {
                try {
                    Write-SetupLog ("Downloading pip bootstrap script (attempt $DownloadAttempt of 4)...")
                    if (Test-Path -LiteralPath $GetPip) { Remove-Item -LiteralPath $GetPip -Force }
                    Invoke-WebRequest -UseBasicParsing -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile $GetPip -TimeoutSec 180
                    if (!(Test-Path -LiteralPath $GetPip -PathType Leaf) -or (Get-Item -LiteralPath $GetPip).Length -lt 100KB) {
                        throw 'Downloaded get-pip.py is missing or unexpectedly small.'
                    }
                    $BootstrapValid = $true
                    break
                } catch {
                    Write-SetupLog ("get-pip.py download attempt $DownloadAttempt failed: " + $_.Exception.Message)
                    if (Test-Path -LiteralPath $GetPip) { Remove-Item -LiteralPath $GetPip -Force -ErrorAction SilentlyContinue }
                    if ($DownloadAttempt -lt 4) { Start-Sleep -Seconds 4 }
                }
            }
        }
        if (!$BootstrapValid) { throw 'Could not download a valid get-pip.py after 4 attempts. Check access to bootstrap.pypa.io.' }

        $PipReady = $false
        for ($PipAttempt = 1; $PipAttempt -le 3; $PipAttempt++) {
            try {
                Write-SetupLog ("Installing pip (attempt $PipAttempt of 3; timeout 90 seconds; 8 retries)...")
                Invoke-NativeLogged $Python @($GetPip,'--disable-pip-version-check','--no-warn-script-location','--timeout','90','--retries','8') 'Install pip into portable Python'
            } catch {
                Write-SetupLog ("pip bootstrap attempt $PipAttempt failed: " + $_.Exception.Message)
            }
            if (Test-Imports $Python 'import pip') {
                $PipReady = $true
                break
            }
            if ($PipAttempt -lt 3) { Start-Sleep -Seconds 5 }
        }
        if (!$PipReady) { throw 'Could not install pip after 3 attempts. Network access to files.pythonhosted.org may be blocked or unavailable; see portable_setup.log.' }
    }

    Write-SetupLog 'Installing app libraries and Piper/ONNX runtime (may take several minutes)...'
    $InstallArgs = @('-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--prefer-binary','--retries','8','--timeout','90','-r',(Join-Path $Root 'requirements.txt'),'piper-tts==1.8.0')
    Invoke-NativeLogged $Python $InstallArgs 'Install Python packages'

    # urllib uses this CA bundle for HTTPS model downloads in the embedded distribution.
    $PipCert = Join-Path $RuntimeDir 'Lib\site-packages\pip\_vendor\certifi\cacert.pem'
    if (Test-Path $PipCert) { $env:SSL_CERT_FILE = $PipCert }
    Write-SetupLog 'Downloading and validating the Persian voice model (about 64 MiB)...'
    Invoke-NativeLogged $Python @((Join-Path $Root 'download_mana_persian_piper_model.py'),'--target',$Root) 'Download Persian Piper model'

    Invoke-NativeLogged $Python @('-c','import fastapi,uvicorn,multipart,docx,pypdf,piper,onnxruntime; from piper import PiperVoice; assert PiperVoice is not None; print(1)') 'Final package import check'
    if (!(Test-Path $Model) -or !(Test-Path $Config)) { throw 'The model or its config file is missing after download.' }
    $ModelHash = (Get-FileHash -LiteralPath $Model -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ModelHash -ne $ExpectedModelHash) { throw 'Persian voice model SHA-256 does not match the expected digest.' }
    $oldFreezePreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $FreezeOutput = @(& $Python -m pip freeze 2>&1)
        $FreezeExit = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $oldFreezePreference
    }
    foreach ($item in $FreezeOutput) { Add-Content -LiteralPath $LogPath -Value ([string]$item) -Encoding UTF8 }
    if ($FreezeExit -eq 0) { Set-Content -LiteralPath (Join-Path $Root 'portable-runtime-packages.txt') -Value $FreezeOutput -Encoding UTF8 }
    $Record = [ordered]@{
        app = 'Network Learning App'
        release = '0.6.0-foundation'
        runtime = "CPython $RuntimeVersion embedded x64"
        python_packages = 'requirements.txt plus piper-tts==1.8.0'
        offline_persian_tts = $true
        model_file = 'models/mana-persian-piper/fa_IR-mana-medium.onnx'
        model_sha256 = $ModelHash
        prepared_utc = [DateTime]::UtcNow.ToString('o')
        note = 'Portable relative paths; copy the whole folder to another compatible Windows x64 PC.'
    }
    $Record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ReadyFile -Encoding UTF8
    Write-SetupLog ''
    Write-SetupLog 'SUCCESS: The complete portable runtime is prepared.'
    Write-SetupLog 'Run run_windows.bat. Normal operation does not need Internet or system Python.'
    Write-SetupLog ('Diagnostics log: ' + $LogPath)
} catch {
    Write-Host ''
    Write-Host ('PORTABLE SETUP FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    Write-SetupLog ('FULL ERROR: ' + $_.Exception.ToString())
    try { Write-SetupLog ('PowerShell details: ' + ($_ | Format-List * -Force | Out-String)) } catch {}
    Write-Host ('Full diagnostics saved to: ' + $LogPath) -ForegroundColor Yellow
    Write-Host 'Existing database and learning data were not intentionally removed.' -ForegroundColor Yellow
    exit 1
} finally {
    $env:SSL_CERT_FILE = $OldSslCertFile
    $env:PIP_TIMEOUT = $OldPipTimeout
    $env:PIP_DEFAULT_TIMEOUT = $OldPipDefaultTimeout
    $env:PIP_RETRIES = $OldPipRetries
    Pop-Location
}
