@echo off
setlocal
net session >nul 2>&1
if not %errorlevel%==0 (
  echo Right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
netsh advfirewall firewall delete rule name="NetworkLearning-LAN-82"
echo Firewall rule removed.
pause
