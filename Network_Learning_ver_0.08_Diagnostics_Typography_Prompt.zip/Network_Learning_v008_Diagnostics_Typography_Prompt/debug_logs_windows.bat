﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo Network Learning ver 0.08 - Debug and Log Collector
echo The collector does NOT copy your SQLite database, lesson content, notes, or saved credentials.
echo ============================================================
set "APP_PY="
rem Match run_windows.bat: prefer the prepared portable runtime, then .venv.
if exist ".portable-python\python.exe" set "APP_PY=.portable-python\python.exe"
if not defined APP_PY if exist ".venv\Scripts\python.exe" set "APP_PY=.venv\Scripts\python.exe"
if not defined APP_PY (
  where python >nul 2>nul
  if not errorlevel 1 set "APP_PY=python"
)
if not defined APP_PY (
  echo ERROR: Python was not found. If the application works, use its Python runtime from this project.
  pause
  exit /b 1
)
"%APP_PY%" collect_debug_logs.py
if errorlevel 1 (
  echo.
  echo ERROR: Could not create diagnostics. Check the console output above.
  pause
  exit /b 1
)
echo.
echo Open the debug_logs folder and send the newest Network_Learning_debug_*.zip for analysis.
pause
endlocal
