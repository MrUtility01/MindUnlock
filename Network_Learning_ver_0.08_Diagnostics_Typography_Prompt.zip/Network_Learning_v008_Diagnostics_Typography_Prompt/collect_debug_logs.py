#!/usr/bin/env python3
"""Create a privacy-conscious diagnostic ZIP for Network Learning.

No SQLite database, imported lessons, browser profile, password store, or user notes
are collected. Text logs are filtered and secret-like values redacted.
"""
from __future__ import annotations
import hashlib, importlib.metadata, json, os, platform, re, subprocess, sys, time, urllib.error, urllib.request, zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'debug_logs'
SECRET_PATTERNS = [
    re.compile(r'(?i)(password(?:_hash)?|passwd|token|secret|authorization|cookie|api[_-]?key|session[_-]?id)(["\']?\s*[:=]\s*["\']?)([^\s,;"\']+)'),
    re.compile(r'(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+'),
]

def redact(text: str) -> str:
    text=text.replace(str(ROOT), '<PROJECT_ROOT>').replace(str(ROOT).replace('/', '\\'), '<PROJECT_ROOT>')
    for pat in SECRET_PATTERNS:
        text=pat.sub(lambda m: (m.group(1) + m.group(2) + '<REDACTED>') if m.lastindex and m.lastindex >= 3 else (m.group(1)+'<REDACTED>'), text)
    # Remove entire lines likely to contain credentials so values with spaces cannot leak.
    kept=[]
    for line in text.splitlines():
        if re.search(r'(?i)\b(password(?:_hash)?|passwd|token|secret|authorization|cookie|api[_ -]?key|session[_ -]?id)\b|set-cookie|credential manager|access token', line):
            kept.append('[REDACTED: credential-like diagnostic line]')
        else:
            kept.append(line[:2000])
    return '\n'.join(kept)+'\n'

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def probe_python(exe: Path) -> dict:
    code=r"""import importlib.util,json,platform,struct,sys,pathlib
mods=['fastapi','uvicorn','multipart','docx','pypdf','piper','onnxruntime']
try:
 import importlib.metadata as md
 versions={m: (md.version(m) if m not in ('multipart','docx') else md.version({'multipart':'python-multipart','docx':'python-docx'}[m])) for m in mods}
except Exception: versions={}
checks={}
for m in mods:
 try: checks[m]=bool(importlib.util.find_spec(m))
 except Exception: checks[m]=False
print(json.dumps({'python':sys.version.split()[0],'executable_name':pathlib.Path(sys.executable).name,'bits':struct.calcsize('P')*8,'platform':platform.platform(),'checks':checks,'versions':versions},ensure_ascii=False))"""
    try:
        p=subprocess.run([str(exe),'-c',code],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=12,cwd=str(ROOT))
        lines=(p.stdout or '').strip().splitlines()
        return {'path':str(exe.relative_to(ROOT)) if exe.is_relative_to(ROOT) else '<system-python>','exit_code':p.returncode,'result':json.loads(lines[-1]) if lines else {},'stderr':redact((p.stderr or '')[-1200:])}
    except Exception as exc:
        return {'path':str(exe.relative_to(ROOT)) if exe.is_relative_to(ROOT) else '<system-python>','error':type(exc).__name__+': '+str(exc)[:160]}

def http_json(url: str) -> dict:
    try:
        with urllib.request.urlopen(url,timeout=2) as resp:
            data=resp.read(200_000).decode('utf-8','replace')
            try: return {'reachable':True,'status':resp.status,'json':json.loads(data)}
            except Exception: return {'reachable':True,'status':resp.status,'body_prefix':data[:500]}
    except urllib.error.HTTPError as exc:
        # An HTTP response proves the service is reachable; protected endpoints
        # may correctly return 401 when the collector has no authenticated session.
        try: body=exc.read(200_000).decode('utf-8','replace')
        except Exception: body=''
        note='authentication required; status endpoint was not queried without a session' if exc.code==401 else 'HTTP endpoint returned an error'
        return {'reachable':True,'status':exc.code,'note':note,'body_prefix':redact(body[:500])}
    except Exception as exc:
        return {'reachable':False,'error':type(exc).__name__+': '+str(exc)[:160]}

EXPECTED_MODEL_SHA256 = 'e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126'

def main() -> int:
    OUT.mkdir(exist_ok=True)
    lines=[]
    add=lines.append
    add('Network Learning diagnostic report')
    add('Generated: '+datetime.now().astimezone().isoformat(timespec='seconds'))
    add('Project folder: <PROJECT_ROOT>')
    add('Version: '+((ROOT/'VERSION.txt').read_text(encoding='utf-8').strip() if (ROOT/'VERSION.txt').is_file() else 'unknown'))
    add('Current Python: '+sys.version.replace('\n',' '))
    try: exe_is_project=Path(sys.executable).resolve().is_relative_to(ROOT.resolve())
    except Exception: exe_is_project=False
    add('Current executable: '+Path(sys.executable).name+(' (project-local)' if exe_is_project else ' (system/other runtime; full path omitted)'))
    add('OS: '+platform.platform())
    add('Architecture: '+platform.machine())
    add('')
    add('== Candidate Python environments ==')
    candidates=[ROOT/'.portable-python'/'python.exe',ROOT/'.venv'/'Scripts'/'python.exe',ROOT/'.tts-venv'/'Scripts'/'python.exe',ROOT/'.piper-venv'/'Scripts'/'python.exe',ROOT/'piper-venv'/'Scripts'/'python.exe',ROOT/'.venv-tts'/'Scripts'/'python.exe']
    for exe in candidates:
        if exe.is_file():
            add(json.dumps(probe_python(exe),ensure_ascii=False,indent=2))
        else:
            add(f'{exe.relative_to(ROOT)}: not present')
    configured_file=ROOT/'piper_python_path.txt'
    if configured_file.is_file():
        try:
            configured=Path(configured_file.read_text(encoding='utf-8').strip().strip('\"'))
            if configured.is_file():
                result=probe_python(configured); result['configured_system_runtime']=True
                add(json.dumps(result,ensure_ascii=False,indent=2))
            else: add('piper_python_path.txt: configured interpreter file missing')
        except Exception as exc: add('piper_python_path.txt: could not be read ('+type(exc).__name__+')')
    else: add('piper_python_path.txt: not configured')
    add('')
    add('== Model files ==')
    model=ROOT/'models'/'mana-persian-piper'/'fa_IR-mana-medium.onnx'
    config=Path(str(model)+'.json')
    for p in (model,config):
        if p.is_file():
            add(f'{p.relative_to(ROOT)}: present; size={p.stat().st_size}; sha256={sha256(p)}' + (f'; expected_sha256_match={sha256(p)==EXPECTED_MODEL_SHA256}' if p == model else ''))
        else: add(f'{p.relative_to(ROOT)}: MISSING')
    add('')
    add('== Local API checks (if the app is running) ==')
    port=82
    try:
        exe=ROOT/'.portable-python'/'python.exe'
        if not exe.is_file(): exe=ROOT/'.venv'/'Scripts'/'python.exe'
        if exe.is_file():
            p=subprocess.run([str(exe),'launch_server.py','--print-port'],capture_output=True,text=True,timeout=4,cwd=str(ROOT))
            if p.returncode==0 and p.stdout.strip().isdigit(): port=int(p.stdout.strip())
    except Exception: pass
    for endpoint in ('api/health','api/tts/status'):
        add(endpoint+': '+json.dumps(http_json(f'http://127.0.0.1:{port}/{endpoint}'),ensure_ascii=False))
    add('')
    add('== Relevant file integrity ==')
    for rel in ('app.py','launch_server.py','tts_worker.py','setup_mana_piper.bat','piper_python_path.txt','run_windows.bat','static/index.html','static/sw.js'):
        p=ROOT/rel
        add(f'{rel}: '+(f'size={p.stat().st_size}; sha256={sha256(p)}' if p.is_file() else 'MISSING'))
    add('')
    add('Privacy note: the SQLite database, imported lesson content, notes, user accounts, browser data and secrets are not included.')
    report='\n'.join(lines)+'\n'
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
    archive=OUT/f'Network_Learning_debug_{stamp}.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('DIAGNOSTICS.txt',redact(report))
        logdir=ROOT/'logs'
        candidates_logs=[]
        if logdir.is_dir():
            candidates_logs += list(logdir.glob('server.log*'))
            candidates_logs += [logdir/'piper_setup.log']
        candidates_logs += [ROOT/'portable_setup.log',ROOT/'piper_setup.log',ROOT/'setup.log']
        # Only known text logs, capped at 2 MiB each; never scan/copy arbitrary folders.
        seen=set()
        for lp in candidates_logs:
            if not lp.is_file() or lp in seen or lp.stat().st_size>2*1024*1024: continue
            seen.add(lp)
            try: text=lp.read_text(encoding='utf-8',errors='replace')
            except Exception: continue
            z.writestr('redacted_logs/'+lp.name,redact(text))
    print('تشخیص پایان یافت.')
    print('فایل گزارش: '+str(archive))
    print('این ZIP شامل دیتابیس، محتوای درس، یادداشت‌ها یا رمزهای ذخیره‌شده نیست.')
    print('اگر لازم شد برای بررسی ارسالش کن؛ قبل از اشتراک‌گذاری، فایل را باز کن و گزارش را مرور کن.')
    return 0

if __name__=='__main__': raise SystemExit(main())
