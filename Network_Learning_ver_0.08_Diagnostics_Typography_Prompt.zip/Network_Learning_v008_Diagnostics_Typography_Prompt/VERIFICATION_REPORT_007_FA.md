# گزارش راستی‌آزمایی Network Learning 0.07 — Compact Study Layout & Piper Fix

**تاریخ:** 2026-10-29

این گزارش فقط آزمون‌های اجراشده در محیط توسعه را ثبت می‌کند. اجرای واقعی برنامه روی رایانهٔ Windows کاربر یا بررسی دیداری تمام صفحات در مرورگر از این محیط انجام نشده است.

## خلاصهٔ تغییرات

1. در `app.py` ماژول `subprocess` وارد شده است. کد v0.06 در توابع تشخیص runtime و فراخوانی `tts_worker.py` از `subprocess.run` استفاده می‌کرد، اما import وجود نداشت. این همان علت کدی است که می‌تواند `NameError` تولید کند، درحالی‌که اسکریپت مستقل نصب Piper پیام موفقیت می‌دهد.
2. آزمون TTS جدید worker را به‌صورت کنترل‌شده شبیه‌سازی می‌کند: بررسی runtime، وضعیت آماده و پاسخ صوتی WAV مسیر API را آزموده است. این آزمون وجود Piper واقعی روی Windows یا کیفیت صدای واقعی را اثبات نمی‌کند.
3. عرض نوار کناری دسکتاپ 260 به 156 پیکسل کاهش یافته است (60٪ مقدار قبلی)؛ رفتار موبایل جداگانه نگه داشته شده.
4. فرم ایجاد محتوا سه‌ستونه، شبکهٔ فصل‌های مدیریت سه/دو/یک‌ستونه، کنترل‌های فیلتر چهار/سه/دو/یک‌ستونه، دکمه‌های گروهی چندستونه و فرم سازندهٔ دوره واکنش‌گرا شده‌اند.
5. برای منوها `title` و `aria-label` اضافه شده و کلیدهای Enter/Space برای بازکردن گروه منو پشتیبانی می‌شوند.
6. کش PWA به `nla-shell-v008` تغییر کرده است تا نسخهٔ قدیمی رابط کمتر استفاده شود.

## آزمون‌های خودکار

| آزمون | نتیجه |
|---|---|
| کامپایل `app.py`, `launch_server.py`, `tts_worker.py`, `collect_debug_logs.py` | PASS |
| نحو JavaScript داخل `static/index.html` | PASS — 10 بلوک |
| `run_v001_startup_regression.py` | PASS — 15 بررسی |
| `run_v002_debug_tts_layout_regression.py` | PASS — 27 بررسی |
| `run_v003_practice_hub_regression.py` | PASS — 15 بررسی |
| `run_v003_practice_progress_regression.py` | PASS — 17 بررسی |
| `run_v004_universal_learning_regression.py` | PASS — 24 بررسی |
| `run_v005_comprehensive_learning_regression.py` | PASS — 27 بررسی |
| `run_v006_study_flow_regression.py` | PASS — 33 بررسی |
| `run_v007_study_layout_tts_regression.py` | PASS — 16 بررسی |
| `run_v0600_approval_workflow_regression.py` | PASS |
| `run_v0600_foundation_regression.py` | PASS — 30 بررسی |
| `run_v10_hierarchy_ui_regression.py` | PASS — 17 بررسی |
| `run_windows_startup_regression.py` | PASS |
| `run_portable_installer_regression.py` | PASS |
| `run_offline_package_integrity_regression.py` | PASS |
| `run_api_regression.py` | PASS — آزمون بستهٔ بزرگ 2,060 رکوردی |
| `run_v0600_package_manifest_regression.py` | PASS پس از بازسازی manifest؛ فایل‌های انتشار و hashها تأیید شدند |

## تشخیص صدای فارسی

گزارش ارسال‌شده از نصب `setup_mana_piper.bat` شامل `Piper runtime ready` و `SUCCESS: The optional speech runtime is ready` است؛ فایل مدل و تنظیمات نیز موجود و hash مدل صحیح گزارش شده. موفقیت setup به‌تنهایی نشان نمی‌دهد API برنامه بتواند worker را فراخوانی کند. بررسی کد v0.06 نشان داد `subprocess` وارد نشده است؛ در این نسخه اصلاح شده و آزمون کنترل‌شدهٔ جدید هر دو مسیر probe و synthesize را آزموده است.

برای آزمون نهایی روی Windows: برنامهٔ قبلی را کامل ببند، نسخهٔ 0.07 را در پوشه‌ای تازه اجرا کن، وارد حساب شو، در تنظیمات وضعیت Piper را تازه‌سازی کن و یک متن کوتاه را واقعاً پخش کن. اگر هنوز خطا وجود داشت، گزارش جدید `debug_logs_windows.bat` را بفرست؛ نصب مجدد مدل در قدم اول لازم نیست.

## محدودیت‌ها

- آزمون واقعی Piper/ONNX و تولید صوت با فایل مدل Mana روی دستگاه Windows مقصد اجرا نشده است؛ آزمون TTS در این محیط worker را mock می‌کند.
- ظاهر نهایی منوها در Chromium واقعی به‌صورت دیداری تأیید نشده است. CSS و ساختار DOM/JavaScript بررسی و آزمون‌های قراردادی اجرا شده‌اند؛ اندازهٔ واقعی نمایشگر و طول عنوان‌ها ممکن است نیازمند تنظیم جزئی باشد.
- تغییر schema پایگاه داده یا فرمت بستهٔ درس انجام نشده؛ هیچ پایگاه دادهٔ کاربر داخل release ZIP قرار نمی‌گیرد.
- نصب کاملاً آفلاین و همگام‌سازی نهایی Android همچنان کارهای مرحلهٔ بعد هستند.

## روش بررسی

ZIP را در پوشه‌ای جدا استخراج کن، برنامهٔ قبلی را با `Ctrl+C` متوقف کن، `run_windows.bat` را از پوشهٔ نسخهٔ 0.07 اجرا کن. نشانی محلی پیش‌فرض `http://127.0.0.1:82/?v=008` است. از پورت 82 به اینترنت عمومی فوروارد نکن.
