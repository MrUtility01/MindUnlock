﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $root 'run_windows.bat'
$icon = Join-Path $root 'NetworkLearningApp.ico'
if (!(Test-Path $target)) { throw "run_windows.bat پیدا نشد: $target" }
if (!(Test-Path $icon)) { throw "NetworkLearningApp.ico پیدا نشد: $icon" }
$desktop = [Environment]::GetFolderPath('Desktop')
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut((Join-Path $desktop 'دانشنامه جامع شبکه.lnk'))
$link.TargetPath = $target
$link.WorkingDirectory = $root
$link.IconLocation = "$icon,0"
$link.Description = 'اجرای دانشنامه جامع شبکه (پورت ۸۲)'
$link.Save()
Write-Host 'میانبر دسکتاپ ساخته شد.'
