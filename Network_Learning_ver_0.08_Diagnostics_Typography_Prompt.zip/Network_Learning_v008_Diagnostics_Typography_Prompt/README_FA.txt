﻿Network Learning ver 0.07 — Compact Study Layout & Piper Fix

راهنمای معتبر فارسی: README_FA.md
مشخصات ساخت بستهٔ کتاب/دوره: COURSE_PACK_SPECIFICATION_V006_FA.md
گزارش آزمون نسخهٔ جاری: Network_Learning_v006_Verification_Report_FA.md
معماری نسخهٔ جاری: ARCHITECTURE_V006_FA.md

نصب تازه باید بدون محتوای آموزشی پیش‌فرض شروع شود. انتقال پایگاه داده از نسخه‌های قدیمی اختیاری است؛ برنامه داده‌های قبلی را خودکار پاک نمی‌کند.
