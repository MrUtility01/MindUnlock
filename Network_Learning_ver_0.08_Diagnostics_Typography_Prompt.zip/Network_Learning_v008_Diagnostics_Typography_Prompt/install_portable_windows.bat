@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo Network Learning - full offline portable setup
echo Requires Internet for the one-time download of the runtime,
echo Python packages and Persian offline voice model.
echo ============================================================
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_portable_windows.ps1"
if errorlevel 1 (
  echo.
  echo Setup did not finish. See the error above. Your existing .venv and database were not removed.
  pause
  exit /b 1
)
echo.
echo Portable setup is complete.
echo You can now copy the entire project folder to another 64-bit Windows PC and run run_windows.bat without Internet or system Python.
echo Keep the whole folder together, including .portable-python and models.
pause
exit /b 0
