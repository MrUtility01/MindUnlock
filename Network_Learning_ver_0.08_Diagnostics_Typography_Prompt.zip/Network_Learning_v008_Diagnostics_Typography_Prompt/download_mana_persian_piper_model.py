#!/usr/bin/env python3
"""Download Mana Persian Piper ONNX model and config into a Network Learning App folder."""
from __future__ import annotations
import argparse, hashlib, json, sys, time, urllib.error, urllib.request, traceback, os, uuid
from pathlib import Path

# Windows PowerShell 5.1 may launch Python with a legacy console code page.
# Never let a Unicode encoding failure hide the original download exception.
def configure_console_encoding() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="backslashreplace")
        except (AttributeError, OSError, ValueError):
            pass

configure_console_encoding()

MODEL_URL = 'https://huggingface.co/MahtaFetrat/Mana-Persian-Piper/resolve/main/fa_IR-mana-medium.onnx?download=true'
CONFIG_URL = 'https://huggingface.co/MahtaFetrat/Mana-Persian-Piper/resolve/main/fa_IR-mana-medium.onnx.json?download=true'
MODEL_SHA256 = 'e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126'

def find_root(explicit: str | None) -> Path:
    if explicit:
        root = Path(explicit).expanduser().resolve()
        if not (root / 'app.py').is_file():
            raise ValueError(f'app.py was not found in target folder: {root}')
        return root
    cwd = Path.cwd().resolve()
    for candidate in (cwd, Path(__file__).resolve().parent, Path(__file__).resolve().parent.parent):
        if (candidate / 'app.py').is_file():
            return candidate
    while True:
        raw = input('Enter the application root folder (the folder containing app.py): ').strip().strip('"')
        if (Path(raw).expanduser() / 'app.py').is_file():
            return Path(raw).expanduser().resolve()
        print('ERROR: app.py was not found in that folder. Check the path and try again.')

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def download(url: str, dest: Path, expected_hash: str | None = None, min_bytes: int = 1) -> None:
    # Per-process temp names prevent two setup windows from locking/deleting the same .part file.
    part = dest.with_suffix(dest.suffix + f'.{os.getpid()}.{uuid.uuid4().hex[:8]}.part')
    if dest.is_file() and dest.stat().st_size >= min_bytes and (not expected_hash or sha256(dest) == expected_hash):
        print(f'Already present and valid: {dest.name}')
        return
    part.unlink(missing_ok=True)
    req = urllib.request.Request(url, headers={'User-Agent': 'NetworkLearningApp/0.02 (offline Persian TTS model downloader)'})
    last_exc = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=60) as response, part.open('wb') as out:
                total = int(response.headers.get('Content-Length') or 0)
                received = 0
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk: break
                    out.write(chunk); received += len(chunk)
                    if total:
                        print(f'\r{dest.name}: {received / total * 100:5.1f}% ({received / 1024 / 1024:.1f} MiB)', end='', flush=True)
            print()
            if part.stat().st_size < min_bytes:
                raise IOError(f'Downloaded file is smaller than expected: {part.stat().st_size} bytes')
            if expected_hash and sha256(part) != expected_hash:
                raise IOError('Model SHA-256 does not match the expected digest.')
            part.replace(dest)
            return
        except Exception as exc:
            last_exc = exc
            try:
                part.unlink(missing_ok=True)
            except OSError:
                pass
            if attempt < 2:
                print(f'Download attempt {attempt+1}/3 failed; retrying: {ascii(str(exc))}')
                time.sleep(2 * (attempt + 1))
    raise RuntimeError(f'Download failed for {dest.name}: {ascii(str(last_exc))}')

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', help='مسیر پوشهٔ اصلی برنامه (جایی که app.py هست)')
    args = parser.parse_args()
    try:
        root = find_root(args.target)
        target = root / 'models' / 'mana-persian-piper'
        target.mkdir(parents=True, exist_ok=True)
        model = target / 'fa_IR-mana-medium.onnx'
        config = target / 'fa_IR-mana-medium.onnx.json'
        print('Destination:', target)
        print('The Persian voice model is about 64 MiB; Internet access is required for initial setup.')
        download(MODEL_URL, model, MODEL_SHA256, min_bytes=55 * 1024 * 1024)
        download(CONFIG_URL, config, None, min_bytes=4096)
        try:
            parsed = json.loads(config.read_text(encoding='utf-8'))
            if not isinstance(parsed, dict): raise ValueError('Model config JSON must be an object.')
        except Exception as exc:
            config.unlink(missing_ok=True)
            raise RuntimeError(f'Model config JSON is invalid: {ascii(str(exc))}')
        print('\nSUCCESS: Voice model and configuration downloaded and validated.')
        print('Model SHA-256:', sha256(model))
        print('Piper model setup complete. The model can be used offline after setup.')
        return 0
    except Exception as exc:
        # Keep the original exception and traceback in UTF-8 even if the console
        # cannot represent Persian characters. Print only ASCII-safe diagnostics.
        try:
            log_root = Path(args.target).expanduser().resolve() if args.target else Path.cwd().resolve()
            log_root.mkdir(parents=True, exist_ok=True)
            log_path = log_root / 'portable_model_download.log'
            with log_path.open('a', encoding='utf-8') as log:
                log.write('\n=== Model download failure ===\n')
                log.write(time.strftime('%Y-%m-%d %H:%M:%S') + '\n')
                log.write(traceback.format_exc())
                log.write('\n')
        except Exception:
            log_path = None
        print('ERROR: ' + ascii(str(exc)), file=sys.stderr)
        if log_path:
            print('Diagnostic details saved to: ' + str(log_path), file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
