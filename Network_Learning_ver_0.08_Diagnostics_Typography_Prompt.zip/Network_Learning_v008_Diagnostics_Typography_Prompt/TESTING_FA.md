# راهنمای آزمون نسخهٔ 0.5.7

برای بررسی واردسازی و بازیابی ایمن:

```powershell
python -m py_compile app.py ai_authoring_kit.py
python tests/run_v057_import_isolation_regression.py
python tests/run_v056_topic_kit_backup_regression.py
python tests/run_v055_quiz_controls_regression.py
python tests/run_v051_32_chapter_pack_import_regression.py
python tests/run_v054_cross_chapter_duplicate_regression.py
```

آزمون‌های بیشتر رگرسیون در پوشهٔ `tests/` هستند. پیش از اجرا روی پایگاه واقعی، ابتدا ZIP کامل پشتیبان بگیر. تست مرورگر واقعی در این محیط به‌دلیل مسدودشدن localhost توسط محیط اجرا تکمیل نشد.

# راهنمای آزمون نسخهٔ ۰.۴.۵

وابستگی‌ها را نصب کن: `pip install -r requirements.txt -r requirements-dev.txt`

از ریشهٔ برنامه اجرا کن:

```powershell
python tests/run_v045_lan_daily_backup_regression.py
python tests/run_api_regression.py
python tests/run_v043_feature_regression.py
python tests/run_v044_chapter_sequence_regression.py
python tests/run_v044_all_chapter_sample_import.py
```

برای مرورگر واقعی، در محیط دارای Playwright و Chromium اجرا کن: `python tests/run_v043_browser_smoke.py`. آزمون Mock فقط قرارداد اولیهٔ رابط را بررسی می‌کند و جایگزین آزمون مرورگر واقعی نیست.

تست LAN روی ویندوز واقعی باید در دو رایانهٔ شبکهٔ Private انجام شود: رمز را از localhost میزبان تنظیم کن، سپس از کلاینت با آدرس LAN وارد شو؛ اتصال در شبکهٔ Public یا اینترنت عمومی را مجاز نکن.
