#!/usr/bin/env python3
"""Validate a Network Learning App chapter ZIP or a chapter folder. Standard library only."""
import json, sys, zipfile, io, re
from pathlib import Path, PurePosixPath

BANKS = {
 'lessons.json':'lesson', 'questions.json':'question', 'examples.json':'example',
 'commands.json':'command', 'labs.json':'lab', 'flashcards.json':'flashcard', 'cards.json':'flashcard'
}
ERRORS=[]; WARNINGS=[]; COUNTS={k:0 for k in ['lesson','question','example','command','lab','flashcard','asset']}
def err(msg): ERRORS.append(msg)
def warn(msg): WARNINGS.append(msg)
def read_json(raw, path):
 try: return json.loads(raw.decode('utf-8-sig'))
 except Exception as e: err(f'{path}: JSON نامعتبر: {e}'); return None

def audit_records(obj, path, kind, seen_uids):
 if not isinstance(obj,dict) or not isinstance(obj.get('items'),list):
  err(f'{path}: باید یک شیء با آرایهٔ items داشته باشد.'); return
 for n,it in enumerate(obj['items'],1):
  label=f'{path} آیتم {n}'
  if not isinstance(it,dict): err(f'{label}: رکورد باید object باشد.'); continue
  uid=str(it.get('uid') or it.get('id') or '').strip()
  if not uid: err(f'{label}: uid یا id الزامی است.')
  elif uid in seen_uids: err(f'{label}: شناسهٔ تکراری {uid}.')
  else: seen_uids.add(uid)
  status=it.get('source_status','review_required')
  if status not in {'review_required','content_enriched','verified','source','editorially_added','backup'}:
   warn(f'{label}: source_status ناشناخته: {status}.')
  if kind=='lesson':
   if not (it.get('title_fa') or it.get('title')): err(f'{label}: title_fa الزامی است.')
   if len(str(it.get('full_content') or it.get('content') or '').strip())<150: warn(f'{label}: متن درس بسیار کوتاه است.')
  elif kind=='question':
   q=it.get('question') or it.get('title_fa')
   opts=it.get('options'); ci=it.get('correct_index')
   if not q: err(f'{label}: question الزامی است.')
   if not isinstance(opts,list) or len(opts)!=4: err(f'{label}: دقیقاً چهار گزینه لازم است.')
   elif any(not str(x).strip() for x in opts) or len({str(x).strip().casefold() for x in opts})<4: err(f'{label}: گزینه‌ها خالی یا تکراری‌اند.')
   if not isinstance(ci,int) or isinstance(ci,bool) or not isinstance(opts,list) or not (0<=ci<len(opts)): err(f'{label}: correct_index باید شمارهٔ صفرمبنا و منطبق با گزینه‌ها باشد.')
   if len(str(it.get('explanation') or it.get('explain_fa') or '').strip())<20: warn(f'{label}: توضیح پاسخ کوتاه/خالی است.')
  elif kind=='flashcard':
   if not str(it.get('front') or it.get('question') or '').strip(): err(f'{label}: front الزامی است.')
   if not str(it.get('back') or it.get('answer') or '').strip(): err(f'{label}: back الزامی است.')
  elif kind=='command':
   if not (it.get('command') or it.get('content')): err(f'{label}: command یا content الزامی است.')
   if not it.get('platform'): err(f'{label}: platform الزامی است.')
   body=' '.join(str(it.get(k) or '') for k in ['content','caution_fa','expected_result_fa'])
   if not any(w in body.lower() for w in ['احتیاط','خطر','rollback','بازگشت','caution','risk']): warn(f'{label}: احتیاط/خطر/روش بازگشت را بررسی کن.')
  elif kind=='lab':
   body=str(it.get('full_content') or it.get('content') or '')
   if len(body)<250: warn(f'{label}: دستورکار آزمایشگاه کوتاه است.')
   for term in ['هدف','نتیجه','عیب‌یابی']:
    if term not in body: warn(f'{label}: بخش «{term}» را بررسی کن.')


def audit_entries(entries, path_prefix=''):
 manifests=[]
 asset_paths={str(PurePosixPath(p)) for p in entries}
 for p,raw in entries.items():
  pp=PurePosixPath(p)
  if pp.name.lower()=='manifest.json':
   obj=read_json(raw,p)
   if isinstance(obj,dict) and obj.get('title_fa'):
    manifests.append((str(pp.parent),obj))
 if not manifests: err('هیچ manifest.json معتبری با title_fa پیدا نشد.')
 for folder,m in manifests:
  if not m.get('slug'): warn(f'{folder}/manifest.json: slug ندارد؛ نگاشت خودکار فصل ممکن است انجام نشود.')
  if m.get('source_status','review_required')=='verified': warn(f'{folder}: کل فصل verified است؛ قبل از استفاده، تمام موارد را واقعاً ممیزی کن.')
 for p,raw in entries.items():
  name=PurePosixPath(p).name.lower()
  if name not in BANKS: continue
  obj=read_json(raw,p)
  # Names are globally unique for a typical single-chapter pack; use per-file sets to support e.g. lesson and card IDs separately.
  seen=set(); audit_records(obj,p,BANKS[name],seen)
  if isinstance(obj,dict) and isinstance(obj.get('items'),list): COUNTS[BANKS[name]]+=len(obj['items'])
  for i,it in enumerate((obj or {}).get('items',[]) if isinstance(obj,dict) else [],1):
   if isinstance(it,dict) and it.get('source_status')=='verified' and not it.get('uid') and not it.get('id'):
    warn(f'{p} آیتم {i}: verified بدون شناسهٔ پایدار.')

 # Check relative Markdown image references inside the package, a common cause of broken diagrams on Import.
 for p,raw in entries.items():
  if PurePosixPath(p).suffix.lower() not in {'.md','.markdown'}: continue
  try: text=raw.decode('utf-8-sig',errors='replace')
  except Exception: continue
  for target in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text):
   target=target.strip().split()[0].strip('<>')
   if target.startswith(('http://','https://','data:','#')): continue
   resolved=str(PurePosixPath(p).parent.joinpath(target))
   # Normalise a harmless ./ prefix without allowing parent-directory traversal.
   parts=[]
   for part in PurePosixPath(resolved).parts:
    if part in ('','.'): continue
    if part=='..':
     if parts: parts.pop()
    else: parts.append(part)
   resolved='/'.join(parts)
   if resolved not in asset_paths: err(f'{p}: تصویر ارجاع‌شده پیدا نشد: {target}')

def main():
 if len(sys.argv)<2:
  print('استفاده: python validate_chapter_pack.py chapter_pack.zip یا پوشهٔ فصل'); return 2
 target=Path(sys.argv[1])
 if not target.exists(): print(f'پیدا نشد: {target}'); return 2
 if target.is_dir():
  entries={str(p.relative_to(target)).replace('\\','/'):p.read_bytes() for p in target.rglob('*') if p.is_file()}
 elif target.suffix.lower()=='.zip':
  with zipfile.ZipFile(target) as z:
   bad=z.testzip()
   if bad: err(f'فایل ZIP خراب است: {bad}')
   entries={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
 else: print('فقط مسیر پوشه یا فایل ZIP پشتیبانی می‌شود.'); return 2
 audit_entries(entries)
 print('خلاصه رکوردها: '+', '.join(f'{k}={v}' for k,v in COUNTS.items()))
 for w in WARNINGS: print('هشدار:',w)
 for e in ERRORS: print('خطا:',e)
 if ERRORS: print(f'ناموفق: {len(ERRORS)} خطا و {len(WARNINGS)} هشدار.'); return 1
 print(f'ساختار پایه معتبر است؛ {len(WARNINGS)} هشدار برای بازبینی انسانی. این ابزار صحت علمی را اثبات نمی‌کند.')
 return 0
if __name__=='__main__': raise SystemExit(main())
