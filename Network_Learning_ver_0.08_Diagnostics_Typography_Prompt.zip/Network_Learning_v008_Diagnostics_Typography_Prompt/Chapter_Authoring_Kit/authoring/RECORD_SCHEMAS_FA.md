# قرارداد داده برای ساخت فصل‌ها و Import

## ساختار ZIP مورد انتظار

```text
chapter_pack.zip
└── chXX_slug/
    ├── manifest.json
    ├── chapter_reference.md
    ├── lessons.json
    ├── questions.json
    ├── examples.json
    ├── commands.json
    ├── labs.json
    ├── flashcards.json
    └── assets/
        ├── diagram_01.png
        └── README_FA.md
```

هر پوشهٔ فصل باید `manifest.json` داشته باشد. اگر چند فصل را با هم می‌فرستی، برای هر فصل پوشه و manifest جدا بساز. نام پوشه بهتر است با `chXX_slug` باشد. برنامه از عنوان/slug برای نگاشت فصل به فهرست پایه استفاده می‌کند؛ اگر نگاشت تشخیص داده نشود، فصل را در گروه فصل‌های واردشده نگه می‌دارد.

## وضعیت بازبینی

- `review_required`: پیش‌نویس یا محتوایی که هنوز از نظر فنی/منبع بازبینی نشده است. برای آزمون سطح یادگیری قابل استفاده نیست.
- `content_enriched`: محتوا تکمیل یا ویرایش شده، اما تأیید نهایی ندارد.
- `verified`: فقط پس از کنترل فنی، تطبیق نسخه، بررسی پاسخ‌ها و آزمایش دستور/سناریو استفاده شود.

هرگز صرفاً برای دیده‌شدن در آزمون، وضعیت را `verified` نکن.

## فیلدهای اصلی رکوردها

### lessons.json

```json
{
  "format": "network-learning-lessons-v1",
  "items": [
    {
      "uid": "chXX-lesson-001",
      "title_fa": "عنوان دقیق درس",
      "summary_fa": "خلاصه یک تا سه جمله‌ای",
      "full_content": "متن کامل Markdown درس با مثال و عیب‌یابی",
      "domain": "مفهوم اصلی",
      "difficulty": "beginner",
      "estimated_minutes": 15,
      "source_status": "review_required"
    }
  ]
}
```

### questions.json — آزمون چندگزینه‌ای

```json
{
  "format": "network-learning-questions-v1",
  "items": [
    {
      "uid": "chXX-q001",
      "id": "chXX-q001",
      "title_fa": "صورت کوتاه سؤال",
      "question": "صورت مستقل، روشن و قابل پاسخ سؤال",
      "options": ["گزینه الف", "گزینه ب", "گزینه ج", "گزینه د"],
      "correct_index": 1,
      "explanation": "دلیل فنی پاسخ درست و توضیح کوتاه برای رد گزینه‌های نزدیک",
      "domain": "موضوع فرعی",
      "difficulty": "intermediate",
      "source_status": "review_required"
    }
  ]
}
```

`correct_index` از صفر شروع می‌شود: ۰ برای گزینه اول، ۱ برای گزینه دوم، ۲ برای گزینه سوم و ۳ برای گزینه چهارم. هر سؤال باید دقیقاً چهار گزینهٔ متمایز، تنها یک پاسخ درست، توضیح و شناسهٔ یکتا داشته باشد. از «همه موارد» و «هیچ‌کدام» مگر با دلیل آموزشی استفاده نکن و گزینه‌های هم‌معنا ننویس.

### flashcards.json

```json
{
  "format": "network-learning-flashcards-v1",
  "items": [
    {
      "uid": "chXX-card001",
      "id": "chXX-card001",
      "front": "یک پرسش کوتاه و مستقل",
      "back": "پاسخ روشن و مختصر، همراه با شرط یا استثنای ضروری",
      "topic": "موضوع کارت",
      "difficulty": "beginner",
      "source_status": "review_required"
    }
  ]
}
```

کارت را روی یک هدف یادگیری متمرکز نگه دار؛ پاسخ نباید وابسته به متن کارت قبلی باشد.

### commands.json

```json
{
  "format": "network-learning-commands-v1",
  "items": [
    {
      "uid": "chXX-cmd001",
      "id": "chXX-cmd001",
      "title_fa": "نام کاربردی دستور",
      "platform": "Linux",
      "product_version": "نسخه یا بازهٔ اعتبار",
      "command": "ip route",
      "content": "**کاربرد:** ...

**پیش‌نیاز/سطح دسترسی:** ...

**خروجی نمونه و تفسیر:** ...

**خطر/احتیاط:** ...

**بازگشت:** ...",
      "summary_fa": "خلاصه کاربرد",
      "when_to_use_fa": "شرایط اجرا",
      "expected_result_fa": "نتیجه مورد انتظار",
      "caution_fa": "خطر و حفاظت از اطلاعات",
      "category": "routing/read-only",
      "source_status": "review_required"
    }
  ]
}
```

پلتفرم و نسخه را دقیق بنویس. دستور تغییردهنده باید روش ثبت وضعیت اولیه، سطح دسترسی، اثر احتمالی و rollback داشته باشد. دستورهای آزمایشی مخرب یا مناسب هدف غیرمجاز منتشر نشوند.

### labs.json

```json
{
  "format": "network-learning-labs-v1",
  "items": [
    {
      "uid": "chXX-lab001",
      "id": "chXX-lab001",
      "title_fa": "نام سناریوی آزمایشگاه",
      "summary_fa": "هدف آزمایش",
      "full_content": "## هدف و مهارت
...
## توپولوژی و پیش‌نیاز
...
## محدوده مجاز
...
## مراحل اجرا
...
## نتیجه مورد انتظار
...
## معیار قبولی
...
## عیب‌یابی
...
## پاک‌سازی و Rollback
...",
      "difficulty": "intermediate",
      "estimated_minutes": 30,
      "source_status": "review_required"
    }
  ]
}
```

### examples.json

```json
{
  "format": "network-learning-examples-v1",
  "items": [
    {
      "uid": "chXX-ex001",
      "id": "chXX-ex001",
      "title_fa": "عنوان مثال",
      "prompt": "مسئله و تمام فرض‌های لازم",
      "content": "## حل مرحله‌به‌مرحله
...
## کنترل نتیجه
...
## خطاهای رایج
...",
      "difficulty": "intermediate",
      "source_status": "review_required"
    }
  ]
}
```

### manifest.json

```json
{
  "title_fa": "عنوان دقیق فصل",
  "slug": "یک slug از authoring/slug_map.json",
  "chapter_order": 1,
  "source_status": "review_required",
  "description_fa": "دامنه، مخاطب، پیش‌نیاز و نسخه‌های پوشش‌داده‌شده"
}
```

## شناسه‌ها، تکرار و منابع

- شناسهٔ یکتا و پایدار بساز: `ch06-q001`, `ch06-card001`, `ch06-cmd001`, `ch06-lab001`.
- شناسهٔ یک رکورد را هنگام اصلاح محتوا عوض نکن؛ حذف تکرار و به‌روزرسانی سابقهٔ برنامه را ساده‌تر می‌کند.
- فایل `sources.md` یا پیوندها و نسخه‌های مستندات را در یادداشت تحریری نگه دار. هر گزارهٔ وابسته به نسخه باید مدل، سیستم‌عامل و نسخه/تاریخ آزمایش را داشته باشد.
- اگر نمونهٔ دستور از منبع برداشت شده، آن را به‌عنوان منبع ثبت کن؛ مثال تألیفی را به منبع نسبت نده.

## چک‌لیست بازبینی پیش از `verified`

1. صحت فنی و تطبیق نسخه بررسی شد.
2. همهٔ اصطلاحات مهم تعریف شده‌اند و مثال مستقل است.
3. دستور/آزمایش در محیط ایزوله یا مستند معتبر آزموده شده است.
4. نتیجهٔ مورد انتظار، خطاهای محتمل و روش بازیابی مشخص‌اند.
5. گزینهٔ سؤال و `correct_index` مستقل بررسی شده‌اند.
6. کارت تکراری یا وابسته به متن قبل نیست.
7. تصویر حق استفاده روشن، متن جایگزین و نام فایل درست دارد.
8. سناریوهای امنیتی مجوز، محدوده و روش پاک‌سازی دارند.
