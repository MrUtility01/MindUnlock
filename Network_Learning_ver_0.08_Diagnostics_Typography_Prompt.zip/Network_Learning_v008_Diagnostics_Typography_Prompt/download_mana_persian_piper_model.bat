@echo off
setlocal
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python.exe "%~dp0download_mana_persian_piper_model.py" --target "%CD%"
) else (
  python "%~dp0download_mana_persian_piper_model.py" --target "%CD%"
)
if errorlevel 1 echo Download failed. See the error above.
pause
