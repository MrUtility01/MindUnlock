# Network Learning — ver 0.08 Diagnostics, Typography & Prompt Profiles

This release adds reading-focused themes, grouped navigation and keyboard shortcuts, per-item source citations, and a book-to-course ZIP workflow. It is a Windows development baseline; a fully offline portable package and Android application are not claimed as complete.

Read [`README_FA.md`](README_FA.md) for the current Persian run instructions and limitations. Read [`COURSE_PACK_SPECIFICATION_V006_FA.md`](COURSE_PACK_SPECIFICATION_V006_FA.md) for accepted input types, content-pack structure, source metadata, and ZIP import rules.

A fresh release package contains no personal database and should start without seeded topic/chapter/lesson content. Do not copy the old `data/` folder into a fresh install unless you intend to carry old content forward. Existing data is not automatically deleted by upgrades.

The book workflow extracts and structurally packages text; it does not include a built-in LLM and does not independently verify the truth, copyright status, or technical correctness of extracted content. All items remain `review_required` until reviewed.

Default local URL: `http://127.0.0.1:82/?v=008`. Use only on a trusted private LAN and never forward port 82 to the public Internet.


## Release 0.08 — diagnostic center, typography, topic workspace and prompt profiles

- Fixed missing `subprocess` import used by Piper worker detection and audio generation.
- Desktop side navigation is 156px wide (about 60% of its former 260px).
- Content creation, content filters, bulk actions, and course-builder forms use responsive multi-column layouts.
- PWA cache is now `nla-shell-v008`.
- The included automated regression mocks the Piper worker and verifies that the synthesize route returns a WAV response; a real Windows synthesis check is still required on the target PC.
