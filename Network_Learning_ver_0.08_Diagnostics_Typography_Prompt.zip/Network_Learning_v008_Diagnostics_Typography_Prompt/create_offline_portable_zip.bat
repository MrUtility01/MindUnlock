﻿@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo Create a movable offline copy of Network Learning
echo Stop run_windows.bat first so the SQLite database is not being written.
echo The archive includes the prepared portable Python runtime, libraries and Persian voice model.
echo Private data in the data folder is excluded unless you explicitly type YES.
echo If included, store the ZIP securely because it contains local accounts and progress.
echo ============================================================
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_offline_portable_zip.ps1"
if errorlevel 1 (
  echo.
  echo Could not create the offline archive. See the error above.
  pause
  exit /b 1
)
echo.
echo The offline archive was created in the parent folder.
echo Extract it to a normal writable folder on another Windows x64 PC, then run run_windows.bat.
pause
exit /b 0
