param([int]$Port = 82)
$addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue
foreach ($entry in $addresses) {
    $ip = [string]$entry.IPAddress
    $parts = $ip.Split('.')
    if ($parts.Length -ne 4) { continue }
    $isPrivate = ($parts[0] -eq '10') -or
        ($parts[0] -eq '192' -and $parts[1] -eq '168') -or
        ($parts[0] -eq '172' -and [int]$parts[1] -ge 16 -and [int]$parts[1] -le 31)
    if ($isPrivate) {
        Write-Output ("  http://{0}:{1}" -f $ip, $Port)
    }
}
