﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set "NL_PIPER_CORE=%~dp0setup_mana_piper_core.bat"
set "NL_PIPER_LOG=%~dp0logs\piper_setup.log"
set "NL_PIPER_NO_PAUSE=1"
if not exist "%NL_PIPER_CORE%" (
  echo ERROR: Missing setup_mana_piper_core.bat
  pause
  exit /b 1
)
echo ============================================================
echo Network Learning - Piper setup (output is saved to a log)
echo Log: %NL_PIPER_LOG%
echo ============================================================
echo Setup output will be saved; it may take a few minutes.
call "%NL_PIPER_CORE%" > "%NL_PIPER_LOG%" 2>&1
set "PIPER_RC=%ERRORLEVEL%"
echo.
echo Piper setup exit code: %PIPER_RC%
echo Log saved at: %NL_PIPER_LOG%
if exist "%NL_PIPER_LOG%" type "%NL_PIPER_LOG%"
if not "%PIPER_RC%"=="0" echo Run debug_logs_windows.bat to include a redacted copy of this log.
echo.
pause
exit /b %PIPER_RC%
