from __future__ import annotations
"""Launch the LAN service using the persistent network settings saved in SQLite.

Environment variables NL_HOST and NL_PORT intentionally override the saved values,
which is useful for temporary diagnostics and automated tests.
"""
import argparse
import logging
from logging.handlers import RotatingFileHandler
import os
import sqlite3
from pathlib import Path

BASE = Path(__file__).resolve().parent
# Make app imports deterministic even when using CPython's isolated embeddable runtime.
import sys
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))
DB = BASE / 'data' / 'network_learning.db'
DEFAULT_HOST = '0.0.0.0'
DEFAULT_PORT = 82


def saved_config() -> tuple[str, int]:
    host, port = DEFAULT_HOST, DEFAULT_PORT
    if DB.is_file():
        try:
            conn = sqlite3.connect(f'file:{DB.as_posix()}?mode=ro', uri=True, timeout=3)
            rows = dict(conn.execute("SELECT key,value FROM settings WHERE key IN ('net_bind_host','net_port')").fetchall())
            conn.close()
            host = str(rows.get('net_bind_host') or host)
            port = int(rows.get('net_port') or port)
        except Exception:
            pass
    if os.environ.get('NL_HOST'):
        host = os.environ['NL_HOST'].strip()
    if os.environ.get('NL_PORT'):
        try:
            port = int(os.environ['NL_PORT'])
        except ValueError as exc:
            raise SystemExit('NL_PORT باید عدد صحیح باشد.') from exc
    if not 1 <= port <= 65535:
        raise SystemExit('پورت باید بین 1 تا 65535 باشد.')
    if not host:
        raise SystemExit('Bind host نمی‌تواند خالی باشد.')
    return host, port



def configure_file_logging() -> None:
    """Write the development server output to logs/server.log and the console.

    Rotation keeps a few small logs. Diagnostics tooling redacts these before
    packaging and never includes the SQLite database or imported learning content.
    """
    log_dir = BASE / 'logs'
    log_dir.mkdir(parents=True, exist_ok=True)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s')
    file_handler = RotatingFileHandler(log_dir / 'server.log', maxBytes=2_000_000, backupCount=4, encoding='utf-8')
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logging.basicConfig(level=logging.INFO, handlers=[console_handler, file_handler], force=True)
    for name in ('uvicorn', 'uvicorn.error', 'uvicorn.access', 'fastapi'):
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        logger.propagate = True
        logger.handlers.clear()

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--print-port', action='store_true', help='print effective port and exit')
    parser.add_argument('--print-host', action='store_true', help='print effective bind host and exit')
    args = parser.parse_args()
    host, port = saved_config()
    if args.print_port:
        print(port)
        return
    if args.print_host:
        print(host)
        return
    configure_file_logging()
    import uvicorn
    print(f'Network Learning: http://127.0.0.1:{port}  (bind={host}:{port})')
    logging.getLogger(__name__).info('Starting Network Learning %s; project=%s; bind=%s:%s', (BASE / 'VERSION.txt').read_text(encoding='utf-8').strip(), BASE, host, port)
    uvicorn.run('app:app', host=host, port=port, reload=False, proxy_headers=False, server_header=False, log_config=None)


if __name__ == '__main__':
    main()
