"""Build portable AI authoring kits with importable examples and bilingual visual briefs."""
from __future__ import annotations
import hashlib, json, re, zipfile
from io import BytesIO
from pathlib import Path
from typing import Any

PACK_FORMAT = 'network-learning-content-pack-v2'


def _base_meta(topic: str, difficulty: str = 'beginner') -> dict[str, Any]:
    return {'requires_human_review': True, 'sample_only': True, 'difficulty': difficulty,
            'topic': topic, 'references': [], 'tags': ['sample-only', 'authoring-template']}


def make_sample_pack(topic_id: str, topic_title: str, chapter_title: str, chapter_id: str = 'c01') -> dict:
    cid = chapter_id if re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}', chapter_id or '') else 'sample-' + hashlib.sha256((topic_id + '|' + chapter_title).encode('utf-8')).hexdigest()[:12]
    source = 'AI_Authoring_Kit_SAMPLE'
    items = [
        {'chapter_id': cid, 'kind': 'lesson', 'title': f'مقدمهٔ فصل — {chapter_title}',
         'summary': 'نمونهٔ ساختار مقدمه؛ متن داخل کروشه باید با موضوع مستند جایگزین شود.',
         'content': '# مقدمهٔ فصل\n\n## تعریف دقیق\n[تعریف مستند موضوع]\n\n## اهمیت و کاربرد\n[مسئلهٔ واقعی و مرز استفاده]\n\n## پیش‌نیازها و اهداف قابل سنجش\n[اهداف مبتدی تا خبره و معیار تسلط]\n\n## نقشهٔ فصل و منابع\n[ترتیب درس‌ها و منابع رسمیِ بررسی‌شده]',
         'source_status': 'review_required', 'source_file': source, 'source_uid': f'{cid}-intro-sample-v1',
         'metadata': {**_base_meta(topic_title), 'record_type': 'chapter_introduction', 'sequence_number': 0,
                      'definition': '[تعریف دقیق]', 'why_it_matters': '[اهمیت]', 'when_to_use': '[شرایط استفاده]',
                      'when_not_to_use': '[محدودیت]', 'prerequisites': [], 'learning_objectives': [], 'references': []}},
        {'chapter_id': cid, 'kind': 'lesson', 'title': 'درس 01 — [عنوان مشخص و قابل ارزیابی]',
         'summary': 'هدف یادگیری را در یک یا دو جمله توضیح بده.',
         'content': '# درس 01 — [عنوان]\n\n## هدف و تعریف عملیاتی\n[تعریف دقیق]\n\n## سازوکار مرحله‌ای\n1. [مرحلهٔ اول و دلیل]\n2. [مرحلهٔ دوم و دلیل]\n\n## مثال حل‌شده و حالت مرزی\n[ورودی، فرض‌ها، مراحل، خروجی مورد انتظار و محدودیت]\n\n## خطاهای رایج و راستی‌آزمایی\n[دلیل خطا و شواهد تأیید]\n\n## تمرین و معیار تسلط\n[تمرین مستقل و معیار پذیرش]',
         'source_status': 'review_required', 'source_file': source, 'source_uid': f'{cid}-lesson-01-sample-v1',
         'metadata': {**_base_meta(topic_title, 'intermediate'), 'record_type': 'book_lesson', 'sequence_number': 1,
                      'estimated_minutes': 25, 'prerequisites': [], 'learning_objectives': ['[هدف قابل سنجش]'],
                      'common_mistakes': ['[خطای رایج]'], 'acceptance_criteria': ['[معیار پذیرش]']}},
        {'chapter_id': cid, 'kind': 'flashcard', 'title': 'کارت 0001 — [پرسش دقیق]',
         'summary': '[پاسخ کوتاه به‌همراه دلیل یا مثال]', 'content': '[پاسخ دقیق]',
         'source_status': 'review_required', 'source_file': source, 'source_uid': f'{cid}-card-0001-sample-v1',
         'metadata': {**_base_meta(topic_title), 'record_type': 'flashcard', 'sequence_number': 1,
                      'front': '[یک پرسش روشن و مستقل]', 'back': '[پاسخ دقیق، دلیل یا مثال کوتاه، و قید مهم]',
                      'related_lessons': [f'{cid}-lesson-01-sample-v1']}},
        {'chapter_id': cid, 'kind': 'question', 'title': 'سؤال 0001 — [سؤال با پاسخ یکتا]',
         'summary': 'سؤال نمونه؛ گزینه‌ها و پاسخ کلید باید بررسی شوند.', 'content': '[صورت سؤال کامل]',
         'source_status': 'review_required', 'source_file': source, 'source_uid': f'{cid}-question-0001-sample-v1',
         'metadata': {**_base_meta(topic_title, 'intermediate'), 'record_type': 'assessment_question', 'sequence_number': 1,
                      'question': '[صورت سؤال کامل]', 'options': ['[گزینهٔ A]', '[گزینهٔ B]', '[گزینهٔ C]', '[گزینهٔ D]'],
                      'correct_index': 0, 'has_answer_key': True,
                      'explanation': '[استدلال پاسخ درست و علت نادرستی هر گزینه]',
                      'option_explanations': ['[چرایی گزینهٔ A]', '[چرایی گزینهٔ B]', '[چرایی گزینهٔ C]', '[چرایی گزینهٔ D]']}},
        {'chapter_id': cid, 'kind': 'note', 'title': 'نکته 0001 — [عنوان مستقل]',
         'summary': '[نکتهٔ مهندسی یا آموزشی]',
         'content': '## مفهوم\n[تعریف]\n\n## کاربرد و مثال\n[شرایط و نمونه]\n\n## محدودیت و معیار پذیرش\n[ضد‌مثال و آزمون]',
         'source_status': 'review_required', 'source_file': source, 'source_uid': f'{cid}-note-0001-sample-v1',
         'metadata': {**_base_meta(topic_title), 'record_type': 'note', 'sequence_number': 1,
                      'definition': '[تعریف]', 'when_to_use': '[کاربرد]', 'common_mistake': '[خطا]',
                      'acceptance_criteria': '[معیار]'}},
        {'chapter_id': cid, 'kind': 'example', 'title': 'مثال 001 — [مسئلهٔ عملی]',
         'summary': '[خلاصهٔ ورودی و مسئله]',
         'content': '## صورت مسئله\n[مسئله]\n\n## فرض‌ها و ورودی‌ها\n[داده‌ها]\n\n## گام‌های حل\n1. [گام اول و دلیل]\n2. [گام دوم و دلیل]\n\n## خروجی مورد انتظار و تفسیر\n[نتیجه، محدودیت و روش راستی‌آزمایی]',
         'source_status': 'review_required', 'source_file': source, 'source_uid': f'{cid}-example-001-sample-v1',
         'metadata': {**_base_meta(topic_title, 'intermediate'), 'record_type': 'worked_example', 'sequence_number': 1,
                      'problem': '[صورت مسئله]', 'input_data': '[ورودی‌های نمونه]',
                      'expected_result': '[خروجی مورد انتظار؛ اجرای واقعی ادعا نشود]',
                      'acceptance_criteria': ['[شرط موفقیت]']}},
    ]
    chapter = {'id': cid, 'title': chapter_title, 'order_num': 1, 'group_name': 'main',
               'description': 'نمونهٔ نمایشی برای مشخص‌کردن قالب؛ پیش از استفاده با محتوای مستند تکمیل شود.',
               'topic_id': topic_id}
    return {'format': PACK_FORMAT, 'version': 2, 'title': f'نمونهٔ قالب — {topic_title} — {chapter_title}',
            'chapter_id': cid, 'topic': {'id': topic_id, 'title': topic_title}, 'chapters': [chapter],
            'items': items, 'visual_assets_manifest_ref': 'visual_assets_manifest.json', 'sample_only': True,
            'notes': ['این فایل الگوی ساختاری است و متن‌های داخل [کروشه] placeholder هستند.',
                      'همهٔ رکوردها review_required هستند؛ واردسازی به‌معنای تأیید نیست.']}


def build_authoring_zip(topic: dict, spec: dict, prompt: str, chapter_title: str,
                        chapter_id: str = 'c01') -> bytes:
    pack = make_sample_pack(topic['id'], topic['title'], chapter_title, chapter_id)
    cid = pack['chapter_id']
    catalog = {'format': 'network-learning-chapter-catalog-v1', 'topic': topic,
               'chapters': [{'id': cid, 'title': chapter_title, 'order_num': 1, 'group_name': 'main',
                             'description': 'عنوان/شناسهٔ نمونه؛ با کاتالوگ واقعی تطبیق داده شود.'}],
               'notes': ['شناسه و عنوان فصل را با کاتالوگ واقعی تطبیق بده.', 'هر بار فقط یک فصل و یک batch بساز.']}
    visual = {'format': 'network-learning-visual-assets-manifest-v1', 'topic': topic, 'chapter_id': cid,
              'assets': [{'asset_uid': f'{cid}-visual-001', 'asset_type': 'infographic',
                          'title_fa': f'اینفوگرافیک آموزشی: {chapter_title}',
                          'title_en': f'Learning infographic: {chapter_title}',
                          'purpose_fa': 'یک مفهوم محوری فصل را با جریان تصویری قابل راستی‌آزمایی توضیح بده.',
                          'prompt_fa': f'یک اینفوگرافیک دقیق و خوانا دربارهٔ [مفهوم از فصل «{chapter_title}»] بساز. عنوان و توضیح اصلی فارسی و راست‌چین (RTL) باشد؛ برچسب‌های استاندارد فنی مثل DNS, TCP, Router, Firewall به انگلیسی و چپ‌به‌راست (LTR)، همراه معادل کوتاه فارسی در صورت نیاز. گام‌ها شماره داشته باشند، فلش‌ها جهت روشن، legend خوانا، کنتراست بالا، فونت فارسی خوانا، پس‌زمینهٔ روشن و فضای امن کافی. نسبت 16:9. متن جعلی، دادهٔ ساختگی، لوگوی جعلی و ادعای پشتیبانی‌نشده نساز. اگر رندر فارسی قابل اتکا نیست، جای برچسب خالی بگذار و متن دقیق را جدا تحویل بده.',
                          'prompt_en': f'Create a technically accurate, clean educational infographic about [a concept from “{chapter_title}”]. Use a bilingual Persian-English visual system: Persian RTL title and concise Persian explanations; English LTR technical labels such as DNS, TCP, Router, and Firewall, with short Persian equivalents where useful. Use numbered steps, directional arrows, a clear legend, high contrast, legible Persian typography, a light background, generous safe margins, and a 16:9 aspect ratio. Do not invent labels, data, logos, or unsupported mechanisms. If Persian text rendering is unreliable, leave clean label placeholders and deliver the exact overlay text separately.',
                          'labels_fa': ['[برچسب فارسی ۱]', '[برچسب فارسی ۲]'],
                          'labels_en': ['[English label 1]', '[English label 2]'],
                          'layout': 'Persian RTL reading path; English technical labels remain LTR; numbered flow with arrows and legend',
                          'aspect_ratio': '16:9',
                          'style': 'clean technical editorial infographic, flat vector shapes, restrained colors, readable line icons, accessible contrast',
                          'alt_text': '[توضیح فارسی کوتاه و دقیق دربارهٔ آنچه تصویر واقعاً نمایش می‌دهد]',
                          'negative_prompt': 'garbled Persian, misspelled English, fake data, fake logos, ambiguous arrows, tiny text, watermark, clutter, unsupported technical claims',
                          'output_status': 'prompt_only_not_generated'}]}
    schema = {
        '$schema': 'https://json-schema.org/draft/2020-12/schema',
        'title': 'Network Learning Content Pack v2',
        'type': 'object',
        'required': ['format', 'version', 'title', 'chapters', 'items'],
        'properties': {
            'format': {'const': PACK_FORMAT}, 'version': {'const': 2},
            'title': {'type': 'string', 'minLength': 1}, 'chapter_id': {'type': 'string'},
            'topic': {'type': 'object', 'required': ['id', 'title'], 'properties': {'id': {'type': 'string'}, 'title': {'type': 'string'}}},
            'sample_only': {'type': 'boolean'},
            'chapters': {'type': 'array', 'minItems': 1, 'items': {'type': 'object',
                'required': ['id', 'title', 'order_num'], 'properties': {
                    'id': {'type': 'string', 'minLength': 1}, 'title': {'type': 'string', 'minLength': 1},
                    'order_num': {'type': 'integer'}, 'group_name': {'type': 'string'},
                    'description': {'type': 'string'}, 'topic_id': {'type': 'string'}}}},
            'items': {'type': 'array', 'items': {'type': 'object',
                'required': ['chapter_id', 'kind', 'title', 'summary', 'content', 'source_status', 'source_file', 'source_uid', 'metadata'],
                'properties': {
                    'chapter_id': {'type': 'string', 'minLength': 1},
                    'kind': {'enum': ['lesson', 'flashcard', 'question', 'command', 'lab', 'example', 'note', 'asset']},
                    'title': {'type': 'string', 'minLength': 1}, 'summary': {'type': 'string'}, 'content': {'type': 'string'},
                    'source_status': {'const': 'review_required'}, 'source_file': {'type': 'string'},
                    'source_uid': {'type': 'string', 'minLength': 1}, 'metadata': {'type': 'object'}},
                'allOf': [
                    {'if': {'properties': {'kind': {'const': 'question'}}, 'required': ['kind']}, 'then': {'properties': {'metadata': {'required': ['options', 'correct_index', 'explanation'], 'properties': {'options': {'type': 'array', 'minItems': 2, 'items': {'type': 'string'}}, 'correct_index': {'type': 'integer', 'minimum': 0}, 'explanation': {'type': 'string'}}}}}},
                    {'if': {'properties': {'kind': {'const': 'flashcard'}}, 'required': ['kind']}, 'then': {'properties': {'metadata': {'required': ['front', 'back'], 'properties': {'front': {'type': 'string', 'minLength': 1}, 'back': {'type': 'string', 'minLength': 1}}}}}}
                ]}}
        }
    }
    visual_md = '''# راهنمای prompt تصویر و اینفوگرافیک دو‌زبانه

برای هر تصویر این فیلدها را تحویل بده: `prompt_fa`, `prompt_en`, `labels_fa`, `labels_en`, `layout`, `aspect_ratio`, `style`, `alt_text`, `negative_prompt`. دو prompt باید از نظر معنا معادل باشند.

- توضیح/عنوان اصلی فارسی RTL؛ برچسب استاندارد فنی مانند DNS، DHCP، VLAN، TCP، Router و Firewall انگلیسی LTR باقی بماند.
- دیاگرام معماری یا جریان: 16:9؛ کارت/پوستر عمودی: 4:5 یا 3:4.
- عنوان کوتاه، کنتراست بالا، فونت فارسی خوانا، فلش‌های بدون ابهام، legend و فضای امن برای برچسب‌ها.
- اگر مدل تولید تصویر، فارسی را دقیق رندر نمی‌کند، برچسب خالی تحویل بده و متن دقیق را جدا ارائه کن؛ متن درهم‌ریخته را درست معرفی نکن.
- منابع/اعداد باید با محتوای درس سازگار باشند. لوگوی ساختگی، watermark، IP حساس یا خروجی اجرانشده را نساز.
- `output_status=prompt_only_not_generated` یعنی فقط prompt تولید شده و تصویر واقعی هنوز ساخته نشده است.
'''
    qa = '''# قالب گزارش اعتبارسنجی

- Batch / فایل: [نام]
- موضوع و فصل: [شناسه و عنوان]
- شمارش رکوردها به تفکیک نوع و سطح: [گزارش]
- JSON parse و UTF-8: [PASS/FAIL]
- فرمت و فیلدهای لازم: [PASS/FAIL]
- UID تکراری / محتوای مشابه: [عدد و فهرست]
- سؤال‌ها: چهار گزینه، کلید صفرمبنا و توضیح گزینه‌به‌گزینه: [PASS/FAIL]
- پیوندهای درس، فصل و کارت: [PASS/FAIL]
- منابع نیازمند تأیید: [فهرست]
- prompt تصویر فارسی/انگلیسی، برچسب‌ها، alt text و وضعیت تصویر: [گزارش]
- موارد نیازمند بررسی انسانی: [فهرست]
- وضعیت تأیید نهایی: فقط بررسی‌کنندهٔ انسانی تعیین کند؛ خودکار verified نکن.
'''
    readme = '''# راهنمای بستهٔ تولید محتوای دانشنامه

## فایل‌ها
- `PROMPT_MASTER.md`: دستور اجرایی اختصاصی این درخواست.
- `PROMPT_MASTER_REFERENCE_FA.md`: پرامپت مادر مرجع پیوست‌شده به پروژه.
- `prompt_spec.json`: تنظیمات همین درخواست.
- `content_pack.json`: نمونهٔ کوچک و قابل پیش‌نمایش سازگار با Import برنامه.
- `content_readable.md`: نمایش انسانی همان نمونهٔ JSON.
- `chapter_catalog.json`: نمونهٔ کاتالوگ فصل.
- `content_pack.schema.json`: قرارداد ساختاری دقیق‌تر برای فیلدهای ضروری.
- `sample_32_chapters_reference.json`: نمونهٔ مرجع ۳۲ فصل؛ فقط برای بررسی ساختار و نه برای واردسازی کامل این بسته.
- `visual_assets_manifest.json`: نمونهٔ prompt دوزبانهٔ تصویر/اینفوگرافیک.
- `visual_prompts_fa_en.md`: راهنمای طراحی بصری و متن دوزبانه.
- `validation_report.md`: گزارش بررسی ساختاری همین نمونه.
- `validation_report_TEMPLATE.md`: قالب گزارش برای batchهای بعدی.
- `manifest.json`: اندازه و SHA-256 فایل‌های ZIP برای کشف خرابی یا تغییر.

## گردش کار
1. در هر درخواست، یک فصل و batch کوچک انتخاب کن.
2. شناسه‌ها و عنوان‌های نمونه را با کاتالوگ واقعی تطبیق بده؛ آن‌ها را کورکورانه کپی نکن.
3. `content_pack.json` این بسته فقط نمونهٔ ساختاری با placeholder است؛ آن را مستقیم به بانک محتوای اصلی وارد نکن. پس از جایگزینی placeholderها با محتوای واقعی و اعتبارسنجی، فایل JSON نهایی تولیدشده توسط مدل را در بخش «واردکردن محتوا» Preview و سپس Import کن.
4. تمام محتوای هوش مصنوعی باید `review_required` بماند تا انسان بررسی کند.
5. `prompt_fa` و `prompt_en` متن‌های متناظر یک تصویرند؛ تولید prompt به معنی ایجاد خود تصویر نیست.

## هشدار
فایل نمونه شامل placeholderهایی مثل `[تعریف دقیق]` است و محتوای آموزشی کامل یا تأییدشده نیست.
'''
    prompt_en = 'Generate one chapter and one small batch. Deliver actual files with the exact names listed in README_IMPORT_FA.md. The importable JSON must use network-learning-content-pack-v2, stable source_uid values, and source_status=review_required. Questions require options, zero-based correct_index and option-by-option explanations. For each visual supply equivalent prompt_fa/prompt_en, labels_fa/labels_en, RTL/LTR layout, aspect_ratio, alt_text and negative_prompt. Report prompt_only_not_generated if the actual image was not generated. Validate JSON, IDs, answer keys, chapter references and human-review items.\n\nREQUEST SPEC:\n' + json.dumps(spec, ensure_ascii=False, indent=2)
    readable_lines = [f"# نمونهٔ قابل‌خواندن — {topic['title']}", '',
                      '> این یک نمونهٔ ساختاری است؛ placeholderها را با محتوای مستند جایگزین کن.',
                      f"- قالب: `{PACK_FORMAT}`", f"- موضوع: {topic['title']} (`{topic['id']}`)",
                      f"- فصل نمونه: {chapter_title} (`{cid}`)", f"- تعداد رکوردها: {len(pack['items'])}", '']
    for item in pack['items']:
        readable_lines += [f"## {item['title']}", '', f"**نوع:** `{item['kind']}`  ·  **UID:** `{item['source_uid']}`  ·  **وضعیت:** `{item['source_status']}`", '',
                           f"**خلاصه:** {item.get('summary') or '—'}", '', item.get('content') or '', '',
                           '**Metadata**', '', '```json', json.dumps(item.get('metadata') or {}, ensure_ascii=False, indent=2), '```', '']
    pack_json = json.dumps(pack, ensure_ascii=False, indent=2)
    json.loads(pack_json)  # Confirm the exact importable JSON can be parsed before packaging.
    question_items = [x for x in pack['items'] if x.get('kind') == 'question']
    duplicate_uids = len([x for x in pack['items'] if x.get('source_uid')]) - len(set(x.get('source_uid') for x in pack['items'] if x.get('source_uid')))
    valid_questions = all(isinstance(x.get('metadata', {}).get('options'), list) and len(x['metadata']['options']) >= 2 and isinstance(x.get('metadata', {}).get('correct_index'), int) and 0 <= x['metadata']['correct_index'] < len(x['metadata']['options']) and bool(x.get('metadata', {}).get('explanation')) for x in question_items)
    all_pending = all(x.get('source_status') == 'review_required' for x in pack['items'])
    validation_report = f'''# گزارش اعتبارسنجی نمونهٔ بستهٔ AI\n\n- قالب: `{PACK_FORMAT}`\n- موضوع: {topic['title']} (`{topic['id']}`)\n- فصل: {chapter_title} (`{cid}`)\n- تعداد رکورد نمونه: {len(pack['items'])}\n- JSON قابل parse و UTF-8: PASS (ساخته و مجدداً parse شده است)\n- شناسه‌های منبع تکراری داخل نمونه: {duplicate_uids}\n- سؤال‌های نمونه: {'PASS' if valid_questions else 'FAIL'}؛ گزینه‌ها و شاخص صفرمبنا بررسی ساختاری شده‌اند، نه صحت علمی پاسخ.\n- وضعیت تمام رکوردها: {'PASS' if all_pending else 'FAIL'}؛ همه `review_required` هستند.\n- پیوند فصل: {'PASS' if all(str(x.get('chapter_id')) == cid for x in pack['items']) else 'FAIL'}\n- پرامپت تصویری فارسی/انگلیسی: موجود؛ وضعیت تصویر واقعی `prompt_only_not_generated` است.\n- موارد نیازمند بررسی انسانی: placeholderهای براکت‌دار، منابع واقعی، ادعاهای تخصصی، پاسخ علمی سؤال، محتوای بصری و تطبیق عنوان/شناسه با کاتالوگ واقعی.\n- وضعیت تأیید علمی: بررسی نشده؛ هیچ رکوردی خودکار تأیید نشده است.\n'''
    root = Path(__file__).resolve().parent
    kit_dir = root / 'Chapter_Authoring_Kit'
    prompt_reference = kit_dir / 'PROMPT_MASTER_All_Chapters_v1_FA.md'
    sample_reference = kit_dir / 'Sample_Import_All_Chapters_01_32_v1_FA.json'
    files = {
        'PROMPT_MASTER.md': prompt,
        'PROMPT_MASTER_REFERENCE_FA.md': prompt_reference.read_text(encoding='utf-8') if prompt_reference.exists() else '# پرامپت مرجع در این نصب موجود نیست.',
        'sample_32_chapters_reference.json': sample_reference.read_text(encoding='utf-8') if sample_reference.exists() else json.dumps({'warning':'مرجع نمونهٔ ۳۲ فصل در این نصب موجود نیست.'}, ensure_ascii=False, indent=2),
        'content_readable.md': '\n'.join(readable_lines),
        'prompt_spec.json': json.dumps(spec, ensure_ascii=False, indent=2),
        'content_pack.json': pack_json,
        'chapter_catalog.json': json.dumps(catalog, ensure_ascii=False, indent=2),
        'content_pack.schema.json': json.dumps(schema, ensure_ascii=False, indent=2),
        'visual_assets_manifest.json': json.dumps(visual, ensure_ascii=False, indent=2),
        'visual_prompts_fa_en.md': visual_md,
        'validation_report.md': validation_report,
        'validation_report_TEMPLATE.md': qa,
        'README_IMPORT_FA.md': readme,
        'PROMPT_MASTER_EN_BRIEF.txt': prompt_en,
    }
    out = BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        manifest = {'format': 'network-learning-ai-authoring-kit-v1', 'topic': topic, 'files': []}
        for name, content in files.items():
            raw = content.encode('utf-8')
            zf.writestr(name, raw)
            manifest['files'].append({'path': name, 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        zf.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    return out.getvalue()
