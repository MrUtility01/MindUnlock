package com.mindunlock.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mindunlock.app.data.repository.SyncRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectScreen(
    repository: SyncRepository,
    onSynced: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var host by remember { mutableStateOf("192.168.1.") }
    var port by remember { mutableStateOf("82") }
    var status by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }

    // Load last config
    LaunchedEffect(Unit) {
        repository.getServerConfig()?.let {
            host = it.host
            port = it.port.toString()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        Icon(
            Icons.Default.Wifi,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "MindUnlock",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            "همگام‌سازی با نسخه ویندوز",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(32.dp))

        OutlinedTextField(
            value = host,
            onValueChange = { host = it },
            label = { Text("آدرس IP سرور ویندوز") },
            placeholder = { Text("192.168.1.10") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Link, null) }
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = port,
            onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
            label = { Text("پورت") },
            placeholder = { Text("82") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                scope.launch {
                    isLoading = true
                    status = ""
                    progressText = ""
                    val p = port.toIntOrNull() ?: 82
                    val test = repository.testConnection(host, p)
                    if (test.isSuccess) {
                        status = test.getOrNull() ?: "متصل شد"
                        // full sync
                        val result = repository.syncAllChapters(host, p) { cur, total, title ->
                            progressText = "($cur/$total) $title"
                        }
                        if (result.isSuccess) {
                            status = "همگام‌سازی موفق — ${result.getOrNull()} فصل ذخیره شد"
                            onSynced()
                        } else {
                            status = "خطا در همگام‌سازی: ${result.exceptionOrNull()?.message}"
                        }
                    } else {
                        status = "خطا در اتصال: ${test.exceptionOrNull()?.message}"
                    }
                    isLoading = false
                }
            },
            enabled = !isLoading && host.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(10.dp))
                Text("در حال همگام‌سازی…")
            } else {
                Icon(Icons.Default.CloudDownload, null)
                Spacer(Modifier.width(8.dp))
                Text("اتصال و دریافت همه فصل‌ها")
            }
        }

        if (progressText.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                progressText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    status,
                    modifier = Modifier.padding(14.dp),
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(Modifier.height(28.dp))
        Text(
            "نکته: گوشی و کامپیوتر باید روی یک شبکه Wi-Fi باشند.\nدر ویندوز برنامه را اجرا کنید (پورت پیش‌فرض ۸۲).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}
