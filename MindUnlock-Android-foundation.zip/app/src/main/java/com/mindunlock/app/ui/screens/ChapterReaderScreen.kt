package com.mindunlock.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mindunlock.app.data.local.ContentItemEntity
import com.mindunlock.app.data.repository.SyncRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterReaderScreen(
    chapterId: String,
    repository: SyncRepository,
    onBack: () -> Unit
) {
    var title by remember { mutableStateOf("فصل") }
    val items by repository.observeItems(chapterId).collectAsState(initial = emptyList())

    LaunchedEffect(chapterId) {
        repository.getChapter(chapterId)?.let { title = it.title }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        }
    ) { padding ->
        if (items.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp)
            ) {
                Text(
                    "محتوایی برای این فصل یافت نشد.\nدوباره همگام‌سازی کنید.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items, key = { it.uid }) { item ->
                    ContentItemCard(item)
                }
            }
        }
    }
}

@Composable
private fun ContentItemCard(item: ContentItemEntity) {
    val typeLabel = when (item.type?.lowercase()) {
        "lesson", "study" -> "درس"
        "note", "tip" -> "نکته"
        "question" -> "سؤال"
        "quiz", "exam" -> "آزمون"
        "lab", "laboratory" -> "آزمایشگاه"
        "flashcard" -> "فلش‌کارت"
        else -> item.type ?: "محتوا"
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            AssistChip(
                onClick = {},
                label = { Text(typeLabel) }
            )
            Spacer(Modifier.height(8.dp))
            if (!item.title.isNullOrBlank()) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
            }
            if (!item.content.isNullOrBlank()) {
                Text(
                    text = item.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            if (!item.answer.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "پاسخ: ${item.answer}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (!item.explanation.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = item.explanation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
