# MindUnlock — Android (Native Kotlin + Compose)

نسخه موبایل آفلاین برنامه **دانشنامه جامع یادگیری** (Network Learning).

## هدف این نسخه (0.1.0-foundation)

- اتصال به سرور ویندوز از طریق IP و پورت (پیش‌فرض ۸۲)
- دریافت Manifest و دانلود فصل‌ها طبق `ANDROID_SYNC_PROTOCOL_FA.md`
- ذخیره محلی با Room (آفلاین کامل پس از همگام‌سازی)
- نمایش لیست فصل‌ها و خواندن محتوای درس / نکته / سؤال / آزمون و ...
- **بدون** قابلیت تولید محتوا، پرامپت یا ساخت موضوع/فصل

## نیازمندی‌ها

- Android Studio Ladybug یا جدیدتر
- JDK 17
- حداقل Android 8.0 (API 26) — هدف‌گذاری‌شده برای Android 15 (API 35)
- گوشی و کامپیوتر روی یک شبکه Wi-Fi

## ساخت و نصب

```bash
# در ریشه پوشه android
./gradlew assembleDebug
# APK در:
# app/build/outputs/apk/debug/app-debug.apk
```

یا در Android Studio: Open → پوشه `android` → Run.

## نحوه استفاده

1. برنامه ویندوز را اجرا کنید (`run_windows.bat`) — پورت پیش‌فرض ۸۲.
2. IP کامپیوتر را در شبکه محلی پیدا کنید.
3. در اپ MindUnlock دکمه همگام‌سازی را بزنید، IP و پورت را وارد کنید.
4. پس از اتمام دانلود، فصل‌ها آفلاین در دسترس هستند.

## ساختار

```
android/
├── app/src/main/java/com/mindunlock/app/
│   ├── data/
│   │   ├── local/          # Room entities + DAOs
│   │   ├── model/          # Sync JSON models
│   │   ├── remote/         # Retrofit Sync API
│   │   └── repository/     # SyncRepository
│   ├── ui/
│   │   ├── screens/        # Connect, ChapterList, Reader
│   │   └── theme/
│   ├── MainActivity.kt
│   └── MindUnlockApp.kt
└── ...
```

## مراحل بعدی (پیشنهادی)

- [ ] دانلود و اعتبارسنجی فایل‌های رسانه (SHA-256)
- [ ] آزمون تعاملی و ثبت پیشرفت
- [ ] پخش صوتی (TTS یا فایل‌های صوتی همگام‌شده)
- [ ] یادداشت و نشانک محلی
- [ ] تم‌های مطالعه و تنظیمات تایپوگرافی
- [ ] همگام‌سازی دوطرفه پیشرفت (طبق بخش ۵ پروتکل)

## مجوز

همان مجوز پروژه اصلی Network Learning.
